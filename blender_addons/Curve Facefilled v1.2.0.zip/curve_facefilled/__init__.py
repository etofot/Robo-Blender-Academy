# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Curve Facefilled",
    "author" : "Vovrzull and Vpgshka", 
    "description" : "Allows you to fill complex shapes from curves and mesh lines with a face, editable in real time",
    "blender" : (3, 6, 0),
    "version" : (1, 2, 0),
    "location" : "N-panel and RMB Facefilled",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import math
import os
from bpy.app.handlers import persistent




def string_to_int(value):
    if value.isdigit():
        return int(value)
    return 0


def string_to_icon(value):
    if value in bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys():
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items[value].value
    return string_to_int(value)


addon_keymaps = {}
_icons = None
fill_curve_addon = {'sna_save_list_select': [], 'sna_collection_fill_curve': '', 'sna_save_select_facedilled_panel': False, 'sna_save_collection_fill_curve': None, 'sna_save_activ_object': None, }
orientation_filled1 = {'sna_angle_rotate_orogin': 0.0, 'sna_object_matematic': None, 'sna_save_object_activ': None, }
orienteshen_filled = {'sna_save_activ_object': None, 'sna_save_object_orient': None, 'sna_save_facefillet': None, 'sna_last_collection_save': None, 'sna_save_object_matematic': None, 'sna_save_object_norotate': None, 'sna_anglerotateorigin': 0.0, 'sna_delete_save_boolean': False, 'sna_save_activ_for_selection': None, 'sna_collection_scene_save': [], }


def sna_update_sna_bezierpoly_E7EB2(self, context):
    sna_updated_prop = self.sna_bezierpoly
    gn_set(bpy.context.view_layer.objects.active.modifiers['Curve Bevel'], 'Input_2', sna_updated_prop)
    bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )


def sna_import_geonode_3E625_493D9(Name_Geonode, Path):
    if property_exists("bpy.data.node_groups[Name_Geonode].name", globals(), locals()):
        pass
    else:
        before_data = list(bpy.data.node_groups)
        bpy.ops.wm.append(directory=Path + r'\NodeTree', filename=Name_Geonode, link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
        appended_A20E2 = None if not new_data else new_data[0]
    if property_exists("bpy.context.view_layer.objects.active.modifiers[Name_Geonode]", globals(), locals()):
        pass
    else:
        modifier_1FED0 = bpy.context.view_layer.objects.active.modifiers.new(name=Name_Geonode, type='NODES', )
        modifier_1FED0.node_group = bpy.data.node_groups[Name_Geonode]


def sna_import_geonode_3E625_D579C(Name_Geonode, Path):
    if property_exists("bpy.data.node_groups[Name_Geonode].name", globals(), locals()):
        pass
    else:
        before_data = list(bpy.data.node_groups)
        bpy.ops.wm.append(directory=Path + r'\NodeTree', filename=Name_Geonode, link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
        appended_A20E2 = None if not new_data else new_data[0]
    if property_exists("bpy.context.view_layer.objects.active.modifiers[Name_Geonode]", globals(), locals()):
        pass
    else:
        modifier_1FED0 = bpy.context.view_layer.objects.active.modifiers.new(name=Name_Geonode, type='NODES', )
        modifier_1FED0.node_group = bpy.data.node_groups[Name_Geonode]


def sna_update_sna_subdive_level_2BE20(self, context):
    sna_updated_prop = self.sna_subdive_level
    gn_set(bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'], 'Input_7', sna_updated_prop)
    bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )


def sna_update_sna_grid_visual_B1ABC(self, context):
    sna_updated_prop = self.sna_grid_visual
    gn_set(bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'], 'Input_6', (1 if sna_updated_prop else 0))
    bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )


def sna_true_deselect__all_C6336_64369():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_true_deselect__all_C6336_385E4():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_05FC7(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_select__set_active_object_07AE7_302F5(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_active_scene_collection_2B61F_97EE9():
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


def sna_new_collection_and_active_32E38_7E530(Collection_Name, Active_Scene_collection):
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection
    if property_exists("bpy.data.collections[Collection_Name]", globals(), locals()):
        if bpy.context.view_layer.layer_collection.children[Collection_Name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[Collection_Name]
    else:
        collection_04D18 = bpy.data.collections.new(name=Collection_Name, )
        bpy.context.collection.children.link(child=collection_04D18, )
        if bpy.context.view_layer.layer_collection.children[collection_04D18.name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[collection_04D18.name]
    if Active_Scene_collection:
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


def sna_select__set_active_object_07AE7_6C52B(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


movetocollection_s3_vars_CA3F2 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_CA3F2(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


def sna_update_sna_flip_normal_9364C(self, context):
    sna_updated_prop = self.sna_flip_normal
    gn_set(bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'], 'Input_5', (1 if sna_updated_prop else 0))
    bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )


def sna_active_scene_collection_2B61F_159AB():
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


def sna_update_sna_loop_curve_B8D26(self, context):
    sna_updated_prop = self.sna_loop_curve
    bpy.data.curves[bpy.context.view_layer.objects.active.name].resolution_u = sna_updated_prop
    bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )


def sna_select__set_active_object_07AE7_027A8(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_select__set_active_object_07AE7_6D8B4(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_ursor_to_object001_0F7D9_3AF70(Object):
    bpy.data.scenes['Scene'].cursor.location = Object.location
    bpy.data.scenes['Scene'].cursor.rotation_euler = Object.rotation_euler


def sna_true_deselect__all_C6336_EC694():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_object_to_cursor001_31671_C5F03(Object):
    Object.location = bpy.data.scenes['Scene'].cursor.location
    Object.rotation_euler = bpy.data.scenes['Scene'].cursor.rotation_euler


def sna_true_deselect__all_C6336_A0868():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_85BF3(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_cursor_to_world_02FD0_0BF78():
    bpy.ops.view3d.snap_cursor_to_center()


def sna_select__set_active_object_07AE7_32E89(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_ursor_to_object001_0F7D9_B05A4(Object):
    bpy.data.scenes['Scene'].cursor.location = Object.location
    bpy.data.scenes['Scene'].cursor.rotation_euler = Object.rotation_euler


def sna_cursor_to_world_02FD0_ACB09():
    bpy.ops.view3d.snap_cursor_to_center()


def sna_true_deselect__all_C6336_EFBC7():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_88395(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


movetocollection_s3_vars_F4130 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_F4130(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


# ---------------------------------------------------------------------------
# Blender 5.2 compatibility layer for Geometry Nodes modifier sockets.
#
# Up to Blender 5.1 the values exposed by a Geometry Nodes modifier were stored
# as plain IDProperties, so they were read and written like a dictionary:
#       modifier["Input_3"] = value
#       layout.prop(modifier, '["Input_3"]')
# Blender 5.2 turned them into real RNA properties:
#       modifier.properties.inputs.Input_3.value = value
#       layout.prop(modifier.properties.inputs.Input_3, 'value')
# and the old dictionary access now raises KeyError.  The helpers below use
# whichever API the running Blender version provides, so the add-on keeps
# working on 3.6 - 5.1 as well as on 5.2 and newer.
# ---------------------------------------------------------------------------

def _gn_socket(Modifier, Key):
    """Return the RNA socket object for Key (Blender 5.2+), or None."""
    properties = getattr(Modifier, 'properties', None)
    if properties is None:
        return None
    inputs = getattr(properties, 'inputs', None)
    if inputs is None:
        return None
    return getattr(inputs, str(Key), None)


def gn_get(Modifier, Key, Default=None):
    """Read a Geometry Nodes modifier socket value."""
    socket = _gn_socket(Modifier, Key)
    if socket is not None:
        try:
            return socket.value
        except Exception:
            return Default
    try:
        return Modifier[Key]
    except Exception:
        return Default


def gn_set(Modifier, Key, Value):
    """Write a Geometry Nodes modifier socket value."""
    socket = _gn_socket(Modifier, Key)
    if socket is not None:
        try:
            socket.value = Value
            return True
        except Exception:
            return False
    try:
        Modifier[Key] = Value
        return True
    except Exception:
        return False


def gn_prop(Layout, Modifier, Key, **Keywords):
    """Draw a Geometry Nodes modifier socket as a UI widget."""
    socket = _gn_socket(Modifier, Key)
    if socket is not None:
        try:
            Layout.prop(socket, 'value', **Keywords)
            return
        except Exception:
            return
    try:
        Layout.prop(Modifier, '["' + str(Key) + '"]', **Keywords)
    except Exception:
        pass


def modifier_get(Object, Name):
    """Return Object.modifiers[Name] or None, without raising."""
    if Object is None:
        return None
    try:
        return Object.modifiers.get(Name)
    except Exception:
        return None



def sna_fnlinkunlink_41AEA(CollectionName):
    movetocollection_s3_vars_F4130['sna_objectstomove'] = []
    for i_5B107 in range(len(bpy.context.view_layer.objects.selected)):
        movetocollection_s3_vars_F4130['sna_objectstomove'].append(bpy.context.view_layer.objects.selected[i_5B107])
    for i_18D5A in range(len(bpy.context.view_layer.objects.selected)):
        for i_BE9A3 in range(len(bpy.context.view_layer.objects.selected[i_18D5A].users_collection)):
            if (bpy.context.view_layer.objects.selected[i_18D5A].users_collection[i_BE9A3].name == CollectionName):
                movetocollection_s3_vars_F4130['sna_objectstomove'].remove(bpy.context.view_layer.objects.selected[i_18D5A])
    for i_EC7E0 in range(len(movetocollection_s3_vars_F4130['sna_objectstomove'])):
        for i_726C8 in range(len(movetocollection_s3_vars_F4130['sna_objectstomove'][i_EC7E0].users_collection)):
            movetocollection_s3_vars_F4130['sna_objectstomove'][i_EC7E0].users_collection[i_726C8].objects.unlink(object=movetocollection_s3_vars_F4130['sna_objectstomove'][i_EC7E0], )
    for i_9A186 in range(len(movetocollection_s3_vars_F4130['sna_objectstomove'])):
        bpy.data.collections[CollectionName].objects.link(object=movetocollection_s3_vars_F4130['sna_objectstomove'][i_9A186], )


def sna_true_deselect__all_C6336_75558():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_601D2(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_true_deselect__all_C6336_BDFE9():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_2AD1C(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


class SNA_PT_EXTENSION_PANEL_07BB5(bpy.types.Panel):
    bl_label = 'Extension panel'
    bl_idname = 'SNA_PT_EXTENSION_PANEL_07BB5'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Facefilled'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.bevel_curve_95a8a', text='Bevel Curve Modif', icon_value=0, emboss=True, depress=property_exists("bpy.context.view_layer.objects.active.modifiers['Curve Bevel']", globals(), locals()))
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Curve Bevel']", globals(), locals()):
            col_BF5F8 = layout.column(heading='', align=False)
            col_BF5F8.alert = False
            col_BF5F8.enabled = True
            col_BF5F8.active = True
            col_BF5F8.use_property_split = False
            col_BF5F8.use_property_decorate = False
            col_BF5F8.scale_x = 1.0
            col_BF5F8.scale_y = 1.0
            col_BF5F8.alignment = 'Expand'.upper()
            col_BF5F8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_5CBC3 = col_BF5F8.row(heading='', align=True)
            row_5CBC3.alert = False
            row_5CBC3.enabled = True
            row_5CBC3.active = True
            row_5CBC3.use_property_split = False
            row_5CBC3.use_property_decorate = False
            row_5CBC3.scale_x = 1.0
            row_5CBC3.scale_y = 1.0
            row_5CBC3.alignment = 'Expand'.upper()
            row_5CBC3.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_5CBC3.operator('sna.bezier_and_poly_swich1_6a9ba', text='Bezier', icon_value=0, emboss=True, depress= not (gn_get(bpy.context.view_layer.objects.active.modifiers['Curve Bevel'], 'Input_2') == 1))
            op.sna_index_poly_bezier = False
            op = row_5CBC3.operator('sna.bezier_and_poly_swich1_6a9ba', text='Poly', icon_value=0, emboss=True, depress=(gn_get(bpy.context.view_layer.objects.active.modifiers['Curve Bevel'], 'Input_2') == 1))
            op.sna_index_poly_bezier = True
            row_79C14 = col_BF5F8.row(heading='', align=True)
            row_79C14.alert = False
            row_79C14.enabled = True
            row_79C14.active = True
            row_79C14.use_property_split = False
            row_79C14.use_property_decorate = False
            row_79C14.scale_x = 1.0
            row_79C14.scale_y = 1.0
            row_79C14.alignment = 'Expand'.upper()
            row_79C14.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            gn_prop(row_79C14, bpy.context.view_layer.objects.active.modifiers['Curve Bevel'], 'Input_3', text='', icon_value=0, emboss=True)
            if (gn_get(bpy.context.view_layer.objects.active.modifiers['Curve Bevel'], 'Input_2') == 1):
                gn_prop(row_79C14, bpy.context.view_layer.objects.active.modifiers['Curve Bevel'], 'Input_4', text='', icon_value=0, emboss=True)
        layout_function = layout
        sna_solidify_extension_CB02B(layout_function, )
        col_4E701 = layout.column(heading='', align=False)
        col_4E701.alert = False
        col_4E701.enabled = True
        col_4E701.active = True
        col_4E701.use_property_split = False
        col_4E701.use_property_decorate = False
        col_4E701.scale_x = 1.0
        col_4E701.scale_y = 1.0
        col_4E701.alignment = 'Expand'.upper()
        col_4E701.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = col_4E701.operator('sna.bevel_edge_modif_9400d', text='Bevel Edge Modif', icon_value=0, emboss=True, depress=property_exists("bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull']", globals(), locals()))
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull']", globals(), locals()):
            col_CAEFB = col_4E701.column(heading='', align=False)
            col_CAEFB.alert = False
            col_CAEFB.enabled = True
            col_CAEFB.active = True
            col_CAEFB.use_property_split = False
            col_CAEFB.use_property_decorate = False
            col_CAEFB.scale_x = 1.0
            col_CAEFB.scale_y = 1.0
            col_CAEFB.alignment = 'Expand'.upper()
            col_CAEFB.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_CAEFB.prop(bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull'], 'width', text='Amount', icon_value=0, emboss=True)
            col_CAEFB.prop(bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull'], 'segments', text='Segments', icon_value=0, emboss=True)
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Weld Vovrzull']", globals(), locals()):
            col_4E701.prop(bpy.context.view_layer.objects.active.modifiers['Weld Vovrzull'], 'merge_threshold', text='Weld', icon_value=0, emboss=True)


class SNA_OT_Bevel_Edge_Modif_9400D(bpy.types.Operator):
    bl_idname = "sna.bevel_edge_modif_9400d"
    bl_label = "Bevel Edge Modif"
    bl_description = "Adds a bevel to check the active object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.view_layer.objects.active.type == 'MESH':
            if property_exists("bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull']", globals(), locals()):
                if (bpy.context.view_layer.objects.active != None):
                    sna_delete_modification_EA26B('Weld Vovrzull')
                    sna_delete_modification_EA26B('Bevel vovrzull')
                    sna_delete_modification_EA26B('WeightedNormal')
                    if (bpy.app.version < (4.0, 1.0, 0.0)):
                        bpy.context.view_layer.objects.active.data.auto_smooth_angle = math.radians(30.0)
            else:
                modifier_34B62 = bpy.context.view_layer.objects.active.modifiers.new(name='Weld Vovrzull', type='WELD', )
                modifier_34B62.show_expanded = False
                modifier_D8B8B = bpy.context.view_layer.objects.active.modifiers.new(name='Bevel vovrzull', type='BEVEL', )
                modifier_D8B8B.affect = 'EDGES'
                modifier_D8B8B.offset_type = 'OFFSET'
                modifier_D8B8B.segments = 3
                modifier_D8B8B.width = 0.019999999552965164
                modifier_D8B8B.profile = 0.699999988079071
                modifier_D8B8B.miter_outer = 'MITER_ARC'
                modifier_D8B8B.use_clamp_overlap = False
                modifier_D8B8B.show_expanded = False
                if property_exists("bpy.context.view_layer.objects.active.modifiers['WeightedNormal']", globals(), locals()):
                    pass
                else:
                    modifier_7583C = bpy.context.view_layer.objects.active.modifiers.new(name='WeightedNormal', type='WEIGHTED_NORMAL', )
                    modifier_7583C.weight = 50
                    modifier_7583C.show_expanded = False
                    if (bpy.app.version < (4.0, 1.0, 0.0)):
                        bpy.context.view_layer.objects.active.data.use_auto_smooth = True
                        bpy.context.view_layer.objects.active.data.auto_smooth_angle = math.radians(60.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_delete_modification_EA26B(Name_Modoficator):
    if property_exists("bpy.context.view_layer.objects.active.modifiers[Name_Modoficator]", globals(), locals()):
        bpy.context.view_layer.objects.active.modifiers.remove(modifier=bpy.context.view_layer.objects.active.modifiers[Name_Modoficator], )


class SNA_OT_Bezier_And_Poly_Swich1_6A9Ba(bpy.types.Operator):
    bl_idname = "sna.bezier_and_poly_swich1_6a9ba"
    bl_label = "Bezier and Poly swich1"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_index_poly_bezier: bpy.props.BoolProperty(name='Index Poly Bezier', description='', default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_bezierpoly = self.sna_index_poly_bezier
        bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Bevel_Curve_95A8A(bpy.types.Operator):
    bl_idname = "sna.bevel_curve_95a8a"
    bl_label = "Bevel Curve"
    bl_description = "Bevel modifier on curves"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.view_layer.objects.active.type == 'CURVE':
            if property_exists("bpy.context.view_layer.objects.active.modifiers['Curve Bevel']", globals(), locals()):
                bpy.context.view_layer.objects.active.modifiers.remove(modifier=bpy.context.view_layer.objects.active.modifiers['Curve Bevel'], )
            else:
                sna_import_geonode_3E625_493D9('Curve Bevel', os.path.join(os.path.dirname(__file__), 'assets', 'Fill Curve geonode.blend'))
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


@persistent
def depsgraph_update_pre_handler_20DDE(dummy):
    if (bpy.context.view_layer.objects.selected and bpy.context.view_layer.objects.active):
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull']", globals(), locals()):
            bpy.context.scene.sna_flip_normal = bool(gn_get(bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'], 'Input_5'))
            bpy.context.scene.sna_grid_visual = bool(gn_get(bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'], 'Input_6'))
            bpy.context.scene.sna_subdive_level = gn_get(bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'], 'Input_7')
            if bpy.context.scene.sna_select_facefilled:
                # The collection socket may be empty, so never dereference it blindly.
                _fill_collection = gn_get(bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'], 'Input_2')
                if _fill_collection is not None:
                    for _fill_object in _fill_collection.objects:
                        _fill_object.select_set(state=True, )
            bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )


class SNA_OT_Fill_Curve_2_7A9Eb(bpy.types.Operator):
    bl_idname = "sna.fill_curve_2_7a9eb"
    bl_label = "Fill Curve 2"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_facefilled_osnov_A03AD()
        sna_apply_fill_curve001_72392()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Apply_Fill_Curve_Fd113(bpy.types.Operator):
    bl_idname = "sna.apply_fill_curve_fd113"
    bl_label = "Apply fill curve"
    bl_description = "Applies modifiers and converts to a mesh, performs an additional function when deletion is enabled"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_apply_fill_curve001_72392()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_create_fill_curve_810B2():
    sna_vovrzull_osi2_09DF2()
    sna_create_cube_and_rotate_5A99D()
    bpy.context.view_layer.objects.active.name = 'Facefilled'
    sna_import_geonode_3E625_D579C('Fill Curve Vovrzull', os.path.join(os.path.dirname(__file__), 'assets', 'Fill Curve geonode.blend'))
    fill_curve_addon['sna_save_activ_object'] = None
    fill_curve_addon['sna_save_activ_object'] = bpy.context.view_layer.objects.active


def sna_apply_fill_curve001_72392():
    if property_exists("bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull']", globals(), locals()):
        fill_curve_addon['sna_save_collection_fill_curve'] = gn_get(bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'], 'Input_2')
        bpy.ops.object.convert(target='MESH', merge_customdata=True)
        if bpy.context.scene.sna_delete_objects:
            bpy.data.collections.remove(collection=fill_curve_addon['sna_save_collection_fill_curve'], )
    else:
        bpy.ops.object.convert(target='MESH', merge_customdata=True)


def sna_save_select_fill_curve001_C3E6A(NoActiv):
    fill_curve_addon['sna_save_list_select'] = []
    for i_59BEB in range(len(bpy.context.view_layer.objects.selected)):
        if NoActiv:
            if (bpy.context.view_layer.objects.selected[i_59BEB] != bpy.context.view_layer.objects.active):
                fill_curve_addon['sna_save_list_select'].append(bpy.context.view_layer.objects.selected[i_59BEB])
        else:
            fill_curve_addon['sna_save_list_select'].append(bpy.context.view_layer.objects.selected[i_59BEB])
        sna_rotate_for_orient_19C95(False, bpy.context.view_layer.objects.selected[i_59BEB])


def sna_add_to_view3d_mt_object_context_menu_345E1(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.fill_curve_2_7a9eb', text='Facefilled', icon_value=0, emboss=True, depress=False)


def sna_add_to_view3d_mt_edit_mesh_context_menu_4594B(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('sna.facefilled_edit_mode001_219d5', text='Facefilled', icon_value=0, emboss=True, depress=False)


class SNA_OT_Add_Object_Facefilled_52650(bpy.types.Operator):
    bl_idname = "sna.add_object_facefilled_52650"
    bl_label = "Add object Facefilled"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_correct_orienteshen_3934F()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_select_panel_corect_B869D():
    fill_curve_addon['sna_save_select_facedilled_panel'] = False
    fill_curve_addon['sna_save_select_facedilled_panel'] = bpy.context.scene.sna_select_facefilled
    bpy.context.scene.sna_select_facefilled = False


class SNA_PT_CURVE_FACEFILLED_95F59(bpy.types.Panel):
    bl_label = 'Curve Facefilled'
    bl_idname = 'SNA_PT_CURVE_FACEFILLED_95F59'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Facefilled'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        split_4EEFA = layout.split(factor=0.8722221851348877, align=True)
        split_4EEFA.alert = False
        split_4EEFA.enabled = True
        split_4EEFA.active = True
        split_4EEFA.use_property_split = False
        split_4EEFA.use_property_decorate = False
        split_4EEFA.scale_x = 1.0
        split_4EEFA.scale_y = 1.0
        split_4EEFA.alignment = 'Expand'.upper()
        if not True: split_4EEFA.operator_context = "EXEC_DEFAULT"
        op = split_4EEFA.operator('sna.apply_fill_curve_fd113', text='Apply', icon_value=string_to_icon('GEOMETRY_NODES'), emboss=True, depress=False)
        op = split_4EEFA.operator('sna.delete_empty_collections_3c97a', text='', icon_value=string_to_icon('TRASH'), emboss=True, depress=False)
        split_8FB2F = layout.split(factor=0.8500000238418579, align=True)
        split_8FB2F.alert = False
        split_8FB2F.enabled = True
        split_8FB2F.active = True
        split_8FB2F.use_property_split = False
        split_8FB2F.use_property_decorate = False
        split_8FB2F.scale_x = 1.0
        split_8FB2F.scale_y = 1.0
        split_8FB2F.alignment = 'Expand'.upper()
        if not True: split_8FB2F.operator_context = "EXEC_DEFAULT"
        op = split_8FB2F.operator('sna.fill_curve_panel_10c70', text='Facefilled', icon_value=0, emboss=True, depress=False)
        op = split_8FB2F.operator('sna.none_fill_facfilled_edcf4', text='N', icon_value=0, emboss=True, depress=False)
        split_A8E77 = layout.split(factor=0.19999998807907104, align=True)
        split_A8E77.alert = False
        split_A8E77.enabled = True
        split_A8E77.active = True
        split_A8E77.use_property_split = False
        split_A8E77.use_property_decorate = False
        split_A8E77.scale_x = 1.0
        split_A8E77.scale_y = 1.0
        split_A8E77.alignment = 'Expand'.upper()
        if not True: split_A8E77.operator_context = "EXEC_DEFAULT"
        split_A8E77.menu('VIEW3D_MT_curve_add', text='', icon_value=string_to_icon('OUTLINER_OB_CURVE'))
        op = split_A8E77.operator('sna.add_object_facefilled_52650', text='Add/Moving', icon_value=0, emboss=True, depress=False)
        if ((bpy.context.view_layer.objects.selected and bpy.context.view_layer.objects.active) and (bpy.context.view_layer.objects.active.type == 'CURVE')):
            layout.prop(bpy.context.view_layer.objects.active.data, 'resolution_u', text='Loop', icon_value=0, emboss=True)
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull']", globals(), locals()):
            col_36DD7 = layout.column(heading='', align=False)
            col_36DD7.alert = False
            col_36DD7.enabled = True
            col_36DD7.active = True
            col_36DD7.use_property_split = False
            col_36DD7.use_property_decorate = False
            col_36DD7.scale_x = 1.0
            col_36DD7.scale_y = 1.0
            col_36DD7.alignment = 'Expand'.upper()
            col_36DD7.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_53275 = col_36DD7.row(heading='', align=False)
            row_53275.alert = False
            row_53275.enabled = True
            row_53275.active = True
            row_53275.use_property_split = False
            row_53275.use_property_decorate = False
            row_53275.scale_x = 1.0
            row_53275.scale_y = 1.0
            row_53275.alignment = 'Expand'.upper()
            row_53275.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_53275.prop(bpy.context.scene, 'sna_select_facefilled', text='Select', icon_value=0, emboss=True)
            row_53275.prop(bpy.context.scene, 'sna_flip_normal', text='Flip Normal', icon_value=0, emboss=True)
            row_569C9 = col_36DD7.row(heading='', align=False)
            row_569C9.alert = False
            row_569C9.enabled = True
            row_569C9.active = True
            row_569C9.use_property_split = False
            row_569C9.use_property_decorate = False
            row_569C9.scale_x = 1.0
            row_569C9.scale_y = 1.0
            row_569C9.alignment = 'Expand'.upper()
            row_569C9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_569C9.prop(bpy.context.scene, 'sna_delete_objects', text='Delete ', icon_value=0, emboss=True)
        op = layout.operator('sna.reate_a_grid_322cb', text='Сreate a grid', icon_value=0, emboss=True, depress=False)
        if 'EDIT_MESH'==bpy.context.mode:
            op = layout.operator('sna.selection_object_facefilled_3c581', text='Selection', icon_value=0, emboss=True, depress=False)
        split_A41C7 = layout.split(factor=0.5, align=False)
        split_A41C7.alert = False
        split_A41C7.enabled = True
        split_A41C7.active = True
        split_A41C7.use_property_split = False
        split_A41C7.use_property_decorate = False
        split_A41C7.scale_x = 1.0
        split_A41C7.scale_y = 1.0
        split_A41C7.alignment = 'Expand'.upper()
        if not True: split_A41C7.operator_context = "EXEC_DEFAULT"
        split_A41C7.prop(bpy.context.scene, 'sna_grid_visual', text='Grid Visual', icon_value=0, emboss=True)
        split_A41C7.prop(bpy.context.scene, 'sna_subdive_level', text='', icon_value=0, emboss=bpy.context.scene.sna_grid_visual)


def sna_facefilled_osnov_A03AD():
    sna_select_panel_corect_B869D()
    sna_save_select_fill_curve001_C3E6A(False)
    for i_164AA in range(len(fill_curve_addon['sna_save_list_select'])):
        if (fill_curve_addon['sna_save_list_select'][i_164AA].data.dimensions == '2D'):
            fill_curve_addon['sna_save_list_select'][i_164AA].data.fill_mode = 'NONE'
    sna_create_fill_curve_810B2()
    sna_true_deselect__all_C6336_64369()
    sna_move_collection_save_D9FED()
    sna_true_deselect__all_C6336_385E4()
    sna_select__set_active_object_07AE7_05FC7(fill_curve_addon['sna_save_activ_object'])
    gn_set(bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'], 'Input_2', bpy.data.collections[fill_curve_addon['sna_collection_fill_curve']])
    bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'].show_viewport = False
    bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull'].show_viewport = True
    sna_fix_double_collection_FF968()
    bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )
    bpy.ops.mesh.primitive_cube_add()
    bpy.ops.object.delete()
    sna_clean_collection_facefilled_935FB()
    sna_select__set_active_object_07AE7_302F5(fill_curve_addon['sna_save_activ_object'])
    bpy.context.scene.sna_select_facefilled = fill_curve_addon['sna_save_select_facedilled_panel']
    sna_active_scene_collection_2B61F_97EE9()


def sna_move_collection_save_D9FED():
    sna_new_collection_and_active_32E38_7E530('Facefilled Collection', False)
    collection_E7386 = bpy.data.collections.new(name='Facefilled', )
    bpy.context.collection.children.link(child=collection_E7386, )
    fill_curve_addon['sna_collection_fill_curve'] = collection_E7386.name
    for i_D999C in range(len(fill_curve_addon['sna_save_list_select'])):
        sna_select__set_active_object_07AE7_6C52B(fill_curve_addon['sna_save_list_select'][i_D999C])
        sna_fnmovetocollection_397D9_CA3F2(fill_curve_addon['sna_collection_fill_curve'])
        sna_rotate_for_orient_19C95(True, fill_curve_addon['sna_save_list_select'][i_D999C])


def sna_rotate_for_orient_19C95(Plus_and_minus, objects_rotate):
    objects_rotate.rotation_euler = ((float(objects_rotate.rotation_euler[0] - math.radians(0.10000000149011612)) if Plus_and_minus else float(objects_rotate.rotation_euler[0] + math.radians(0.10000000149011612))), objects_rotate.rotation_euler[1], objects_rotate.rotation_euler[2])


class SNA_OT_Fill_Curve_Panel_10C70(bpy.types.Operator):
    bl_idname = "sna.fill_curve_panel_10c70"
    bl_label = "Fill Curve panel"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.view_layer.objects.active != None):
            sna_active_scene_collection_2B61F_159AB()
            if 'OBJECT'==bpy.context.mode:
                pass
            else:
                sna_selection_object_facefilled001_183BF()
            sna_facefilled_osnov_A03AD()
        else:
            self.report({'ERROR'}, message='Select Activ Object')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Reate_A_Grid_322Cb(bpy.types.Operator):
    bl_idname = "sna.reate_a_grid_322cb"
    bl_label = "Сreate a grid"
    bl_description = "in object mode creates quads on the entire plane, in edit mode only on selected faces"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.view_layer.objects.active.type == 'MESH':
            if property_exists("bpy.context.view_layer.objects.active.modifiers['Fill Curve Vovrzull']", globals(), locals()):
                pass
            else:
                if 'OBJECT'==bpy.context.mode:
                    bpy.ops.object.mode_set(mode='EDIT')
                    sna_mesh_to_quad001_4693E()
                else:
                    bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
                    bpy.ops.mesh.tris_convert_to_quads(face_threshold=180.0, shape_threshold=180.0, seam=True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_mesh_to_quad001_4693E():
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')
    bpy.ops.mesh.tris_convert_to_quads(face_threshold=180.0, shape_threshold=180.0, seam=True)


class SNA_OT_None_Fill_Facfilled_Edcf4(bpy.types.Operator):
    bl_idname = "sna.none_fill_facfilled_edcf4"
    bl_label = "None Fill FacFilled"
    bl_description = "Disables the fill of all curves in collections."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        for i_5861C in range(len(bpy.data.collections['Facefilled Collection'].children)):
            for i_AB5DF in range(len(bpy.data.collections['Facefilled Collection'].children[i_5861C].objects)):
                if (bpy.data.collections['Facefilled Collection'].children[i_5861C].objects[i_AB5DF].type == 'CURVE'):
                    if (bpy.data.collections['Facefilled Collection'].children[i_5861C].objects[i_AB5DF].data.dimensions == '2D'):
                        bpy.data.collections['Facefilled Collection'].children[i_5861C].objects[i_AB5DF].data.fill_mode = 'NONE'
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fix_orient_2d_curve_7056D(Name_collection, project_or_selected):
    bpy.ops.object.mode_set(mode='OBJECT')
    for i_E7AAD in range(len((fill_curve_addon['sna_save_list_select'] if project_or_selected else bpy.data.collections[Name_collection].objects))):
        sna_select__set_active_object_07AE7_027A8((fill_curve_addon['sna_save_list_select'] if project_or_selected else bpy.data.collections[Name_collection].objects)[i_E7AAD])
        bpy.ops.object.origin_set('INVOKE_DEFAULT', type='ORIGIN_GEOMETRY')
        bpy.ops.object.duplicate_move()
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='VERT')
        bpy.ops.mesh.select_all(action='SELECT')
        if (len(bpy.context.view_layer.objects.active.data.polygons) == 0):
            bpy.ops.mesh.fill()
            bpy.ops.mesh.dissolve_limited('INVOKE_DEFAULT', delimit={'NORMAL'})
        bpy.ops.transform.create_orientation(name='Vovrzull Facefilled')
        bpy.context.scene.transform_orientation_slots[0].type = 'Vovrzull Facefilled'
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.data.objects.remove(object=bpy.context.view_layer.objects.active, )
        bpy.context.scene.tool_settings.use_transform_data_origin = True
        sna_select__set_active_object_07AE7_6D8B4((fill_curve_addon['sna_save_list_select'] if project_or_selected else bpy.data.collections[Name_collection].objects)[i_E7AAD])
        bpy.ops.transform.transform(mode='ALIGN')
        bpy.context.scene.tool_settings.use_transform_data_origin = False
        bpy.ops.transform.delete_orientation()
        bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
        sna_fix_origin_rotate3_5E78D((fill_curve_addon['sna_save_list_select'] if project_or_selected else bpy.data.collections[Name_collection].objects)[i_E7AAD])


def sna_fix_origin_rotate3_5E78D(Object_Active):
    orientation_filled1['sna_save_object_activ'] = Object_Active
    sna_ursor_to_object001_0F7D9_3AF70(bpy.context.view_layer.objects.active)
    sna_true_deselect__all_C6336_EC694()
    bpy.ops.mesh.primitive_vert_add()
    bpy.ops.object.mode_set(mode='OBJECT')
    sna_object_to_cursor001_31671_C5F03(bpy.context.view_layer.objects.active)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    Xcontrol = 0.5
    Ycontrol = 0.0
    Zcontrol = 0.0
    import bmesh
    # Check if we're in Edit Mode
    if bpy.context.mode != 'EDIT_MESH':
        bpy.ops.object.mode_set(mode='EDIT')
    # Get the selected mesh object and its data
    obj = bpy.context.active_object
    mesh = obj.data
    # Create a BMesh to work with
    bm = bmesh.from_edit_mesh(mesh)
    # Extrude the selected faces (you can also use .verts to extrude vertices)
    bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value":(Xcontrol, Ycontrol, Zcontrol)})
    # Update the BMesh
    bmesh.update_edit_mesh(mesh)
    # Deselect all faces or vertices
    #bm.select_flush(False)
    bpy.ops.mesh.select_all(action='INVERT')
    bpy.context.scene.transform_orientation_slots[0].type = 'GLOBAL'
    Xcontrol = 0.0
    Ycontrol = 0.0
    Zcontrol = -0.5
    import bmesh
    # Check if we're in Edit Mode
    if bpy.context.mode != 'EDIT_MESH':
        bpy.ops.object.mode_set(mode='EDIT')
    # Get the selected mesh object and its data
    obj = bpy.context.active_object
    mesh = obj.data
    # Create a BMesh to work with
    bm = bmesh.from_edit_mesh(mesh)
    # Extrude the selected faces (you can also use .verts to extrude vertices)
    bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value":(Xcontrol, Ycontrol, Zcontrol)})
    # Update the BMesh
    bmesh.update_edit_mesh(mesh)
    # Deselect all faces or vertices
    #bm.select_flush(False)
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.convert(target='CURVE')
    bpy.context.view_layer.objects.active.data.dimensions = '2D'
    bpy.ops.object.convert(target='MESH')
    p1 = bpy.context.view_layer.objects.active.data.vertices[0].co
    p2 = bpy.context.view_layer.objects.active.data.vertices[1].co
    p3 = bpy.context.view_layer.objects.active.data.vertices[2].co
    angle1 = None
    angle2 = None
    angle3 = None
    # Calculate the vectors representing the sides of the triangle
    v1 = (p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2])
    v2 = (p3[0] - p2[0], p3[1] - p2[1], p3[2] - p2[2])
    v3 = (p1[0] - p3[0], p1[1] - p3[1], p1[2] - p3[2])
    # Calculate the lengths of the sides
    side1 = math.sqrt(v1[0]**2 + v1[1]**2 + v1[2]**2)
    side2 = math.sqrt(v2[0]**2 + v2[1]**2 + v2[2]**2)
    side3 = math.sqrt(v3[0]**2 + v3[1]**2 + v3[2]**2)
    # Calculate the angles using the Law of Cosines
    angle1 = math.degrees(math.acos((side2**2 + side3**2 - side1**2) / (2 * side2 * side3)))
    angle2 = math.degrees(math.acos((side3**2 + side1**2 - side2**2) / (2 * side3 * side1)))
    angle3 = math.degrees(math.acos((side1**2 + side2**2 - side3**2) / (2 * side1 * side2)))
    # Print the angles
    print("Angle 1: {:.2f} degrees".format(angle1))
    print("Angle 2: {:.2f} degrees".format(angle2))
    print("Angle 3: {:.2f} degrees".format(angle3))
    orientation_filled1['sna_angle_rotate_orogin'] = 0.0
    orientation_filled1['sna_angle_rotate_orogin'] = angle3
    orientation_filled1['sna_object_matematic'] = None
    orientation_filled1['sna_object_matematic'] = bpy.context.view_layer.objects.active
    bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
    bpy.context.scene.tool_settings.use_transform_data_origin = True
    sna_true_deselect__all_C6336_A0868()
    sna_select__set_active_object_07AE7_85BF3(orientation_filled1['sna_save_object_activ'])
    bpy.ops.transform.rotate(value=(float(math.radians(orientation_filled1['sna_angle_rotate_orogin']) * -1.0) if (orientation_filled1['sna_object_matematic'].data.vertices[2].co[1] > orientation_filled1['sna_object_matematic'].data.vertices[0].co[1]) else math.radians(orientation_filled1['sna_angle_rotate_orogin'])), orient_axis='Z', orient_type='LOCAL', constraint_axis=(False, False, True))
    sna_cursor_to_world_02FD0_0BF78()
    bpy.data.objects.remove(object=orientation_filled1['sna_object_matematic'], )
    bpy.context.scene.tool_settings.use_transform_data_origin = False


def sna_vovrzull_osi2_09DF2():
    sna_save_select_fill_curve001_C3E6A(False)
    if (len(fill_curve_addon['sna_save_list_select']) == 0):
        fill_curve_addon['sna_save_list_select'].append(bpy.context.view_layer.objects.active)
    sna_fix_orient_2d_curve_7056D('', True)


def sna_create_cube_and_rotate_5A99D():
    sna_select__set_active_object_07AE7_32E89(fill_curve_addon['sna_save_list_select'][0])
    sna_ursor_to_object001_0F7D9_B05A4(bpy.context.view_layer.objects.active)
    bpy.ops.transform.create_orientation(name='Vovrzull Facefilled')
    bpy.context.scene.transform_orientation_slots[0].type = 'Vovrzull Facefilled'
    bpy.ops.mesh.primitive_cube_add(size=0.5)
    bpy.ops.transform.transform(mode='ALIGN')
    bpy.ops.transform.delete_orientation()
    bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
    sna_cursor_to_world_02FD0_ACB09()


def sna_correct_orienteshen_3934F():
    sna_save_select_fill_curve001_C3E6A(True)
    orienteshen_filled['sna_save_activ_object'] = None
    orienteshen_filled['sna_save_activ_object'] = bpy.context.view_layer.objects.active
    for i_8E55A in range(len(bpy.context.view_layer.objects.selected)):
        bpy.context.view_layer.objects.selected[i_8E55A].location = bpy.context.view_layer.objects.active.location
        bpy.context.view_layer.objects.selected[i_8E55A].rotation_euler = bpy.context.view_layer.objects.active.rotation_euler
    sna_true_deselect__all_C6336_EFBC7()
    for i_CC56D in range(len(fill_curve_addon['sna_save_list_select'])):
        if (i_CC56D == 0):
            sna_select__set_active_object_07AE7_88395(fill_curve_addon['sna_save_list_select'][i_CC56D])
        else:
            fill_curve_addon['sna_save_list_select'][i_CC56D].select_set(state=True, )
    if property_exists("orienteshen_filled['sna_save_activ_object'].modifiers['Fill Curve Vovrzull']", globals(), locals()):
        sna_fnmovetocollection_397D9_F4130(gn_get(orienteshen_filled['sna_save_activ_object'].modifiers['Fill Curve Vovrzull'], 'Input_2').name)


class SNA_OT_Blender_Market_Link_B7439(bpy.types.Operator):
    bl_idname = "sna.blender_market_link_b7439"
    bl_label = "Blender market link"
    bl_description = "Blender market link"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.url_open('INVOKE_DEFAULT', url='https://superhivemarket.com/creators/vovrzul777')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Youtube_Be414(bpy.types.Operator):
    bl_idname = "sna.youtube_be414"
    bl_label = "Youtube"
    bl_description = "Youtube link"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.url_open('INVOKE_DEFAULT', url='https://www.youtube.com/@Vovrzull')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_550DD(bpy.types.AddonPreferences):
    bl_idname = __package__

    def draw(self, context):
        if not (False):
            layout = self.layout 
            col_B4910 = layout.column(heading='', align=False)
            col_B4910.alert = False
            col_B4910.enabled = True
            col_B4910.active = True
            col_B4910.use_property_split = False
            col_B4910.use_property_decorate = False
            col_B4910.scale_x = 1.0
            col_B4910.scale_y = 1.0
            col_B4910.alignment = 'Expand'.upper()
            col_B4910.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_B4910.label(text='Useful links', icon_value=0)
            row_DCDC6 = col_B4910.row(heading='', align=False)
            row_DCDC6.alert = False
            row_DCDC6.enabled = True
            row_DCDC6.active = True
            row_DCDC6.use_property_split = False
            row_DCDC6.use_property_decorate = False
            row_DCDC6.scale_x = 1.0
            row_DCDC6.scale_y = 1.0
            row_DCDC6.alignment = 'Expand'.upper()
            row_DCDC6.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_DCDC6.operator('sna.blender_market_link_b7439', text='Blender market', icon_value=0, emboss=True, depress=False)
            op = row_DCDC6.operator('sna.youtube_be414', text='Youtube', icon_value=0, emboss=True, depress=False)
            op = row_DCDC6.operator('sna.boosty_5f55e', text='Boosty', icon_value=0, emboss=True, depress=False)


class SNA_OT_Boosty_5F55E(bpy.types.Operator):
    bl_idname = "sna.boosty_5f55e"
    bl_label = "Boosty"
    bl_description = "Boosty link"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.url_open('INVOKE_DEFAULT', url='https://boosty.to/vovrzull')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fix_double_collection_FF968():
    orienteshen_filled['sna_save_activ_object'] = None
    orienteshen_filled['sna_save_activ_object'] = bpy.context.view_layer.objects.active
    for i_717AC in range(len(bpy.context.scene.collection.children)):
        if (bpy.context.scene.collection.children[i_717AC].name[:len('Facefilled')] == 'Facefilled'):
            for i_967C2 in range(len(bpy.data.collections[bpy.context.scene.collection.children[i_717AC].name].objects)):
                if (bpy.data.collections[bpy.context.scene.collection.children[i_717AC].name].objects[i_967C2] == orienteshen_filled['sna_save_activ_object']):
                    bpy.data.collections[bpy.context.scene.collection.children[i_717AC].name].objects.unlink(object=orienteshen_filled['sna_save_activ_object'], )
                    bpy.context.scene.collection.objects.link(object=orienteshen_filled['sna_save_activ_object'], )


class SNA_OT_Selection_Object_Facefilled_3C581(bpy.types.Operator):
    bl_idname = "sna.selection_object_facefilled_3c581"
    bl_label = "Selection object facefilled"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_selection_object_facefilled001_183BF()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_selection_object_facefilled001_183BF():
    if 'EDIT_MESH'==bpy.context.mode:
        orienteshen_filled['sna_save_activ_for_selection'] = None
        orienteshen_filled['sna_save_activ_for_selection'] = bpy.context.view_layer.objects.active
        bpy.ops.mesh.separate(type='SELECTED')
        bpy.ops.object.mode_set(mode='OBJECT')
        sna_save_select_fill_curve001_C3E6A(True)
        sna_true_deselect__all_C6336_75558()
        for i_88761 in range(len(fill_curve_addon['sna_save_list_select'])):
            if (i_88761 == 0):
                sna_select__set_active_object_07AE7_601D2(fill_curve_addon['sna_save_list_select'][i_88761])
            else:
                fill_curve_addon['sna_save_list_select'][i_88761].select_set(state=True, )
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
    else:
        bpy.ops.object.mode_set(mode='OBJECT')


class SNA_OT_Delete_Empty_Collections_3C97A(bpy.types.Operator):
    bl_idname = "sna.delete_empty_collections_3c97a"
    bl_label = "delete empty collections"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_clean_collection_facefilled_935FB()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_clean_collection_facefilled_935FB():
    orienteshen_filled['sna_collection_scene_save'] = []
    bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
    for i_8EB72 in range(len(bpy.data.collections)):
        orienteshen_filled['sna_collection_scene_save'].append(bpy.data.collections[i_8EB72])
    for i_194B7 in range(len(orienteshen_filled['sna_collection_scene_save'])):
        if ((len(orienteshen_filled['sna_collection_scene_save'][i_194B7].objects) == 0) and (len(orienteshen_filled['sna_collection_scene_save'][i_194B7].children) == 0)):
            bpy.data.collections.remove(collection=orienteshen_filled['sna_collection_scene_save'][i_194B7], )


class SNA_OT_Facefilled_Edit_Mode001_219D5(bpy.types.Operator):
    bl_idname = "sna.facefilled_edit_mode001_219d5"
    bl_label = "Facefilled edit mode.001"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_selection_object_facefilled001_183BF()
        sna_facefilled_osnov_A03AD()
        orienteshen_filled['sna_delete_save_boolean'] = bpy.context.scene.sna_delete_objects
        bpy.context.scene.sna_delete_objects = True
        sna_apply_fill_curve001_72392()
        bpy.context.scene.sna_delete_objects = orienteshen_filled['sna_delete_save_boolean']
        sna_true_deselect__all_C6336_BDFE9()
        sna_select__set_active_object_07AE7_2AD1C(orienteshen_filled['sna_save_activ_for_selection'])
        orienteshen_filled['sna_save_activ_object'].select_set(state=True, )
        bpy.ops.object.join()
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.remove_doubles(threshold=0.009999999776482582)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Vovrzull_Solidify_Ec049(bpy.types.Operator):
    bl_idname = "sna.vovrzull_solidify_ec049"
    bl_label = "Vovrzull Solidify"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if bpy.context.view_layer.objects.active.type == 'MESH':
            if property_exists("bpy.context.view_layer.objects.active.modifiers['Solidify Vovrzull']", globals(), locals()):
                bpy.context.view_layer.objects.active.modifiers.remove(modifier=bpy.context.view_layer.objects.active.modifiers['Solidify Vovrzull'], )
            else:
                modifier_11E7C = bpy.context.view_layer.objects.active.modifiers.new(name='Solidify Vovrzull', type='SOLIDIFY', )
                bpy.context.view_layer.objects.active.modifiers['Solidify Vovrzull'].thickness = 0.5
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_solidify_extension_CB02B(layout_function, ):
    op = layout_function.operator('sna.vovrzull_solidify_ec049', text='Solidify Modif', icon_value=0, emboss=True, depress=property_exists("bpy.context.view_layer.objects.active.modifiers['Solidify Vovrzull']", globals(), locals()))
    if property_exists("bpy.context.view_layer.objects.active.modifiers['Solidify Vovrzull']", globals(), locals()):
        layout_function.prop(bpy.context.view_layer.objects.active.modifiers['Solidify Vovrzull'], 'thickness', text='', icon_value=0, emboss=True)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.types.Scene.sna_loop_curve = bpy.props.IntProperty(name='Loop Curve', description='', default=0, subtype='NONE', update=sna_update_sna_loop_curve_B8D26)
    bpy.types.Scene.sna_select_facefilled = bpy.props.BoolProperty(name='Select facefilled', description='when clicking on an object with a filled face, selects all related objects, rotate and scale for quick movement', default=False)
    bpy.types.Scene.sna_flip_normal = bpy.props.BoolProperty(name='Flip Normal', description='', default=False, update=sna_update_sna_flip_normal_9364C)
    bpy.types.Scene.sna_delete_objects = bpy.props.BoolProperty(name='Delete objects', description='apply removes used items', default=False)
    bpy.types.Scene.sna_custom_axis = bpy.props.BoolProperty(name='Custom Axis', description='if the axis of the object is wrong, it creates its own axis', default=False)
    bpy.types.Scene.sna_delete_custom_orient = bpy.props.BoolProperty(name='Delete Custom orient', description='', default=True)
    bpy.types.Scene.sna_grid_visual = bpy.props.BoolProperty(name='Grid Visual', description='', default=False, update=sna_update_sna_grid_visual_B1ABC)
    bpy.types.Scene.sna_subdive_level = bpy.props.IntProperty(name='Subdive Level', description='', default=0, subtype='NONE', min=0, max=6, update=sna_update_sna_subdive_level_2BE20)
    bpy.types.Scene.sna_bezierpoly = bpy.props.BoolProperty(name='bezier/poly', description='', default=False, update=sna_update_sna_bezierpoly_E7EB2)
    bpy.utils.register_class(SNA_PT_EXTENSION_PANEL_07BB5)
    bpy.utils.register_class(SNA_OT_Bevel_Edge_Modif_9400D)
    bpy.utils.register_class(SNA_OT_Bezier_And_Poly_Swich1_6A9Ba)
    bpy.utils.register_class(SNA_OT_Bevel_Curve_95A8A)
    bpy.app.handlers.depsgraph_update_pre.append(depsgraph_update_pre_handler_20DDE)
    bpy.utils.register_class(SNA_OT_Fill_Curve_2_7A9Eb)
    bpy.utils.register_class(SNA_OT_Apply_Fill_Curve_Fd113)
    bpy.types.VIEW3D_MT_object_context_menu.prepend(sna_add_to_view3d_mt_object_context_menu_345E1)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.prepend(sna_add_to_view3d_mt_edit_mesh_context_menu_4594B)
    bpy.utils.register_class(SNA_OT_Add_Object_Facefilled_52650)
    bpy.utils.register_class(SNA_PT_CURVE_FACEFILLED_95F59)
    bpy.utils.register_class(SNA_OT_Fill_Curve_Panel_10C70)
    bpy.utils.register_class(SNA_OT_Reate_A_Grid_322Cb)
    bpy.utils.register_class(SNA_OT_None_Fill_Facfilled_Edcf4)
    bpy.utils.register_class(SNA_OT_Blender_Market_Link_B7439)
    bpy.utils.register_class(SNA_OT_Youtube_Be414)
    bpy.utils.register_class(SNA_AddonPreferences_550DD)
    bpy.utils.register_class(SNA_OT_Boosty_5F55E)
    bpy.utils.register_class(SNA_OT_Selection_Object_Facefilled_3C581)
    bpy.utils.register_class(SNA_OT_Delete_Empty_Collections_3C97A)
    bpy.utils.register_class(SNA_OT_Facefilled_Edit_Mode001_219D5)
    bpy.utils.register_class(SNA_OT_Vovrzull_Solidify_Ec049)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_bezierpoly
    del bpy.types.Scene.sna_subdive_level
    del bpy.types.Scene.sna_grid_visual
    del bpy.types.Scene.sna_delete_custom_orient
    del bpy.types.Scene.sna_custom_axis
    del bpy.types.Scene.sna_delete_objects
    del bpy.types.Scene.sna_flip_normal
    del bpy.types.Scene.sna_select_facefilled
    del bpy.types.Scene.sna_loop_curve
    bpy.utils.unregister_class(SNA_PT_EXTENSION_PANEL_07BB5)
    bpy.utils.unregister_class(SNA_OT_Bevel_Edge_Modif_9400D)
    bpy.utils.unregister_class(SNA_OT_Bezier_And_Poly_Swich1_6A9Ba)
    bpy.utils.unregister_class(SNA_OT_Bevel_Curve_95A8A)
    bpy.app.handlers.depsgraph_update_pre.remove(depsgraph_update_pre_handler_20DDE)
    bpy.utils.unregister_class(SNA_OT_Fill_Curve_2_7A9Eb)
    bpy.utils.unregister_class(SNA_OT_Apply_Fill_Curve_Fd113)
    bpy.types.VIEW3D_MT_object_context_menu.remove(sna_add_to_view3d_mt_object_context_menu_345E1)
    bpy.types.VIEW3D_MT_edit_mesh_context_menu.remove(sna_add_to_view3d_mt_edit_mesh_context_menu_4594B)
    bpy.utils.unregister_class(SNA_OT_Add_Object_Facefilled_52650)
    bpy.utils.unregister_class(SNA_PT_CURVE_FACEFILLED_95F59)
    bpy.utils.unregister_class(SNA_OT_Fill_Curve_Panel_10C70)
    bpy.utils.unregister_class(SNA_OT_Reate_A_Grid_322Cb)
    bpy.utils.unregister_class(SNA_OT_None_Fill_Facfilled_Edcf4)
    bpy.utils.unregister_class(SNA_OT_Blender_Market_Link_B7439)
    bpy.utils.unregister_class(SNA_OT_Youtube_Be414)
    bpy.utils.unregister_class(SNA_AddonPreferences_550DD)
    bpy.utils.unregister_class(SNA_OT_Boosty_5F55E)
    bpy.utils.unregister_class(SNA_OT_Selection_Object_Facefilled_3C581)
    bpy.utils.unregister_class(SNA_OT_Delete_Empty_Collections_3C97A)
    bpy.utils.unregister_class(SNA_OT_Facefilled_Edit_Mode001_219D5)
    bpy.utils.unregister_class(SNA_OT_Vovrzull_Solidify_Ec049)
