import bpy
import dataclasses


addon_keymaps = []


@dataclasses.dataclass(frozen=True)
class KMI:
	category: str
	idname: str
	type: str = 'NONE'
	value: str = 'PRESS'
	ctrl: bool = False
	alt: bool = False
	shift: bool = False

	oskey: bool = False
	key_modifier: str = 'NONE'
	head: bool = False
	active: bool = True
	space_type: str = 'EMPTY'



KMI_DEFINITIONS = (
	KMI('Object Mode', 'object.curvebasher_modal_editor',  type='K', alt=True),
	KMI('Object Mode', 'object.curvebasher_curve_raycast', type='C', alt=True),

	# Unbound (more like set to str 'NONE')
	KMI('Object Mode', 'object.curvebasher_wire_generator'),
	KMI('Object Mode', 'object.curvebasher_draw_curve'),
	KMI('Object Mode', 'object.curvebasher_mesh_to_curve'),

	KMI('Curve',       'curve.curvebasher_modal_editor',   type='K', alt=True),
	KMI('Curve',       'object.curvebasher_curve_raycast', type='C', alt=True),
	KMI('Mesh',        'mesh.curvebasher_modal_editor',    type='K', alt=True),
)


def ensure_keymap(kc, name, space_type='EMPTY'):
	km = kc.keymaps.get(name)
	if not km:
		km = kc.keymaps.new(name=name, space_type=space_type)

	return km


def create_keymaps():
	addon_keymaps.clear()	# minimal guard against stale tracking

	wm = bpy.context.window_manager
	kc = wm.keyconfigs.addon

	if not kc:
		return
	
	for item in KMI_DEFINITIONS:
		km = ensure_keymap(kc, item.category)
		kmi = km.keymap_items.new(
			item.idname, item.type, item.value,
			ctrl=item.ctrl, alt=item.alt, shift=item.shift
		)
		addon_keymaps.append((km, kmi))


def destroy_keymaps():
	for km, kmi in addon_keymaps:
		km.keymap_items.remove(kmi)

	addon_keymaps.clear()


def register():
	create_keymaps()


def unregister():
	destroy_keymaps()
