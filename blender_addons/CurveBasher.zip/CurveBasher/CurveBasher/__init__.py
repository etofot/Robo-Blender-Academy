bl_info = {
	'name'        : 'CurveBasher',
	'description' : 'Curve Generators and Kitbashing Tools',
	'author'      : 'Armored Colony',
	'version'     : (1, 4, 3),
	'blender'     : (2, 90),
	# 'location'    : 'View3D > Add > Mesh',
	# 'warning'     : 'Whatever', # Used for warning icon and text in addons panel.
	# 'wiki_url'    : 'www.armoredColony.com\n', # This should be for Documentation.
	'category'    : 'ARMORED',
}


import sys


if 'bpy' in locals():
	if __name__ in sys.modules:
		del sys.modules[__name__]

	dotted = __name__ + "."
	for name in tuple(sys.modules):
		if name.startswith(dotted):
			del sys.modules[name]


import bpy


# MODULES AND SUBPACKAGES FROM THE CURRENT PACKAGE
from . import (
	utils,
	operators,
	operators_internal,
	keymaps,
	preferences,
	ui,
)


modules_with_register = (
	utils.properties,
	operators,
	operators_internal,
	keymaps,
	preferences,
	ui,
)


def register():
	for module in modules_with_register:
		if hasattr(module, 'register'):
			module.register()
		# else:
		# 	print(f'Module {module.__name__} does not have a register function.')


def unregister():
	for module in reversed(modules_with_register):
		if hasattr(module, 'unregister'):
			module.unregister()
		# else:
		# 	print(f'Module {module.__name__} does not have an unregister function.')

