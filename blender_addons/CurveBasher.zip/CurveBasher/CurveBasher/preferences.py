import bpy
import rna_keymap_ui

from .operators import (
	curvebasher_modal_editor,
	curvebasher_wire_generator,
	curvebasher_curve_raycast,
	curvebasher_mesh_to_curve,
)

from . import(
	keymaps,
	utils,
	ui,
)


# def draw_keymap(kc, layout, category, idname):
# 	'''
# 	Draw a full keymap item and its properties without the delete button 
# 	(disabled when the context_pointer is not set).
# 	'''
	
# 	km = kc.keymaps[category]
# 	kmi = km.keymap_items[idname]
# 	# layout.context_pointer_set('keymap', km)
# 	rna_keymap_ui.draw_kmi([], kc, km, kmi, layout, 0)


# def draw_simple_keymap(kc, layout, category, idname):
# 	'''
# 	Draw a short keymap item with a single field and no extra properties
# 	or delete button.
# 	'''
	
# 	km = kc.keymaps[category]
# 	kmi = km.keymap_items[idname]
# 	layout.prop(kmi, 'type', text='', full_event=True)


def url_button(row, text, url, icon):
	row.operator('wm.url_open', text=text, icon_value=icon.icon_id).url = url


def toggle_n_panel(self, context):
	classes = (
		ui.panels.CURVEBASH_PT_Panel,
		ui.panels.CURVEBASH_PT_SubPanel_Keymaps,   # Not registering seems to be enough to disable it.
		)

	for cls in classes:
		if self.show_n_panel:
			bpy.utils.register_class(cls)
		else:
			bpy.utils.unregister_class(cls)


def update_reset_modal_editor(self, context):
	self.property_unset('reset_modal_editor')

	pop_cls = curvebasher_modal_editor.ModalEditorPropertyGroup
	prop_names = utils.properties.get_declared_props_from_class(pop_cls)

	for name in prop_names:
		self.property_unset(name)
		if utils.addon.debug():
			print(f'Unset prop: {name}')


def update_reset_wire_generator(self, context):
	self.property_unset('reset_wire_generator')
		
	pop_cls = curvebasher_wire_generator.WireGeneratorPropertyGroup
	prop_names = utils.properties.get_declared_props_from_class(pop_cls)

	for name in prop_names:
		self.property_unset(name)
		if utils.addon.debug():
			print(f'Unset prop: {name}')


def update_reset_curve_raycast(self, context):
	self.property_unset('reset_curve_raycast')
		
	pop_cls = curvebasher_curve_raycast.CurveRaycastPropertyGroup
	prop_names = utils.properties.get_declared_props_from_class(pop_cls)

	for name in prop_names:
		self.property_unset(name)
		if utils.addon.debug():
			print(f'Unset prop: {name}')


def update_reset_mesh_to_curve(self, context):
	self.property_unset('reset_mesh_to_curve')
		
	pop_cls = curvebasher_mesh_to_curve.MeshToCurvePropertyGroup
	prop_names = utils.properties.get_declared_props_from_class(pop_cls)

	for name in prop_names:
		self.property_unset(name)
		if utils.addon.debug():
			print(f'Unset prop: {name}')


class ARMORED_PT_Curve_Basher_Preferences(
	bpy.types.AddonPreferences, 
	curvebasher_mesh_to_curve.MeshToCurvePropertyGroup,
	curvebasher_wire_generator.WireGeneratorPropertyGroup,
	curvebasher_curve_raycast.CurveRaycastPropertyGroup,
	curvebasher_modal_editor.ModalEditorPropertyGroup,
):

	bl_idname = utils.addon.get_name()

	preference_tabs: bpy.props.EnumProperty(
		name='Preference Tabs',
		default='KEYMAPS',
		items=[ 
			('KEYMAPS',     'Keymaps',      'Assign Keymaps to different aspects of the addon',),
			('SETTINGS',    'Settings',     'Configure how the addon works'),
			('DEVELOPER',   'Developer',    'Developer settings not meant for the end user'), 
		]
	)

	show_n_panel: bpy.props.BoolProperty(
		name='Show Sidebar Tab (N Panel)', 
		default=True,
		description='Show the Curve Basher tab in Blender\'s sidebar (N Panel)', 
		update=toggle_n_panel,
	)
	
	curve_scale: bpy.props.FloatProperty(
		name='Curve Scale', 
		default=1,
		description=(
			'A scale multiplier for all curves created by the addon, '
			'Useful when working with different Scene Units.'
		),
		soft_min=0.001,
	)
	
	# DEVELOPER PROPERTIES
	debug: bpy.props.BoolProperty(
		name='Debug Mode', 
		default=False,
		description='Prints a lot of junk in the console so I can see what the addon is doing (NOT MEANT FOR END USERS)',
	)

	mc_undo_push: bpy.props.BoolProperty(
		name='Mesh to Curve', 
		default=False,
		description='Extra undo step in the invoke method (sometimes prevents glitches like cables rendering black)',
	)

	cr_undo_push: bpy.props.BoolProperty(
		name='Curve Raycast', 
		default=False,
		description='Extra undo step in the invoke method (sometimes prevents glitches like cables rendering black)',
	)

	wg_undo_push: bpy.props.BoolProperty(
		name='Wire Generator', 
		default=False,
		description='Extra undo step in the invoke method (sometimes prevents glitches like cables rendering black)',
	)

	mk_override_apply_locations_rotation: bpy.props.BoolProperty(
		name='Override Apply All Transforms', 
		default=False,
		description='Applying the scale of a  standard Bezier curves transfers that scale to its control points, this setting bypasses that',
	)

	mk_inverse_scale_points: bpy.props.BoolProperty(
		name='Inverse Scale Curve Points', 
		default=True,
		description='Applying the scale of a standard Bezier curve transfers that scale to its control points, this setting counteracts that effect)',
	)
	
	gravity_dimensions_override: bpy.props.FloatProperty(
		name='Gravity Min Dimensions', 
		default=0.01,
		description='Gravity volumes misbehave when the surrounding objects have no dimensions, this value is only used in that specific scenario',
		min=0.0001,
		precision=4,
	)

	reset_modal_editor: bpy.props.BoolProperty(
		name='Reset Modal Editor',
		default=False,
		update=update_reset_modal_editor,
	)
	
	reset_wire_generator: bpy.props.BoolProperty(
		name='Reset Wire Generator',
		default=False,
		update=update_reset_wire_generator,
	)
	
	reset_curve_raycast: bpy.props.BoolProperty(
		name='Reset Curve Raycast',
		default=False,
		update=update_reset_curve_raycast,
	)
	
	reset_mesh_to_curve: bpy.props.BoolProperty(
		name='Reset Mesh to Curve',
		default=False,
		update=update_reset_mesh_to_curve,
	)


	def draw(self, context):
		self._draw_video_buttons()
		
		layout = self.layout
		row = layout.row()
		row.prop(self, 'preference_tabs', expand=True)

		if self.preference_tabs == 'KEYMAPS':
			self._draw_keymaps_layout(context)

		elif self.preference_tabs == 'SETTINGS':
			self._draw_settings_layout(context)

		elif self.preference_tabs == 'DEVELOPER':
			self._draw_developer_layout()

		else:
			self._draw_keymaps_layout(context)

		utils.icons.draw_promo_web_icons(self)
	
	def _draw_video_buttons(self):
		'''
		Draw the quickstart video buttons.
		'''
		
		layout = self.layout
		layout.use_property_split = False

		box = layout.box()
		row = box.row(align=True)
		row.scale_y = 1.5
		row.operator('wm.url_open', text='Quickstart Video', icon='FILE_MOVIE').url = 'https://www.youtube.com/watch?v=6UesTk-pUNk'
		row.separator()
		row.operator('wm.url_open', text='Full Playlist', icon='FILE_MOVIE').url = 'https://youtube.com/playlist?list=PLJJAC1PMAT68-zw0fyxzsR5RFGmIf9_fs&si=k3enbw0eZC3Q66Qq'
		layout.separator()
		
	def _draw_keymaps_layout(self, context):
		'''
		Drawn when the KEYMAPS tab is selected.
		'''

		utils.keymaps.repair_keymaps_once(keymaps.KMI_DEFINITIONS)
		
		wm = context.window_manager
		kc = wm.keyconfigs.user
		layout = self.layout

		layout.separator()
		layout.box().row().label(text='TIP: Some tools do different things depending what mode you\'re in.')
		layout.separator()

		def indented_box(layout, factor=.04):
			split = layout.split(factor=factor)
			split.column()
			return split.box()

		def draw_keymap(box, label, category, idname):
			split = box.split(factor=0.15)
			left = split.column()
			right = split.column()

			left.label(text=label)

			km = kc.keymaps[category]
			kmi = km.keymap_items[idname]
			# right.context_pointer_set('keymap', km)
			rna_keymap_ui.draw_kmi([], kc, km, kmi, right, 0)
			# right.prop(kmi, 'type', text='', full_event=True)

		layout.label(text='\u2022 Modal Editor (browse presets and transform curves):')
		box = indented_box(layout.column())
		draw_keymap(box, label='Object',     category='Object Mode',  idname='object.curvebasher_modal_editor')
		draw_keymap(box, label='Edit Mesh',  category='Mesh',         idname='mesh.curvebasher_modal_editor')
		draw_keymap(box, label='Edit Curve', category='Curve',        idname='curve.curvebasher_modal_editor')

		layout.separator()

		layout.label(text='\u2022 Raycast Curve (click on surfaces to define curve endpoints):')
		box = indented_box(layout.column())
		draw_keymap(box, label='Object',     category='Object Mode',  idname='object.curvebasher_curve_raycast',)

		layout.separator()
		
		layout.label(text='\u2022 Add Menu > Curve (Shift+A):')
		box = indented_box(layout.column())
		draw_keymap(box, label='Object',     category='Object Mode',  idname='object.curvebasher_wire_generator')
		draw_keymap(box, label='Object',     category='Object Mode',  idname='object.curvebasher_draw_curve')

		layout.separator()

		layout.label(text='\u2022 Context Menu (RMB):')
		box = indented_box(layout.column())
		draw_keymap(box, label='Object',     category='Object Mode',  idname='object.curvebasher_mesh_to_curve')

		layout.separator()


	def _draw_settings_layout(self, context):
		'''
		Drawn when the SETTINGS tab is selected.
		'''

		def reset_prop_group_button(layout, name):
			row = layout.row()
			row.scale_y = 1.3
			row.prop(self, name, toggle=True, text='RESET')
			
		layout = self.layout
		layout.use_property_split = True

		box = layout.box()
		box.prop(self, 'show_n_panel')

		box = layout.box()
		box.label(text='Global (affects all operators):')
		box.prop(self, 'curve_scale')

		col = layout.column()
		col.label(text='The following settings are only used for initialization (the first time a tool is run in a session):', icon='ERROR')
		
		split = layout.split()
		left_column = split.column()
		right_column = split.column()

		box = left_column.box()
		box.label(text='Modal Editor / Preset Browser:')
		reset_prop_group_button(box, 'reset_modal_editor')
		curvebasher_modal_editor.CurveBasher.draw_custom(self, context, layout=box)
		left_column.separator(factor=2)

		box = left_column.box()
		box.label(text='Curve Raycast:')
		reset_prop_group_button(box, 'reset_curve_raycast')
		curvebasher_curve_raycast.OBJECT_OT_curvebasher_curve_raycast.draw_custom(self, context, layout=box)
		left_column.separator(factor=2)

		box = right_column.box()
		box.label(text='Wire Generator:')
		reset_prop_group_button(box, 'reset_wire_generator')
		curvebasher_wire_generator.OBJECT_OT_curvebasher_wire_generator.draw_custom(self, context, layout=box)
		right_column.separator(factor=2)

		box = right_column.box()
		box.label(text='Mesh to Curve:')
		reset_prop_group_button(box, 'reset_mesh_to_curve')
		curvebasher_mesh_to_curve.OBJECT_OT_curvebasher_mesh_to_curve.draw_custom(self, context, layout=box)
		right_column.separator(factor=2)

	def _draw_developer_layout(self):
		'''
		Drawn when the DEVELOPER tab is selected.
		'''

		layout = self.layout
		layout.use_property_split = True

		box = layout.box()
		box.label(text='DEVELOPER OPTIONS - Do not touch!', icon='ERROR')
		col = box.column()
		col.prop(self, 'debug', toggle=True)
		
		col.separator()
		
		col = box.column(heading='Undo Push')
		col.prop(self, 'cr_undo_push')
		col.prop(self, 'wg_undo_push')
		col.prop(self, 'mc_undo_push')
		
		col.separator()
		
		col = box.column(heading='Scale Fix')
		col.label(text='Curvebash Browser:')
		col.prop(self, 'mk_override_apply_locations_rotation')
		col.prop(self, 'mk_inverse_scale_points')

		col = box.column(heading='')
		col.label(text='Wire Generator:')
		col.prop(self, 'gravity_dimensions_override')
		

classes = ( 
	ARMORED_PT_Curve_Basher_Preferences,    # Addon Preferences must register LAST.
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	
	utils.icons.load_icons()
	

def unregister():
	for cls in classes:
		bpy.utils.unregister_class(cls)
	
	utils.icons.unload_icons()
