import bpy
import os

from .. utils import addon


# class ARMORED_OT_Curve_Basher_Open_Preset_File(bpy.types.Operator):
#     '''Open the blend file that contains the default kitbash presets'''

#     bl_idname  = 'armored.open_kitbash_preset_file'
#     bl_label   = 'Open Kitbash Preset File'

#     def execute(self, context):
#         bpy.ops.wm.read_homefile(app_template='')
#         file_path = os.path.join(os.path.dirname(__file__), 'cable_packs/default_cables.blend')
#         bpy.ops.wm.open_mainfile(filepath=file_path)
#         return {'FINISHED'}

def get_keymap_string(operator_idname):
    '''
    Return a formatterd string of the keymap assigned to the specified operator.
    '''
     
    for km in bpy.context.window_manager.keyconfigs.user.keymaps:
        for kmi in km.keymap_items:
               
            if kmi.idname != operator_idname:
                continue
               
            if kmi.type == 'NONE':
                return 'Unassigned'
               
            parts = []
            if kmi.ctrl:  parts.append('Ctrl')
            if kmi.alt:   parts.append('Alt')
            if kmi.shift: parts.append('Shift')
            if kmi.oskey: parts.append('Cmd')
               
            parts.append(kmi.type)
               
            return '+'.join(parts)
          
    return 'Unassigned'


class CURVEBASH_PT_Panel(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Curvebasher'
    bl_label = 'Curvebasher'

    def draw(self, context):
        layout = self.layout
        layout.operator('curvebash.open_blend_file', text='Open Preset File')
        

class CURVEBASH_PT_SubPanel_Keymaps(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Curvebasher'
    bl_label = 'KEYMAPS:'
    bl_parent_id = 'CURVEBASH_PT_Panel'
    
    def draw(self, context):

        def keymap_block(layout, category='Blank', factor=0.4):
            box = layout.box()
            box.label(text=category)
            
            row       = box.row()
            split     = row.split(factor=factor)
            left_col  = split.column(align=True)
            right_col = split.column(align=True)

            left_col.alignment = 'RIGHT'
            right_col.alignment = 'LEFT'
            layout.separator()

            return left_col.label, right_col.label
        
        layout = self.layout
        key, action = keymap_block(layout, category='Main Keymaps:')

        key(text=get_keymap_string('object.curvebasher_modal_editor'));            action(text='- Modal Editor (Object Mode)')
        key(text=get_keymap_string('mesh.curvebasher_modal_editor'));              action(text='- Modal Editor (Edit Mesh)')
        key(text=get_keymap_string('curve.curvebasher_modal_editor'));             action(text='- Modal Editor (Edit Curve)')
        key(text=get_keymap_string('object.curvebasher_curve_raycast'));    action(text='- Raycast Curve')

        key, action = keymap_block(layout, category='Add Menu > Curve (Shift+A):')
        key(text=get_keymap_string('object.curvebasher_wire_generator'));   action(text='- Wire Generator')
        key(text=get_keymap_string('object.curvebasher_draw_curve'));       action(text='- Draw Curve')
        
        key, action = keymap_block(layout, category='Context Menu (RMB):')
        key(text=get_keymap_string('object.curvebasher_mesh_to_curve'));    action(text='- Mesh to Curve')

        layout.label(text='This tab can be disabled in the preferences.')


classes = (
    CURVEBASH_PT_Panel,
    CURVEBASH_PT_SubPanel_Keymaps,   # Not registering seems to be enough to disable it.
)

def register():
    if not addon.get_prefs().show_n_panel:
        return

    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    try:
        for cls in classes:
            bpy.utils.unregister_class(cls)
    except Exception:
        pass