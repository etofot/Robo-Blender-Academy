import bpy
# import gpu

# from gpu_extras.batch import batch_for_shader

from .. utils import(
	addon,
    # colors,
    curve_utils,
    draw,
)


addon_name = 'CURVEBASHER'


def draw_kitbasher_hud(self, context):
    props = addon.get_prefs()
    # draw_hud_background(self)

    draw.draw_title(self, addon_name)
    draw.draw_string(self, f'\'{self.profile_name}\'')
    
    # if self.expanded_HUD:
    if props.me_expanded_hud:
        draw.draw_body(self, layout_kitbasher_expanded(self))
    else:
        draw.draw_body(self, layout_kitbasher_collapsed(self))

    # (Optional).
    draw.draw_preset_keymap(self) # Scroll Up/Down

# def draw_hud_background(self):
#     offset_x = 20
#     offset_y = -10
#     width = 310
#     height = 250
#     vertices = (
#         (self.mouse_x + offset_x, self.mouse_y + offset_y), (self.mouse_x + offset_x + width, self.mouse_y + offset_y),
#         (self.mouse_x + offset_x, self.mouse_y + offset_y - height), (self.mouse_x + offset_x + width, self.mouse_y + offset_y - height)
#     )

#     indices = (
#         (0, 1, 2), (2, 1, 3))

#     shader = gpu.shader.from_builtin('2D_UNIFORM_COLOR')
#     batch = batch_for_shader(shader, 'TRIS', {"pos": vertices}, indices=indices)

#     shader.bind()
#     shader.uniform_float("color", colors.HUD_BACKGROUND)
#     batch.draw(shader)

#     return shader, batch


# LAYOUTS -----------------------------------------------------------------------------------------

def layout_kitbasher_collapsed(self):
    # FORMAT = Tuple: (Attribute Name, Value, Hotkey) or String: 'SEPARATOR'

    body = [
            ('TYPE:', self.mode_name,      'switch 1-3'     ),
            ('Mode:', self.transform_name, 'switch S, R, T, G' ),
            'SEPARATOR',

            ('EXPAND HUD >>', '', 'F1' )
        ]
    
    return body


def layout_kitbasher_expanded(self):
    props = addon.get_prefs()
    # FORMAT = (Attribute Name, Value, Hotkey) or 'SEPARATOR'

    body = [
            ('TYPE:', self.mode_name,      'switch 1-3'     ),
            ('Mode:', self.transform_name, 'switch S, R, T, G' ),
            'SEPARATOR',
        ]
    
    master_curve_mode = self.master_curve.get('mode', 1)

    if master_curve_mode == 1:
        curve = self.master_curve
        point_count     = curve_utils.point_count(curve)
        curve_segments  = curve_utils.resolution_u_to_segments(point_count, curve.data.resolution_u)
        curve_sides     = curve_utils.bevel_resolution_to_sides(curve.data.bevel_resolution)
        
        simple_curve_options = [
            ('Segments',    curve_segments, 'SHIFT + Scroll Up/Down'),
            ('Sides',       curve_sides,    ' CTRL + Scroll Up/Down'),
        ]
        
        body.extend(simple_curve_options)
        body.append('SEPARATOR',)
    
    elif master_curve_mode == 2:
        array_type_str = self.array_type.replace('_', ' ').lower().title()
        array_options = [
            ('Array Type:', array_type_str, 'toggle F' ),
        ]

        if self.array_type == 'FIXED_COUNT':
            array_options.append(
                ('Count:', self.array_count, 'SHIFT + Scroll Up/Down' ),
            )

        array_options.append(('Caps', props.me_array_caps, 'toggle C'))
        array_options.append('SEPARATOR',)
        body.extend(array_options)
    

    global_options = [
            ('Shading:',   props.me_smoothing.lower().capitalize(), 'cycle A' ),
            'SEPARATOR',
            
            ('Wireframe:',   props.me_wireframe, 'toggle W' ),
            ('Outline:',     props.me_outline,   'toggle Z' ),
            ('Stretch-fit:', self.master_curve.data.use_stretch,   'toggle X' ),
            'SEPARATOR',

            ('Select Curve Points', '', 'TAB' ),  
            ('Reset Transforms',    '', 'ALT + S, R, T, G' ),  
            ('Randomize Transform', '', 'hold ALT' ),  
            ('Ultra Randomize',     '', 'hold ALT + SHIFT' ),  
            'SEPARATOR',

            ('<< COLLAPSE HUD',  '', 'F1' )
        ]

    body.extend(global_options)
    
    return body