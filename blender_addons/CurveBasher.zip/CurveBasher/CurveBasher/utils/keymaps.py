# ARMORED – Keymap Repair (run-once, actionable logging)
# Call from your prefs draw():
#    from .keymap_repair import repair_keymaps_once
#    repair_keymaps_once(kmi_definitions, mirror_to_user=True)
#
# Expects `kmi_definitions` = iterable of objects with:
#   category, idname, type, value, ctrl, alt, shift, active


import bpy


# --- guard: run at most once per session unless force=True ---
_HAS_RUN = False
_NS_KEY = 'armored_curvebasher_keymap_repair_ran'
ADDON_NAME = (__package__ or __name__).split('.', 1)[0]


def _log(msg):
	print(f'[{ADDON_NAME}] {msg}')


def _guard_tripped():
	global _HAS_RUN
	if _HAS_RUN:
		return True
	ns = getattr(bpy.app, 'driver_namespace', None)
	return bool(ns and ns.get(_NS_KEY, False))


def _trip_guard():
	global _HAS_RUN
	_HAS_RUN = True
	ns = getattr(bpy.app, 'driver_namespace', None)
	if ns is not None:
		ns[_NS_KEY] = True


def reset_guard():
	'Allow running again during this Blender session.'
	global _HAS_RUN
	_HAS_RUN = False
	ns = getattr(bpy.app, 'driver_namespace', None)
	if ns and _NS_KEY in ns:
		try:
			del ns[_NS_KEY]
		except Exception:
			pass


# --- internals ---

def _kc():
	wm = bpy.context.window_manager
	return getattr(wm, 'keyconfigs', None)


def _ensure_km(kc, name, space_type='EMPTY'):
	km = kc.keymaps.get(name)
	if not km:
		km = kc.keymaps.new(name=name, space_type=space_type)
	return km


def _find_kmi_by_id(km, idname):
	if not km:
		return None
	for kmi in km.keymap_items:
		if kmi.idname == idname:
			return kmi
	return None


def _create_kmi(km, idname, type_, value_, ctrl=False, alt=False, shift=False, active=True):
	kmi = km.keymap_items.new(idname, type_, value_, ctrl=ctrl, alt=alt, shift=shift)
	kmi.active = active
	return kmi


def _fmt_binding(type_, value_, ctrl, alt, shift):
	return f'{type_}+{value_} ctrl={int(bool(ctrl))} alt={int(bool(alt))} shift={int(bool(shift))}'


def _restore_addon_defaults(definitions, actions):
	kc = _kc()
	if not kc or not getattr(kc, 'addon', None):
		# Not an error; just no work possible in this context.
		return
	kc_addon = kc.addon

	for d in definitions:
		km = _ensure_km(kc_addon, d.category)
		kmi = _find_kmi_by_id(km, d.idname)
		if kmi:
			# Only touch 'active' if it needs correcting; log if changed.
			if getattr(kmi, 'active', True) != d.active:
				kmi.active = d.active
				actions.append(f"[addon] set-active: {d.category}:{d.idname} -> {int(bool(d.active))}")
			continue

		_create_kmi(km, d.idname, d.type, d.value, d.ctrl, d.alt, d.shift, d.active)
		actions.append(f"[addon] created: {d.category}:{d.idname} -> {_fmt_binding(d.type, d.value, d.ctrl, d.alt, d.shift)} active={int(bool(d.active))}")


def _ensure_user_presence(definitions, mirror_to_user, actions):
	kc = _kc()
	if not kc or not getattr(kc, 'user', None):
		return
	kc_user = kc.user
	kc_addon = getattr(kc, 'addon', None)

	for d in definitions:
		km_u = _ensure_km(kc_user, d.category)
		kmi_u = _find_kmi_by_id(km_u, d.idname)
		if kmi_u:
			# Nothing to change; user already has an override.
			continue

		if not mirror_to_user:
			continue

		# Mirror addon’s current binding if available; else use declared default.
		type_, value_, ctrl_, alt_, shift_, active_, src = d.type, d.value, d.ctrl, d.alt, d.shift, d.active, 'declared'
		if kc_addon:
			km_a = kc_addon.keymaps.get(d.category)
			kmi_a = _find_kmi_by_id(km_a, d.idname) if km_a else None
			if kmi_a:
				type_, value_, ctrl_, alt_, shift_, active_ = kmi_a.type, kmi_a.value, kmi_a.ctrl, kmi_a.alt, kmi_a.shift, kmi_a.active
				src = 'addon'

		kmi_new = km_u.keymap_items.new(d.idname, type_, value_, ctrl=ctrl_, alt=alt_, shift=shift_)
		kmi_new.active = active_
		actions.append(f"[user] created ({src}): {d.category}:{d.idname} -> {_fmt_binding(type_, value_, ctrl_, alt_, shift_)} active={int(bool(active_))}")


# --- public entry point ---

def repair_keymaps_once(definitions, *, mirror_to_user=True, force=False, verbose=True):
	'''
	Run-once repair:
	- Ensures addon defaults exist (kc.addon).
	- Ensures user overrides exist (kc.user) without overwriting user edits.
	Guarded to run once per session unless force=True.

	Logging:
	- Prefixed with the add-on/extension name.
	- Only concrete changes are printed.
	- If nothing changed, prints: '[…] No changes made.'
	'''

	if not force and _guard_tripped():
		return False

	kc = _kc()
	# If keyconfigs aren’t ready yet, skip without tripping the guard.
	if not kc or (getattr(kc, 'addon', None) is None) or (getattr(kc, 'user', None) is None):
		return False

	actions = []
	_restore_addon_defaults(definitions, actions)
	_ensure_user_presence(definitions, mirror_to_user, actions)

	if verbose:
		if actions:
			_log('Repair changes:')
			for line in actions:
				_log('  ' + line)
			_log(f'Repair summary: {len(actions)} change(s).')
		# else:
			# _log('No changes made.')

	_trip_guard()
	return True