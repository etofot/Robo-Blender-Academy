import bpy
import numpy as np
import math
import mathutils
import typing

from .. import utils



def get_declared_props_from_class(prop_class: object) -> typing.Iterator[str]:
	'''
	Yield property names declared in the given (non-registered) class via annotations.
	This does NOT use bl_rna — it only detects what the user defined manually.
	'''
	for name in getattr(prop_class, '__annotations__', {}):
		yield name


def load_defaults_from_addon_preferences(operator: bpy.types.Operator, prop_class: typing.Type) -> None:
	'''
	Load properties from addon preferences to operator,
	using only the props declared in the shared class.
	'''

	addon_prefs = utils.addon.get_prefs()

	for prop in get_declared_props_from_class(prop_class):
		# print(f'Found: {prop} \t {getattr(addon_prefs, prop)}')
		if hasattr(operator, prop) and hasattr(addon_prefs, prop):
			setattr(operator, prop, getattr(addon_prefs, prop))


def save_operator_properties_to_addon_preferences(self, prop_class) -> None:
	'''
	Save properties from operator to addon preferences,
	using only the props declared in the shared class.
	'''

	addon_prefs = utils.addon.get_prefs()

	for name in get_declared_props_from_class(prop_class):
		if hasattr(self, name) and hasattr(addon_prefs, name):
			setattr(addon_prefs, name, getattr(self, name))
	

def register():
	'''
	Custom Properties for certain blender types.
	'''
	
	bpy.types.Object.uniform_scale = bpy.props.FloatProperty(
		name='Uniform Object Scale', 
		set=set_uniform_object_scale, 
		get=get_uniform_object_scale, 
		unit='LENGTH',
	)
	
	bpy.types.Object.profile_rot = bpy.props.FloatProperty(
		name='Curve Profile Rotation', 
		set=set_profile_rot, 
		get=get_profile_rot,
	)

	bpy.types.Object.curve_slide = bpy.props.FloatProperty(
		name='Curve Slide', 
		set=set_curve_slide, 
		get=get_curve_slide,
	)
	
	bpy.types.Object.bounds_center = bpy.props.FloatVectorProperty(
		name='Bounding Box Center', 
		get=get_bounds_center, 
		subtype='XYZ', 
		unit='LENGTH',
	)

	bpy.types.Object.array_fit_count = bpy.props.IntProperty(
		name='Fit to Curve Array Count', 
		get=get_array_fit_count,
	)

	bpy.types.Object.array_count = bpy.props.IntProperty(
		name='Array Count', 
		get=get_array_count,
	)
			
	bpy.types.Object.array_center = bpy.props.FloatProperty(
		name='Center Z of the array', 
		get=get_array_center, 
		set=set_array_center,
	)

	bpy.types.Object.array_dimensions = bpy.props.FloatProperty(
		name='Length Z of the array', 
		get=get_array_dimensions,
	)

	bpy.types.Mesh.dimensions = bpy.props.FloatVectorProperty(
		name='Mesh Dimensions', 
		get=get_mesh_dimensions, 
		subtype='XYZ', 
		unit='LENGTH',
	)

	bpy.types.Mesh.uniform_scale = bpy.props.FloatProperty(
		name='Uniform Mesh Scale', 
		set=set_uniform_mesh_scale, 
		get=get_uniform_mesh_scale, 
		unit='LENGTH',
	)

	bpy.types.Collection.type = bpy.props.StringProperty(
		name=' Type', 
		get=get_collection_type,
	)


def unregister():
	del bpy.types.Object.uniform_scale
	del bpy.types.Object.profile_rot
	del bpy.types.Object.curve_slide
	del bpy.types.Object.bounds_center
	del bpy.types.Object.array_fit_count
	del bpy.types.Object.array_count
	del bpy.types.Object.array_center
	del bpy.types.Object.array_dimensions
	del bpy.types.Mesh.dimensions
	del bpy.types.Mesh.uniform_scale
	del bpy.types.Collection.type


# PROPERTY FUNCTIONS >>
# ---------------------------------------------------------------------

def get_uniform_object_scale(self):
	return self.get('uniform_scale', self.scale.z)


def set_uniform_object_scale(self, value):
	ob = self

	ob.scale = (value, value, value)
	ob['uniform_scale'] = value


def get_uniform_mesh_scale(self):
	return self.get('uniform_scale', 1)    # Small defauklt val is preferable.


def set_uniform_mesh_scale(self, value):
	me = self

	prev_scale = self.uniform_scale
	scale = 1 / prev_scale * value
	mat_scale = mathutils.Matrix.Diagonal((scale, scale, scale, scale))

	me.transform(mat_scale)
	me['uniform_scale'] = value


def get_profile_rot(self):
	return self.get('profile_rot', 0)


def set_profile_rot(self, value):
	ob = self

	prev_rot = self.profile_rot
	rot = value - prev_rot      # Assume Radians
	mat_rot = mathutils.Matrix.Rotation(rot, 4, 'Z')

	ob.data.transform(mat_rot)
	ob['profile_rot'] = value


def get_curve_slide(self):
	return self.get('curve_slide', 0)


def set_curve_slide(self, value):
	ob = self

	prev_rot = self.curve_slide
	rot = value - prev_rot      # Assume Radians
	mat_rot = mathutils.Matrix.Rotation(rot, 4, 'Z')

	ob.data.transform(mat_rot)
	ob['curve_slide'] = value


def get_mesh_dimensions(self):
	me = self
	
	coords = np.empty(3 * len(me.vertices))
	me.vertices.foreach_get('co', coords)

	x, y, z = coords.reshape((-1, 3)).T

	mesh_dim = (
			x.max() - x.min(),
			y.max() - y.min(),
			z.max() - z.min()
			)

	return mesh_dim


def get_bounds_center(self):
	ob = self
	
	local_bbox_center = 0.125 * sum((mathutils.Vector(b) for b in ob.bound_box), mathutils.Vector())
	global_bbox_center = ob.matrix_world @ local_bbox_center

	return global_bbox_center


def get_array_dimensions(self):
	ob = self

	array = ob.modifiers.get('CB Array')
	if not array:
		return 0

	array_len = ob.array_count * ob.data.dimensions.z

	if array.start_cap is not None:
		array_len += array.start_cap.dimensions.z

	if array.end_cap is not None:
		array_len += array.end_cap.dimensions.z

	array_len *=  ob.scale.z

	return array_len


def get_array_fit_count(self):
	ob = self

	array = ob.modifiers.get('CB Array')
	if not array:
		return 1
	
	curve = array.curve
	if not curve:
		return 1
	
	curve_len = curve.data.splines[0].calc_length()
	mesh_len = ob.data.dimensions.z * ob.scale.z

	fit_count = math.ceil(curve_len / mesh_len)

	return fit_count


def get_array_count(self):
	ob = self

	mesh_len = ob.data.dimensions.z #* ob.scale.z   # Don't think this is needed
							# considering how curve arrays work.
	array = ob.modifiers.get('CB Array')
	if not array:
		return
	
	if array.fit_type == 'FIXED_COUNT':
		return array.count

	if array.fit_type == 'FIT_LENGTH':
		return math.ceil(array.fit_length / mesh_len)

	if array.fit_type == 'FIT_CURVE':
		curve = array.curve
		if not curve:
			return
		
		return math.ceil(curve.data.splines[0].calc_length() / mesh_len)


def set_array_center(self, value):
	ob = self

	# Use other properties.
	mesh_len = ob.data.dimensions.z# * ob.scale.z
	count = ob.array_count

	mid_z = value - mesh_len * (count-1) / 2

	ob.location.z = mid_z


def get_array_center(self):
	ob = self
	
	# return ob.array_dimensions / 2
	
	# Use other properties.
	mesh_len = ob.data.dimensions.z #* ob.scale.z
	count = ob.array_count

	return ob.location.z + mesh_len / 2 * (count-1)


def get_collection_type(self):
	return 'COLLECTION'