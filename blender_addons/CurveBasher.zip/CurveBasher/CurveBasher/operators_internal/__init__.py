from . import (
	open_blend_file,
)

import bpy


modules = [mod for mod in locals().values() if getattr(mod, '__package__', '').startswith(__package__)]


def register():
	for module in modules:
		if hasattr(module, 'register'):
			module.register()


def unregister():
	for module in modules:
		if hasattr(module, 'unregister'):
			module.unregister()