import bpy

import math
import mathutils


from .. import utils


def update_matrix(obj):
    if obj.parent is None:
        obj.matrix_world = obj.matrix_basis

    else:
        obj.matrix_world = obj.parent.matrix_world * \
                           obj.matrix_parent_inverse * \
                           obj.matrix_basis

def apply_scale_and_clear_transforms(obj):
	'''
	Apply scale and then clear all transformations.
	'''

	obj.data.transform(mathutils.Matrix.Diagonal(obj.scale).to_4x4())

	# Reset scale
	obj.scale = (1.0, 1.0, 1.0)

	# Clear location and rotation
	obj.location = (0.0, 0.0, 0.0)
	obj.rotation_euler = (0.0, 0.0, 0.0)
	

def apply_scale_rotateX180_and_clear_transforms(obj):
	'''
	Apply scale, rotate 180° around X, and then clear all transformations.
	'''

	# Create scale matrix
	scale_mat = mathutils.Matrix.Diagonal(obj.scale).to_4x4()

	# Create rotation matrix (180 degrees around X)
	rot_x_180 = mathutils.Matrix.Rotation(math.radians(180), 4, 'X')

	# Combine transformations: rotation * scale
	transform_mat = rot_x_180 @ scale_mat

	# Apply to mesh
	obj.data.transform(transform_mat)

	# Reset transforms
	obj.scale = (1.0, 1.0, 1.0)
	obj.rotation_euler = (0.0, 0.0, 0.0)
	obj.location = (0.0, 0.0, 0.0)

def add_modifiers(self, context, ob, curve, fit_type, count):
	# Array Modifier. >>

	array = utils.modifiers.array(ob)

	array.fit_type = fit_type
	# array.count = count if fit_type == 'FIXED_COUNT' else 1
	array.count = count
	array.curve = curve
	array.use_merge_vertices = self.mtc_merge

	if array.start_cap != self.start_cap:
		array.start_cap = self.start_cap

	if array.end_cap != self.end_cap:
		array.end_cap = self.end_cap
	
	if self.start_cap is None or self.end_cap is None:
		ob.curvebash.start_cap = ''
		ob.curvebash.end_cap   = ''
		cap1_id = ob.get('cap1')
		cap2_id = ob.get('cap2')

		if cap1_id: del ob['cap1']
		if cap2_id: del ob['cap2']

	else:
		ob.curvebash.start_cap = self.start_cap.name
		ob.curvebash.end_cap   = self.end_cap.name
		ob['cap1'] = self.start_cap.name
		ob['cap2'] = self.end_cap.name

	if self.mtc_offset_type == 'RELATIVE':
		array.use_constant_offset = False
		# if self.mtc_offset_relative == 0:
		#     self.report({'WARNING'}, 'Your offset is set to 0')
		array.relative_offset_displace[2] = self.mtc_offset_relative
		self.mtc_prev_offset_relative         = self.mtc_offset_relative

	elif self.mtc_offset_type == 'CONSTANT':
		array.use_constant_offset = True
		array.constant_offset_displace[2] = self.mtc_offset_constant
	
	# Curve Modifier >>
	deform = utils.modifiers.curve(ob, curve=curve)

	context.view_layer.update()

	ob.curvebash.offset_type = self.mtc_offset_type
	ob.curvebash.offset_relative = self.mtc_offset_relative
	ob.curvebash.offset_constant = self.mtc_offset_constant

	return array, deform


def get_caps(self, context, ob, meshes):
	active = context.active_object

	start_cap = utils.objects.find(active.curvebash.get('start_cap'))
	end_cap = utils.objects.find(active.curvebash.get('end_cap'))

	return start_cap, end_cap


def create_caps(self, context, obj, meshes):
	self.start_cap = None
	self.end_cap = None

	def center_origin_and_clear_transforms(obj):
		utils.transforms.center_origin(obj)	# Required for accurate positioning on the curve.
		apply_scale_and_clear_transforms(obj)	# Apply scale and clear transforms.
	
	# Didn't find any reference to cap objects. Try to create them.
	# if not self.start_cap and not self.end_cap:
	if len(meshes) > 1:
		if obj.curvebash.get('strain') != 'FAST_FOOD':
			self.start_cap = utils.objects.duplicate_object(context,  meshes[1], suffix='_in', linked=False, hidden=False)
			center_origin_and_clear_transforms(self.start_cap)
			meshes[1].select_set(False)
			if utils.addon.debug():
				print(f'cap 1 from mesh {meshes[1].name}')

		if len(meshes) > 2:
			if obj.curvebash.get('strain') != 'FAST_FOOD':
				self.end_cap = utils.objects.duplicate_object(context,  meshes[2], suffix='_in', linked=False, hidden=False)
				center_origin_and_clear_transforms(self.end_cap)
				meshes[2].select_set(False)
				if utils.addon.debug():
					print(f'cap 2 from mesh {meshes[2].name}')

		else:
			if self.start_cap:
				self.end_cap = utils.objects.duplicate_object(context, self.start_cap, suffix='_in', linked=False, hidden=False)
				center_origin_and_clear_transforms(self.end_cap)
				apply_scale_rotateX180_and_clear_transforms(self.end_cap)
				if utils.addon.debug():
					print(f'cap 2 from dup of cap 1 {self.start_cap.name}')

	else:
		if utils.addon.debug():
			print('and active caps are set to None so do nothing I guess')
	


def reposition(self, context, ob, curve, place='CENTER', slide=0, flip=False):
	curve_mod = ob.modifiers.get('CB Curve') 
	if curve_mod: 
		curve_mod.show_viewport = False
	else:
		if utils.addon.debug():
			print('this thing has no curve modifier')
			self.report({'WARNING'}, 'Expected curve modifier not found')

	context.view_layer.update()

	array_len = ob.dimensions.copy().z
	mesh_len  = ob.data.dimensions.z * ob.scale.z       # Mesh data dims are local, hence the mult.
	curve_len = curve.data.splines[0].calc_length()

	if curve_mod: 
		curve_mod.show_viewport = True
	
	start_cap_len = 0
	if self.start_cap is not None:
		start_cap_len = self.start_cap.data.dimensions.z

	end_cap_len = 0
	if self.end_cap is not None:
		end_cap_len = self.end_cap.data.dimensions.z

	if place == 'START':
		pos = mesh_len/2 + start_cap_len

	elif place == 'CENTER':
		pos = mesh_len/2 + start_cap_len + curve_len/2 - array_len/2

	elif place == 'END':
		pos = mesh_len/2 + curve_len - array_len + end_cap_len

	if flip:
		ob.rotation_euler.x = math.pi
		pos += array_len - mesh_len - start_cap_len - end_cap_len
		ob.curvebash.flip = True

	else:
		ob.rotation_euler.x = 0

	offset = 0
	if self.start_cap is not None:
		if self.offset_type == 'RELATIVE':
			offset = mesh_len * (self.offset_relative-1)
		elif self.offset_type == 'CONSTANT':
			offset = self.offset_constant

	ob.location = (0, 0, pos + slide + offset)

	ob.curvebash.place = place
	ob.curvebash.slide = slide
	ob.curvebash.flip  = flip


class CurvebashSettings(bpy.types.PropertyGroup):
	# Old code, not part of addon preferences. Just leave it here for now.
	
	strain: bpy.props.StringProperty()
	curve:  bpy.props.StringProperty()

	place: bpy.props.StringProperty()
	slide: bpy.props.FloatProperty()
	flip:  bpy.props.BoolProperty()

	scale:    bpy.props.FloatProperty()
	rotation: bpy.props.FloatProperty()
	
	# mesh_scale: bpy.props.FloatProperty()

	start_cap: bpy.props.StringProperty()
	end_cap:   bpy.props.StringProperty()

	offset_type:     bpy.props.StringProperty()
	offset_relative: bpy.props.FloatProperty()
	offset_constant: bpy.props.FloatProperty()


# class MeshToCurvePropertyGroup(bpy.types.PropertyGroup):
class MeshToCurvePropertyGroup:
	'''
	User Editable Properties

	Registered early by the addon preferences, this property group allows
	shared settings between the operator and the addon preferences. 
	
	NOTE:
	-The values stored in the preferences are only used the first time the operator runs.
	- Use a prefix for everythign here, to prevent conflicts with other operator properties 
	that appear in the preferences.
	'''

	def update_mtc_reset_placement(self, context):
		if self.mtc_placement == {'START'}:
			self.mtc_place = 'START'

		elif self.mtc_placement == {'CENTER'}:
			self.mtc_place = 'CENTER'
		
		elif self.mtc_placement == {'END'}:
			self.mtc_place = 'END'
		
		self.mtc_slide=0
		self.property_unset('mtc_placement')

		return None

	# def update_mtc_offset_type(self, context):
	# 	if self.mtc_offset_type == 'RELATIVE':
	# 		self.mtc_prev_offset_constant = self.mtc_offset_constant 

	# 		if self.mtc_offset_relative != self.mtc_prev_offset_relative:
	# 			self.mtc_offset_relative = self.mtc_prev_offset_relative
			
	# 		self.mtc_using_constant = False
				
	# 	elif self.mtc_offset_type == 'CONSTANT':
	# 		self.mtc_offset_relative = 1
		
	# 	return None


	# mode: bpy.props.StringProperty(default='ADD')

	mtc_fit_type: bpy.props.EnumProperty(
		name='Array Type',
		default='FIXED_COUNT',
		items=[
			('FIXED_COUNT', 'Fixed Count', 'Control the array count manually'),
			('FIT_CURVE', 'Fit to Curve', 'Match the array count to the curve length (aproximation, combine with "Stretch Fit" for a perfect fit)'),
		],
	)

	mtc_count: bpy.props.IntProperty(
		name='Count',
		description='Array element count',
		default=1,
		min=1,
		soft_max=50,
	)

	mtc_place: bpy.props.StringProperty(
		name='Place', 
		default='CENTER',
	)

	def mtc_get_placement_items(self, context):
		return [ 
			('START',  'Start',  'Move mesh to curve start',),
			('CENTER', 'Center', 'Move mesh to curve center'),
			('END',    'End',    'Move mesh to curve End'), 
		]

	mtc_placement: bpy.props.EnumProperty(
		name='Move to',
		default=0,
		options={'ENUM_FLAG'},
		items=mtc_get_placement_items,	# Allows using a default of 0, which we can store.
		update=update_mtc_reset_placement,
		# items=[ 
		# 	('START',  'Start',  'Move mesh to curve start',),
		# 	('CENTER', 'Center', 'Move mesh to curve center'),
		# 	('END',    'End',    'Move mesh to curve End'), 
		# ]
	)

	mtc_offset_type: bpy.props.EnumProperty(
		name='Offset Type',
		# update=update_mtc_offset_type,
		default='RELATIVE',
		items=[ 
			('RELATIVE', 'Relative', 'Based on mesh dimensions'),
			('CONSTANT', 'Constant', 'Based on an absolute value'),
		],
	)

	mtc_offset_relative: bpy.props.FloatProperty(
		name='Offset', 
		default=1,
		description='Relative separation between array elements',
	)

	mtc_offset_constant: bpy.props.FloatProperty(
		name='Offset', 
		default=0,
		description='Constant separation between array elements',
	)

	mtc_using_constant: bpy.props.BoolProperty(
		default=False,
	)

	mtc_prev_offset_relative: bpy.props.FloatProperty(
		default=1,
	)

	mtc_prev_offset_constant: bpy.props.FloatProperty(
		default=0,
	)

	mtc_merge: bpy.props.BoolProperty(
		name='Merge Vertices', 
		default=True,
		description='Merge vertices in adjacent duplicates',
	)

	mtc_scale: bpy.props.FloatProperty(
		name='Scale', 
		default=1.0,
		description='Mesh Scale',
		precision=2, 
		step=0.1, 
		min=0.1, 
		soft_min=0.01,
	)

	mtc_rotation: bpy.props.FloatProperty(
		name='Rotation', 
		default=0,
		description='Rotation in degrees',
		precision=0, 
		step=10,
	)

	mtc_slide: bpy.props.FloatProperty(
		name='Slide', 
		default=0,
		description='Slide along curve',
		precision=2, 
		step=0.5,
	)

	mtc_flip: bpy.props.BoolProperty(
		name='Reverse', 
		default=False,
		description='Reverse direction of the Mesh/Array (only noticeable with asymmetrical meshes)',
	)

	mtc_stretch_to_fit: bpy.props.BoolProperty(
		name='Stretch-fit (disables Slide)', 
		default=False,
		description='Stretch the Array to fit perfectly withink the bounds of the curve (cannot slide while this is enabled)',
	)
	
	# rot: bpy.props.FloatProperty(name='Rot', default=0)


class OBJECT_OT_curvebasher_mesh_to_curve(bpy.types.Operator, MeshToCurvePropertyGroup):
	'''Curvebasher - Apply a mesh to a curve plus array options.\nSHIFT + LMB - Mesh to Curve Endpoints instead.

	armoredColony.com '''

	bl_idname = 'object.curvebasher_mesh_to_curve'
	bl_label  = 'Curvebasher Mesh to Curve'
	bl_options = {'REGISTER', 'UNDO', 'PRESET'}

	def set_save_as_defaults(self, context):
		utils.properties.save_operator_properties_to_addon_preferences(self, MeshToCurvePropertyGroup)

	save_as_defaults: bpy.props.BoolProperty(
		name='Save as Defaults',
		default=False,
		description='Save the current settings as the new startup defaults for this operator',
		update=set_save_as_defaults,
		options={'SKIP_SAVE', 'HIDDEN'},  # Don't save the operator to the undo stack.
	)

	initialized: bpy.props.BoolProperty(
		default=False,
		options={'HIDDEN'},
		description=(
			'Used internally to check if the operator should use addon preferences '
			'for its property defaults the first time it runs.'
		),
	)

	# mesh_to_curve_props: bpy.props.PointerProperty(type=MeshToCurvePropertyGroup)
	
	# We need to store this separetely (not a Pointer Property Group) so it doesn't trigger 
	# a property reset when we try to access it from the draw_menu function.
	mtc_mode: bpy.props.StringProperty(default='ADD')

	def draw(self, context):
		self.draw_custom(context, self.layout)

	def draw_custom(self, context, layout: bpy.types.UILayout):
		'''
		Same as draw() but takes in a custom layout element, which allows more control 
		when called from the addon preferences.
		'''

		layout.use_property_split = True
		col = layout.column(align=True)

		row = col.row()
		row.prop(self, 'mtc_fit_type', expand=True)

		sub_col = col.column()
		sub_col.enabled = True if self.mtc_fit_type == 'FIXED_COUNT' else False
		sub_col.prop(self, 'mtc_count')
		col.separator()

		col.prop(self, 'mtc_scale')
		col.prop(self, 'mtc_rotation')
		col.separator()

		col.prop(self, 'mtc_slide'); #row.prop(props, 'center', text='', icon='FAKE_USER_OFF')
		row = col.row(align=True)
		# self.placement = {}
		row.prop(self, 'mtc_placement', expand=True)
		col.separator()

		col.prop(self, 'mtc_flip', toggle=True, expand=True)
		col.separator()

		row = col.row()
		row.prop(self, 'mtc_offset_type', expand=True)

		if self.mtc_offset_type == 'RELATIVE':
			col.prop(self, 'mtc_offset_relative')
			if self.mtc_offset_relative == 0:
				col.label(text='(Relative offset of 0 can create overlapping geo)')

		elif self.mtc_offset_type == 'CONSTANT':
			col.prop(self, 'mtc_offset_constant')
		
		elif self.mtc_offset_type == 'BOTH':
			col.prop(self, 'mtc_offset_relative')
			col.prop(self, 'mtc_offset_constant')

		col.separator()

		col.prop(self, 'mtc_merge')
		col.separator()

		col = col.column(heading='Curve Settings', align=True)
		col.prop(self, 'mtc_stretch_to_fit')
		# col.prop(self, 'stretch')
		col.separator(factor=1.5)

		col.use_property_split = False
		if hasattr(self, 'save_as_defaults'):
			col.prop(self, 'save_as_defaults', toggle=True, icon='FILE_TICK')

	def invoke(self, context, event):
		if utils.addon.debug():
			print('Invoked Mesh to Curve')

		if utils.addon.get_prefs().mc_undo_push:
			bpy.ops.ed.undo_push()

		if not self.initialized:
			print('INIT MESH TO CURVE')
			utils.properties.load_defaults_from_addon_preferences(self, MeshToCurvePropertyGroup)
			self.initialized = True

		
		# Use the settings of any existing modifier  __________________________________________________
		active_mesh = context.active_object
		array_mod = active_mesh.modifiers.get('CB Array')

		# Get what we can from the array instead of the properties.
		if array_mod is not None:
			self.mtc_fit_type = array_mod.fit_type
			self.mtc_count = array_mod.count

			self.mtc_offset_relative = array_mod.relative_offset_displace[2]
			self.mtc_offset_constant = array_mod.constant_offset_displace[2]

		self.start_cap = utils.objects.retrieve(context, active_mesh.curvebash.get('start_cap'))
		self.end_cap   = utils.objects.retrieve(context, active_mesh.curvebash.get('end_cap'))

		self.mtc_place       = active_mesh.curvebash.get('place',       self.mtc_place)
		self.mtc_slide       = active_mesh.curvebash.get('slide',       self.mtc_slide)
		self.mtc_flip        = active_mesh.curvebash.get('flip',        self.mtc_flip)
		self.mtc_scale       = active_mesh.curvebash.get('scale',       self.mtc_scale)
		self.mtc_rotation    = active_mesh.curvebash.get('rotation',    self.mtc_rotation)
		self.mtc_offset_type = active_mesh.curvebash.get('offset_type', self.mtc_offset_type)
		
		# END  __________________________________________________


		# MODE OVERRIDES
		if event.shift:
			if utils.addon.debug():
				print('Holding SHIFT, using ENDPOINTS mode')
			self.mtc_mode = 'ENDPOINTS'
			self.mtc_count = 1
			self.mtc_fit_type = 'FIXED_COUNT'
			self.mtc_slide = 0
			self.start_cap = None
			self.end_cap = None

		# bpy.ops.ed.undo_push()
		return self.execute(context)


	def execute(self, context):
		mesh_objects = [ob for ob in context.selected_objects if ob.type == 'MESH']
		curves = [ob for ob in context.selected_objects if ob.type == 'CURVE']

		if not mesh_objects:
			self.report({'ERROR'}, 'Select at least one Mesh')
			return {'FINISHED'}

		active_mesh = mesh_objects[0]
		if context.active_object in mesh_objects:
			active_mesh = context.active_object

		if self.mtc_mode in {'ADD', 'ENDPOINTS'}:
			if not curves:
				self.report({'ERROR'}, 'Select at least one Curve')
				return {'FINISHED'}

			# Filter any curve that is used as a profile by other areas of the addon.
			curves = [curve for curve in curves if curve.get('type') != 'profile']

			for curve in curves:
				# Gotta do all this stuff to prevent applied scale
				# from being transfered to curve control point radius'
				update_matrix(curve)

				original_scale = curve.matrix_world.to_scale()
				is_scaled = any(abs(s - 1.0) > 1e-5 for s in original_scale)

				if is_scaled:
					spline = curve.data.splines[0]

					if spline.type == 'BEZIER':
						for p in spline.bezier_points:
							if p.radius != 0:
								# Undo the effect of the scale (assume uniform scale)
								p.radius /= sum(original_scale) / 3.0

					elif spline.type in {'POLY', 'NURBS'}:
						for p in spline.points:
							if p.radius != 0:
								p.radius /= sum(original_scale) / 3.0

				curve.data.transform(curve.matrix_world)
				curve.matrix_world = mathutils.Matrix()

				curve.data.use_stretch       = self.mtc_stretch_to_fit
				curve.data.use_deform_bounds = self.mtc_stretch_to_fit

			

		# -------------------------------------------------------------------
		if self.mtc_mode == 'ADD':
			self._add_obj_to_curve(context, active_mesh, curves, mesh_objects, place=self.mtc_place, slide=self.mtc_slide, flip=self.mtc_flip)
		
		elif self.mtc_mode == 'ENDPOINTS':
			self._add_obj_to_curve(context, active_mesh, curves, mesh_objects, place='START', slide=self.mtc_slide,  flip=False)
			self._add_obj_to_curve(context, active_mesh, curves, mesh_objects, place='END',   slide=-self.mtc_slide, flip=True)

		elif self.mtc_mode == 'EDIT':
			editable_meshes = [ob for ob in mesh_objects if ob.curvebash.strain == 'FAST_FOOD']

			if not editable_meshes:
				self.report({'ERROR'}, 'No Editable Curvebash was found')
				return {'FINISHED'}

			for obj in editable_meshes:
				
				curve_name = obj.curvebash.get('curve')
				curve = context.scene.objects.get(curve_name)

				if curve is None:
					del obj['curvebash']
					self.report({'ERROR'}, 'Failed to Edit Curvebash [missing original curve]')
					return {'FINISHED'}

				curve.data.use_stretch = self.mtc_stretch_to_fit
				curve.data.use_deform_bounds = self.mtc_stretch_to_fit

				self.start_cap, self.end_cap = get_caps(self, context, obj, mesh_objects)

				# NOT SURE IF THIS SHOULD CREATE CAPS
				# USEFUL FOR ADDING CAPS TO A PRE-EXISTING ARRAY?
				# DOES NOT EVEN WORK XD!!!
				# if not self.start_cap or not self.end_cap:
				#     if addon.debug():
				#         print('get caps is None, try to create')
				#     create_caps(self, context, obj, editable_meshes)    # Sets caps to None if no geo is available to use.
				# else:
				#     if addon.debug():
				#         print('skip cap creation')
				
				obj.data.uniform_scale = self.mtc_scale
				obj.curvebash.scale = self.mtc_scale
				if self.start_cap and self.end_cap:
					self.start_cap.data.uniform_scale = self.mtc_scale
					self.end_cap.data.uniform_scale = self.mtc_scale
				
				obj.rotation_euler.z = math.radians(self.mtc_rotation)
				obj.curvebash.rotation = self.mtc_rotation

				add_modifiers(self, context, obj, curve, fit_type=self.mtc_fit_type, count=self.mtc_count)
				reposition(self, context, obj, curve, place=self.mtc_place, slide=self.mtc_slide, flip=self.mtc_flip)

				obj.curvebash.strain = 'FAST_FOOD'
				curve.select_set(False)

		if self.save_as_defaults:
			self.save_as_defaults = False
			self.report({'INFO'}, 'Settings Saved as Defaults')

		return {'FINISHED'}
	
	def _add_obj_to_curve(self, context, source_mesh, curves, mesh_objects, slide, place='START', flip=False):
		for curve in curves:
			obj = utils.objects.duplicate_object(context, source_mesh, linked=False)   
			obj.curvebash.curve = curve.name

			utils.transforms.center_origin(obj)	# Required for accurate positioning on the curve.
			apply_scale_and_clear_transforms(obj)	# Apply scale and clear transforms.

			create_caps(self, context, obj, mesh_objects)    # Does nothing if no reference to cap objects are found.

			obj.data.uniform_scale = self.mtc_scale
			obj.curvebash.scale = self.mtc_scale
			if self.start_cap and self.end_cap:
				self.start_cap.data.uniform_scale = self.mtc_scale
			
			obj.rotation_euler.z = math.radians(self.mtc_rotation)
			obj.curvebash.rotation = self.mtc_rotation
			
			array_mod, _ = add_modifiers(self, context, obj, curve, fit_type=self.mtc_fit_type, count=self.mtc_count)
			reposition(self, context, obj, curve, place=place, slide=slide, flip=flip)

			obj['curve'] = curve.name

			obj.curvebash.strain = 'FAST_FOOD'
			context.view_layer.objects.active = obj     

		
		# TESTING SHIT
		context.view_layer.update()

def draw_menu(self, context):
	obj = context.active_object
	strain = obj.curvebash.get('strain') if obj is not None else ''

	layout = self.layout
	layout.separator()
	layout.operator_context = 'INVOKE_DEFAULT'

	operator = layout.operator(OBJECT_OT_curvebasher_mesh_to_curve.bl_idname, text='Mesh to Curve')
	operator.mtc_mode = 'ADD'

	if strain == 'FAST_FOOD':
		operator = layout.operator(OBJECT_OT_curvebasher_mesh_to_curve.bl_idname, text='Edit Curvebash')
		operator.mtc_mode = 'EDIT'


classes = (
	OBJECT_OT_curvebasher_mesh_to_curve,
	CurvebashSettings,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	bpy.types.VIEW3D_MT_object_context_menu.append(draw_menu)
	bpy.types.Object.curvebash = bpy.props.PointerProperty(type=CurvebashSettings)
	

def unregister():
	for cls in classes:
		bpy.utils.unregister_class(cls)
	bpy.types.VIEW3D_MT_object_context_menu.remove(draw_menu)
	del bpy.types.Object.curvebash
