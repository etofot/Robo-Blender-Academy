import bpy

from .. import utils

			
class CurveRaycastPropertyGroup:
	'''
	User Editable Properties

	Registered early by the addon preferences, this property group allows
	shared settings between the operator and the addon preferences. 
	
	NOTE:
	-The values stored in the preferences are only used the first time the operator runs.
	- Use a prefix for everythign here, to prevent conflicts with other operator properties 
	that appear in the preferences.
	'''

	# CUSTOM GET/SET/UPDATE  __________________________________________________

	def update_cr_curve_sag(self, context):
		if self.cr_sag_strength == 0:
			self.cr_sag_strength = 0.5

	def update_cr_reset_handles(self, context):
		self.property_unset('cr_adaptive_strength')
		self.property_unset('cr_handle_offset')
		self.property_unset('cr_sag_strength')
		self.property_unset('cr_reset_handles')

	def update_cr_reset_all(self, context):
		'''
		We do it manually so the reset button works inside
		the addon preferences, without an operator instance.
		'''
		
		self.property_unset('cr_radius')
		self.property_unset('cr_outer_handle_type')
		self.property_unset('cr_adaptive_strength')
		self.property_unset('cr_handle_offset')
		self.property_unset('cr_resolution_u')
		self.property_unset('cr_bevel_resolution')
		self.property_unset('cr_curve_sag')
		self.property_unset('cr_sag_strength')
		self.property_unset('cr_mid_handle_type')
		self.property_unset('cr_reset_all')
		self.property_unset('cr_enter_edit')

	# RESETS  __________________________________________________

	cr_reset_handles: bpy.props.BoolProperty(
		name='Handles', 
		default=False,
		description=(
			'Reset all properties that affect handle positions:\n'
			'\u2022 Adaptive Strengths\n'
			'\u2022 Handle Offsets'
		),
		update=update_cr_reset_handles,
	)
	
	cr_reset_all: bpy.props.BoolProperty(name='All', default=False,
		description='Reset everything to default values',
		update=update_cr_reset_all)
	
	# CURVE SETTINGS  __________________________________________________

	cr_radius: bpy.props.FloatProperty(
		name='Radius', 
		default=0.1,
		description='Cable Radius',
		precision=3, 
		min=0, 
		step=0.2,
	)

	cr_resolution_u: bpy.props.IntProperty(
		name='Curve Resolution', 
		default=24, 
		min=1,
		soft_max=64,
		max=1024,
	)

	cr_bevel_resolution: bpy.props.IntProperty(
		name='Bevel Resolution', 
		default=4, 
		min=0,
		max=32,
	)

	# HANDLE SETTINGS  __________________________________________________

	cr_outer_handle_type: bpy.props.EnumProperty(name='Handle Algorithm', default='ADAPTIVE',
		items=[ ('ADAPTIVE', 'Adaptive', 'Desc'),
			('FIXED', 'Fixed', 'Desc'), ],
	)

	cr_adaptive_strength: bpy.props.FloatProperty(name='Adaptive Strength', default=0.5,
		description='Handle size grows the farther the curve\'s endpoints are from each other', 
		precision=2, step=1,
	)

	cr_handle_offset: bpy.props.FloatProperty(name='Handle Size', default=1, 
		description='Handle Size Multiplier',
		precision=3, step=0.1,
	)

	cr_mid_handle_type: bpy.props.EnumProperty(name='Mid Handle Type', default='ALIGNED',
		items=[ ('AUTO', 'Auto', 'Handle resizes automatically the farther it is from the adjacent points'),
			('ALIGNED', 'Aligned', 'Fixed middle handle'), ],
	)
	

	# GRAVITY  __________________________________________________

	cr_curve_sag: bpy.props.BoolProperty(name='Gravity', default=False,
		description='Simulate gravity',
		update=update_cr_curve_sag,
	)

	cr_sag_strength: bpy.props.FloatProperty(name='Strength', default=0.5, 
		description='Gravity Strength',
		precision=3, step=0.1,
	)

	
	# POST OPTIONS  __________________________________________________

	cr_keep_prev_sel: bpy.props.BoolProperty(name='Keep Previous Selection', default=True,
		description='Maintain the previous selection',
	)

	cr_enter_edit: bpy.props.BoolProperty(name='Enter Edit Mode', default=False,
		description='Enter Edit-mode after creating a cable',
	)


class OBJECT_OT_curvebasher_curve_raycast(bpy.types.Operator, CurveRaycastPropertyGroup):
	'''Curvebasher - Spawn a curve with enpoints that are facing the surface normal (uses raycast).

	armoredColony.com '''

	bl_idname = 'object.curvebasher_curve_raycast'
	bl_label  = 'Curvebasher Curve Raycast'
	bl_options = {'REGISTER', 'UNDO', 'PRESET'}

	def set_save_as_defaults(self, context):
		utils.properties.save_operator_properties_to_addon_preferences(self, CurveRaycastPropertyGroup)

	save_as_defaults: bpy.props.BoolProperty(
		name='Save as Defaults',
		default=False,
		description='Save the current settings as the new startup defaults for this operator',
		update=set_save_as_defaults,
		options={'SKIP_SAVE', 'HIDDEN'},  # Don't save the operator to the undo stack.
	)

	initialized: bpy.props.BoolProperty(
		default=False,
		options={'HIDDEN'},
		description=(
			'Used internally to check if the operator should use addon preferences '
			'for its property defaults the first time it runs.'
		),
	)

	def draw(self, context):
		self.draw_custom(context, self.layout)
	
	def draw_custom(self, context, layout: bpy.types.UILayout):
		'''
		Same as draw() but takes in a custom layout element, which allows more control 
		when called from the addon preferences.
		'''

		def find_curve_segments():
			return utils.curve_utils.resolution_u_to_segments(3, self.cr_resolution_u)
		
		def find_curve_sides():
			return utils.curve_utils.bevel_resolution_to_sides(self.cr_bevel_resolution)

		layout.use_property_split = True
		col = layout.column(align=True)

		row = col.row(heading='RESET')
		row.prop(self, 'cr_reset_handles', toggle=True)
		row.prop(self, 'cr_reset_all', toggle=True)
		col.separator(factor=1.5)
		
		col.prop(self, 'cr_radius')
		col.separator(factor=1.5)

		row = col.row()
		row.prop(self, 'cr_outer_handle_type', expand=True)
		sub1 = col.row()
		sub1.enabled = True if self.cr_outer_handle_type == 'ADAPTIVE' else False
		sub1.prop(self, 'cr_adaptive_strength')

		col.prop(self, 'cr_handle_offset')
		col.separator(factor=1.5)

		col.prop(self, 'cr_curve_sag', toggle=True)
		sub2 = col.column(align=True)
		sub2.enabled = True if self.cr_curve_sag else False
		sub2.prop(self, 'cr_sag_strength')
		col.separator(factor=1.5)

		row = col.row()
		row.prop(self, 'cr_mid_handle_type', expand=True)
		col.separator(factor=1.5)
		
		row = col.row()
		row.prop(self, 'cr_resolution_u')
		row.label(text=f' = {find_curve_segments()} segments')
		row = col.row()
		row.prop(self, 'cr_bevel_resolution')
		row.label(text=f' = {find_curve_sides()} sides')
		col.separator(factor=1.5)

		col.prop(self, 'cr_keep_prev_sel')
		col.separator(factor=1.5)

		col.prop(self, 'cr_enter_edit')
		col.separator(factor=1.5)

		col.use_property_split = False
		if hasattr(self, 'save_as_defaults'):
			col.prop(self, 'save_as_defaults', toggle=True, icon='FILE_TICK')
		
	def invoke(self, context, event):
		# if context.mode != 'OBJECT':
			# bpy.ops.object.mode_set(mode='OBJECT')
		if utils.addon.get_prefs().cr_undo_push:
			bpy.ops.ed.undo_push()
		
		if not self.initialized:
			utils.properties.load_defaults_from_addon_preferences(self, CurveRaycastPropertyGroup)
			self.initialized = True
		
		self._key_type = event.type
		self._key_value = event.value
		self._counter = 0
		self._locations = list()
		self._rotations = list()
		self._normals = list()
		self._marker = None

		# self.curve = curve_utils.new_bezier(self, context, handle_type='FREE')

		context.window.cursor_modal_set('PAINT_CROSS')  # modal_set to work better

		context.window_manager.modal_handler_add(self)
		# bpy.ops.ed.undo_push()
		return {'RUNNING_MODAL'}

	def modal(self, context, event):

		if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and not event.alt:

			loc, normal = utils.raycast.cursorcast(context, rot_as_vector=True)

			self._locations.append(loc)
			self._normals.append(normal)
			
			self._counter += 1
			
			if self._counter == 1:
				radius = self.cr_radius * utils.addon.get_prefs().curve_scale
				self._marker = utils.curve_utils.circle_marker(
					self, context, name='P1', radius=radius, location=loc, normal=normal)
				
			elif self._counter >= 2:
				utils.objects.delete_object_data(self._marker)
				context.window.cursor_modal_restore()

				# EXECUTE >>
				return self.execute(context)

		# Blender or Maya Navigation.
		elif (  
			event.type in {'MIDDLEMOUSE', 'WHEELUPMOUSE', 'WHEELDOWNMOUSE' } or 
			(event.type in {'LEFTMOUSE', 'MIDDLEMOUSE', 'RIGHTMOUSE', 'MOUSEMOVE'} and event.alt) or 
			event.type in {'F', 'NUMPAD_PERIOD'}
		):
			return {'PASS_THROUGH'}
		

		# Cancel or Operator's Shortcut Key pressed again.
		elif (event.type in {'RIGHTMOUSE', 'ESC'} or
			event.type == self._key_type and event.value == self._key_value):

			utils.objects.delete_object_data(self._marker)
			context.window.cursor_modal_restore()

			self.report({'OPERATOR'}, 'CANCELLED')
			return {'CANCELLED'}

		return {'RUNNING_MODAL'}

	def execute(self, context):
		curve = utils.curve_utils.new_normal_handle_bezier(
			context, 
			self.cr_radius, 
			self.cr_resolution_u, 
			self.cr_bevel_resolution, 
			self.cr_handle_offset,
			self.cr_mid_handle_type,
			self.cr_outer_handle_type,
			self.cr_adaptive_strength,
			self.cr_curve_sag, 
			self.cr_sag_strength,
			self.cr_keep_prev_sel, 
			self._locations, 
			self._normals,
		)
	# self, context, self._locations, self._normals)
		
		curve.select_set(True)
		context.view_layer.objects.active = curve

		if self.cr_enter_edit:
			prev_sel = context.selected_objects
			bpy.ops.object.select_all(action='DESELECT')

			bpy.ops.object.mode_set(mode='EDIT')

			for ob in prev_sel:
				ob.select_set(True)
		
		if self.save_as_defaults:
			self.save_as_defaults = False
			self.report({'INFO'}, 'Settings Saved as Defaults')

		return {'FINISHED'}


classes = (
	OBJECT_OT_curvebasher_curve_raycast,
)

def register():
	for cls in classes:
		bpy.utils.register_class(cls)
	

def unregister():
	for cls in classes:
		bpy.utils.unregister_class(cls)
