from . import (
	curvebasher_modal_editor,
	curvebasher_wire_generator,
	curvebasher_curve_raycast,
	curvebasher_mesh_to_curve,
	curvebasher_draw_curve_tool,
)


import bpy


modules = [mod for mod in locals().values() if getattr(mod, '__package__', '').startswith(__package__)]


def register():
	for module in modules:
		if hasattr(module, 'register'):
			module.register()


def unregister():
	for module in modules:
		if hasattr(module, 'unregister'):
			module.unregister()