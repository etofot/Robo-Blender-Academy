# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

bl_info = {
	'name': 'Random Flow',
	'author': 'Ian Lloyd Dela Cruz',
	'version': (4, 1, 5),
	'blender': (5, 2, 0),
	'location': '3d View > Tool shelf',
	'description': 'Collection of random greebling functionalities',
	'warning': '',
	'wiki_url': '',
	'doc_url': 'https://www.blenderguppy.com/add-ons/random-flow',
	'tracker_url': 'https://www.blenderguppy.com/add-ons/help-and-support',
	'category': 'Mesh'}

import bpy
from . import operators
from . import utils
from . import ui
from . import preferences

def register():
	import os

	operators.register()
	ui.register()
	preferences.register()

	# presets
	if register_preset_path := getattr(bpy.utils, "register_preset_path", None):
		register_preset_path(os.path.join(os.path.dirname(__file__)))

def unregister():
	import os

	preferences.unregister()
	ui.unregister()
	operators.unregister()

	# presets
	if unregister_preset_path := getattr(bpy.utils, "unregister_preset_path", None):
		unregister_preset_path(os.path.join(os.path.dirname(__file__)))