import bpy
op = bpy.context.active_operator

op.scatter_type = 'CUBE'
op.mesh_name = ''
op.meshes.clear()
op.coll_name = ''
op.collections.clear()
item_sub_1 = op.collections.add()
item_sub_1.name = 'Collection'
op.coll_seed = 1
op.scatter_seed = 1
op.scatter_points = 500
op.sca_mode = 'AXIS'
op.cuts_base = 0
op.cuts_smooth = 0
op.cuts_fractal = 0
op.cuts_seed = 1
op.uni_size = 0.5
op.size_min = 0.05000000074505806
op.size_max = 0.30000001192092896
op.size_seed = 1
op.scale_max = (2.0, 2.0, 2.0)
op.scale_min = (0.10000000149011612, 0.10000000149011612, 0.10000000149011612)
op.scale_seed = (2, 2, 2)
op.rot_mode = 'FREE'
op.rot_axis = (0.0, 0.0, 0.0)
op.rot_seed = (2, 2, 2)
op.explode_min = 0.0
op.explode_max = 0.0
op.explode_seed = 1
op.cluster = 0.0
op.margin = 0.0
op.offset = 0.0
op.mat_index = -1
op.use_mirror = True
op.single_scatter = True
op.follow_normal = True
op.track_normal = False
op.no_overlap = False
op.use_convex_hull = True
op.use_dissolve = False
op.angle = 0.0872664600610733
