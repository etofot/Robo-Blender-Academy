import bpy
op = bpy.context.active_operator

op.vcname = 'Vertex Color'
op.vclist = ''
op.vcolors.clear()
op.color_max = (1.0, 1.0, 1.0)
op.color_min = (0.0, 0.0, 0.0)
op.limit = 'OBJECT'
op.col_seed = 1
op.sat_min = 1.0
op.sat_max = 1.0
op.sat_seed = 1
op.val_min = 0.699999988079071
op.val_max = 0.8999999761581421
op.val_seed = 1
op.offset = 1
op.obj_offset = 1
op.single_color = False
op.use_hg = set()
op.col_hg_stops = 2
op.sat_hg_stops = 2
op.val_hg_stops = 2
op.mark_sharp = False
op.sharpness = 0.5235987901687622
op.dirty_vc = False
op.blur_str = 1.0
op.blur_iter = 1
op.hi_angle = 1.5707963705062866
op.drt_angle = 0.0
op.drt_only = False
op.normalize = True
