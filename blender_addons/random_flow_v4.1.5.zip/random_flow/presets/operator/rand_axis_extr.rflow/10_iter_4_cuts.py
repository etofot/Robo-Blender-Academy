import bpy
op = bpy.context.active_operator

op.cuts_base = 0
op.loops_iter = 10
op.extr_offset = (5, 5, 5)
op.loop_offset = (0.5, 0.5, 0.5)
op.axis_order1 = 'X'
op.axis_order2 = 'Y'
op.axis_order3 = 'Z'
op.axis_loop = (5, 5, 5)
op.loop_seed = (1, 1, 1)
op.globl_seed = 19
op.min_length = (1.0, 1.0, 1.0)
op.depth_max = (0.5, 0.5, 0.5)
op.depth_min = (0.10000000149011612, 0.10000000149011612, 0.10000000149011612)
op.depth_seed = (1, 1, 1)
op.inner_cut = (4, 4, 4)
op.scale_max = (1.0, 1.0, 1.0)
op.scale_min = (1.0, 1.0, 1.0)
op.scale_seed = (1, 1, 1)
op.threshold = (0.5, 0.5, 0.5)
op.scale_clipping = 9.999999747378752e-05
op.mat_index = -1
op.use_mirror = True
op.single_obj = False
op.hit_self = False
op.cut_symm = True
