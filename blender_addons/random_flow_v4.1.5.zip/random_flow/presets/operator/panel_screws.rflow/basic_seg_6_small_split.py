import bpy
op = bpy.context.active_operator

op.mesh_type = 'BASIC'
op.mesh_name = ''
op.meshes.clear()
item_sub_1 = op.meshes.add()
item_sub_1.name = 'Cube'
op.import_name = ''
op.import_meshes.clear()
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'captive01'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'captive02'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'phillips01'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'roundhead01'
op.coll_name = ''
op.collections.clear()
item_sub_1 = op.collections.add()
item_sub_1.name = 'Collection'
op.coll_seed = 1
op.margin = 0.014999999664723873
op.offset = 0.0
op.origin = 'FACES'
op.mode = 'ANGLE'
op.threshold = 0.5235987901687622
op.spacing = 0.5
op.radius = 0.004999999888241291
op.rot_z = 0.0
op.rot_seed = 2
op.depth = 0.00800000037997961
op.segment = 6
op.bvl_offset = 0.001500000013038516
op.bvl_seg = 1
op.birth_perc = 100.0
op.birth_seed = 1
op.mat_index = -1
op.per_face = False
op.use_split = True
op.use_mirror = True
op.tagged_only = False
op.use_dissolve = True
op.angle = 0.0872664600610733
