import bpy
op = bpy.context.active_operator

op.mesh_type = 'BASIC'
op.mesh_name = ''
op.meshes.clear()
item_sub_1 = op.meshes.add()
item_sub_1.name = 'Cube'
op.import_name = ''
op.import_meshes.clear()
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'cable_coupling01'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'cable_coupling02'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'flange01'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'flange02'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'flange03_hvy'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'flange04_hvy'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'flange05_caps'
item_sub_1 = op.import_meshes.add()
item_sub_1.name = 'flange06_caps'
op.coll_name = ''
op.collections.clear()
item_sub_1 = op.collections.add()
item_sub_1.name = 'Collection'
op.coll_seed = 1
op.amount = 2
op.spacing = 1.0
op.cap_offset = 0.0
op.bod_offset = 0.0
op.radius = 0.019999999552965164
op.rot_z = 0.0
op.rot_seed = 2
op.depth = 0.019999999552965164
op.segment = 6
op.mat_index = -1
op.limit = 'NONE'
op.even_count = True
