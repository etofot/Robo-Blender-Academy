# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

import bpy
from .preferences import *

def set_panel(self, col, open_state, name="", type=""):

	if bpy.app.version >= (4,2,3):
		header, panel = col.panel_prop(self, name)
		header.label(text=type)
	else:
		row = col.row().split(factor=0.1, align=True)
		row.prop(self, name, text="", emboss=False, toggle=True, icon="TRIA_DOWN" if open_state else "TRIA_RIGHT")
		row.label(text=type)
		panel = open_state

	return panel

def r_loop_extr_ui(self, context):

	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	col.row(align=True).prop(self, "redo_page", expand=True)
	if self.redo_page == '1':
		panel = set_panel(self, col, self.solver_open_state, "solver_open_state", "Solver")
		if panel:
			col.label(text="Solver: 1. Walk 2. Radial 3. Square 4. Maze")
			col.row(align=True).prop(self, "lsolver_num", text="")
			col.label(text="Path: 1. None 2. Shortest 3. Longest (Walk Only)")
			col.row(align=True).prop(self, "lpath_num", text="")
		panel = set_panel(self, col, self.loops_open_state, "loops_open_state", "Loop Objects, Ratio and Size")
		if panel:
			col.label(text="Loops | Ratio | Seed" + (" " * 1) + "(shift+click to add multiple or remove)")
			col.row(align=True).prop(self, "loop_objs", expand=True)
			col.row(align=True).prop(self, "lratio", text="")
			col.row(align=True).prop(self, "invert_ratio", expand=True)
			col.row(align=True).prop(self, "lratio_seed", text="")
			col.row(align=True).prop(self, "globl_seed1")
			if self.size_mode == 'PERCENT':
				col.label(text="Loops Panel Size (Percent) Max | Min")
				col.row(align=True).prop(self, "lsize01_max", text="")
				col.row(align=True).prop(self, "lsize01_min", text="")
			else:
				col.label(text="Loops Panel Size (Number) Max | Min")
				col.row(align=True).prop(self, "lsize02_max", text="")
				col.row(align=True).prop(self, "lsize02_min", text="")
		panel = set_panel(self, col, self.extr_open_state, "extr_open_state", "Extrude")
		if panel:
			col.label(text="Loops Inset Depth Max | Min | Seed")
			col.row(align=True).prop(self, "ldepth_max", text="")
			col.row(align=True).prop(self, "ldepth_min", text="")
			col.row(align=True).prop(self, "ldepth_seed", text="")
			col.row(align=True).prop(self, "globl_seed2")
			col.label(text="Loops Inset Thickness")
			col.row(align=True).prop(self, "lthick", text="")
		panel = set_panel(self, col, self.subd_open_state, "subd_open_state", "Subdivision")
		if panel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Subdivision:")
			row.row(align=True).prop(self, "cuts_base")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Smoothing:")
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "cuts_smooth")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "smooth_iter")
			split2.prop(self, "base_smooth", text="", icon="MESH_UVSPHERE")
			col.label(text="Loops Subdivision")
			col.row(align=True).prop(self, "loop_subdv", text="")
	else:
		panel = set_panel(self, col, self.global_open_state, "global_open_state", "Global Settings")
		if panel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Size Mode:")
			row.row(align=True).prop(self, "size_mode", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Join Tris:")
			row.row(align=True).prop(self, "join_tris", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Even Offset:")
			row.row(align=True).prop(self, "even_offset", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Cut Method:")
			row.row(align=True).prop(self, "cut_method", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Cut Angle:")
			row.row(align=True).prop(self, "cut_threshold", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Clear Faces:")
			row.row(align=True).prop(self, "clear_faces", expand=True)
		panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
		if panel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Split Crease:")
			row.row(align=True).prop(self, "split_crease", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Triangulate:")
			if self.size_mode == 'PERCENT':
				row.row(align=True).prop(self, "tri_perc", text="")
			else:
				row.row(align=True).prop(self, "tri_num", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Material Index:")
			row.row(align=True).prop(self, "mat_index", text="")
			flow = col.column_flow(columns=2, align=True)
			flow.prop(self, "use_mirror")
			flow.prop(self, "rand_inset")
			flow.prop(self, "orig_only")
			flow.prop(self, "inset_vgroup")
			row = col.row().split(factor=0.5, align=True)
			row.prop(self, "use_clip")
			if self.use_clip:
				row.row(align=True).prop(self, "clip_axis", text="", expand=True)
				col.prop(self, "clip_dist")
			col.prop(self, "use_dissolve")
			if self.use_dissolve:
				col.prop(self, "angle")

def r_panels_ui(self, context):

	obj = context.active_object
	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	if self.panel_type != 'BEVEL':
		col.row(align=True).prop(self, "redo_page", expand=True)
	if self.redo_page == '1':
		panel = set_panel(self, col, self.solver_open_state, "solver_open_state", "Solver")
		if panel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Type:")
			row.row(align=True).prop(self, "panel_type", expand=True)
			if self.panel_type in ['INSET', 'BEVEL']:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Solver:")
				row.row(align=True).prop(self, "solver", expand=True)
				if not self.solver in ['RADIAL', 'SQUARE', 'MAZE']:
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Path:")
					row.row(align=True).prop(self, "path", expand=True)
		panel = set_panel(self, col, self.panel_open_state, "panel_open_state", "Panel")
		if panel:
			if self.panel_type in ['INSET', 'SHARP']:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Panel Amount:")
				split1 = row.split(factor=0.8, align=True)
				split1.row(align=True).prop(self, "panel_amount", text="")
				split2 = split1.split(factor=0.5, align=True)
				split2.prop(self, "invert_panel_amount", text="", icon="ARROW_LEFTRIGHT")
				split2.prop(self, "remove_panels", text="", icon="STICKY_UVS_DISABLE")
			if self.panel_type in ['INSET', 'BEVEL']:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Panel Size:")
				split = row.split(factor=0.5, align=True)
				if self.size_mode == 'PERCENT':
					split.row(align=True).prop(self, "panel_min_perc", text="Min")
					split.row(align=True).prop(self, "panel_max_perc", text="Max")
				else:
					split.row(align=True).prop(self, "panel_min_num", text="Min")
					split.row(align=True).prop(self, "panel_max_num", text="Max")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Size Mode:")
				row.row(align=True).prop(self, "size_mode", expand=True)
			if self.panel_type in ['INSET', 'SHARP']:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Inset Clear:")
				row.row(align=True).prop(self, "inset_clear", expand=True)
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Cut Method:")
				row.row(align=True).prop(self, "cut_method", expand=True)
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Cut Angle:")
				row.row(align=True).prop(self, "cut_threshold", text="")
			if self.panel_type == 'INSET':
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Face Tags:")
				split1 = row.split(factor=0.8, align=True)
				split1.row(align=True).prop(self, "use_face_tags", expand=True)
				split2 = split1.split(factor=0.5, align=True)
				split2.prop(self, "invert_tags", text="", icon="ARROW_LEFTRIGHT")
				split2.prop(self, "sharpen_tags", text="", icon="MOD_EDGESPLIT")
				if self.use_face_tags == 'ON':
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Uniform Split:")
					row.row(align=True).prop(self, "uniform_split", expand=True)
			if self.panel_type in ['INSET', 'BEVEL', 'SKIN']:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Join Tris:")
				row.row(align=True).prop(self, "join_tris", expand=True)
				if self.merge_pnl:
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Sharpen Border:")
					row.row(align=True).prop(self, "border_sharp", expand=True)
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Panel Seed:")
				row.row(align=True).prop(self, "edge_seed", text="")
		panel = set_panel(self, col, self.subd_open_state, "subd_open_state", "Subdivision")
		if panel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Subdivision:")
			row.row(align=True).prop(self, "cuts_base")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Pre Smoothing:")
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "pre_cuts_smooth")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "pre_smooth_iter")
			split2.prop(self, "pre_area_smooth", text="", icon="OBJECT_HIDDEN")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Post Smoothing:")
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "post_cuts_smooth")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "post_smooth_iter")
			split2.prop(self, "post_area_smooth", text="", icon="OBJECT_HIDDEN")
			col.separator(factor=0.5)
			col.prop(self, "smooth_boundary")
		if self.panel_type in ['INSET', 'SHARP', 'SKIN']:
			panel = set_panel(self, col, self.inset_open_state, "inset_open_state", "Extrude")
			if panel:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Thickness:")
				if self.uni_thickness:
					split = row.split(factor=0.9, align=True)
					split.row(align=True).prop(self, "thickness", text="")
					split.prop(self, "uni_thickness", text="", icon="LINKED")
				else:
					split1 = row.split(factor=0.5, align=True)
					split1.row(align=True).prop(self, "thickness_min")
					split2 = split1.split(factor=0.8, align=True)
					split2.row(align=True).prop(self, "thickness_max")
					split2.prop(self, "uni_thickness", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Thickness Seed:")
					row.row(align=True).prop(self, "thickness_seed", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Even Depth:")
				row.row(align=True).prop(self, "even_offset", expand=True)
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Depth:")
				if self.uni_depth:
					split = row.split(factor=0.9, align=True)
					split.row(align=True).prop(self, "depth", text="")
					split.prop(self, "uni_depth", text="", icon="LINKED")
				else:
					split1 = row.split(factor=0.5, align=True)
					split1.row(align=True).prop(self, "depth_min")
					split2 = split1.split(factor=0.8, align=True)
					split2.row(align=True).prop(self, "depth_max")
					split2.prop(self, "uni_depth", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Depth Seed:")
					row.row(align=True).prop(self, "depth_seed", text="")
					if self.use_face_tags == 'ON' \
						and self.uniform_split == 'ON':
						row = col.row().split(factor=0.27, align=True)
						row.label(text="Split Mask:")
						split = row.split(factor=0.5, align=True)
						split.row(align=True).prop(self, "split_thickness", text="Thick")
						split.row(align=True).prop(self, "split_depth", text="Depth")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Margin:")
				if self.merge_pnl:
					split = row.split(factor=0.5, align=True)
					split.row(align=True).prop(self, "margin_indent")
					split.row(align=True).prop(self, "margin_outdent")
				else:
					row.row(align=True).prop(self, "margin", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Margin Proc:")
				row.row(align=True).prop(self, "margin_perc", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Margin Seed:")
				row.row(align=True).prop(self, "margin_seed", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Offset:")
				row.row(align=True).prop(self, "offset_faces", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Clear Faces:")
				row.row(align=True).prop(self, "clear_faces", expand=True)
				if self.panel_type  == 'INSET' and self.use_skin == 'OFF':
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Mark Only:")
					row.row(align=True).prop(self, "mark_only", expand=True)
		else:
			panel = set_panel(self, col, self.inset1_open_state, "inset1_open_state", "Bevel")
			if panel:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Width")
				row.row(align=True).prop(self, "pnl_width", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Offset:")
				row.row(align=True).prop(self, "pnl_offset", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Cut Method:")
				row.row(align=True).prop(self, "cut_method", expand=True)
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Cut Angle:")
				row.row(align=True).prop(self, "cut_threshold", text="")
			panel = set_panel(self, col, self.notch_open_state, "notch_open_state", "Notches")
			if panel:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Notches:")
				split = row.split(factor=0.5, align=True)
				split.row(align=True).prop(self, "notch_count")
				split.row(align=True).prop(self, "notch_size")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Notch Seed:")
				row.row(align=True).prop(self, "notch_seed", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Size Mode:")
				row.row(align=True).prop(self, "size_mode", expand=True)
			panel = set_panel(self, col, self.aux1_open_state, "aux1_open_state", "Auxiliary")
			if panel:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Triangulate:")
				if self.size_mode == 'PERCENT':
					row.row(align=True).prop(self, "tri_perc", text="")
				else:
					row.row(align=True).prop(self, "tri_num", text="")
				col.separator(factor=0.5)
				col.prop(self, "split_borders")
				col.prop(self, "margin_bounds")
				col.prop(self, "cut_symm")
	else:
		if self.panel_type != 'SHARP':
			panel = set_panel(self, col, self.notch_open_state, "notch_open_state", "Notches")
			if panel:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Notches:")
				split = row.split(factor=0.5, align=True)
				split.row(align=True).prop(self, "notch_count")
				split.row(align=True).prop(self, "notch_size")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Notch Seed:")
				row.row(align=True).prop(self, "notch_seed", text="")
		panel = set_panel(self, col, self.skin_open_state, "skin_open_state", "Skin")
		if panel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Use Skin:")
			row.row(align=True).prop(self, "use_skin", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Depth:")
			row.row(align=True).prop(self, "skin_depth", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Offset:")
			row.row(align=True).prop(self, "skin_offset", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Resolution:")
			row.row(align=True).prop(self, "skin_resolution", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Bevel Offset:")
			row.row(align=True).prop(self, "bevel_width", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Bevel Segments:")
			row.row(align=True).prop(self, "bevel_segments", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Bevel Profile:")
			row.row(align=True).prop(self, "bevel_profile", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Bevel Threshold:")
			row.row(align=True).prop(self, "bevel_threshold", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Root Seed:")
			row.row(align=True).prop(self, "root_seed", text="")
			col.separator(factor=0.5)
			col.prop(self, "skin_smooth")
			col.prop(self, "bevel_clamp")
		if self.panel_type != 'BEVEL':
			panel = set_panel(self, col, self.bevel_open_state, "bevel_open_state", "Bevel")
			if panel:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Bevel Mode:")
				row.row(align=True).prop(self, "bevel_mode", expand=True)
				if self.bevel_mode == 'CORNER':
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Bevel Offset:")
					if self.uni_bevel:
						split = row.split(factor=0.9, align=True)
						split.row(align=True).prop(self, "bvl_offset_uni", text="")
						split.prop(self, "uni_bevel", text="", icon="LINKED")
					else:
						split1 = row.split(factor=0.5, align=True)
						split1.row(align=True).prop(self, "bvl_offset_min")
						split2 = split1.split(factor=0.8, align=True)
						split2.row(align=True).prop(self, "bvl_offset_max")
						split2.prop(self, "uni_bevel", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Bvl Seg/Angle:")
					split = row.split(factor=0.5, align=True)
					split.row(align=True).prop(self, "bvl_seg")
					split.row(align=True).prop(self, "bvl_angle")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Bevel Seed:")
					row.row(align=True).prop(self, "bvl_seed", text="")
				else:
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Bevel Offset:")
					if self.uni_bevel_sharp:
						split = row.split(factor=0.9, align=True)
						split.row(align=True).prop(self, "bvl_sharp_uni", text="")
						split.prop(self, "uni_bevel_sharp", text="", icon="LINKED")
					else:
						split1 = row.split(factor=0.5, align=True)
						split1.row(align=True).prop(self, "bvl_sharp_min")
						split2 = split1.split(factor=0.8, align=True)
						split2.row(align=True).prop(self, "bvl_sharp_max")
						split2.prop(self, "uni_bevel_sharp", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Bvl Seg/Angle:")
					split = row.split(factor=0.5, align=True)
					split.row(align=True).prop(self, "bvl_sharp_seg")
					split.row(align=True).prop(self, "bvl_sharp_angle")
					if not self.uni_bevel_sharp:
						row = col.row().split(factor=0.27, align=True)
						row.label(text="Bevel Seed:")
						row.row(align=True).prop(self, "bvl_sharp_seed", text="")
					col.prop(self, "harden_normals")
					col.prop(self, "clamp_overlap")
			panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
			if panel:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Split Crease:")
				row.row(align=True).prop(self, "split_crease", expand=True)
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Triangulate:")
				if self.size_mode == 'PERCENT':
					row.row(align=True).prop(self, "tri_perc", text="")
				else:
					row.row(align=True).prop(self, "tri_num", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Material Index:")
				row.row(align=True).prop(self, "mat_index", text="")
				col.separator(factor=0.5)
				flow = col.column_flow(columns=2, align=True)
				flow.prop(self, "use_mirror")
				flow.prop(self, "merge_pnl")
				flow.prop(self, "inset_vgroup")
				flow.prop(self, "floater_set")
				row = col.row().split(factor=0.5, align=True)
				row.prop(self, "use_clip")
				if self.use_clip:
					row.row(align=True).prop(self, "clip_axis", text="", expand=True)
					col.prop(self, "clip_dist")
				col.prop(self, "use_dissolve")
				if self.use_dissolve:
					col.prop(self, "angle")

def r_slice_ui(self, context):

	obj = context.active_object
	mesh = obj.data

	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.solver_open_state, "solver_open_state", "Solver")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Solver:")
		row.row(align=True).prop(self, "solver", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Direction:")
		flow = row.column_flow(columns=2, align=True)
		flow.prop(self, "direction", expand=True)
		if self.direction == 'TANGENT':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Tangent:")
			row.row(align=True).prop(self, "tangent_idx", text="")
		if self.direction == 'XYZ':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Axis:")
			row.row(align=True).prop(self, "axis", text="", emboss=True, toggle=True)
	panel = set_panel(self, col, self.cuts_open_state, "cuts_open_state", "Cuts")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cut Amount:")
		row.row(align=True).prop(self, "cut_range", text="")
		if self.solver == 'RAND':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Min Length:")
			row.row(align=True).prop(self, "min_length", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Slide:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "slide_min")
		split.row(align=True).prop(self, "slide_max")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Distance:")
		row.row(align=True).prop(self, "bisect_dist", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cut Seed:")
		row.row(align=True).prop(self, "cut_seed", text="")
	panel = set_panel(self, col, self.extr_open_state, "extr_open_state", "Extrude")
	if panel:
		if mesh.is_editmode:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Mode:")
			row.row(align=True).prop(self, "mode", expand=True)
		if self.mode == 'SPLIT' \
			or not mesh.is_editmode:
			if not self.use_wire:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Thickness:")
				if self.uni_thickness:
					split = row.split(factor=0.9, align=True)
					split.row(align=True).prop(self, "thickness", text="")
					split.prop(self, "uni_thickness", text="", icon="LINKED")
				else:
					split1 = row.split(factor=0.5, align=True)
					split1.row(align=True).prop(self, "thickness_min")
					split2 = split1.split(factor=0.8, align=True)
					split2.row(align=True).prop(self, "thickness_max")
					split2.prop(self, "uni_thickness", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Thickness Seed:")
					row.row(align=True).prop(self, "thickness_seed", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Even Depth:")
				row.row(align=True).prop(self, "even_offset", expand=True)
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Depth:")
				if self.uni_depth:
					split = row.split(factor=0.9, align=True)
					split.row(align=True).prop(self, "depth", text="")
					split.prop(self, "uni_depth", text="", icon="LINKED")
				else:
					split1 = row.split(factor=0.5, align=True)
					split1.row(align=True).prop(self, "depth_min")
					split2 = split1.split(factor=0.8, align=True)
					split2.row(align=True).prop(self, "depth_max")
					split2.prop(self, "uni_depth", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Depth Seed:")
					row.row(align=True).prop(self, "depth_seed", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Inner Margin:")
				if self.uni_inner_margin:
					split = row.split(factor=0.9, align=True)
					split.row(align=True).prop(self, "inner_margin", text="")
					split.prop(self, "uni_inner_margin", text="", icon="LINKED")
				else:
					split1 = row.split(factor=0.5, align=True)
					split1.row(align=True).prop(self, "inner_margin_min")
					split2 = split1.split(factor=0.8, align=True)
					split2.row(align=True).prop(self, "inner_margin_max")
					split2.prop(self, "uni_inner_margin", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Margin Seed:")
					row.row(align=True).prop(self, "inner_margin_seed", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Outer Margin:")
				if self.uni_outer_margin:
					split = row.split(factor=0.9, align=True)
					split.row(align=True).prop(self, "outer_margin", text="")
					split.prop(self, "uni_outer_margin", text="", icon="LINKED")
				else:
					split1 = row.split(factor=0.5, align=True)
					split1.row(align=True).prop(self, "outer_margin_min")
					split2 = split1.split(factor=0.8, align=True)
					split2.row(align=True).prop(self, "outer_margin_max")
					split2.prop(self, "uni_outer_margin", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Margin Seed:")
					row.row(align=True).prop(self, "outer_margin_seed", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Scale:")
				if self.uni_scale:
					split = row.split(factor=0.9, align=True)
					split.row(align=True).prop(self, "scale", text="")
					split.prop(self, "uni_scale", text="", icon="LINKED")
				else:
					split1 = row.split(factor=0.5, align=True)
					split1.row(align=True).prop(self, "scale_min")
					split2 = split1.split(factor=0.8, align=True)
					split2.row(align=True).prop(self, "scale_max")
					split2.prop(self, "uni_scale", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Scale Seed:")
					row.row(align=True).prop(self, "scale_seed", text="")
				if self.direction != 'FACE':
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Rotation:")
					row.row(align=True).prop(self, "cut_rot", text="")
			else:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Thickness:")
				row.row(align=True).prop(self, "wire_thickness", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Offset:")
				row.row(align=True).prop(self, "wire_offset", text="")
		else:
			if self.use_inset:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Thickness:")
				if self.uni_thickness:
					split = row.split(factor=0.9, align=True)
					split.row(align=True).prop(self, "thickness", text="")
					split.prop(self, "uni_thickness", text="", icon="LINKED")
				else:
					split1 = row.split(factor=0.5, align=True)
					split1.row(align=True).prop(self, "thickness_min")
					split2 = split1.split(factor=0.8, align=True)
					split2.row(align=True).prop(self, "thickness_max")
					split2.prop(self, "uni_thickness", text="", icon="UNLINKED")
					row = col.row().split(factor=0.27, align=True)
					row.label(text="Thickness Seed:")
					row.row(align=True).prop(self, "thickness_seed", text="")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Even Depth:")
				row.row(align=True).prop(self, "even_offset", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Depth:")
			if self.uni_depth:
				split = row.split(factor=0.9, align=True)
				split.row(align=True).prop(self, "depth", text="")
				split.prop(self, "uni_depth", text="", icon="LINKED")
			else:
				split1 = row.split(factor=0.5, align=True)
				split1.row(align=True).prop(self, "depth_min")
				split2 = split1.split(factor=0.8, align=True)
				split2.row(align=True).prop(self, "depth_max")
				split2.prop(self, "uni_depth", text="", icon="UNLINKED")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Depth Seed:")
				row.row(align=True).prop(self, "depth_seed", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Inner Margin:")
			if self.uni_inner_margin:
				split = row.split(factor=0.9, align=True)
				split.row(align=True).prop(self, "inner_margin", text="")
				split.prop(self, "uni_inner_margin", text="", icon="LINKED")
			else:
				split1 = row.split(factor=0.5, align=True)
				split1.row(align=True).prop(self, "inner_margin_min")
				split2 = split1.split(factor=0.8, align=True)
				split2.row(align=True).prop(self, "inner_margin_max")
				split2.prop(self, "uni_inner_margin", text="", icon="UNLINKED")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Inner Margin Seed:")
				row.row(align=True).prop(self, "inner_margin_seed", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Outer Margin:")
			if self.uni_outer_margin:
				split = row.split(factor=0.9, align=True)
				split.row(align=True).prop(self, "outer_margin", text="")
				split.prop(self, "uni_outer_margin", text="", icon="LINKED")
			else:
				split1 = row.split(factor=0.5, align=True)
				split1.row(align=True).prop(self, "outer_margin_min")
				split2 = split1.split(factor=0.8, align=True)
				split2.row(align=True).prop(self, "outer_margin_max")
				split2.prop(self, "uni_outer_margin", text="", icon="UNLINKED")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Margin Seed:")
				row.row(align=True).prop(self, "outer_margin_seed", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Scale:")
			if self.uni_scale:
				split = row.split(factor=0.9, align=True)
				split.row(align=True).prop(self, "scale", text="")
				split.prop(self, "uni_scale", text="", icon="LINKED")
			else:
				split1 = row.split(factor=0.5, align=True)
				split1.row(align=True).prop(self, "scale_min")
				split2 = split1.split(factor=0.8, align=True)
				split2.row(align=True).prop(self, "scale_max")
				split2.prop(self, "uni_scale", text="", icon="UNLINKED")
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Scale Seed:")
				row.row(align=True).prop(self, "scale_seed", text="")
			if self.direction != 'FACE':
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Rotation:")
				row.row(align=True).prop(self, "cut_rot", text="")
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		if self.mode == 'SPLIT' \
			or not mesh.is_editmode:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Material Index:")
			row.row(align=True).prop(self, "mat_index", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Proc:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "proc_perc")
		split.row(align=True).prop(self, "proc_seed")
		flow = col.column_flow(columns=2, align=True)
		if not mesh.is_editmode:
			flow.prop(self, "use_mirror")
		if self.mode == 'SPLIT' \
			or not mesh.is_editmode:
			flow.prop(self, "use_wire")
			if self.use_wire:
				flow = col.column_flow(columns=2, align=True)
				flow.prop(self, "floater_set")
				flow.prop(self, "use_bounds")
		if self.mode == 'MERGE' \
			and mesh.is_editmode: col.prop(self, "use_inset")
		if self.mirror:
			row = col.row().split(factor=0.5, align=True)
			row.prop(self, "use_clip")
			if self.use_clip:
				row.row(align=True).prop(self, "clip_axis", text="", expand=True)
				col.prop(self, "clip_dist")
		col.prop(self, "use_dissolve")
		if self.use_dissolve:
			col.prop(self, "angle")

def r_axis_extr_ui(self, context):

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.cuts_open_state, "cuts_open_state", "Cuts")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Base Cut:")
		row.row(align=True).prop(self, "cuts_base", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Inner Cut:")
		row.row(align=True).prop(self, "inner_cut", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Iteration:")
		row.row(align=True).prop(self, "loops_iter", text="")
	panel = set_panel(self, col, self.loops_open_state, "loops_open_state", "Loops")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Source Extrude:")
		row.row(align=True).prop(self, "extr_offset", text="")
		row = col.row().split(factor=0.28, align=True)
		row.label(text="Axis Order:")
		row.row(align=True).prop(self, "axis_order1", text="")
		row.row(align=True).prop(self, "axis_order2", text="")
		row.row(align=True).prop(self, "axis_order3", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Axis Loop:")
		row.row(align=True).prop(self, "axis_loop", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Loop Seed:")
		row.row(align=True).prop(self, "loop_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Global Seed:")
		row.row(align=True).prop(self, "globl_seed", text="")
	panel = set_panel(self, col, self.extr_open_state, "extr_open_state", "Extrude")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Min Length:")
		row.row(align=True).prop(self, "min_length", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Depth Max:")
		row.row(align=True).prop(self, "depth_max", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Depth Min:")
		row.row(align=True).prop(self, "depth_min", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Depth Seed:")
		row.row(align=True).prop(self, "depth_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Threshold:")
		row.row(align=True).prop(self, "threshold", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Scale Max:")
		row.row(align=True).prop(self, "scale_max", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Scale Min:")
		row.row(align=True).prop(self, "scale_min", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Scale Seed:")
		row.row(align=True).prop(self, "scale_seed", text="")
		if self.mirror:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Scale Clipping:")
			row.row(align=True).prop(self, "scale_clipping", text="")
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Material Index:")
		row.row(align=True).prop(self, "mat_index", text="")
		col.separator(factor=0.5)
		flow = col.column_flow(columns=2, align=True)
		flow.prop(self, "use_mirror")
		flow.prop(self, "hit_self")
		if self.use_mirror:
			flow.prop(self, "cut_symm")
			if context.active_object.mode == 'OBJECT': flow.prop(self, "single_obj")
		else:
			flow.label(text="")

def r_cells_ui(self, context):

	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.pool_open_state, "pool_open_state", "Pool")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Size Mode:")
		row.row(align=True).prop(self, "size_mode", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Pool Size:")
		if self.size_mode == 'PERCENT':
			row.row(align=True).prop(self, "pool_size_perc", text="")
		else:
			row.row(align=True).prop(self, "pool_size_num", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Island Size:")
		row.row(align=True).prop(self, "island_size", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Minimum Size:")
		row.row(align=True).prop(self, "min_size", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Proc Size:")
		row.row(align=True).prop(self, "proc_size", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Proc Seed:")
		row.row(align=True).prop(self, "proc_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Pool Seed:")
		row.row(align=True).prop(self, "pool_seed", text="")
	panel = set_panel(self, col, self.subd_open_state, "subd_open_state", "Subdivision")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cut Method:")
		row.row(align=True).prop(self, "cut_method", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cut Angle:")
		row.row(align=True).prop(self, "cut_threshold", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Subdivision:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "cuts_base")
		split.row(align=True).prop(self, "cuts_smooth")
	panel = set_panel(self, col, self.extr_open_state, "extr_open_state", "Extrude")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Thickness:")
		row.row(align=True).prop(self, "thickness", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Depth:")
		row.row(align=True).prop(self, "depth", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Depth Seed:")
		row.row(align=True).prop(self, "depth_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Margin:")
		split = row.split(factor=0.5, align=True)
		split.prop(self, "inner_margin", text="Inner")
		split.prop(self, "outer_margin", text="Outer")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset Mode:")
		row.row(align=True).prop(self, "offset_mode", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset:")
		row.row(align=True).prop(self, "offset", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset Seed:")
		row.row(align=True).prop(self, "offset_seed", text="")
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Align Axis:")
		row.row(align=True).prop(self, "align_axis", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text=" ")
		row.label(text=(" " * 1) + "(shift+click to add multiple or remove)")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Align Threshold:")
		row.row(align=True).prop(self, "align_threshold", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Triangulate:")
		if self.size_mode == 'PERCENT':
			row.row(align=True).prop(self, "tri_perc", text="")
		else:
			row.row(align=True).prop(self, "tri_num", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Material Index:")
		row.row(align=True).prop(self, "mat_index", text="")
		col.separator(factor=0.5)
		flow = col.column_flow(columns=2, align=True)
		flow.prop(self, "use_mirror")
		flow.prop(self, "floater_set")
		flow.prop(self, "clear_adj")
		flow.prop(self, "use_emit")
		if self.offset_mode == 'INDIV' \
			or self.cut_method == 'INDIV':
			col.prop(self, "track_normal")

def r_scatter_ui(self, context):

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.point_open_state, "point_open_state", "Points")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Type:")
		row.row(align=True).prop(self, "scatter_type", expand=True)
		if self.scatter_type == 'MESH':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Mesh:")
			row.prop_search(
				self,
				"mesh_name",
				self,
				"meshes",
				text="",
				icon = "MESH_DATA"
				)
		if self.scatter_type == 'COLLECTION':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Collection:")
			row.prop_search(
				self,
				"coll_name",
				self,
				"collections",
				text="",
				icon = "OUTLINER_COLLECTION"
				)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Object Seed:")
			row.row(align=True).prop(self, "coll_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Points:")
		row.row(align=True).prop(self, "scatter_points", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Point Seed:")
		row.row(align=True).prop(self, "scatter_seed", text="")
	panel = set_panel(self, col, self.subd_open_state, "subd_open_state", "Subdivision")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cuts:")
		row.row(align=True).prop(self, "cuts_base", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Smooth:")
		row.row(align=True).prop(self, "cuts_smooth", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Fractal:")
		row.row(align=True).prop(self, "cuts_fractal", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Fractal Seed:")
		row.row(align=True).prop(self, "cuts_seed", text="")
	panel = set_panel(self, col, self.transf_open_state, "transf_open_state", "Transform")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Scale Mode:")
		row.row(align=True).prop(self, "sca_mode", expand=True)
		if self.sca_mode == 'UNIFORM':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Size:")
			row.row(align=True).prop(self, "uni_size", text="")
		else:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Size:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "size_min")
			split.row(align=True).prop(self, "size_max")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Size Seed:")
			row.row(align=True).prop(self, "size_seed", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Scale Max:")
			row.row(align=True).prop(self, "scale_max", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Scale Min:")
			row.row(align=True).prop(self, "scale_min", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Scale Seed:")
			row.row(align=True).prop(self, "scale_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Rotation Mode:")
		row.row(align=True).prop(self, "rot_mode", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Rotation:")
		row.row(align=True).prop(self, "rot_axis", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Rotation Seed:")
		row.row(align=True).prop(self, "rot_seed", text="")
	panel = set_panel(self, col, self.offset_open_state, "offset_open_state", "Offset")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Explode:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "explode_min")
		split.row(align=True).prop(self, "explode_max")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Explode Seed:")
		row.row(align=True).prop(self, "explode_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cluster:")
		row.row(align=True).prop(self, "cluster", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Margin:")
		row.row(align=True).prop(self, "margin", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset:")
		row.row(align=True).prop(self, "offset", text="")
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Material Index:")
		row.row(align=True).prop(self, "mat_index", text="")
		col.separator(factor=0.5)
		flow = col.column_flow(columns=2, align=True)
		flow.prop(self, "use_mirror")
		flow.prop(self, "no_overlap")
		flow.prop(self, "single_scatter")
		flow.prop(self, "follow_normal")
		if self.no_overlap and not self.follow_normal:
			flow = col.column_flow(columns=2, align=True)
			flow.prop(self, "use_convex_hull")
			flow.prop(self, "track_normal")
		else:
			if self.no_overlap:
				col.prop(self, "use_convex_hull")
			if not self.follow_normal:
				col.prop(self, "track_normal")
		col.prop(self, "use_dissolve")
		if self.use_dissolve:
			col.prop(self, "angle")

def r_tubes_ui(self, context):

	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.path_open_state, "path_open_state", "Path")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Mode:")
		row.row(align=True).prop(self, "mode", expand = True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Path:")
		row.row(align=True).prop(self, "path", expand = True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Amount:")
		row.row(align=True).prop(self, "tube_amount", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Align:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "turn_count")
		split.row(align=True).prop(self, "turn_angle")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Length:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "edg_length_min")
		split.row(align=True).prop(self, "edg_length_max")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Seed:")
		row.row(align=True).prop(self, "edg_seed", text="")
		row = col.row().split(factor=0.27, align=True)
	panel = set_panel(self, col, self.subd_open_state, "subd_open_state", "Subdivision")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cut Method:")
		row.row(align=True).prop(self, "cut_method", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cut Angle:")
		row.row(align=True).prop(self, "cut_threshold", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Subdivision:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "cuts_base")
		split.row(align=True).prop(self, "cuts_smooth")
		row = col.row().split(factor=0.27, align=True)
	panel = set_panel(self, col, self.extr_open_state, "extr_open_state", "Extrude")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Width:")
		if self.uni_width:
			split = row.split(factor=0.9, align=True)
			split.row(align=True).prop(self, "width", text="")
			split.prop(self, "uni_width", text="", icon="LINKED")
		else:
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "width_min")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "width_max")
			split2.prop(self, "uni_width", text="", icon="UNLINKED")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Width Seed:")
			row.row(align=True).prop(self, "width_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Margin:")
		row.row(align=True).prop(self, "margin", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset:")
		if self.uni_offset:
			split = row.split(factor=0.9, align=True)
			split.row(align=True).prop(self, "edg_offset", text="")
			split.prop(self, "uni_offset", text="", icon="LINKED")
		else:
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "edg_offset_min")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "edg_offset_max")
			split2.prop(self, "uni_offset", text="", icon="UNLINKED")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Offset Seed:")
			row.row(align=True).prop(self, "offset_seed", text="")
	panel = set_panel(self, col, self.bevel_open_state, "bevel_open_state", "Bevel")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Resolution:")
		row.row(align=True).prop(self, "resnum", text="")
		if self.uni_bevel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Bevel Offset:")
			split = row.split(factor=0.9, align=True)
			split.row(align=True).prop(self, "bvl_offset_uni", text="")
			split.prop(self, "uni_bevel", text="", icon="LINKED")
		else:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Bevel Offset:")
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "bvl_offset_min")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "bvl_offset_max")
			split2.prop(self, "uni_bevel", text="", icon="UNLINKED")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Bvl Seg/Angle:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "bvl_seg")
		split.row(align=True).prop(self, "bvl_angle")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Bevel Seed:")
		row.row(align=True).prop(self, "bvl_seed", text="")
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Tri Mode:")
		row.row(align=True).prop(self, "tri_mode", expand = True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Triangulate:")
		if self.tri_mode == 'PERCENT':
			row.row(align=True).prop(self, "tri_perc", text="")
		else:
			row.row(align=True).prop(self, "tri_num", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Material Index:")
		row.row(align=True).prop(self, "mat_index", text="")
		col.separator(factor=0.5)
		flow = col.column_flow(columns=2, align=True)
		flow.prop(self, "use_mirror")
		flow.prop(self, "limit_body")
		flow.prop(self, "use_fallback")
		flow.prop(self, "smooth_shade")

def r_cables_ui(self, context):

	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.type_open_state, "type_open_state", "Type")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cable Type:")
		row.row(align=True).prop(self, "cable_type", expand = True)
		if self.cable_type == 'CATN':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Spline Type:")
			row.row(align=True).prop(self, "spline_type", expand = True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Slack:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "slack_min")
			split.row(align=True).prop(self, "slack_max")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Slack Seed:")
			row.row(align=True).prop(self, "slack_seed", text="")
		else:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Manual Offset:")
			row.row(align=True).prop(self, "manual_offset", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Normal Offset:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "norm_offset_min")
			split.row(align=True).prop(self, "norm_offset_max")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Noise:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "offset_noise")
			split.row(align=True).prop(self, "wiggle_noise")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Slack Seed:")
			row.row(align=True).prop(self, "slack_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Island Limit:")
		row.row(align=True).prop(self, "island_limit", expand = True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Island Seed:")
		row.row(align=True).prop(self, "island_seed", text="")
		if self.island_limit != 'NONE':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Sort Method:")
			row.row(align=True).prop(self, "sort_method", expand = True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cable Amount:")
		row.row(align=True).prop(self, "cable_num", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Origin Seed:")
		row.row(align=True).prop(self, "points_seed", text="")
	panel = set_panel(self, col, self.offset_open_state, "offset_open_state", "Offset")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Margin:")
		row.row(align=True).prop(self, "margin", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset:")
		row.row(align=True).prop(self, "offset", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Min Distance:")
		row.row(align=True).prop(self, "dist_thresh", text="")
	panel = set_panel(self, col, self.bevel_open_state, "bevel_open_state", "Bevel")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Bevel:")
		if self.uni_bvl:
			split = row.split(factor=0.9, align=True)
			split.row(align=True).prop(self, "bvl_depth", text="")
			split.prop(self, "uni_bvl", text="", icon="LINKED")
		else:
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "bvl_depth_min")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "bvl_depth_max")
			split2.prop(self, "uni_bvl", text="", icon="UNLINKED")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Bevel Seed:")
			row.row(align=True).prop(self, "bvl_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Resolution:")
		row.row(align=True).prop(self, "bvl_res")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Resolution U:")
		row.row(align=True).prop(self, "res_u", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Steps:")
		row.row(align=True).prop(self, "steps", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Extrude:")
		row.row(align=True).prop(self, "extrude", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Twist Mode:")
		row.row(align=True).prop(self, "twist_mode", expand = True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Twist Smooth:")
		row.row(align=True).prop(self, "twist_smooth", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Tilt:")
		row.row(align=True).prop(self, "tilt", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Radius:")
		row.row(align=True).prop(self, "r_radius", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Radius Seed:")
		row.row(align=True).prop(self, "radius_seed", text="")
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Material Index:")
		row.row(align=True).prop(self, "mat_index", text="")
		col.separator(factor=0.5)
		flow = col.column_flow(columns=2, align=True)
		flow.prop(self, "use_mirror")
		flow.prop(self, "join_curves")
		flow.prop(self, "no_overlap")
		if self.no_overlap:
			flow.prop(self, "overlap_self")

def r_symbols_ui(self, context):

	obj = context.active_object
	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.solver_open_state, "solver_open_state", "Solver")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Solver:")
		row.row(align=True).prop(self, "solver", expand=True)
		if not self.solver in ['RADIAL', 'SQUARE', 'MAZE']:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Path:")
			row.row(align=True).prop(self, "path", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Mode:")
		row.row(align=True).prop(self, "mode", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Repeat Seed:")
		row.row(align=True).prop(self, "repeat_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Probability:")
		row.row(align=True).prop(self, "probability", text="")
	panel = set_panel(self, col, self.color_open_state, "color_open_state", "Color")
	if panel:
		col.template_color_picker(self, "emit_color", value_slider=True)
		col.separator(factor=0.5)
		col.prop(self, "new_mat")
		col.separator(factor=0.5)
	panel = set_panel(self, col, self.panel_open_state, "panel_open_state", "Panel")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Notches:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "notch_count")
		split.row(align=True).prop(self, "notch_size")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Notch Seed:")
		row.row(align=True).prop(self, "notch_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Size Mode:")
		row.row(align=True).prop(self, "size_mode", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Panel Amount:")
		split1 = row.split(factor=0.8, align=True)
		split1.row(align=True).prop(self, "panel_amount", text="")
		split2 = split1.split(factor=0.5, align=True)
		split2.prop(self, "invert_panel_amount", text="", icon="ARROW_LEFTRIGHT")
		split2.prop(self, "remove_panels", text="", icon="STICKY_UVS_DISABLE")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Panel Size:")
		split = row.split(factor=0.5, align=True)
		if self.size_mode == 'PERCENT':
			split.row(align=True).prop(self, "panel_min_perc", text="Min")
			split.row(align=True).prop(self, "panel_max_perc", text="Max")
		else:
			split.row(align=True).prop(self, "panel_min_num", text="Min")
			split.row(align=True).prop(self, "panel_max_num", text="Max")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Space:")
		row.row(align=True).prop(self, "space_perc", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Space Offset:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "space_offset_min")
		split.row(align=True).prop(self, "space_offset_max")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Panel Seed:")
		row.row(align=True).prop(self, "edge_seed", text="")
	panel = set_panel(self, col, self.subd_open_state, "subd_open_state", "Subdivision")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Line Subdv:")
		row.row(align=True).prop(self, "cuts_base", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Char Subdv:")
		row.row(align=True).prop(self, "cuts_faces", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Smoothing:")
		split1 = row.split(factor=0.5, align=True)
		split1.row(align=True).prop(self, "cuts_smooth")
		split2 = split1.split(factor=0.58 if not self.base_smooth else 0.8, align=True)
		split2.row(align=True).prop(self, "smooth_iter")
		if not self.base_smooth:
			split3 = split2.split(factor=0.5, align=True)
			split3.prop(self, "area_smooth", text="", icon="OBJECT_HIDDEN")
			split3.prop(self, "base_smooth", text="", icon="MESH_UVSPHERE")
		else:
			split2.prop(self, "base_smooth", text="", icon="MESH_UVSPHERE")
	panel = set_panel(self, col, self.inset_open_state, "inset_open_state", "Inset")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Margin:")
		row.row(align=True).prop(self, "margin", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Thickness:")
		row.row(align=True).prop(self, "thickness", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Inset Max:")
		row.row(align=True).prop(self, "inset_max", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Inset Min:")
		row.row(align=True).prop(self, "inset_min", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Inset Seed:")
		row.row(align=True).prop(self, "inset_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset:")
		row.row(align=True).prop(self, "offset_faces", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Clear Faces:")
		row.row(align=True).prop(self, "clear_faces", expand=True)
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Triangulate:")
		if self.size_mode == 'PERCENT':
			row.row(align=True).prop(self, "tri_perc", text="")
		else:
			row.row(align=True).prop(self, "tri_num", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Poke:")
		if self.size_mode == 'PERCENT':
			row.row(align=True).prop(self, "poke_perc", text="")
		else:
			row.row(align=True).prop(self, "poke_num", text="")
		col.separator(factor=0.5)
		col.prop(self, "merge_source")
		col.prop(self, "use_mirror")
		row = col.row().split(factor=0.5, align=True)
		row.prop(self, "use_clip")
		if self.use_clip:
			row.row(align=True).prop(self, "clip_axis", text="", expand=True)
			col.prop(self, "clip_dist")

def r_shading_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Limit:")
	flow = row.column_flow(columns=2, align=True)
	flow.prop(self, "limit", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Sharpness:")
	row.row(align=True).prop(self, "sharpness", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Distribution:")
	row.row(align=True).prop(self, "shade_distr", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Seed:")
	row.row(align=True).prop(self, "shade_seed", text="")

def r_vertex_color_ui(self, context):

	layout = self.layout
	col = layout.column()
	col.separator()
	col.template_color_picker(self, "color_max", value_slider=False)
	col.separator()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="New Layer:")
	row.row(align=True).prop(self, "vcname", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Use Saved:")
	row.prop_search(
		self,
		"vclist",
		self,
		"vcolors",
		text="",
		icon = "GROUP_VCOL"
		)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Limit:")
	flow = row.column_flow(columns=2, align=True)
	flow.prop(self, "limit", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Hue Max:")
	row.row(align=True).prop(self, "color_max", text="", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Hue Min:")
	row.row(align=True).prop(self, "color_min", text="", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Saturation:")
	split = row.split(factor=0.5, align=True)
	split.row(align=True).prop(self, "sat_min")
	split.row(align=True).prop(self, "sat_max")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Value:")
	split = row.split(factor=0.5, align=True)
	split.row(align=True).prop(self, "val_min")
	split.row(align=True).prop(self, "val_max")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Random Seeds:")
	split = row.split(factor=0.33, align=True)
	split.row(align=True).prop(self, "col_seed")
	split.row(align=True).prop(self, "sat_seed")
	split.row(align=True).prop(self, "val_seed")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Hard Gradient:")
	row.row(align=True).prop(self, "use_hg", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text=" ")
	row.label(text=(" " * 2) + "(shift+click to add multiple or remove)")
	if self.use_hg != set():
		row = col.row().split(factor=0.27, align=True)
		row.label(text="HG Stops:")
		split = row.split(factor=0.33, align=True)
		split.row(align=True).prop(self, "col_hg_stops")
		split.row(align=True).prop(self, "sat_hg_stops")
		split.row(align=True).prop(self, "val_hg_stops")
	if self.limit != 'OBJECT':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Island Offset:")
		row.row(align=True).prop(self, "offset", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Object Offset:")
	row.row(align=True).prop(self, "obj_offset", text="")
	col.separator(factor=0.5)
	if self.limit == 'SELECT':
		col.prop(self, "single_color")
	if self.limit == 'SHARP':
		col.prop(self, "mark_sharp")
		if self.mark_sharp: col.prop(self, "sharpness")
	col.prop(self, "assign_mat_id")
	col.prop(self, "dirty_vc")
	if self.dirty_vc:
		col.separator(factor=0.5)
		col.prop(self, "blur_str")
		col.prop(self, "blur_iter")
		col.prop(self, "hi_angle")
		col.prop(self, "drt_angle")
		col.separator(factor=0.5)
		col.prop(self, "drt_only")
		col.prop(self, "normalize")

def r_animation_ui(self, context):

	act_obj = context.active_object

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Type:")
	row.row(align=True).prop(self, "anim_type", expand=True)
	if self.anim_type == 'AXIS':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Animation:")
		row.row(align=True).prop(self, "dpath", expand=True)
		if self.use_cycles:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Mode:")
			row.row(align=True).prop(self, "mode", expand=True)
		if act_obj.type == 'MESH':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Pivot:")
			row.row(align=True).prop(self, "pivot", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Axis:")
		row.row(align=True).prop(self, "axis", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text=" ")
		row.label(text=(" " * 2) + "(shift+click to add multiple or remove)")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Frames:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "start_frame")
		split.row(align=True).prop(self, "end_frame")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Seed:")
		row.row(align=True).prop(self, "frame_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		if self.dpath == 'ROTATE':
			row.label(text="Rotation:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "rot_min")
			split.row(align=True).prop(self, "rot_max")
		else:
			if self.dpath == 'MOVE':
				txt = "Move:"
			elif self.dpath == 'SCALE': txt = "Scale:"
			row.label(text=txt)
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "val_min")
			split.row(align=True).prop(self, "val_max")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Seed:")
		row.row(align=True).prop(self, "anim_seed", text="")
		if self.add_parent:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Empty Type:")
			row.row(align=True).prop(self, "type_empty", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Location:")
			row.row(align=True).prop(self, "loc_empty", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Size:")
			row.row(align=True).prop(self, "size_empty", text="")
		col.separator(factor=0.5)
		flow = col.column_flow(columns=2, align=True)
		flow.prop(self, "split_mesh")
		flow.prop(self, "use_cycles")
		flow.prop(self, "clear_anim")
		flow.prop(self, "add_parent")
		flow.prop(self, "reset_transform")
		flow.prop(self, "even_frames")
		flow.prop(self, "rem_parent")
		if self.add_parent: flow.prop(self, "face_normal")
	else:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Collection:")
		row.prop_search(
			self,
			"coll_name",
			self,
			"collections",
			text="",
			icon = "OUTLINER_COLLECTION"
			)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Precision:")
		row.row(align=True).prop(self, "precision", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Limit Frames:")
		row.row(align=True).prop(self, "limit_frames", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "offset_min")
		split.row(align=True).prop(self, "offset_max")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset Seed:")
		row.row(align=True).prop(self, "offset_seed", text="")

def r_offset_ui(self, context):

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Even Depth:")
	row.row(align=True).prop(self, "even_offset", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Use Boundary:")
	row.row(align=True).prop(self, "use_boundary", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Offset:")
	if self.uni_offset:
		split = row.split(factor=0.9, align=True)
		split.row(align=True).prop(self, "offset", text="")
		split.prop(self, "uni_offset", text="", icon="LINKED")
	else:
		split1 = row.split(factor=0.5, align=True)
		split1.row(align=True).prop(self, "offset_min")
		split2 = split1.split(factor=0.8, align=True)
		split2.row(align=True).prop(self, "offset_max")
		split2.prop(self, "uni_offset", text="", icon="UNLINKED")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset Seed:")
		row.row(align=True).prop(self, "offset_seed", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Scale:")
	if self.uni_scale:
		split = row.split(factor=0.9, align=True)
		split.row(align=True).prop(self, "scale", text="")
		split.prop(self, "uni_scale", text="", icon="LINKED")
	else:
		split1 = row.split(factor=0.5, align=True)
		split1.row(align=True).prop(self, "scale_min")
		split2 = split1.split(factor=0.8, align=True)
		split2.row(align=True).prop(self, "scale_max")
		split2.prop(self, "uni_scale", text="", icon="UNLINKED")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Scale Seed:")
		row.row(align=True).prop(self, "scale_seed", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Margin:")
	if self.uni_margin:
		split = row.split(factor=0.9, align=True)
		split.row(align=True).prop(self, "margin", text="")
		split.prop(self, "uni_margin", text="", icon="LINKED")
	else:
		split1 = row.split(factor=0.5, align=True)
		split1.row(align=True).prop(self, "margin_min")
		split2 = split1.split(factor=0.8, align=True)
		split2.row(align=True).prop(self, "margin_max")
		split2.prop(self, "uni_margin", text="", icon="UNLINKED")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Margin Seed:")
		row.row(align=True).prop(self, "margin_seed", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Mark Sharp:")
	row.row(align=True).prop(self, "mark_sharp", expand=True)
	if self.mark_sharp == 'ALL':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Angle:")
		row.row(align=True).prop(self, "edge_sharpness", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Bevel:")
	row.row(align=True).prop(self, "bvl_offset", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Segments:")
	row.row(align=True).prop(self, "bvl_seg", text="")
	col.separator(factor=0.5)
	flow = col.column_flow(columns=2, align=True)
	flow.prop(self, "inset_indv")
	flow.prop(self, "remove_border")
	flow.prop(self, "clamp_overlap")
	if self.remove_border:
		col.prop(self, "angle_threshold")
	row = col.row().split(factor=0.5, align=True)
	row.prop(self, "use_clip")
	if self.use_clip:
		row.row(align=True).prop(self, "clip_axis", text="", expand=True)
		col.prop(self, "clip_dist")

def r_bevel_ui(self, context):

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Bevel Offset:")
	if self.uni_bevel:
		split = row.split(factor=0.9, align=True)
		split.row(align=True).prop(self, "bvl_uni", text="")
		split.prop(self, "uni_bevel", text="", icon="LINKED")
	else:
		split1 = row.split(factor=0.5, align=True)
		split1.row(align=True).prop(self, "bvl_min")
		split2 = split1.split(factor=0.8, align=True)
		split2.row(align=True).prop(self, "bvl_max")
		split2.prop(self, "uni_bevel", text="", icon="UNLINKED")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Bvl Seg/Angle:")
	split = row.split(factor=0.5, align=True)
	split.row(align=True).prop(self, "bvl_seg")
	split.row(align=True).prop(self, "bvl_angle")
	if not self.uni_bevel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Bevel Seed:")
		row.row(align=True).prop(self, "bvl_seed", text="")
	col.separator(factor=0.5)
	col.prop(self, "harden_normals")
	col.prop(self, "clamp_overlap")

def edit_rgeo_ui(self, context):

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Type:")
	row.row(align=True).prop(self, "offset_type", expand=True)
	if self.offset_type == 'OFFSET':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Mode:")
		row.row(align=True).prop(self, "mode", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Split:")
		row.row(align=True).prop(self, "split_type", expand=True)
		if self.mode == 'RAND':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Min Offset:")
			row.row(align=True).prop(self, "min_offset", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Max Offset:")
			row.row(align=True).prop(self, "max_offset", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Seed:")
			row.row(align=True).prop(self, "seed", text="")
		else:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Name:")
			row.prop_search(
				self,
				"vertex_color",
				context.active_object.data,
				"color_attributes",
				text=""
				)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Offset:")
			row.row(align=True).prop(self, "offset", text="")
		if self.split_type == 'BEVEL':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Min Bevel:")
			row.row(align=True).prop(self, "min_bevel", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Max Bevel:")
			row.row(align=True).prop(self, "max_bevel", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Merge Distance:")
		row.row(align=True).prop(self, "merge_dist", text="")
	else:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cut Depth:")
		row.row(align=True).prop(self, "cut_depth", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Min Bevel:")
		row.row(align=True).prop(self, "min_bevel", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Max Bevel:")
		row.row(align=True).prop(self, "max_bevel", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Subdivide Mesh:")
	row.row(align=True).prop(self, "subdiv_mesh", text="")

def copy_rgeo(self, context):

	layout = self.layout
	col = layout.column()
	col.prop(self, "use_selected")

def bevel_node_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Mode:")
	row.row(align=True).prop(self, "mode", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Material:")
	row.row(align=True).prop(self, "mat_mode", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Samples:")
	row.row(align=True).prop(self, "samples")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Radius:")
	row.row(align=True).prop(self, "radius")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Location:")
	row.row(align=True).prop(self, "nloc", text="")

def clear_overlap_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Limit:")
	row.row(align=True).prop(self, "object_limit", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Clear:")
	row.row(align=True).prop(self, "clear_limit", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Threshold:")
	row.row(align=True).prop(self, "threshold", text="")

def make_flanges_ui(self, context):

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.type_open_state, "type_open_state", "Type")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Type:")
		flow = row.column_flow(columns=2, align=True)
		flow.prop(self, "mesh_type", expand=True)
		if self.mesh_type == 'MESH':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Mesh:")
			row.prop_search(
				self,
				"mesh_name",
				self,
				"meshes",
				text="",
				icon = "MESH_DATA"
				)
		if self.mesh_type == 'CUSTOM':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Import Mesh:")
			row.prop_search(
				self,
				"import_name",
				self,
				"import_meshes",
				text="",
				icon = "IMPORT"
				)
		if self.mesh_type == 'COLLECTION':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Collection:")
			row.prop_search(
				self,
				"coll_name",
				self,
				"collections",
				text="",
				icon = "OUTLINER_COLLECTION"
				)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Object Seed:")
			row.row(align=True).prop(self, "coll_seed", text="")
	panel = set_panel(self, col, self.shape_open_state, "shape_open_state", "Shape")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Scale Mode:")
		row.row(align=True).prop(self, "scale_mode", expand=True)
		if self.even_count:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Amount:")
			row.row(align=True).prop(self, "amount", text="")
		else:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Spacing:")
			row.row(align=True).prop(self, "spacing", text="")
		if self.mesh_type != 'BASIC':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Radius:")
			row.row(align=True).prop(self, "radius", text="")
		else:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Radius:")
			row.row(align=True).prop(self, "radius", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Depth:")
			row.row(align=True).prop(self, "depth", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Segments:")
			row.row(align=True).prop(self, "segment", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Offset:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "cap_offset")
		split.row(align=True).prop(self, "bod_offset")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Rotation:")
		row.row(align=True).prop(self, "rot_z", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Rotation Seed:")
		row.row(align=True).prop(self, "rot_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Limit:")
		row.row(align=True).prop(self, "limit", expand=True)
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Material Index:")
		row.row(align=True).prop(self, "mat_index", text="")
		col.separator(factor=0.5)
		col.prop(self, "even_count")

def panel_screws_ui(self, context):

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.type_open_state, "type_open_state", "Type")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Type:")
		flow = row.column_flow(columns=2, align=True)
		flow.prop(self, "mesh_type", expand=True)
		if self.mesh_type == 'MESH':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Mesh:")
			row.prop_search(
				self,
				"mesh_name",
				self,
				"meshes",
				text="",
				icon = "MESH_DATA"
				)
		if self.mesh_type == 'CUSTOM':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Import Mesh:")
			row.prop_search(
				self,
				"import_name",
				self,
				"import_meshes",
				text="",
				icon = "IMPORT"
				)
		if self.mesh_type == 'COLLECTION':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Collection:")
			row.prop_search(
				self,
				"coll_name",
				self,
				"collections",
				text="",
				icon = "OUTLINER_COLLECTION"
				)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Object Seed:")
			row.row(align=True).prop(self, "coll_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Origin:")
		row.row(align=True).prop(self, "origin", expand=True)
		if self.origin == 'FACES':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Mode:")
			row.row(align=True).prop(self, "mode", expand=True)
			if self.mode == 'ANGLE':
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Threshold:")
				row.row(align=True).prop(self, "threshold", text="")
	panel = set_panel(self, col, self.shape_open_state, "shape_open_state", "Shape")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Radius:")
		if self.uni_radius:
			split = row.split(factor=0.9, align=True)
			split.row(align=True).prop(self, "radius", text="")
			split.prop(self, "uni_radius", text="", icon="LINKED")
		else:
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "radius_min")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "radius_max")
			split2.prop(self, "uni_radius", text="", icon="UNLINKED")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Radius Seed:")
			row.row(align=True).prop(self, "radius_seed", text="")
		if self.origin == 'FACES':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Margin:")
			row.row(align=True).prop(self, "margin", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Offset:")
			row.row(align=True).prop(self, "offset", text="")
		if self.mode == 'VERTS' \
			or self.origin == 'VERTS':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Spacing:")
			row.row(align=True).prop(self, "spacing", text="")
		if self.mesh_type == 'BASIC':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Shape:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "depth")
			split.row(align=True).prop(self, "segment")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Bevel:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "bvl_offset")
			split.row(align=True).prop(self, "bvl_seg")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Rotation:")
		row.row(align=True).prop(self, "rot_z", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Rotation Seed:")
		row.row(align=True).prop(self, "rot_seed", text="")
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Proc:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "birth_perc")
		split.row(align=True).prop(self, "birth_seed")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Material Index:")
		row.row(align=True).prop(self, "mat_index", text="")
		col.separator(factor=0.5)
		flow = col.column_flow(columns=2, align=True)
		flow.prop(self, "use_mirror")
		if self.origin == 'FACES':
			flow.prop(self, "use_split")
			flow.prop(self, "per_face")
			flow.prop(self, "tagged_only")
			col.prop(self, "use_dissolve")
			if self.use_dissolve:
				col.prop(self, "angle")

def panel_cloth_ui(self, context):

	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.mode_open_state, "mode_open_state", "Mode")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Split Mode:")
		row.row(align=True).prop(self, "split_mode", expand=True)
		if self.split_mode == 'ANGLE':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Cut Angle:")
			row.row(align=True).prop(self, "cut_threshold", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Bake Frames:")
		row.row(align=True).prop(self, "bake_frames", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Quality:")
		row.row(align=True).prop(self, "qual_steps", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cloth Seed:")
		row.row(align=True).prop(self, "rand_seed", text="")
	panel = set_panel(self, col, self.shape_open_state, "shape_open_state", "Shape")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Transform Mode:")
		row.row(align=True).prop(self, "prop_mode", expand=True)
		if self.prop_mode == 'RANDOM':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Mass:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "mass_min", text="Min")
			split.row(align=True).prop(self, "mass_max", text="Max")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Pressure:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "up_force_min", text="Min")
			split.row(align=True).prop(self, "up_force_max", text="Max")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Shrink:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "shrink_min_min", text="Min")
			split.row(align=True).prop(self, "shrink_min_max", text="Max")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Gravity:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "gravity_min", text="Min")
			split.row(align=True).prop(self, "gravity_max", text="Max")
		else:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Mass:")
			row.row(align=True).prop(self, "mass_max", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Pressure:")
			row.row(align=True).prop(self, "up_force_max", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Shrink:")
			row.row(align=True).prop(self, "shrink_min_max", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Gravity:")
			row.row(align=True).prop(self, "gravity_max", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Margin:")
		row.row(align=True).prop(self, "margin", text="")
	panel = set_panel(self, col, self.subd_open_state, "subd_open_state", "Subdivision")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Pre Smooth:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "smooth_factor")
		split.row(align=True).prop(self, "smooth_iter")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Subdivision:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "cuts_base")
		split.row(align=True).prop(self, "cuts_smooth")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Noise:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "fractal")
		split.row(align=True).prop(self, "along_normal")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Noise Seed:")
		row.row(align=True).prop(self, "noise_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Subsurf Level:")
		row.row(align=True).prop(self, "subd_lvl", text="")
	if self.obj_collisions or self.collision_self:
		panel = set_panel(self, col, self.coll_open_state, "coll_open_state", "Collision")
		if panel:
			if self.obj_collisions or self.collision_self:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Collision:")
				row.row(align=True).prop(self, "col_quality", text="Quality")
			if self.obj_collisions:
				row = col.row().split(factor=0.27, align=True)
				row.label(text=" ")
				row.row(align=True).prop(self, "col_distance", text="Object: Distance")
				row = col.row().split(factor=0.27, align=True)
				row.label(text=" ")
				row.row(align=True).prop(self, "col_thickness", text="Object: Thickness")
			if self.collision_self:
				row = col.row().split(factor=0.27, align=True)
				row.label(text=" ")
				row.row(align=True).prop(self, "col_distance_self", text="Self: Distance")
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Material Index:")
		row.row(align=True).prop(self, "mat_index", text="")
		col.separator(factor=0.5)
		flow = col.column_flow(columns=2, align=True)
		flow.prop(self, "use_mirror")
		flow.prop(self, "flip_normal")
		flow.prop(self, "smooth_shade")
		flow.prop(self, "indiv_effect")
		flow.prop(self, "remove_sel")
		flow.prop(self, "obj_collisions")
		if self.obj_collisions: flow.prop(self, "collide_source")
		flow.prop(self, "collision_self")
		flow = col.column_flow(columns=2, align=True)
		flow.prop(self, "pin_cloth")
		flow.prop(self, "keep_corners")
		if self.keep_corners:
			col.prop(self, "pin_threshold")
		col.prop(self, "pin_sharp_borders")

def plate_insets_ui(self, context):

	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.plating_open_state, "plating_open_state", "Plating")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Subdivision:")
		row.row(align=True).prop(self, "cuts_base", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Join Tris:")
		row.row(align=True).prop(self, "join_tris", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Smooth:")
		row.row(align=True).prop(self, "mesh_smooth", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Plates:")
		row.row(align=True).prop(self, "pool_size", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Size:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "plating_size_min")
		split.row(align=True).prop(self, "plating_size_max")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Tolerance:")
		row.row(align=True).prop(self, "ptol", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Plating Seed:")
		row.row(align=True).prop(self, "pl_seed", text="")
	panel = set_panel(self, col, self.extr_open_state, "extr_open_state", "Extrude")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Adj Faces:")
		row.row(align=True).prop(self, "adj_mode", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Even Offset:")
		row.row(align=True).prop(self, "even_offset", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Thickness:")
		if self.uni_thickness:
			split = row.split(factor=0.9, align=True)
			split.row(align=True).prop(self, "pl_thick", text="")
			split.prop(self, "uni_thickness", text="", icon="LINKED")
		else:
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "pl_thick_min")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "pl_thick_max")
			split2.prop(self, "uni_thickness", text="", icon="UNLINKED")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Thickness Seed:")
			row.row(align=True).prop(self, "thickness_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Depth:")
		if self.uni_depth:
			split = row.split(factor=0.9, align=True)
			split.row(align=True).prop(self, "pl_depth", text="")
			split.prop(self, "uni_depth", text="", icon="LINKED")
		else:
			split1 = row.split(factor=0.5, align=True)
			split1.row(align=True).prop(self, "pl_depth_min")
			split2 = split1.split(factor=0.8, align=True)
			split2.row(align=True).prop(self, "pl_depth_max")
			split2.prop(self, "uni_depth", text="", icon="UNLINKED")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Height Seed:")
		row.row(align=True).prop(self, "depth_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Inner Margin:")
		row.row(align=True).prop(self, "margin_type", expand=True)
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Margins:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "pl_margin_outer")
		split.row(align=True).prop(self, "pl_margin_inner")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Reverse:")
		row.row(align=True).prop(self, "rev_depth", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Reverse Seed:")
		row.row(align=True).prop(self, "rev_seed", text="")
	panel = set_panel(self, col, self.aux_open_state, "aux_open_state", "Auxiliary")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Triangulate:")
		row.row(align=True).prop(self, "tri_perc", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Limit Smooth:")
		row.row(align=True).prop(self, "limit_smooth", expand=True)
		if self.limit_smooth == 'NONE':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Shading:")
			row.row(align=True).prop(self, "base_smooth", expand=True)
		if self.limit_smooth == 'RANDOM':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Shading Seed:")
			row.row(align=True).prop(self, "shading_seed", text="")
		col.separator(factor=0.5)
		col.prop(self, "use_mirror")
		row = col.row().split(factor=0.5, align=True)
		row.prop(self, "use_clip")
		if self.use_clip:
			row.row(align=True).prop(self, "clip_axis", text="", expand=True)
			col.prop(self, "clip_dist")
		col.prop(self, "use_dissolve")
		if self.use_dissolve:
			col.prop(self, "angle")

def quick_displace_ui(self, context):

	props = context.scene.rflow_props

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	panel = set_panel(self, col, self.type_open_state, "type_open_state", "Type")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Type:")
		row.row(align=True).prop(self, "displ_type", text="")
		if self.displ_type == 'IMAGE':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Image:")
			row.prop_search(
				self,
				"img_name",
				self,
				"images",
				text="",
				icon = "IMAGE_DATA"
				)
		if self.displ_type == 'CLOUDS':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Noise Basis:")
			row.row(align=True).prop(self, "noise_basis", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Mode:")
		row.row(align=True).prop(self, "displ_mode", expand=True)
		if self.displ_mode == 'SELECTION':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Smoothing:")
			split = row.split(factor=0.5, align=True)
			split.row(align=True).prop(self, "subtract_sel")
			split.row(align=True).prop(self, "expand_subtr")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Coordinates:")
		row.row(align=True).prop(self, "coords", expand=True)
	panel = set_panel(self, col, self.strength_open_state, "strength_open_state", "Strength")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Strength:")
		row.row(align=True).prop(self, "strength", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Midlevel:")
		row.row(align=True).prop(self, "mid_level", text="")
		if self.displ_type == 'CLOUDS':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Size:")
			row.row(align=True).prop(self, "noise_scale", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Depth:")
			row.row(align=True).prop(self, "noise_depth", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Brightness:")
		row.row(align=True).prop(self, "intensity", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Contrast:")
		row.row(align=True).prop(self, "contrast", text="")
	panel = set_panel(self, col, self.smooth_open_state, "smooth_open_state", "Smoothing")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Pre Smooth:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "smooth_factor1")
		split.row(align=True).prop(self, "smooth_iter1")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Post Smooth:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "smooth_factor2")
		split.row(align=True).prop(self, "smooth_iter2")
	if self.displ_type == 'IMAGE':
		panel = set_panel(self, col, self.img_open_state, "img_open_state", "Image Size")
		if panel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Size:")
			row.row(align=True).prop(self, "img_size", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Filter Size:")
			row.row(align=True).prop(self, "filter_size", text="")
	if self.coords == 'UV':
		panel = set_panel(self, col, self.uv_open_state, "uv_open_state", "UV Mapping")
		if panel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Location:")
			row.row(align=True).prop(self, "img_pos", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Rotation:")
			row.row(align=True).prop(self, "img_rotation", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Seed:")
			row.row(align=True).prop(self, "pos_seed", text="")
	if self.coords == 'OBJECT':
		panel = set_panel(self, col, self.object_open_state, "object_open_state", "Object Mapping")
		if panel:
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Location:")
			row.row(align=True).prop(self, "location", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Location Seed:")
			row.row(align=True).prop(self, "loc_seed", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Rotation:")
			row.row(align=True).prop(self, "rotation", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Rotation Seed:")
			row.row(align=True).prop(self, "rotation_seed", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Scale:")
			row.row(align=True).prop(self, "scale", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Scale Seed:")
			row.row(align=True).prop(self, "scale_seed", text="")
	panel = set_panel(self, col, self.subd_open_state, "subd_open_state", "Subdivision")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Subdivision:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "cuts_base")
		split.row(align=True).prop(self, "cuts_smooth")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Noise:")
		split = row.split(factor=0.5, align=True)
		split.row(align=True).prop(self, "fractal")
		split.row(align=True).prop(self, "along_normal")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Noise Seed:")
		row.row(align=True).prop(self, "noise_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Subsurf Level:")
		row.row(align=True).prop(self, "subd_lvl", text="")
	panel = set_panel(self, col, self.transf_open_state, "transf_open_state", "Transform")
	if panel:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Obj Scale Max:")
		row.row(align=True).prop(self, "obj_sca_max", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Obj Scale Min:")
		row.row(align=True).prop(self, "obj_sca_min", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Scale Seed:")
		row.row(align=True).prop(self, "sca_seed", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Obj Rotation:")
		row.row(align=True).prop(self, "obj_rot", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Rotation Seed:")
		row.row(align=True).prop(self, "rot_seed", text="")

def partition_mesh_ui(self, context):

	layout = self.layout
	col = layout.column()
	if self.merge:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Merge:")
		row.row(align=True).prop(self, "merge_dist", text="")
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Dissolve:")
		row.row(align=True).prop(self, "dissolve_dist", text="")
		col.separator(factor=0.5)
		col.prop(self, "only_similar")
		col.prop(self, "clear_fill")
		if self.clear_fill:
			col.prop(self, "max_face_area")
	else:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Mode:")
		row.row(align=True).prop(self, "mode", expand=True)
		if self.mode == 'RANDOM':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Solver:")
			row.row(align=True).prop(self, "solver", expand=True)
			if not self.solver in ['RADIAL', 'SQUARE']:
				row = col.row().split(factor=0.27, align=True)
				row.label(text="Path:")
				row.row(align=True).prop(self, "path", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Size Mode:")
			row.row(align=True).prop(self, "size_mode", expand=True)
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Panel Size:")
			split = row.split(factor=0.5, align=True)
			if self.size_mode == 'PERCENT':
				split.row(align=True).prop(self, "panel_min_perc", text="Min")
				split.row(align=True).prop(self, "panel_max_perc", text="Max")
			else:
				split.row(align=True).prop(self, "panel_min_num", text="Min")
				split.row(align=True).prop(self, "panel_max_num", text="Max")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Panel Seed:")
			row.row(align=True).prop(self, "edge_seed", text="")
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Cut Method:")
			row.row(align=True).prop(self, "cut_method", expand=True)
		if self.mode == 'SHARP':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Sharpness:")
			row.row(align=True).prop(self, "angle_sharp", text="")

def join_objs_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Join To:")
	row.prop_search(
		self,
		"list",
		self,
		"meshes",
		text="",
		icon = "MESH_DATA"
		)

def split_mesh_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Split From:")
	row.prop_search(
		self,
		"list",
		self,
		"vgroups",
		text="",
		icon = "GROUP_VERTEX"
		)

def set_origin_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.2, align=True)
	row.label(text="Origin:")
	row.row(align=True).prop(self, "origin", expand=True)
	col1 = col.column()
	col1.enabled = self.origin == 'AXIS'
	row = col1.row().split(factor=0.2, align=True)
	row.label(text="Axis:")
	row.row(align=True).prop(self, "axis", expand=True)
	row = col1.row().split(factor=0.2, align=True)
	row.label(text="Location:")
	row.row(align=True).prop(self, "location", expand=True)
	row = col1.row().split(factor=0.2, align=True)
	row.label(text="Tolerance:")
	row.row(align=True).prop(self, "tolerance", expand=True)
	col.separator(factor=0.5)
	col.prop(self, "use_farthest")

def merge_objs_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.29, align=True)
	row.label(text="Operand Type:")
	row.row(align=True).prop(self, "operand_type", expand=True)
	row = col.row().split(factor=0.29, align=True)
	row.label(text="Solver:")
	row.row(align=True).prop(self, "solver", expand=True)
	row = col.row().split(factor=0.29, align=True)
	row.label(text="Merge To:")
	row.prop_search(
		self,
		"list",
		self,
		"meshes",
		text="",
		icon = "MESH_DATA"
		)
	row = col.row().split(factor=0.29, align=True)
	row.label(text="Offset Target:")
	row.row(align=True).prop(self, "offset_target", text="")
	row = col.row().split(factor=0.29, align=True)
	row.label(text="Offset Boolean:")
	row.row(align=True).prop(self, "offset_bool", text="")
	col.separator(factor=0.5)
	flow = col.column_flow(columns=2, align=True)
	if self.operand_type == 'OBJ':
		flow.prop(self, "use_self")
	flow.prop(self, "hole_tolr")
	flow.prop(self, "fill_holes")

def crease_sharp_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Sharpness:")
	row.row(align=True).prop(self, "sharpness", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Factor:")
	row.row(align=True).prop(self, "crease", text="")
	col.separator(factor=0.5)
	col.prop(self, "selected_only")

def smooth_sharp_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.28, align=True)
	row.label(text="Sharpness:")
	row.row(align=True).prop(self, "sharpness", text="")
	row = col.row().split(factor=0.28, align=True)
	row.label(text="Smooth Sharp:")
	split = row.split(factor=0.5, align=True)
	split.row(align=True).prop(self, "smooth_factor1")
	split.row(align=True).prop(self, "smooth_iter1")
	row = col.row().split(factor=0.28, align=True)
	row.label(text="Smooth Flat:")
	split = row.split(factor=0.5, align=True)
	split.row(align=True).prop(self, "smooth_factor2")
	split.row(align=True).prop(self, "smooth_iter2")
	row = col.row().split(factor=0.28, align=True)
	row.label(text="Offset:")
	row.row(align=True).prop(self, "offset", text="")
	col.separator(factor=0.5)
	col.prop(self, "smooth_boundary")
	col.prop(self, "selected_only")
	if self.selected_only:
		col.prop(self, "invert")

def straight_uv_ui(self, context):

	layout = self.layout
	col = layout.column()
	col.separator(factor=0.1)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Limit:")
	row.row(align=True).prop(self, "limit", expand=True)
	if self.limit == 'SHARP':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Edge Sharpness:")
		row.row(align=True).prop(self, "sharpness", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Edge Length Mode:")
	row.row(align=True).prop(self, "edg_length_mode", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Min Edge Length:")
	row.row(align=True).prop(self, "edg_length", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Face Seed:")
	row.row(align=True).prop(self, "face_seed", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Margin:")
	row.row(align=True).prop(self, "margin", text="")

def sort_elem_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Sort Method:")
	row.row(align=True).prop(self, "sort_method", text="")

def quad_slice_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Direction:")
	row.row(align=True).prop(self, "direction", expand=True)
	if self.direction == 'TANGENT':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Tangent:")
		row.row(align=True).prop(self, "tangent_idx", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Origin:")
	row.row(align=True).prop(self, "origin", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Geometry:")
	row.row(align=True).prop(self, "geometry", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Limit:")
	row.row(align=True).prop(self, "limit", expand=True)
	if self.origin == 'EDGE':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Factor:")
		row.row(align=True).prop(self, "slide_factor", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Rotation:")
	row.row(align=True).prop(self, "cut_rot", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Distance:")
	row.row(align=True).prop(self, "bisect_dist", text="")
	col.separator(factor=0.5)
	col.prop(self, "use_tagged")
	col.prop(self, "share_cuts")

def grid_project_ui(self, context):

	layout = self.layout
	col = layout.column()
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Center:")
	row.row(align=True).prop(self, "grid_center", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Direction:")
	row.row(align=True).prop(self, "direction", expand=True)
	if self.direction == 'TANGENT' \
		and self.grid_center == 'PERFACE':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Tangent Basis:")
		row.row(align=True).prop(self, "tangent_src", expand=True)
		if self.tangent_src == 'SELECT':
			row = col.row().split(factor=0.27, align=True)
			row.label(text="Tangent:")
			row.row(align=True).prop(self, "tangent_idx", text="")
	if self.direction == 'TANGENT' \
		and self.grid_center == 'AVERAGE':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Tangent:")
		row.row(align=True).prop(self, "tangent_idx", text="")
	if self.grid_center == 'AVERAGE':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Geometry:")
		row.row(align=True).prop(self, "cut_geo", expand=True)
	if self.cuts_amt == 'SAME':
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cuts:")
		row.row(align=True).prop(self, "cuts", text="")
	else:
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Cuts:")
		row.row(align=True).prop(self, "cut_xy", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Cuts Amount:")
	row.row(align=True).prop(self, "cuts_amt", expand=True)
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Offset:")
	row.row(align=True).prop(self, "offset_xy", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Size:")
	row.row(align=True).prop(self, "size", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Proc:")
	split = row.split(factor=0.5, align=True)
	split.row(align=True).prop(self, "birth_perc")
	split.row(align=True).prop(self, "birth_seed")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Rotation:")
	row.row(align=True).prop(self, "rot", text="")
	row = col.row().split(factor=0.27, align=True)
	row.label(text="Distance:")
	row.row(align=True).prop(self, "bisect_dist", text="")
	col.separator(factor=0.5)
	col.prop(self, "tri_ngons")

def save_data_ui(self, context):

	if self.mode == 'USE':
		layout = self.layout
		col = layout.column()
		row = col.row().split(factor=0.27, align=True)
		row.label(text="Mesh Data:")
		row.prop_search(
			self,
			"list",
			self,
			"meshes",
			text="",
			icon = "MESH_DATA"
			)
		col.separator(factor=0.5)
		col.box().label(text=self.same_info, icon="INFO")
	else: None