bl_info = {
    "name": "Navid3ds Interactive Loft Pro",
    "author": "Navid3ds",
    "version": (15, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Navid3ds Tab",
    "description": "Interactive loft engine with automatic vertex resampling for mixed profiles, mesh baking, and official links",
    "category": "Mesh",
}

import bpy
from bpy.app.handlers import persistent
import webbrowser
import math

class NA3DS_LoftProfile_Property(bpy.types.PropertyGroup):
    curve_obj: bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="Curve",
        poll=lambda self, obj: obj.type == 'CURVE'
    )

def resample_layer(points, target_count, is_cyclic):
    """Surgically redistributes vertices evenly along any profile perimeter to match vertex counts perfectly"""
    if not points or len(points) == 0:
        return []
    if len(points) == target_count:
        return [p.copy() for p in points]
    
    # Calculate cumulative perimeter distances
    dists = [0.0]
    for i in range(1, len(points)):
        dists.append(dists[-1] + (points[i] - points[i-1]).length)
        
    if is_cyclic and len(points) > 1:
        dists.append(dists[-1] + (points[0] - points[-1]).length)
        
    total_dist = dists[-1]
    if total_dist == 0.0:
        return [points[0].copy() for _ in range(target_count)]
        
    new_points = []
    for i in range(target_count):
        if is_cyclic:
            factor = i / target_count
        else:
            factor = i / (target_count - 1) if target_count > 1 else 0.0
            
        target_d = factor * total_dist
        
        idx = 0
        while idx < len(dists) - 1 and dists[idx+1] < target_d:
            idx += 1
            
        d0 = dists[idx]
        d1 = dists[idx+1]
        t = (target_d - d0) / (d1 - d0) if d1 != d0 else 0.0
        
        p0 = points[idx % len(points)]
        p1 = points[(idx + 1) % len(points)]
        new_points.append(p0.lerp(p1, t))
        
    return new_points

def generate_loft(context):
    scene = context.scene
    curves = [item.curve_obj for item in scene.navid_loft_items if item.curve_obj]
    
    if len(curves) < 2:
        loft_obj = scene.objects.get("Navid3ds_Loft_Result")
        if loft_obj:
            loft_obj.data.clear_geometry()
        return
        
    loft_mesh_name = "Navid3ds_Loft_Result"
    loft_obj = scene.objects.get(loft_mesh_name)
    
    if not loft_obj:
        mesh_data = bpy.data.meshes.new(loft_mesh_name)
        loft_obj = bpy.data.objects.new(loft_mesh_name, mesh_data)
        scene.collection.objects.link(loft_obj)
    
    all_vertices = []
    all_faces = []
    base_curve_points = []
    
    depsgraph = context.evaluated_depsgraph_get()
    
    for curve_obj in curves:
        points = []
        try:
            curve_eval = curve_obj.evaluated_get(depsgraph)
            mesh_from_curve = bpy.data.meshes.new_from_object(curve_eval)
            for vertex in mesh_from_curve.vertices:
                global_co = curve_obj.matrix_world @ vertex.co
                points.append(global_co)
            bpy.data.meshes.remove(mesh_from_curve)
        except:
            continue
        if points:
            base_curve_points.append(points)

    num_layers = len(base_curve_points)
    if num_layers < 2:
        return

    # ---- AUTOMATIC CAD RESAMPLING CORE ----
    target_vertex_count = max(len(layer) for layer in base_curve_points)
    is_cyclic = scene.navid_loft_cyclic
    
    resampled_layers = []
    for layer in base_curve_points:
        resampled_layers.append(resample_layer(layer, target_vertex_count, is_cyclic))
    base_curve_points = resampled_layers
    # ----------------------------------------

    final_subdivided_layers = []
    steps = scene.navid_loft_steps
    smooth_factor = scene.navid_loft_blend
    
    for i in range(num_layers):
        layer_now = base_curve_points[i]
        final_subdivided_layers.append(layer_now)
        
        if i < num_layers - 1:
            layer_next = base_curve_points[i+1]
            min_len = target_vertex_count
            has_prev = (i > 0)
            has_next_next = (i < num_layers - 2)
            
            for s in range(1, steps):
                t = s / steps
                interpolated_layer = []
                
                for j in range(min_len):
                    p_now = layer_now[j]
                    p_next = layer_next[j]
                    p_linear = p_now.lerp(p_next, t)
                    
                    if has_prev or has_next_next:
                        p_prev = base_curve_points[i-1][j] if has_prev else p_now
                        control_p = p_now + (p_next - p_prev) * 0.25
                        p_bezier = (1 - t)**2 * p_now + 2 * (1 - t) * t * control_p + t**2 * p_next
                        smooth_p = p_linear.lerp(p_bezier, smooth_factor)
                        interpolated_layer.append(smooth_p)
                    else:
                        interpolated_layer.append(p_linear)
                        
                final_subdivided_layers.append(interpolated_layer)

    for layer in final_subdivided_layers:
        for p in layer:
            all_vertices.append(p)
            
    for i in range(len(final_subdivided_layers) - 1):
        len1 = len(final_subdivided_layers[i])
        len2 = len(final_subdivided_layers[i+1])
        min_len = min(len1, len2)
        
        start_idx_l1 = sum(len(final_subdivided_layers[j]) for j in range(i))
        start_idx_l2 = start_idx_l1 + len1
        
        for j in range(min_len - 1):
            v1 = start_idx_l1 + j
            v2 = start_idx_l1 + j + 1
            v3 = start_idx_l2 + j + 1
            v4 = start_idx_l2 + j
            all_faces.append((v1, v4, v3, v2))
            
        if scene.navid_loft_cyclic:
            v1 = start_idx_l1 + min_len - 1
            v2 = start_idx_l1
            v3 = start_idx_l2
            v4 = start_idx_l2 + min_len - 1
            all_faces.append((v1, v4, v3, v2))

    if scene.navid_loft_cap:
        bot_len = len(final_subdivided_layers[0])
        bot_face = list(range(bot_len))
        bot_face.reverse()
        all_faces.append(tuple(bot_face))
        
        top_len = len(final_subdivided_layers[-1])
        start_top_idx = sum(len(final_subdivided_layers[j]) for j in range(len(final_subdivided_layers)-1))
        top_face = list(range(start_top_idx, start_top_idx + top_len))
        all_faces.append(tuple(top_face))

    loft_obj.data.clear_geometry()
    loft_obj.data.from_pydata(all_vertices, [], all_faces)
    
    for face in loft_obj.data.polygons:
        face.use_smooth = True
        
    loft_obj.data.update()

@persistent
def loft_depsgraph_update(scene, depsgraph):
    for update in depsgraph.updates:
        if update.id.name == "Navid3ds_Loft_Result":
            return
    try:
        generate_loft(bpy.context)
    except:
        pass

class NA3DS_OT_AddSelected(bpy.types.Operator):
    bl_idname = "navid3ds.loft_add_selected"
    bl_label = "Add Selected Curves"
    
    def execute(self, context):
        scene = context.scene
        for obj in context.selected_objects:
            if obj.type == 'CURVE':
                if not any(item.curve_obj == obj for item in scene.navid_loft_items):
                    item = scene.navid_loft_items.add()
                    item.curve_obj = obj
        generate_loft(context)
        return {'FINISHED'}

class NA3DS_OT_RemoveItem(bpy.types.Operator):
    bl_idname = "navid3ds.loft_remove_item"
    bl_label = "Remove"
    index: bpy.props.IntProperty()
    
    def execute(self, context):
        context.scene.navid_loft_items.remove(self.index)
        generate_loft(context)
        return {'FINISHED'}

class NA3DS_OT_MoveItem(bpy.types.Operator):
    bl_idname = "navid3ds.loft_move_item"
    bl_label = "Move"
    index: bpy.props.IntProperty()
    direction: bpy.props.StringProperty()
    
    def execute(self, context):
        items = context.scene.navid_loft_items
        idx = self.index
        if self.direction == 'UP' and idx > 0:
            items.move(idx, idx - 1)
        elif self.direction == 'DOWN' and idx < len(items) - 1:
            items.move(idx, idx + 1)
        generate_loft(context)
        return {'FINISHED'}

class NA3DS_OT_ClearAll(bpy.types.Operator):
    bl_idname = "navid3ds.loft_clear_all"
    bl_label = "Clear All"
    
    def execute(self, context):
        context.scene.navid_loft_items.clear()
        loft_obj = context.scene.objects.get("Navid3ds_Loft_Result")
        if loft_obj:
            loft_obj.data.clear_geometry()
        return {'FINISHED'}

class NA3DS_OT_BakeLoft(bpy.types.Operator):
    bl_idname = "navid3ds.loft_bake"
    bl_label = "Bake Loft to Mesh"
    bl_description = "Convert current loft instance into a permanent independent mesh"
    
    def execute(self, context):
        scene = context.scene
        loft_obj = scene.objects.get("Navid3ds_Loft_Result")
        
        if not loft_obj or not loft_obj.data.vertices:
            self.report({'WARNING'}, "No active loft mesh found to bake!")
            return {'CANCELLED'}
            
        baked_mesh_data = loft_obj.data.copy()
        baked_mesh_data.name = "Navid3ds_Loft_Baked_Mesh"
        
        baked_obj = bpy.data.objects.new("Navid3ds_Loft_Baked", baked_mesh_data)
        baked_obj.matrix_world = loft_obj.matrix_world
        scene.collection.objects.link(baked_obj)
        
        bpy.ops.object.select_all(action='DESELECT')
        baked_obj.select_set(True)
        context.view_layer.objects.active = baked_obj
        
        scene.navid_loft_items.clear()
        loft_obj.data.clear_geometry()
        
        self.report({'INFO'}, "Loft baked successfully! Ready for the next mesh.")
        return {'FINISHED'}

class NA3DS_OT_OpenSocialLink(bpy.types.Operator):
    bl_idname = "navid3ds.open_social_link"
    bl_label = "Open Link"
    url: bpy.props.StringProperty()
    
    def execute(self, context):
        webbrowser.open(self.url)
        return {'FINISHED'}

class NA3DS_PT_LoftPanel(bpy.types.Panel):
    bl_label = "Navid3ds Loft Engine"
    bl_idname = "NA3DS_PT_loft_panel_v15"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'Navid3ds'

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        
        layout.operator("navid3ds.loft_add_selected", text="Add Selected Curves", icon='ADD')
        
        layout.separator()
        layout.label(text="Loft Profiles (Manual Order):")
        
        box = layout.box()
        if len(scene.navid_loft_items) == 0:
            box.label(text="List is empty. Add curves to start.", icon='INFO')
        
        for idx, item in enumerate(scene.navid_loft_items):
            if item.curve_obj:
                row = box.row(align=True)
                row.label(text=f"{idx+1}: {item.curve_obj.name}", icon='OUTLINER_OB_CURVE')
                
                up_op = row.operator("navid3ds.loft_move_item", text="", icon='TRIA_UP')
                up_op.index = idx
                up_op.direction = 'UP'
                
                down_op = row.operator("navid3ds.loft_move_item", text="", icon='TRIA_DOWN')
                down_op.index = idx
                down_op.direction = 'DOWN'
                
                rem_op = row.operator("navid3ds.loft_remove_item", text="", icon='REMOVE')
                rem_op.index = idx

        if len(scene.navid_loft_items) > 0:
            layout.operator("navid3ds.loft_clear_all", text="Clear Entire List", icon='TRASH')
        
        layout.separator()
        settings_box = layout.box()
        settings_box.label(text="Loft Settings:")
        settings_box.prop(scene, "navid_loft_cyclic", text="Closed / Cyclic")
        settings_box.prop(scene, "navid_loft_cap", text="Cap Holes")
        settings_box.prop(scene, "navid_loft_steps", text="Loft Steps")
        settings_box.prop(scene, "navid_loft_blend", text="Corner Softness")
        
        if len(scene.navid_loft_items) > 0:
            layout.separator()
            layout.operator("navid3ds.loft_bake", text="Bake Loft to Mesh", icon='FILE_TICK')
            
        layout.separator()
        about_box = layout.box()
        about_box.label(text="About & Support:", icon='USER')
        about_box.label(text="Developed by Navid3ds", icon='CHECKMARK')
        
        row_social = about_box.row(align=True)
        ig_op = row_social.operator("navid3ds.open_social_link", text="Navid3ds Instagram", icon='COMMUNITY')
        ig_op.url = "https://www.instagram.com/navid3ds?igsh=aHRnNXMybWp1bzFm"

def register():
    bpy.utils.register_class(NA3DS_LoftProfile_Property)
    bpy.types.Scene.navid_loft_items = bpy.props.CollectionProperty(type=NA3DS_LoftProfile_Property)
    
    bpy.types.Scene.navid_loft_cyclic = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.navid_loft_cap = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.navid_loft_steps = bpy.props.IntProperty(default=8, min=1, max=64)
    bpy.types.Scene.navid_loft_blend = bpy.props.FloatProperty(default=0.5, min=0.0, max=1.0)
    
    bpy.utils.register_class(NA3DS_PT_LoftPanel)
    bpy.utils.register_class(NA3DS_OT_AddSelected)
    bpy.utils.register_class(NA3DS_OT_RemoveItem)
    bpy.utils.register_class(NA3DS_OT_MoveItem)
    bpy.utils.register_class(NA3DS_OT_ClearAll)
    bpy.utils.register_class(NA3DS_OT_BakeLoft)
    bpy.utils.register_class(NA3DS_OT_OpenSocialLink)
    
    if loft_depsgraph_update not in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.append(loft_depsgraph_update)

def unregister():
    if loft_depsgraph_update in bpy.app.handlers.depsgraph_update_post:
        bpy.app.handlers.depsgraph_update_post.remove(loft_depsgraph_update)
        
    bpy.utils.unregister_class(NA3DS_PT_LoftPanel)
    bpy.utils.unregister_class(NA3DS_OT_AddSelected)
    bpy.utils.unregister_class(NA3DS_OT_RemoveItem)
    bpy.utils.unregister_class(NA3DS_OT_MoveItem)
    bpy.utils.unregister_class(NA3DS_OT_ClearAll)
    bpy.utils.unregister_class(NA3DS_OT_BakeLoft)
    bpy.utils.unregister_class(NA3DS_OT_OpenSocialLink)
    bpy.utils.unregister_class(NA3DS_LoftProfile_Property)
    
    del bpy.types.Scene.navid_loft_items
    del bpy.types.Scene.navid_loft_cyclic
    del bpy.types.Scene.navid_loft_cap
    del bpy.types.Scene.navid_loft_steps
    del bpy.types.Scene.navid_loft_blend

if __name__ == "__main__":
    register()