# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2022, Dmitry Aleksandrovich Maslov (ABTOMAT), Alex Zhornyak (alexander.zhornyak@gmail.com)

import bpy

from bpy.types import PropertyGroup
from bpy.props import CollectionProperty, FloatProperty, IntProperty, StringProperty, EnumProperty, FloatVectorProperty

from .blender_zen_utils import ZenLocks, ZenPolls
from .draw_sets import ZBBQ_EdgeLayerManager, mark_groups_modified
from .ico import ZBBQ_Icons
from .labels import ZBBQ_Labels
from .colors import ZBBQ_Colors
from .commonFunc import ZBBQ_CommonFunc, ZBBQ_PropUtils, ZBBQ_MaterialFunc
from .consts import ZBBQ_Consts
from .units import ZBBQ_Unit, ZBBQ_UnitSystemsForEnumProperty, ZBBQ_Units, ZBBQ_UnitsForEnumPropertyConsideringUnitSystem
from .keymap_manager import draw_keymaps
from .vlog import Log

from .zen_common.combo_panel import ZenComboSettings
from .zen_common.pref_utils import ZenAddonExpandProps

from .demo_examples import (
    ZBBQ_DemoExample,
    ZBBQ_DemoExampleProps,

    ZBBQ_OT_DemoExamplesUpdate,
    ZBBQ_OT_DemoExamplesDownload,
    ZBBQ_OT_DemoExamplesDelete,

    ZBBQ_UL_DemoExampleList)


def update_addon_prop(self, context: bpy.types.Context):
    if not context.preferences.is_dirty:
        context.preferences.is_dirty = True


class ZBBQ_AddonExpandProps(ZenAddonExpandProps, bpy.types.PropertyGroup):

    expand_bake_properties: bpy.props.BoolProperty(
        name="Bake Properties",
        description="Expand panel with bake properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_render: bpy.props.BoolProperty(
        name="Bake Render",
        description="Expand panel with bake render properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_output: bpy.props.BoolProperty(
        name="Bake Output",
        description="Expand panel with bake output properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_ao: bpy.props.BoolProperty(
        name="Bake AO",
        description="Expand panel with ambient occlusion properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_curvature: bpy.props.BoolProperty(
        name="Bake Curvature",
        description="Expand panel with curvature properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_convexity: bpy.props.BoolProperty(
        name="Bake Convexity",
        description="Expand panel with convexity properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_concavity: bpy.props.BoolProperty(
        name="Bake Concavity",
        description="Expand panel with concavity properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_bevels_mask: bpy.props.BoolProperty(
        name="Bake Bevels Mask",
        description="Expand panel with bevel mask properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_parts_id: bpy.props.BoolProperty(
        name="Bake Parts ID",
        description="Expand panel with parts identification properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_material_id: bpy.props.BoolProperty(
        name="Bake Material ID",
        description="Expand panel with material identification properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_os_normal: bpy.props.BoolProperty(
        name="Bake Object Space Normals",
        description="Expand panel with object space normal properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_normal: bpy.props.BoolProperty(
        name="Bake Normal",
        description="Expand panel with tangent space normal properties",
        default=False,
        update=update_addon_prop
    )

    expand_viewport_sampling_preset_properties: bpy.props.BoolProperty(
        name="Preset Properties",
        description="Expand panel with viewport preview preset properties",
        default=False,
        update=update_addon_prop
    )

    expand_viewport_sampling_viewport_preset_properties: bpy.props.BoolProperty(
        name="Viewport",
        description="Expand panel with viewport preset properties",
        default=True,
        update=update_addon_prop
    )

    expand_viewport_sampling_denoise_preset_properties: bpy.props.BoolProperty(
        name="Denoise",
        description="Expand panel with denoise preset properties",
        default=False,
        update=update_addon_prop
    )

    expand_viewport_addon_properties: bpy.props.BoolProperty(
        name="Addon",
        description="Expand panel with preview addon properties",
        default=False,
        update=update_addon_prop
    )

    expand_render_preset_properties: bpy.props.BoolProperty(
        name="Preset Properties",
        description="Expand panel with render preset properties",
        default=False,
        update=update_addon_prop
    )

    expand_render_viewport_preset_properties: bpy.props.BoolProperty(
        name="Viewport",
        description="Expand panel with viewport preset properties",
        default=True,
        update=update_addon_prop
    )

    expand_render_denoise_preset_properties: bpy.props.BoolProperty(
        name="Denoise",
        description="Expand panel with denoise preset properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_maps: bpy.props.BoolProperty(
        name="Bake Maps",
        description="Expand panel with bake maps properties",
        default=False,
        update=update_addon_prop
    )

    expand_bake_misc: bpy.props.BoolProperty(
        name="Bake Misc",
        description="Expand panel with bake miscelanous properties",
        default=False,
        update=update_addon_prop
    )

    expand_live_boolean: bpy.props.BoolProperty(
        name="Live Boolean",
        description="Expand panel with live boolean properties",
        default=False,
        update=update_addon_prop
    )

    expand_vertex_color_mask: bpy.props.BoolProperty(
        name="Vertex Color Mask",
        description="Expand panel with vertex color mask properties",
        default=False,
        update=update_addon_prop
    )

    expand_normal_studio: bpy.props.BoolProperty(
        name="Normal Preview Studio",
        description="Expand panel with normal map preview studio",
        default=False,
        update=update_addon_prop
    )

    expand_normal_map_tools: bpy.props.BoolProperty(
        name="Normal Map Tools",
        description="Expand panel with normal map tools",
        default=False,
        update=update_addon_prop
    )

    expand_mesh_tools: bpy.props.BoolProperty(
        name="Mesh Tools",
        description="Expand panel with mesh tools",
        default=False,
        update=update_addon_prop
    )

    expand_misc_tools: bpy.props.BoolProperty(
        name="Misc Tools",
        description="Expand panel with miscelanous tools",
        default=False,
        update=update_addon_prop
    )


def ZBBQ_RebuildColoredEdges(self, context):

    try:
        ZenLocks.lock_depsgraph_update()

        for obj in context.objects_in_mode:
            if not ZBBQ_CommonFunc.ObjectIsMesh(obj):
                continue
            mark_groups_modified(ZBBQ_EdgeLayerManager, obj)

    finally:
        ZenLocks.unlock_depsgraph_update()
    pass


class ZBBQ_Pref_BevelPreset(PropertyGroup):

    radius: FloatProperty(
            name=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Radius_Name,
            description=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Radius_Desc,
            default=0.1,
            min=0,
            subtype="UNSIGNED",
            update=ZBBQ_RebuildColoredEdges
            # precision=3
    )

    radius_ui: FloatProperty(
            name=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Radius_Name,
            description=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Radius_Desc,
            default=0.1,
            min=0,
            subtype="UNSIGNED",
            options={'HIDDEN', 'SKIP_SAVE'},
            get=lambda self: self.radius
    )

    unitSystem: EnumProperty(  # Yes, we need it here as well to check out which units we may include to Enum
            name=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_UnitSystem_Name,
            description=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_UnitSystem_Desc,
            items=ZBBQ_UnitSystemsForEnumProperty,
            default="METRIC"
    )

    units: EnumProperty(
            name=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Units_Name,
            description=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Units_Desc,
            items=lambda self, context: ZBBQ_UnitsForEnumPropertyConsideringUnitSystem(self.unitSystem),
            update=ZBBQ_RebuildColoredEdges
    )

    statistics_objects: bpy.props.IntProperty(
        name="Statistics Objects",
        options={'HIDDEN', 'SKIP_SAVE'},
        min=0,
        default=0
    )

    statistics_objects_in_mode: bpy.props.IntProperty(
        name="Statistics Objects In Mode",
        options={'HIDDEN', 'SKIP_SAVE'},
        min=0,
        default=0
    )

    def get_units_ui(self):
        t_map_items = {
            item[0]: idx
            for idx, item in enumerate(ZBBQ_UnitsForEnumPropertyConsideringUnitSystem(self.unitSystem))
        }
        return t_map_items.get(self.units, 0)

    units_ui: EnumProperty(
            name=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Units_Name,
            description=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Units_Desc,
            items=lambda self, context: ZBBQ_UnitsForEnumPropertyConsideringUnitSystem(self.unitSystem),
            options={'HIDDEN', 'SKIP_SAVE'},
            get=get_units_ui
    )

    # To-Do: Remove this and make icon-generation from Color Vector

    colorId: StringProperty(
           name=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_ColorId_Name,
           description=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_ColorId_Desc,
           default="Blue"
    )

    color: FloatVectorProperty(
           name=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Color_Name,
           description=ZBBQ_Labels.ZBBQ_Pref_BevelPreset_Prop_Color_Desc,
           subtype='COLOR_GAMMA',
           size=3,
           min=0, max=1
    )

    def iconId(self):
        return ZBBQ_Colors[self.colorId].iconId()

    def getUnitInfo(self):
        return ZBBQ_Units[self.units]

    def unitAndSceneScaleMultiplier(self):
        return ZBBQ_Unit.unitAndSceneScaleMultiplierByUnitsName(self.units)


class ZBBQ_Pref_BevelPresetGroup(PropertyGroup):

    def on_title_update(self, context: bpy.types.Context):
        self.name = self.title

    title: StringProperty(
            name=ZBBQ_Labels.ZBBQ_Pref_BevelPresetGroup_Prop_Title_Name,
            description=ZBBQ_Labels.ZBBQ_Pref_BevelPresetGroup_Prop_Title_Desc,
            default="Untitled",
            update=on_title_update
    )

    unitSystem: EnumProperty(
            name=ZBBQ_Labels.ZBBQ_Pref_BevelPresetGroup_Prop_UnitSystem_Name,
            description=ZBBQ_Labels.ZBBQ_Pref_BevelPresetGroup_Prop_UnitSystem_Desc,
            items=ZBBQ_UnitSystemsForEnumProperty,
            default="METRIC"
    )

    bevelPresets: CollectionProperty(type=ZBBQ_Pref_BevelPreset)
    bevelPresetsIndex: IntProperty(
            name=ZBBQ_Labels.ZBBQ_Pref_BevelPresetGroup_Prop_BevelPresetsIndex_Title,
            description=ZBBQ_Labels.ZBBQ_Pref_BevelPresetGroup_Prop_BevelPresetsIndex_Desc,
            default=0)

    max_bevel_value: FloatProperty(name='Max Bevel Value', description='Maximum bevel value in the entire scene', default=0.0)

    def GetActiveBevelPreset(self):
        return self.bevelPresets[self.bevelPresetsIndex] if self.bevelPresetsIndex in range(len(self.bevelPresets)) else None


class ZBBQ_PanelEnableGroup(bpy.types.PropertyGroup):

    def get_context(self):
        p_context = self.get('_context', None)
        if p_context is None:

            p_context = {}

            addon_prefs = ZBBQ_CommonFunc.GetPrefs()

            if addon_prefs.dock_VIEW_3D_panels == self:
                p_context['is_floating'] = False
                p_context['mode'] = 'VIEW_3D'
            elif addon_prefs.float_VIEW_3D_panels == self:
                p_context['is_floating'] = True
                p_context['mode'] = 'VIEW_3D'

            self['_context'] = p_context
        return p_context

    def get_val(self, prop_name):
        p_context = self.get_context()
        b_is_floating = p_context['is_floating']
        s_context_mode = p_context['mode']

        p_default = False if b_is_floating else ZBBQ_Consts.uv_enblr[prop_name][s_context_mode] is not None
        if p_default and not b_is_floating:
            if prop_name in {'enable_pt_preferences', 'enable_pt_main'}:
                return True

        return self.get(prop_name, p_default)

    def set_val(self, prop_name, value):
        p_old_val = self.get_val(prop_name)
        if p_old_val != value:
            self[prop_name] = value

            for window in bpy.context.window_manager.windows:
                for area in window.screen.areas:
                    area.tag_redraw()

    enable_pt_main: bpy.props.BoolProperty(
        name='Main',
        get=lambda self: self.get_val('enable_pt_main'),
        set=lambda self, value: self.set_val('enable_pt_main', value))
    enable_pt_quality: bpy.props.BoolProperty(
        name='Quality',
        get=lambda self: self.get_val('enable_pt_quality'),
        set=lambda self, value: self.set_val('enable_pt_quality', value))
    enable_pt_tools: bpy.props.BoolProperty(
        name='Tools',
        get=lambda self: self.get_val('enable_pt_tools'),
        set=lambda self, value: self.set_val('enable_pt_tools', value))
    enable_pt_preferences: bpy.props.BoolProperty(
        name='Preferences',
        get=lambda self: self.get_val('enable_pt_preferences'),
        set=lambda self, value: self.set_val('enable_pt_preferences', value))
    enable_pt_help: bpy.props.BoolProperty(
        name='Help',
        get=lambda self: self.get_val('enable_pt_help'),
        set=lambda self, value: self.set_val('enable_pt_help', value))
    enable_pt_bake: bpy.props.BoolProperty(
        name='Bake',
        get=lambda self: self.get_val('enable_pt_bake'),
        set=lambda self, value: self.set_val('enable_pt_bake', value))


class ZBBQ_ComboSettings(ZenComboSettings, bpy.types.PropertyGroup):
    pinned: bpy.props.StringProperty(
        name='Pinned Combo Panels',
        default="{'ZBBQ_PT_Bevels': True}"
    )

    combo_VIEW_3D_edit_mode: bpy.props.EnumProperty(
        name='Combo Edit Mode',
        description='Selected panel in view 3d edit mesh combo mode',
        items=[
            ('ZBBQ_PT_Bevels', 'Bevels', ''),
            ('ZBBQ_PT_Bake', 'Bake', ''),
            ('ZBBQ_PT_Tools', 'Tools', ''),
            ('ZBBQ_PT_Preferences', 'Preferences', ''),
            ('ZBBQ_PT_Help', 'Help', '')
        ],
        options={'ENUM_FLAG'},
        default={'ZBBQ_PT_Bevels'}
    )


class ZBBQ_Prefs(bpy.types.AddonPreferences):
    bl_idname = ZenPolls.ADDON_PACKAGE

    op_id = "zbbq"

    check_for_updates: bpy.props.BoolProperty(
        name='Check For Updates',
        description='Check for available new addon version on the official Zen UV website',
        default=False
    )

    bevelPresetGroups: CollectionProperty(type=ZBBQ_Pref_BevelPresetGroup)

    bevelPresetGroupsDropdown: bpy.props.StringProperty(
            name=ZBBQ_Labels.ZBBQ_Prefs_Prop_BevelPresetGroupsDropdown_Name,
            description=ZBBQ_Labels.ZBBQ_Prefs_Prop_BevelPresetGroupsDropdown_Desc,
            update=ZBBQ_RebuildColoredEdges
    )

    smartSelectRadiusThreshold: FloatProperty(
            name=ZBBQ_Labels.ZBBQ_Prefs_Prop_SmartSelectRadiusThreshold_Name,
            description=ZBBQ_Labels.ZBBQ_Prefs_Prop_SmartSelectRadiusThreshold_Desc,
            default=ZBBQ_Consts.smartSelectRadiusThresholdDefault,
            min=0,
            max=20,
            # max=150,
            # soft_max=20,
            subtype='PERCENTAGE')

    cycles_auto_activation: bpy.props.BoolProperty(
            name="Cycles Automatic Activation",
            description="If option is set then Cycles engine will be automatically enabled",
            default=True)

    n_panel_name: bpy.props.EnumProperty(
        name="Addon N-Panel Name",
        description=(
            "Name of the addon tab in N-Panel\n"
            "* You can set it to Zen to combine all Zen addons in one tab\n"
            "** Requires Blender restart"),
        items=[
            (ZBBQ_Consts.addonId, ZBBQ_Consts.addonName, "Default addon name"),
            ("ZEN", "Zen", "Is used to combine all Zen addons in one tab")
        ],
        default=ZBBQ_Consts.addonId
    )

    demo: bpy.props.PointerProperty(
        name='Demo',
        type=ZBBQ_DemoExampleProps
    )

    expand_props: bpy.props.PointerProperty(
        name="Expand Properties",
        type=ZBBQ_AddonExpandProps
    )

    def on_display_statistics_update(self, context):
        try:
            if self.display_statistics:
                bpy.ops.wm.zen_bbq_update_data()
        except Exception as e:
            Log.error("DISPLAY STATISTICS:", e)

    display_statistics: bpy.props.BoolProperty(
        name="Display Preset Statistics",
        description="Display bevel preset statistics after pressing update button",
        default=False,
        update=on_display_statistics_update
    )

    tabs: bpy.props.EnumProperty(
        items=[
            ("COMMON", "Common", ""),
            ("KEYMAP", "Keymap", ""),
            ("UI", "UI", ""),
            ("HELP", "Help", ""),
        ],
        default="COMMON"
    )

    def on_material_update(self, context: bpy.types.Context):
        if self.material_shading_type != 'NONE':
            b_has_override_node = ZBBQ_MaterialFunc.has_any_objs_with_node(
                context, ZBBQ_Consts.PREVIEW_SHADER_NAME, use_mat_suffix=True)
            b_has_image_override = ZBBQ_MaterialFunc.has_any_objs_with_node(
                context, ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME, use_mat_suffix=True)
            if not b_has_override_node and not b_has_image_override:
                for area in context.screen.areas:
                    if area.type == 'VIEW_3D':
                        p_space = area.spaces.active
                        if isinstance(p_space, bpy.types.SpaceView3D):
                            if p_space.shading.type != self.material_shading_type:
                                try:
                                    p_space.shading.type = self.material_shading_type
                                except Exception as e:
                                    Log.error("SET SHADING:", e)

    def on_shader_shading_type_update(self, context: bpy.types.Context):
        if self.material_shading_type != 'NONE':
            b_has_override_node = ZBBQ_MaterialFunc.has_any_objs_with_node(
                context, ZBBQ_Consts.PREVIEW_SHADER_NAME, use_mat_suffix=True)
            if b_has_override_node:

                if self.cycles_auto_activation:
                    if self.shader_shading_type == 'RENDERED':
                        if ZBBQ_CommonFunc.IsCyclesEnabled(context):
                            if context.scene.render.engine != 'CYCLES':
                                context.scene.render.engine = 'CYCLES'

                for area in context.screen.areas:
                    if area.type == 'VIEW_3D':
                        p_space = area.spaces.active
                        if isinstance(p_space, bpy.types.SpaceView3D):
                            if p_space.shading.type != self.shader_shading_type:
                                try:
                                    p_space.shading.type = self.shader_shading_type
                                except Exception as e:
                                    Log.error("SET SHADING:", e)

    def on_image_shading_type_update(self, context: bpy.types.Context):
        if self.material_shading_type != 'NONE':
            b_has_image_override = ZBBQ_MaterialFunc.has_any_objs_with_node(
                context, ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME, use_mat_suffix=True)
            if b_has_image_override:
                for area in context.screen.areas:
                    if area.type == 'VIEW_3D':
                        p_space = area.spaces.active
                        if isinstance(p_space, bpy.types.SpaceView3D):
                            if p_space.shading.type != self.image_shading_type:
                                try:
                                    p_space.shading.type = self.image_shading_type
                                except Exception as e:
                                    Log.error("SET SHADING:", e)

    material_shading_type: ZBBQ_PropUtils.get_shading_type(p_default='MATERIAL', fn_update=on_material_update)
    shader_shading_type: ZBBQ_PropUtils.get_shading_type(p_default='RENDERED', fn_update=on_shader_shading_type_update)
    image_shading_type: ZBBQ_PropUtils.get_shading_type(p_default='MATERIAL', fn_update=on_image_shading_type_update)

    material_shading_type_locked: ZBBQ_PropUtils.get_shading_type_locked(p_default=False)
    shader_shading_type_locked: ZBBQ_PropUtils.get_shading_type_locked(p_default=True)
    image_shading_type_locked: ZBBQ_PropUtils.get_shading_type_locked(p_default=True)

    def on_shader_preview_enabled_update(self, context: bpy.types.Context):
        from .sceneConfig import ZBBQ_SceneProperties

        p_scene = context.scene
        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        if not p_scene_props.is_baking_active:
            if p_scene_props.preview_mode == 'SHADER':
                ZBBQ_CommonFunc.SetShaderPreviewMode(context, reset=False)

    shader_preview_enabled: bpy.props.BoolProperty(
        name="Shader Bevels Preview",
        description="If option is set then material output is overriden with shader bevel preview",
        default=True,
        update=on_shader_preview_enabled_update
    )

    bake_check_flipped_uvs: bpy.props.BoolProperty(
        name="Check Flipped UVs",
        description="Check for flipped/mirrored UV faces before baking to prevent texture mirroring artifacts",
        default=True
    )

    bake_check_overlapped_uvs: bpy.props.BoolProperty(
        name="Check Overlapped UVs",
        description="Check for overlapping UV islands or faces before baking to prevent texture bleeding",
        default=True
    )

    material_default_color: bpy.props.FloatVectorProperty(
        name="Default Material Color",
        description="Color applied to objects that do not have any material assigned",
        subtype='COLOR',
        size=4,
        min=0.0, max=1.0,
        default=ZBBQ_Consts.bbq_default_material_base_color
    )

    shader_preview_color: bpy.props.FloatVectorProperty(
        name="Bevel Shader Color",
        description="Override color used for displaying shader-based bevels",
        subtype='COLOR',
        size=4,
        min=0.0, max=1.0,
        default=ZBBQ_Consts.bbq_default_shader_mode_base_color
    )

    image_preview_color: bpy.props.FloatVectorProperty(
        name="Bake Preview Color",
        description="Base color used to inspect and preview baked normal maps clearly",
        subtype='COLOR',
        size=4,
        min=0.0, max=1.0,
        default=ZBBQ_Consts.bbq_default_normal_inspect_mode_base_color
    )

    dock_VIEW_3D_panels: bpy.props.PointerProperty(
        name='Docked View3D Panels', type=ZBBQ_PanelEnableGroup)

    dock_VIEW_3D_panels_enabled: bpy.props.BoolProperty(
        name="Enable Docked View3D Panel",
        default=True
    )

    float_VIEW_3D_panels: bpy.props.PointerProperty(
        name='Floating View3D Panels', type=ZBBQ_PanelEnableGroup)

    combo_panel: bpy.props.PointerProperty(type=ZBBQ_ComboSettings)

    def draw_common(self, layout: bpy.types.UILayout, context: bpy.types.Context):
        col = layout.column(align=False)
        col.use_property_split = True
        col.use_property_decorate = False
        col.prop(self, "n_panel_name")
        col.prop(self, "smartSelectRadiusThreshold")
        col.prop(self, "material_default_color")
        col.prop(self, 'cycles_auto_activation')
        col.prop(self, 'display_statistics')

    def draw(self, context: bpy.types.Context):
        layout = self.layout

        row = layout.row()
        row.prop(self, "tabs", expand=True)

        if self.tabs == 'COMMON':
            box = layout.box()
            self.draw_common(box, context)

            layout.label(text="Cleanup / Repair")

            box = layout.box()

            box.operator("global.zen_bbq_reset_preferences")
            box.operator("global.zen_bbq_addon_cleanup")

        elif self.tabs == 'KEYMAP':
            draw_keymaps(context, layout)

        elif self.tabs == 'UI':
            col = layout.column()
            title_box = col.box()
            title_box.label(text="3D Viewport", icon="VIEW3D")
            self.combo_panel.draw_panels_enabler(context, layout, "VIEW_3D")

        elif self.tabs == 'HELP':

            col = layout.column(align=False)

            row = col.row(align=True)
            row.operator(
                "wm.url_open",
                text=ZBBQ_Labels.PANEL_HELP_DOC_LABEL,
                icon="HELP"
            ).url = ZBBQ_Labels.PANEL_HELP_DOC_LINK
            row = col.row(align=True)
            row.operator(
                "wm.url_open",
                text=ZBBQ_Labels.PANEL_HELP_DISCORD_LABEL,
                icon_value=ZBBQ_Icons['Discord-Logo-White_32'].id()
            ).url = ZBBQ_Labels.PANEL_HELP_DISCORD_LINK

            box = layout.box()
            self.demo.draw(box, context)

        box_products = layout.box()
        box_products.label(text='Zen Add-ons')
        box_products.operator(
            "wm.url_open",
            text=ZBBQ_Labels.PREF_ZEN_SETS_URL_DESC,
            icon_value=ZBBQ_Icons['zen-sets_32'].id()
        ).url = ZBBQ_Labels.PREF_ZEN_SETS_URL_LINK
        box_products.operator(
            "wm.url_open",
            text=ZBBQ_Labels.PREF_ZEN_UV_URL_DESC,
            icon_value=ZBBQ_Icons['zen-uv_32'].id()
        ).url = ZBBQ_Labels.PREF_ZEN_UV_URL_LINK
        box_products.operator(
            "wm.url_open",
            text=ZBBQ_Labels.PREF_ZEN_UV_CHECKER_URL_DESC,
            icon_value=ZBBQ_Icons['checker_32'].id()
        ).url = ZBBQ_Labels.PREF_ZEN_UV_CHECKER_URL_LINK
        box_products.operator(
            "wm.url_open",
            text=ZBBQ_Labels.PREF_ZEN_UV_TOPMOST_URL_DESC,
            # icon_value=ZBBQ_Icons['checker_32'].id()
        ).url = ZBBQ_Labels.PREF_ZEN_UV_TOPMOST_URL_LINK


classes = (

    ZBBQ_Pref_BevelPreset,
    ZBBQ_Pref_BevelPresetGroup,

    ZBBQ_PanelEnableGroup,
    ZBBQ_ComboSettings,

    ZBBQ_AddonExpandProps,
    ZBBQ_DemoExample,
    ZBBQ_DemoExampleProps,
    ZBBQ_OT_DemoExamplesUpdate,
    ZBBQ_OT_DemoExamplesDownload,
    ZBBQ_OT_DemoExamplesDelete,
    ZBBQ_UL_DemoExampleList,

    ZBBQ_Prefs,

)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
