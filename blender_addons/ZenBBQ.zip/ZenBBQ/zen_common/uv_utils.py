# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2021, Valeriy Yatsenko (lightbio@gmail.com)

import bmesh


def calc_face_uv_area(face: bmesh.types.BMFace, uv_layer: bmesh.types.BMLayerItem) -> tuple[float, bool]:
    loops = face.loops
    n = len(loops)
    if n < 3:
        return 0.0, False
    area = 0.0
    for i in range(n):
        v1 = loops[i][uv_layer].uv
        v2 = loops[(i + 1) % n][uv_layer].uv
        area += v1.x * v2.y - v2.x * v1.y
    return abs(area) * 0.5, area < 0


def is_face_flipped(face: bmesh.types.BMFace, uv_layer: bmesh.types.BMLayerItem):
    _, is_flipped = calc_face_uv_area(face, uv_layer)
    return is_flipped
