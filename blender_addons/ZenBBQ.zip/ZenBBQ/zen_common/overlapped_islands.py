# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2026, Alex Zhornyak (alexander.zhornyak@gmail.com)

import bmesh
import numpy as np
from bpy_extras.bmesh_utils import bmesh_linked_uv_islands

from mathutils.geometry import tessellate_polygon


def _get_island_bbox(island, uv_layer):
    xs = []
    ys = []
    for f in island:
        for loop in f.loops:
            uv = loop[uv_layer].uv
            xs.append(uv.x)
            ys.append(uv.y)
    return min(xs), max(xs), min(ys), max(ys)


def _get_island_triangles_np(island, uv_layer):
    triangles = []
    for f in island:
        uv_vectors = [loop[uv_layer].uv for loop in f.loops]
        if len(uv_vectors) == 3:
            triangles.append((uv_vectors[0][:], uv_vectors[1][:], uv_vectors[2][:]))
            continue
        tri_indices = tessellate_polygon([uv_vectors])
        for tri in tri_indices:
            triangles.append((uv_vectors[tri[0]][:], uv_vectors[tri[1]][:], uv_vectors[tri[2]][:]))
    if not triangles:
        return np.zeros((0, 3, 2), dtype=np.float64)
    return np.array(triangles, dtype=np.float64)


def _triangle_full_containment_matrix(tris_inner, tris_outer, eps):
    Ti, To = tris_inner.shape[0], tris_outer.shape[0]
    if Ti == 0 or To == 0:
        return np.zeros((Ti, To), dtype=bool)

    pts = tris_inner.reshape(Ti, 3, 1, 2)
    t0 = tris_outer[None, None, :, 0, :]
    t1 = tris_outer[None, None, :, 1, :]
    t2 = tris_outer[None, None, :, 2, :]

    def cross_pt(o, a, b):
        return (a[..., 0] - o[..., 0]) * (b[..., 1] - o[..., 1]) - \
               (a[..., 1] - o[..., 1]) * (b[..., 0] - o[..., 0])

    d1 = cross_pt(t0, t1, pts)
    d2 = cross_pt(t1, t2, pts)
    d3 = cross_pt(t2, t0, pts)

    inside_or_on_pos = (d1 >= -eps) & (d2 >= -eps) & (d3 >= -eps)
    inside_or_on_neg = (d1 <= eps) & (d2 <= eps) & (d3 <= eps)
    per_vertex = inside_or_on_pos | inside_or_on_neg
    return per_vertex.all(axis=1)


def _triangles_overlap_batch(tris_a, tris_b, eps):
    TA = tris_a.shape[0]
    TB = tris_b.shape[0]
    if TA == 0 or TB == 0:
        return False

    a_edges = np.stack([tris_a, np.roll(tris_a, -1, axis=1)], axis=2).reshape(-1, 2, 2)
    b_edges = np.stack([tris_b, np.roll(tris_b, -1, axis=1)], axis=2).reshape(-1, 2, 2)

    Ap1, Ap2 = a_edges[:, 0, :], a_edges[:, 1, :]
    Bp1, Bp2 = b_edges[:, 0, :], b_edges[:, 1, :]

    dxB = Bp2[:, 0] - Bp1[:, 0]
    dyB = Bp2[:, 1] - Bp1[:, 1]
    d1 = dxB[None, :] * (Ap1[:, 1][:, None] - Bp1[:, 1][None, :]) - \
        dyB[None, :] * (Ap1[:, 0][:, None] - Bp1[:, 0][None, :])
    d2 = dxB[None, :] * (Ap2[:, 1][:, None] - Bp1[:, 1][None, :]) - \
        dyB[None, :] * (Ap2[:, 0][:, None] - Bp1[:, 0][None, :])

    dxA = Ap2[:, 0] - Ap1[:, 0]
    dyA = Ap2[:, 1] - Ap1[:, 1]
    d3 = dxA[:, None] * (Bp1[:, 1][None, :] - Ap1[:, 1][:, None]) - \
        dyA[:, None] * (Bp1[:, 0][None, :] - Ap1[:, 0][:, None])
    d4 = dxA[:, None] * (Bp2[:, 1][None, :] - Ap1[:, 1][:, None]) - \
        dyA[:, None] * (Bp2[:, 0][None, :] - Ap1[:, 0][:, None])

    crossing = (((d1 > eps) & (d2 < -eps)) | ((d1 < -eps) & (d2 > eps))) & \
               (((d3 > eps) & (d4 < -eps)) | ((d3 < -eps) & (d4 > eps)))
    if crossing.any():
        return True

    if _triangle_full_containment_matrix(tris_a, tris_b, eps).any():
        return True
    if _triangle_full_containment_matrix(tris_b, tris_a, eps).any():
        return True

    return False


def _compute_bbox_overlap_matrix(bboxes, eps=1e-9):
    xmin, xmax, ymin, ymax = bboxes[:, 0], bboxes[:, 1], bboxes[:, 2], bboxes[:, 3]
    overlap_x = (xmin[:, None] <= xmax[None, :] + eps) & (xmax[:, None] >= xmin[None, :] - eps)
    overlap_y = (ymin[:, None] <= ymax[None, :] + eps) & (ymax[:, None] >= ymin[None, :] - eps)
    return overlap_x & overlap_y


class ZenOverlappedException(Exception):
    pass


class ZenFlippedException(Exception):
    pass


def get_overlapped_islands(
        bm: bmesh.types.BMesh, uv_layer=None,
        eps: float = 1e-6,
        check_flipped_throw=False, check_overlapped_throw=False):

    from .uv_utils import is_face_flipped

    if uv_layer is None:
        uv_layer = bm.loops.layers.uv.active
    if uv_layer is None:
        return []

    if check_flipped_throw:
        for face in bm.faces:
            if is_face_flipped(face, uv_layer):
                raise ZenFlippedException(f"Face: {face.index} is flipped")

    islands = bmesh_linked_uv_islands(bm, uv_layer)
    n = len(islands)
    if n <= 1:
        return []

    bboxes = np.array([_get_island_bbox(isl, uv_layer) for isl in islands], dtype=np.float64)
    triangles = [_get_island_triangles_np(isl, uv_layer) for isl in islands]

    bbox_matrix = _compute_bbox_overlap_matrix(bboxes)
    i_idx, j_idx = np.triu_indices(n, k=1)
    candidate_mask = bbox_matrix[i_idx, j_idx]
    candidate_pairs = list(zip(i_idx[candidate_mask].tolist(), j_idx[candidate_mask].tolist()))

    has_overlap = [False] * n
    for i, j in candidate_pairs:
        if has_overlap[i] and has_overlap[j]:
            continue
        if _triangles_overlap_batch(triangles[i], triangles[j], eps):
            if check_overlapped_throw:
                raise ZenOverlappedException(f"Island: {i} has overlap with: {j}")

            has_overlap[i] = True
            has_overlap[j] = True

    return [islands[i] for i in range(n) if has_overlap[i]]
