# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2026, Alex Zhornyak, alexander.zhornyak@gmail.com

import bpy
import addon_utils

import os
import json
from datetime import datetime
import urllib.request
import ssl


def check_addon_version(addon_id, addon_version, addon_version_id, is_internet_enabled, n_elapsed_hours=3):
    p_new_addon_version = None

    b_is_verified_locally = False

    target_path = os.path.join("presets", "zen")
    target_path = bpy.utils.user_resource('SCRIPTS', path=target_path, create=True)
    s_local_version_cache = os.path.join(target_path, "version_cache.json")

    t_version_data = None

    if os.path.exists(s_local_version_cache):
        try:
            with open(s_local_version_cache, "r", encoding="utf-8") as f:
                t_version_data = json.load(f)
                if t_version_data:
                    t_data: dict = t_version_data.get(addon_id, dict())
                    s_time = t_data.get("timestamp", None)
                    if s_time:
                        last_time = datetime.fromisoformat(s_time)
                        current_time = datetime.now()
                        if (current_time - last_time).total_seconds() < n_elapsed_hours * 3600:

                            b_is_verified_locally = True

                            t_version = tuple(t_data.get("version", (0, 0, 0)))
                            t_was_version = addon_version
                            if t_was_version < t_version:
                                p_new_addon_version = t_version
        except Exception as e:
            print(f"{addon_id}: CHECK ADDON VERSION:", e)

    if not b_is_verified_locally:
        if is_internet_enabled:
            ssl_context = ssl._create_unverified_context()
            s_version_url = 'https://raw.githubusercontent.com/ZenMastersTeam/Zen-UV/main/README.md'
            with urllib.request.urlopen(s_version_url, context=ssl_context) as f:
                config = f.read().decode('utf-8')  # type: str

                s_identificator = f"# {addon_version_id}"

                t_lines = config.split('\n')
                for line in t_lines:
                    if line.startswith(s_identificator):
                        s_version = line.replace(s_identificator, '').strip()
                        t_version = [int(v) for v in s_version.split('.')]
                        t_version = tuple(t_version[:3])
                        t_was_version = addon_version
                        if t_was_version < t_version:
                            p_new_addon_version = t_version

                        with open(s_local_version_cache, 'w', encoding="utf-8") as f:
                            if t_version_data is None:
                                t_version_data = {}

                            t_version_data[addon_id] = {
                                "version": t_version,
                                "timestamp": datetime.now().isoformat()
                            }
                            json.dump(t_version_data, f, indent=4)

    return p_new_addon_version


def check_addon_duplicated(original_id, addon_package, addon_version):

    def check_addon_name(s_package):
        if s_package != original_id:
            raise RuntimeError(f"We do not allow to rename folder other than {original_id}!")

    if bpy.app.version < (4, 2, 0):
        # NOTE: here we will check only the name of the addon package
        check_addon_name(addon_package)
        return

    # NOTE: the checking system is essential only after Blender 4.2 when extensions were introduced
    from bl_pkg.bl_extension_ui import pkg_repo_module_prefix  # type: ignore

    from collections import defaultdict

    extension_repos = bpy.context.preferences.extensions.repos

    repo_ids = {pkg_repo_module_prefix(repo_item) for repo_item in extension_repos if repo_item.enabled}

    # NOTE: the list of all ready-to-use modules
    t_used_modules = {module.__name__: module.__file__ for module in addon_utils.modules()}

    # NOTE: 'bl_ext.RepoNNN.ZenUV' will be truncated to 'ZenUV'
    def get_identifier(module_name):
        for id in repo_ids:
            if module_name.startswith(id):
                return module_name.replace(id, "")
        return module_name

    this_addon_id = get_identifier(addon_package)

    check_addon_name(this_addon_id)

    # NOTE: dict of active addons {'ZenUV': ['bl_ext.Repo1.ZenUV', 'bl_ext.RepoNNN.ZenUV']}
    active_addons = defaultdict(list)
    for addon in bpy.context.preferences.addons:
        s_module_name = addon.module
        if s_module_name == addon_package or s_module_name not in t_used_modules:
            continue

        addon_id = get_identifier(s_module_name)

        active_addons[addon_id].append(s_module_name)

    p_addon_copies = active_addons.get(this_addon_id, [])
    if len(p_addon_copies) > 0:
        s_version = ".".join(map(str, addon_version))
        error_lines = [
            f"Can not activate {this_addon_id} {s_version}:",
            f"  1) {__file__}",
            "Other version detected:"
        ]

        for idx, item in enumerate(p_addon_copies):
            error_lines.append(f"  {idx + 2}) {item} - {t_used_modules.get(item, '')}")

        raise RuntimeError("\n".join(error_lines))
