# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2023, Alex Zhornyak (alexander.zhornyak@gmail.com)


class ZenContext:

    PROXY = None

    @classmethod
    def get_prefs(cls):
        return cls.PROXY.get_prefs()

    @classmethod
    def get_combo_panel_props(cls):
        return cls.PROXY.get_combo_panel_props()

    @classmethod
    def get_combo_panel_map(cls):  # uv_enblr
        return cls.PROXY.get_combo_panel_map()

    @classmethod
    def get_polls(cls):
        return cls.PROXY.get_polls()

    @classmethod
    def get_log(cls):
        return cls.PROXY.get_log()
