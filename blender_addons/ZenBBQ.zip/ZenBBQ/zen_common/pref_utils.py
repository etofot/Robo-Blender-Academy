# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2024, Alex Zhornyak (alexander.zhornyak@gmail.com)

import bpy

app_version = bpy.app.version


class ZenAddonExpandProps:
    def prepare_layout_panel(
            self, p_layout: bpy.types.UILayout, s_identifier: str,
            fn_draw_header: callable = None,
            fn_create_body: callable = lambda layout: layout.box(), s_panel_caption: str = None):
        body: bpy.types.UILayout = None

        if not s_panel_caption:
            s_panel_caption = self.bl_rna.properties[s_identifier].name

        if app_version >= (4, 1, 0):
            header: bpy.types.UILayout = None
            panel: bpy.types.UILayout = None

            header, panel = p_layout.panel_prop(self, s_identifier)
            if fn_draw_header is None:
                header.label(text=s_panel_caption)
            else:
                fn_draw_header(header)
            if panel:
                body = fn_create_body(panel)
        else:
            b_expanded = getattr(self, s_identifier)

            s_icon = 'TRIA_DOWN' if b_expanded else 'TRIA_RIGHT'

            header = p_layout.row(align=True)
            header.alignment = 'LEFT'
            if fn_draw_header is None:
                header.prop(self, s_identifier, text=s_panel_caption, icon=s_icon, emboss=False)
            else:
                header.prop(self, s_identifier, text="", icon=s_icon, emboss=False)
                fn_draw_header(header)

            if b_expanded:
                body = fn_create_body(p_layout)

        return body
