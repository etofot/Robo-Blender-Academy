# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2024, Alex Zhornyak, alexander.zhornyak@gmail.com

import bpy
from timeit import default_timer as timer
import logging
from datetime import timedelta
from dataclasses import dataclass
import os

from ..vlog import Log

from .bake_ui import ScxmlBakeItem
from ..blend_scxml.monitor_scxml import UdpMonitorMachine
from ..commonFunc import ZBBQ_MaterialFunc, ZBBQ_CommonFunc, ZBBQ_Consts


@dataclass
class BakeObjectData:
    collection: bpy.types.Collection = None
    object: bpy.types.Object = None
    index: int = 0


class ScxmlBakeLogicException(Exception):
    pass


class ScxmlBakeObjectException(Exception):
    pass


def FormatTimeStr(milliseconds):
    # Check if milliseconds is zero
    if milliseconds <= 0:
        return "00:00.000"

    # Convert milliseconds to timedelta
    delta = timedelta(milliseconds=milliseconds)

    # Extract components
    hours = int(delta.total_seconds() // 3600)
    minutes = int((delta.total_seconds() % 3600) // 60)
    seconds = int(delta.total_seconds() % 60)
    milliseconds = delta.microseconds // 1000

    # Hide zero hours only if they are the only non-zero component
    if hours == 0:
        return f"{minutes:02d}:{seconds:02d}.{milliseconds:03d}"
    else:
        # Format the string with leading zeros
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}.{milliseconds:03d}"


class ScxmlData:

    def __init__(self, sm: UdpMonitorMachine) -> None:
        self.sm = sm

        self.IS_FIRST = False

        self.WAS_ENGINE = ""
        self.WAS_PREVIEW_MAP = ""
        self.WERE_PROP_SPACES = {}
        self.s_BAKE_OBJECT = ""
        self.WAS_ACTIVE_OBJECT = ""
        self.WERE_SELECTED_OBJECTS = set()
        self.WERE_RENDERED_STATE = {}

        self.init_and_clear_data()

    def init_and_clear_data(self):
        self.s_BAKE_ERROR = ""
        self.t_OVERRIDE_STATE = {}
        self.t_BAKE_MATS = set()
        self.it_BAKE_MAP = None
        self.p_BAKE_MAPS = None
        self.t_EXPLODE_STATE = {}

    @classmethod
    def update_view(cls):
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

    def check_bake_ready_throw(self):
        from ..sceneConfig import ZBBQ_SceneProperties
        ctx = bpy.context

        if bpy.app.is_job_running("OBJECT_BAKE"):
            raise RuntimeError("Baking process is not finished yet!")

        p_scene = ctx.scene
        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq
        p_init_objects = p_scene_props.get_init_bake_objects(ctx)
        if len(p_init_objects) == 0:
            raise RuntimeError("No selected mesh objects!")

        p_bake_maps_items = p_scene_props.get_actve_bake_maps().items()
        if len(p_bake_maps_items) == 0:
            raise RuntimeError("No active bake maps (Normal, AO, etc.)!")

    # MARK: Bake Start
    def bake_start(self):
        try:
            from ..sceneConfig import ZBBQ_SceneProperties

            addon_prefs = ZBBQ_CommonFunc.GetPrefs()

            ctx = bpy.context
            p_scene = ctx.scene
            p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

            self.init_and_clear_data()

            p_bake_maps_items = p_scene_props.get_actve_bake_maps().items()
            if len(p_bake_maps_items) == 0:
                raise ScxmlBakeLogicException("No active bake maps!")

            self.p_BAKE_MAPS = iter(p_bake_maps_items)
            self.it_BAKE_MAP = next(self.p_BAKE_MAPS)

            p_bake_collection: bpy.types.Collection = p_scene_props.bake_pinned_collection
            if not p_bake_collection:
                raise ScxmlBakeLogicException("No bake init objects data!")

            if len(p_bake_collection.objects) == 0:
                raise ScxmlBakeLogicException("There are no objects in bake init data!")

            if not self.s_BAKE_OBJECT:
                idx = 0
            else:
                idx = p_bake_collection.objects.find(self.s_BAKE_OBJECT)
                if idx not in range(len(p_scene_props.bake_pinned_collection.objects)):
                    raise ScxmlBakeObjectException(f"Can not find internal object: {self.s_BAKE_OBJECT}")

                idx += 1

            p_scene_props.bake_objects_index = idx

            self.s_BAKE_OBJECT = p_bake_collection.objects[idx].name

            p_obj: bpy.types.Object

            for p_obj in ctx.selectable_objects[:]:
                p_obj.select_set(False)

            for it_idx, p_obj in enumerate(p_scene_props.bake_pinned_collection.objects):
                if not p_scene_props.bake_batch and it_idx != idx:
                    continue

                p_obj_item: ScxmlBakeItem = p_obj.zbbq_bake_data

                p_obj_item.bake_state = 'INIT'
                p_obj_item.bake_time_start = timer()
                p_obj_item.bake_fail_status = 'NONE'

                p_explode_mod: bpy.types.Modifier = p_obj.modifiers.get(ZBBQ_Consts.bbq_explode_modifier_name, None)
                if p_explode_mod:
                    self.t_EXPLODE_STATE[p_obj] = p_explode_mod.show_render

                me: bpy.types.Mesh = p_obj.data

                if not me.uv_layers:
                    p_obj_item.bake_fail_status = 'NO_UV_MAPS'
                    self.sm.send("bake.object_not_ready")
                    raise ScxmlBakeObjectException(f"{self.s_BAKE_OBJECT} - does not have UV Maps!")

                p_obj.select_set(True)
                ctx.view_layer.objects.active = p_obj

                ZBBQ_MaterialFunc.ObjectFillMissingMatsWithDefaultZenBBQMaterial(p_obj)

                if not ZBBQ_CommonFunc.ObjectHasDataLayerRadius(p_obj):
                    p_obj_item.bake_fail_status = 'NO_BEVEL_RADIUS'
                    self.sm.send("bake.object_not_ready")
                elif not ZBBQ_CommonFunc.ObjectHasDataLayerUserDefined(p_obj):
                    p_obj_item.bake_fail_status = 'NO_USER_DEF_ATTR'
                    self.sm.send("bake.object_not_ready")
                else:
                    if addon_prefs.bake_check_flipped_uvs or addon_prefs.bake_check_overlapped_uvs:
                        res = ZBBQ_CommonFunc.ObjectCheckForOverlappedAndFlipped(
                            p_obj, check_overlapped=addon_prefs.bake_check_overlapped_uvs,
                            check_flipped=addon_prefs.bake_check_flipped_uvs)
                        if res[0]:
                            p_obj_item.bake_fail_status = 'OVERLAPPED'
                        elif res[1]:
                            p_obj_item.bake_fail_status = 'FLIPPED'

                self.t_OVERRIDE_STATE[self.s_BAKE_OBJECT] = (
                    ZBBQ_MaterialFunc.obj_has_materials_with_node(
                        ctx, p_obj, ZBBQ_Consts.PREVIEW_SHADER_NAME, use_mat_suffix=True),
                    ZBBQ_MaterialFunc.obj_has_materials_with_node(
                        ctx, p_obj, ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME, use_mat_suffix=True),
                )

                for idx, it_mat in enumerate(me.materials):
                    if p_scene_props.bake_material_mode == 'ACTIVE' and p_obj.active_material != it_mat:
                        continue

                    self.t_BAKE_MATS.add(it_mat)

            cycles = getattr(ctx.scene, "cycles", None)
            if cycles:
                cycles.device = p_scene_props.bake_render_device
                cycles.use_denoising = False

            self.sm.send("bake.object.next_map")
        except ScxmlBakeLogicException as e:
            self.s_BAKE_ERROR = str(e)
            logging.error(self.s_BAKE_ERROR)
            self.sm.send("bake.error", data=self.s_BAKE_ERROR)
        except ScxmlBakeObjectException as e:
            self.s_BAKE_ERROR = str(e)
            logging.error(self.s_BAKE_ERROR)
            self.sm.send("bake.object.failed_to_start", data=self.s_BAKE_ERROR)

    # MARK: Bake Map
    def bake_map(self):
        try:
            from ..sceneConfig import ZBBQ_SceneProperties

            ctx = bpy.context
            p_scene = ctx.scene
            p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq
            addon_prefs = ZBBQ_CommonFunc.GetPrefs()

            p_bake_collection: bpy.types.Collection = p_scene_props.bake_pinned_collection
            if not p_bake_collection:
                raise ScxmlBakeLogicException("No bake init objects data!")

            if len(p_bake_collection.objects) == 0:
                raise ScxmlBakeLogicException("There are no objects in bake init data!")

            s_map_id = self.it_BAKE_MAP[0].upper()
            p_scene_props.preview_map = s_map_id

            p_handled_materials = set()

            p_handled_images = set()

            s_image_suffix = self.it_BAKE_MAP[1].bake_image_suffix

            b_disable_explode = getattr(self.it_BAKE_MAP[1], "bake_disable_explode_in_renders", False)

            n_bake_margin = (
                self.it_BAKE_MAP[1].bake_margin
                if self.it_BAKE_MAP[1].bake_image_size_override
                else p_scene_props.bake_margin)

            p_obj: bpy.types.Object
            for it_idx, p_obj in enumerate(p_scene_props.bake_pinned_collection.objects):
                if not p_scene_props.bake_batch and it_idx != p_scene_props.bake_objects_index:
                    continue

                p_explode_mod: bpy.types.Modifier = p_obj.modifiers.get(ZBBQ_Consts.bbq_explode_modifier_name, None)
                if p_explode_mod:
                    if b_disable_explode:
                        p_explode_mod.show_render = False
                    else:
                        p_explode_render_state = self.t_EXPLODE_STATE.get(p_obj, None)
                        if p_explode_render_state is not None:
                            if p_explode_mod.show_render != p_explode_render_state:
                                p_explode_mod.show_render = p_explode_render_state

                me: bpy.types.Mesh = p_obj.data

                for idx, it_mat in enumerate(me.materials):
                    if p_scene_props.bake_material_mode == 'ACTIVE' and p_obj.active_material != it_mat:
                        continue

                    if it_mat not in p_handled_materials:
                        p_handled_materials.add(it_mat)
                    else:
                        continue

                    s_image_name = ZBBQ_MaterialFunc.GetBakeImageName(
                        p_scene, it_mat, ctx.collection, p_obj, idx, s_image_suffix)

                    p_node_image = None

                    p_baking_nodes = ZBBQ_MaterialFunc.MaterialGetShaderNodesBakingImages(it_mat, s_image_name)
                    if p_baking_nodes:
                        p_node_image = p_baking_nodes[0]

                    ZBBQ_MaterialFunc.MaterialRemoveOverrideNode(it_mat)

                    if addon_prefs.shader_preview_enabled:
                        ZBBQ_MaterialFunc.MaterialAddOverrideNode(
                            p_obj,
                            it_mat,
                            ZBBQ_Consts.PREVIEW_SHADER_NAME,
                            ZBBQ_Consts.PREVIEW_SHADER_NAME,
                            reset=False)

                    if p_node_image is None:
                        p_node_image = ZBBQ_MaterialFunc.MaterialAddShaderNodeBakingImage(it_mat, s_image_name)

                    if p_node_image:
                        p_image = p_node_image.image
                        if p_image and p_image not in p_handled_images:
                            p_handled_images.add(p_image)

                            p_node_image.image = ZBBQ_MaterialFunc.CheckBakeImageSize(ctx, it_mat, p_image)
                            p_node_image.image.generated_color = self.it_BAKE_MAP[1].IMAGE_COLOR

                        nodes = it_mat.node_tree.nodes
                        for node in nodes:
                            node.select = False

                        p_node_image.select = True
                        nodes.active = p_node_image
                    else:
                        raise ScxmlBakeObjectException("Can not find bake image node in {self.s_BAKE_OBJECT}:{it_mat.name}")

            n_margin = 0 if p_scene_props.bake_batch else n_bake_margin

            p_bake_type = (
                'EMIT'
                if p_scene_props.preview_map != 'NORMAL' or (
                    addon_prefs.shader_preview_enabled and p_scene_props.use_bbq_engine) else
                'NORMAL'
            )

            res = {}
            if bpy.ops.object.bake.poll():
                res = bpy.ops.object.bake(
                    'INVOKE_DEFAULT',
                    type=p_bake_type,
                    use_selected_to_active=False,
                    use_clear=False,
                    normal_space="TANGENT",
                    normal_r="POS_X",
                    normal_g='NEG_Y' if p_scene_props.is_direct_x else 'POS_Y',
                    normal_b="POS_Z",
                    margin_type='EXTEND',
                    margin=n_margin
                )

            if 'RUNNING_MODAL' not in res:
                raise ScxmlBakeLogicException("Can not execute Bake operator!")

        except ScxmlBakeLogicException as e:
            self.s_BAKE_ERROR = str(e)
            logging.error(self.s_BAKE_ERROR)
            self.sm.send("bake.error", data=self.s_BAKE_ERROR)
        except ScxmlBakeObjectException as e:
            self.s_BAKE_ERROR = str(e)
            logging.error(self.s_BAKE_ERROR)
            self.sm.send("bake.object.failed_to_start", data=self.s_BAKE_ERROR)

    def bake_map_exit(self):
        try:
            ctx = bpy.context
            from ..sceneConfig import ZBBQ_SceneProperties
            p_scene = bpy.context.scene
            p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

            p_bake_info = self.get_current_bake_object_info(ctx)

            for p_obj in p_bake_info.collection.objects:
                if not p_scene_props.bake_batch and p_obj != p_bake_info.object:
                    continue

                p_explode_state = self.t_EXPLODE_STATE.get(p_obj, None)
                if p_explode_state is not None:
                    p_explode_mod: bpy.types.Modifier = p_obj.modifiers.get(ZBBQ_Consts.bbq_explode_modifier_name, None)
                    if p_explode_mod:
                        if p_explode_mod.show_render != p_explode_state:
                            p_explode_mod.show_render = p_explode_state

        except ScxmlBakeLogicException as e:
            self.s_BAKE_ERROR = str(e)
            logging.error(self.s_BAKE_ERROR)
            self.sm.send("bake.error", data=self.s_BAKE_ERROR)

    def get_current_bake_object_info(self, context: bpy.types.Context) -> BakeObjectData:
        from ..sceneConfig import ZBBQ_SceneProperties
        ctx = bpy.context
        p_scene = ctx.scene
        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        p_bake_collection: bpy.types.Collection = p_scene_props.bake_pinned_collection
        if not p_bake_collection:
            raise ScxmlBakeLogicException("No prepared objects for baking!")

        n_obj_count = len(p_bake_collection.objects)

        idx_bake_object = p_bake_collection.objects.find(self.s_BAKE_OBJECT)
        if idx_bake_object not in range(n_obj_count):
            raise ScxmlBakeLogicException(f"Can not find internal object:{self.s_BAKE_OBJECT}")

        p_obj: bpy.types.Object = p_bake_collection.objects[idx_bake_object]
        if p_obj is None:
            raise ScxmlBakeLogicException(f"Can not find view layer object: {self.s_BAKE_OBJECT}")

        return BakeObjectData(object=p_obj, index=idx_bake_object, collection=p_bake_collection)

    def bake_object_status_changed(self, state, force_finalize=False):
        try:
            ctx = bpy.context
            from ..sceneConfig import ZBBQ_SceneProperties
            p_scene = bpy.context.scene
            p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

            p_bake_info = self.get_current_bake_object_info(ctx)

            for p_obj in p_bake_info.collection.objects:
                if not p_scene_props.bake_batch and p_obj != p_bake_info.object:
                    continue

                p_obj_item: ScxmlBakeItem = p_obj.zbbq_bake_data
                p_obj_item.bake_time = FormatTimeStr((timer() - p_obj_item.bake_time_start) * 1000)
                p_obj_item.bake_state = state

            if force_finalize:
                b_comleted = p_scene_props.bake_batch or (p_bake_info.index == len(p_bake_info.collection.objects) - 1)
                self._check_finalize_bake_index(b_comleted, is_success=False)

        except ScxmlBakeLogicException as e:
            self.s_BAKE_ERROR = str(e)
            logging.error(self.s_BAKE_ERROR)
            self.sm.send("bake.error", data=self.s_BAKE_ERROR)

    def _check_finalize_bake_index(self, b_completed, is_success: bool = True):
        if b_completed:
            if is_success:
                self.sm.send("bake.completed.success")
            else:
                self.sm.send("bake.completed.error")
        else:
            self.sm.send("bake.object.continue")

    # MARK: Bake Completed
    def bake_completed(self):
        try:
            from ..sceneConfig import ZBBQ_SceneProperties, BakeBaseProps

            ctx = bpy.context

            p_scene = ctx.scene
            p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq
            folder = p_scene_props.bake_output_directory

            p_bake_info = self.get_current_bake_object_info(ctx)

            p_handled_images = set()

            p_handled_materials = set()

            p_map: BakeBaseProps = self.it_BAKE_MAP[1]

            n_bake_margin = (
                self.it_BAKE_MAP[1].bake_margin
                if self.it_BAKE_MAP[1].bake_image_size_override
                else p_scene_props.bake_margin)

            for p_obj in p_bake_info.collection.objects:
                if not p_scene_props.bake_batch and p_obj != p_bake_info.object:
                    continue

                p_obj_item: ScxmlBakeItem = p_obj.zbbq_bake_data
                p_obj_item.bake_state = 'COMPLETED'
                p_obj_item.bake_time = FormatTimeStr((timer() - p_obj_item.bake_time_start) * 1000)

                mat: bpy.types.Material

                me: bpy.types.Mesh = p_obj.data

                for idx, mat in enumerate(me.materials):
                    if mat not in self.t_BAKE_MATS:
                        continue

                    if mat not in p_handled_materials:
                        p_handled_materials.add(mat)
                    else:
                        continue

                    p_image: bpy.types.Image = None

                    s_image_name = ZBBQ_MaterialFunc.GetBakeImageName(p_scene, mat, ctx.collection, p_obj, idx, p_map.bake_image_suffix)
                    nodes = ZBBQ_MaterialFunc.MaterialGetShaderNodesBakingImages(mat, s_image_name)
                    if nodes:
                        p_image = nodes[0].image
                        path = os.path.join(folder, s_image_name)

                        if p_image and p_image not in p_handled_images:
                            try:
                                p_handled_images.add(p_image)

                                if p_scene_props.bake_batch:
                                    ZBBQ_MaterialFunc.apply_margin_fast(p_image, margin_pixels=n_bake_margin, default_color=p_map.IMAGE_COLOR)
                                else:
                                    ZBBQ_MaterialFunc.set_alpha_channel_value(p_image, 1.0)

                                p_image.save_render(path)
                            except Exception as e:
                                raise ScxmlBakeLogicException(str(e))

                        if not p_map.bake_add_image_node_after_render:
                            for node in nodes:
                                if not ZBBQ_CommonFunc.IsNodeLinked(node):
                                    mat.node_tree.nodes.remove(node)

                    p_override_state = self.t_OVERRIDE_STATE.get(self.s_BAKE_OBJECT, None)
                    if p_override_state is not None:
                        if not p_override_state[0]:
                            ZBBQ_MaterialFunc.MaterialRemoveOverrideNode(mat)

                            if p_override_state[1] and p_image:
                                try:
                                    p_override = ZBBQ_MaterialFunc.MaterialAddOverrideNode(
                                        p_obj,
                                        mat,
                                        ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME,
                                        ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME,
                                        reset=False)
                                    if p_override:
                                        inner_nodes = p_override.node_tree.nodes

                                        ZBBQ_MaterialFunc.AssignImagesToNormalImageNodes(
                                            ctx, inner_nodes, p_scene, mat, p_obj, idx, folder, self.it_BAKE_MAP[1].bake_image_suffix)
                                    else:
                                        raise RuntimeError("Can not create preview node! Object: {obj.name} Material: {mat.name}")
                                except Exception as e:
                                    Log.error('SET IMAGE OVERRIDE:', e)

            try:
                self.it_BAKE_MAP = next(self.p_BAKE_MAPS)
                self.sm.send("bake.object.next_map")
            except StopIteration:
                b_comleted = p_scene_props.bake_batch or (p_bake_info.index == len(p_bake_info.collection.objects) - 1)
                self._check_finalize_bake_index(b_comleted)

        except ScxmlBakeLogicException as e:
            self.s_BAKE_ERROR = str(e)
            logging.error(self.s_BAKE_ERROR)
            self.sm.send("bake.error", data=self.s_BAKE_ERROR)

    def bake_item_update(self):
        try:
            from ..sceneConfig import ZBBQ_SceneProperties

            ctx = bpy.context
            p_scene = ctx.scene
            p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

            p_bake_info = self.get_current_bake_object_info(ctx)
            for p_obj in p_bake_info.collection.objects:
                if not p_scene_props.bake_batch and p_obj != p_bake_info.object:
                    continue

                p_obj_item: ScxmlBakeItem = p_obj.zbbq_bake_data
                p_obj_item.bake_time = FormatTimeStr((timer() - p_obj_item.bake_time_start) * 1000)
        except ScxmlBakeLogicException as e:
            self.s_BAKE_ERROR = str(e)
            logging.error(self.s_BAKE_ERROR)
            self.sm.send("bake.error", data=self.s_BAKE_ERROR)

    def bake_handle_error(self):
        self.s_BAKE_ERROR = self.sm.datamodel["_event"].data

    def exit_baking(self):
        from ..sceneConfig import ZBBQ_SceneProperties
        ctx = bpy.context
        p_render = ctx.scene.render
        p_scene = ctx.scene
        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        if self.WAS_PREVIEW_MAP and p_scene_props.preview_map != self.WAS_PREVIEW_MAP:
            p_scene_props.preview_map = self.WAS_PREVIEW_MAP

        if self.WAS_ENGINE and p_render.engine != self.WAS_ENGINE:
            p_render.engine = self.WAS_ENGINE

        if self.WAS_ACTIVE_OBJECT != ctx.view_layer.objects.active:
            try:
                ctx.view_layer.objects.active = self.WAS_ACTIVE_OBJECT
            except Exception as e:
                Log.error("EXIT BAKING - Active:", e)

        for obj in ctx.selectable_objects[:]:
            obj.select_set(obj in self.WERE_SELECTED_OBJECTS)

        for obj in ctx.view_layer.objects:
            p_hide_render = self.WERE_RENDERED_STATE.get(obj, None)
            if p_hide_render is not None:
                if obj.hide_render != p_hide_render:
                    obj.hide_render = p_hide_render

        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'PROPERTIES':
                    p_space_props = area.spaces.active
                    if isinstance(p_space_props, bpy.types.SpaceProperties):
                        p_context = self.WERE_PROP_SPACES.get(p_space_props, None)
                        if p_context:
                            if p_space_props.context != p_context:
                                p_space_props.context = p_context

    def enter_baking(self):
        from ..sceneConfig import ZBBQ_SceneProperties

        ctx = bpy.context
        p_render = ctx.scene.render
        p_scene = ctx.scene
        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        self.WAS_ENGINE = p_render.engine
        self.s_BAKE_OBJECT = ""
        self.WAS_PREVIEW_MAP = p_scene_props.preview_map

        if ZBBQ_CommonFunc.IsCyclesEnabled(ctx):
            if p_render.engine != 'CYCLES':
                p_render.engine = 'CYCLES'

        self.WAS_ACTIVE_OBJECT = ctx.view_layer.objects.active
        self.WERE_SELECTED_OBJECTS = set(ctx.selected_objects)

        self.WERE_RENDERED_STATE = {obj: obj.hide_render for obj in ctx.view_layer.objects}

        for obj in ctx.view_layer.objects:
            if True or obj.type == 'MESH':
                obj.hide_render = not obj.visible_get()

        if not p_scene_props.bake_objects_pin and self.IS_FIRST:
            p_scene_props.save_bake_pinned_objects(ctx)

        self.WERE_PROP_SPACES.clear()

        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'PROPERTIES':
                    p_space_props = area.spaces.active
                    if isinstance(p_space_props, bpy.types.SpaceProperties):
                        self.WERE_PROP_SPACES[p_space_props] = p_space_props.context
                        if p_space_props.context != 'SCENE':
                            p_space_props.context = 'SCENE'
