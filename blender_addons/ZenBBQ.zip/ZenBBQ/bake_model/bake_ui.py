# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2024, Alex Zhornyak, alexander.zhornyak@gmail.com

import bpy


@bpy.app.handlers.persistent
def zenbbq_bake_object_pre(obj: bpy.types.Object, _):
    from ..eventHandling import sm
    if sm:
        sm.send("bake.object.pre", data=obj)


@bpy.app.handlers.persistent
def zenbbq_bake_object_cancel(obj: bpy.types.Object, _):
    from ..eventHandling import sm
    if sm:
        sm.send("bake.object.cancel", data=obj)


@bpy.app.handlers.persistent
def zenbbq_bake_object_complete(obj: bpy.types.Object, _):
    from ..eventHandling import sm
    if sm:
        sm.send("bake.object.complete", data=obj)


class WM_OT_ZBBQScxmlBakeTrigger(bpy.types.Operator):
    bl_idname = "wm.zbbq_scxml_bake_trigger"
    bl_label = "Trigger Machine"
    bl_description = "Send event to state machine"

    event_name: bpy.props.StringProperty(
        name="Event Name",
        default=""
    )

    desc: bpy.props.StringProperty(
        name="Description",
        default=""
    )

    @classmethod
    def description(cls, context, props):
        if props:
            if props.desc:
                return props.desc
        return cls.bl_description

    def execute(self, context):
        from ..eventHandling import sm
        if sm:
            sm.send(self.event_name)
        return {'FINISHED'}


class WM_OT_ZBBQScxmlBakeStart(bpy.types.Operator):
    bl_idname = "wm.zbbq_scxml_bake_start"
    bl_label = "Bake Start"
    bl_description = "Start texture baking workflow based on bevel attributes"

    def execute(self, context):
        from ..eventHandling import sm
        from .bake import ScxmlData
        if sm:
            p_bake_data: ScxmlData = sm.datamodel["BakeData"]
            try:
                p_bake_data.check_bake_ready_throw()
            except Exception as e:
                self.report({'WARNING'}, str(e))
                return {'CANCELLED'}

            sm.send("bake.start")
        return {'FINISHED'}


class ScxmlBakeItem(bpy.types.PropertyGroup):
    bake_time: bpy.props.StringProperty(name="Bake Time", default="00:00")

    bake_time_start: bpy.props.FloatProperty(name="Bake Time Start", default=0.0, min=0.0)

    bake_state: bpy.props.EnumProperty(
        name="Bake State",
        description="Current status of the object baking process",
        items=[
            ('NONE', 'None', "No baking operations have been performed on this object"),
            ('INIT', 'Initializing', "Preparing geometry, attributes, and resources for baking"),

            ('BAKING_AO', 'Baking AO', "Ambient Occlusion map baking is currently in progress"),
            ('BAKING_CURVATURE', 'Baking Curvature', "Curvature map baking is currently in progress"),
            ('BAKING_CONVEXITY', 'Baking Convexity', "Convexity map baking is currently in progress"),
            ('BAKING_CONCAVITY', 'Baking Concavity', "Concavity map baking is currently in progress"),
            ('BAKING_BEVELS_MASK', 'Baking Bevels Mask', "Bevels Mask map baking is currently in progress"),
            ('BAKING_PARTS_ID', 'Baking Parts ID', "Parts ID map baking is currently in progress"),
            ('BAKING_MATERIAL_ID', 'Baking Material ID', "Material ID map baking is currently in progress"),
            ('BAKING_OS_NORMAL', 'Baking OS Normal', "Object Space Normal map baking is currently in progress"),
            ('BAKING_NORMAL', 'Baking Normal', "Normal map baking is currently in progress"),

            ('COMPLETED', 'Completed', "Baking finished successfully and results are ready"),
            ('FAILED', 'Failed', "Baking process encountered an error and stopped"),
            ('CANCELLED', 'Cancelled', "Baking process was interrupted by the user"),
        ],
        default="NONE"
    )

    bake_fail_status: bpy.props.EnumProperty(
        name="Bake Fail Status",
        description="The reason why bake is failed",
        items=[
            ('NONE', 'None', 'None'),
            ('NO_BEVEL_RADIUS', 'No Bevels', 'Beval radius is not set'),
            ('NO_USER_DEF_ATTR', 'No Attribute', 'Bevel user defined attribute is not set'),
            ('NO_INTACT', 'No Intact', 'Intact bevel radius is not set'),
            ('NO_UV_MAPS', 'No UVs', 'No UV maps in object'),
            ('OVERLAPPED', 'Overlapped', 'There are overlapped islands in object'),
            ('FLIPPED', 'Flipped', 'There are flipped faces in object'),
        ],
        default="NONE"
    )


class SCXML_UL_BakeList(bpy.types.UIList):

    def filter_items(self, context: bpy.types.Context, data, propname: str):
        p_objects = getattr(data, propname)

        p_selectable = set(context.selectable_objects)

        filters = {
            idx for idx, obj in enumerate(p_objects)
            if obj and obj.type != 'MESH' or obj not in p_selectable}

        # Default return values.
        flt_flags = [self.bitflag_filter_item] * len(p_objects)

        if self.use_filter_show and self.filter_name:
            flt_flags = bpy.types.UI_UL_list.filter_items_by_name(
                self.filter_name, self.bitflag_filter_item, p_objects)

        for idx in filters:
            flt_flags[idx] &= ~self.bitflag_filter_item

        flt_neworder = []

        b_alpha_sort = self.use_filter_show and self.use_filter_sort_alpha

        if b_alpha_sort:
            flt_neworder = bpy.types.UI_UL_list.sort_items_by_name(p_objects, 'name')

        return flt_flags, flt_neworder

    def draw_item(self, context: bpy.types.Context, layout: bpy.types.UILayout, data, item: bpy.types.Object, icon, active_data, active_propname, index):
        from ..eventHandling import sm
        from ..sceneConfig import ZBBQ_SceneProperties
        p_scene = context.scene
        p_bbq_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        if sm and sm.In("BakeInit"):
            row = layout.row(align=True)
            row.prop(item, "name", emboss=False, text="")
            if not p_bbq_props.bake_objects_pin and p_bbq_props.bake_objects_mode == 'COLLECTION':
                row.label(text=context.collection.name)
            return

        row = layout.row(align=False)

        p_bake_data: ScxmlBakeItem = item.zbbq_bake_data

        b_object_not_ready = p_bake_data.bake_fail_status != 'NONE'
        row.alert = p_bake_data.bake_state in {'FAILED'}

        r1 = row.row(align=True)
        r1.alert = b_object_not_ready
        b_in_progress = p_bake_data.bake_state in {'NONE', 'INIT'} or 'BAKING' in p_bake_data.bake_state
        r1.label(text=item.name, icon='TEMP' if b_in_progress else 'INFO')

        s_bake_state_label = layout.enum_item_name(p_bake_data, 'bake_state', p_bake_data.bake_state)
        op = row.operator("wm.zbbq_description_holder", emboss=False, text=s_bake_state_label)
        op.desc = layout.enum_item_description(p_bake_data, 'bake_state', p_bake_data.bake_state)
        row.prop(p_bake_data, "bake_time", text="", emboss=False)

        if b_object_not_ready:
            r1 = row.row(align=True)
            r1.alert = True
            r1.label(text=layout.enum_item_name(p_bake_data, "bake_fail_status", p_bake_data.bake_fail_status))
        else:
            if sm and sm.In("SomeObjectNotReadyActive"):
                row.label(text="")

        if sm and sm.In("BakeAllDone"):
            row.row(align=True)
            op = row.operator("wm.zbbq_activate_object", text="", icon="RESTRICT_SELECT_OFF")
            op.object_name = item.name


scxml_classes = (
    ScxmlBakeItem,

    SCXML_UL_BakeList,
    WM_OT_ZBBQScxmlBakeTrigger,
    WM_OT_ZBBQScxmlBakeStart
)


def register():
    for cls in scxml_classes:
        bpy.utils.register_class(cls)

    bpy.types.Object.zbbq_bake_data = bpy.props.PointerProperty(type=ScxmlBakeItem)

    bpy.app.handlers.object_bake_cancel.append(zenbbq_bake_object_cancel)
    bpy.app.handlers.object_bake_pre.append(zenbbq_bake_object_pre)
    bpy.app.handlers.object_bake_complete.append(zenbbq_bake_object_complete)


def unregister():

    bpy.app.handlers.object_bake_cancel.remove(zenbbq_bake_object_cancel)
    bpy.app.handlers.object_bake_pre.remove(zenbbq_bake_object_pre)
    bpy.app.handlers.object_bake_complete.remove(zenbbq_bake_object_complete)

    if hasattr(bpy.types.Object, "zbbq_bake_data"):
        del bpy.types.Object.zbbq_bake_data

    for cls in reversed(scxml_classes):
        bpy.utils.unregister_class(cls)
