# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2022, Dmitry Aleksandrovich Maslov (ABTOMAT), Alex Zhornyak (alexander.zhornyak@gmail.com), Valery Yatsenko

import bmesh
import bpy
import addon_utils

import math
import random
import os
import uuid
import colorsys
import numpy as np
from collections import defaultdict

from mathutils import Vector

from .shader_nodes.shader_overrider import BbqShaderOverrider
from .shader_nodes.image_overrider import BbqPreviewImageOverrider
from .ico import ZBBQ_Icons
from .units import ZBBQ_Units, ZBBQ_UnitsForEnumPropertyConsideringUnitSystem
from .colors import ZBBQ_Colors
from .consts import ZBBQ_Consts
from .vlog import Log
from .blender_zen_utils import ZenPolls, ZenStrUtils, _setnameex, update_view3d_in_all_screens
from .labels import ZBBQ_Labels
from .zen_common.overlapped_islands import get_overlapped_islands, ZenFlippedException, ZenOverlappedException
from .zen_common.uv_utils import is_face_flipped


_CACHE_ADDON_VERSION = None


class ZBBQ_CommonFunc:

    # ==== Checking the required conditions to use Zen BBQ
    @staticmethod
    def ObjectIsMesh(obj: bpy.types.Object):
        # Checks if this object can be used with this addon
        return obj.type == "MESH"

    @classmethod
    def GetMeshObjectsInMode(cls, context: bpy.types.Context):
        p_objects = []
        if context.mode == 'OBJECT':
            p_objects = context.selected_objects
        elif context.mode == 'EDIT_MESH':
            p_objects = context.objects_in_mode
        return [obj for obj in p_objects if obj.type == 'MESH']

    @classmethod
    def PollMeshObjectsInMode(cls, context: bpy.types.Context):
        p_objects = []
        if context.mode == 'OBJECT':
            p_objects = context.selected_objects
        elif context.mode == 'EDIT_MESH':
            p_objects = context.objects_in_mode
        return any(obj.type == 'MESH' for obj in p_objects)

    @staticmethod
    def ObjectHasDataLayerRadius(obj: bpy.types.Object):
        me: bpy.types.Mesh = obj.data
        return me.attributes.find(ZBBQ_Consts.customDataLayerRadiusName) != -1

    @staticmethod
    def ObjectHasDataLayerUserDefined(obj: bpy.types.Object):
        me: bpy.types.Mesh = obj.data
        return me.attributes.find(ZBBQ_Consts.customDataLayerUserDefinedName) != -1

    @classmethod
    def ObjectCheckForOverlappedAndFlipped(cls, obj: bpy.types.Object, check_overlapped=True, check_flipped=True):
        res = [False, False]

        me: bpy.types.Mesh = obj.data
        if me.is_editmode:
            bm = bmesh.from_edit_mesh(me)
        else:
            bm = bmesh.new()
            bm.from_mesh(me)

        try:
            if check_overlapped:
                get_overlapped_islands(bm, check_overlapped_throw=check_overlapped, check_flipped_throw=check_flipped)
            elif check_flipped:
                uv_layer = bm.loops.layers.uv.active
                if uv_layer:
                    for face in bm.faces:
                        if is_face_flipped(face, uv_layer):
                            raise ZenFlippedException(f"Face: {face.index} is flipped")

        except ZenFlippedException as e:
            res[1] = True
            Log.error("CHECK FLIPPED:", obj.name, e)
        except ZenOverlappedException as e:
            res[0] = True
            Log.error("CHECK OVERLAPPED:", obj.name, e)

        if not me.is_editmode:
            bm.free()

        return res

    @staticmethod
    def is_attribute_bevel_exist_edge_domain(obj: bpy.types.Object):
        return obj.data.attributes.find(ZBBQ_Consts.edgeAttributeBevelWidthName) != -1

    @staticmethod
    def ObjectAddDataLayerRadius(obj: bpy.types.Object):
        me: bpy.types.Mesh = obj.data
        me.attributes.new(
            name=ZBBQ_Consts.customDataLayerRadiusName,
            type="FLOAT", domain="POINT")

    @staticmethod
    def create_attribute_bevel_edge_domain(obj: bpy.types.Object):
        obj.data.attributes.new(
            name=ZBBQ_Consts.edgeAttributeBevelWidthName,
            type="FLOAT", domain="EDGE")

    @staticmethod
    def ObjectAddDataLayerUserDefined(obj: bpy.types.Object):
        me: bpy.types.Mesh = obj.data
        me.attributes.new(
            name=ZBBQ_Consts.customDataLayerUserDefinedName,
            type="FLOAT", domain="POINT")

    @staticmethod
    def ObjectSetIntactBevel(obj: bpy.types.Object, val, units):
        # print(f"Adding Property for the given object of type {type(obj)}!")
        obj.ZenBBQ_LiveBooleanRadius = val
        try:
            if units is not None:
                obj.ZBBQ_IntactBevelDisplayUnits = units
        except Exception as e:
            Log.error("SET INTACT BEVEL UNITS:", e)

    @staticmethod
    def ObjectRemoveDataLayerRadius(obj):
        # print("Removing Data Radius Layer from the given object!")
        obj.data.attributes.remove(obj.data.attributes[ZBBQ_Consts.customDataLayerRadiusName])

    @staticmethod
    def ObjectRemoveDataLayerUserDefined(obj):
        # print("Removing Data Intacntess Layer from the given object!")
        obj.data.attributes.remove(obj.data.attributes[ZBBQ_Consts.customDataLayerUserDefinedName])

    # ==== Whole object operations

    @classmethod
    def ObjectIsReadyForBevel(cls, obj: bpy.types.Object):
        try:
            if cls.ObjectIsMesh(obj):
                if cls.ObjectHasDataLayerRadius(obj):
                    if cls.ObjectHasDataLayerUserDefined(obj):
                        return True
                    else:
                        raise RuntimeError("User defined attribute is not set")
                else:
                    raise RuntimeError("Bevel radius is not set")
            else:
                raise RuntimeError("Is not a mesh")
        except Exception as e:
            Log.error(f"Obj:{obj.name}:", e)

        return False

    @classmethod
    def ObjectIsReadyForBevelSilent(cls, obj: bpy.types.Object):
        try:
            return cls.ObjectIsReadyForBevel(obj)
        except Exception:
            pass
        return False

    @classmethod
    def ObjectGetReadyForBevel(cls, obj):

        result = {'success': False, 'dataLayerWasAdded': False, 'edgeBevelAttrWasAdded': False}

        if not cls.ObjectIsMesh(obj):
            # We can't get object ready if it's not convenient at all
            return result

        if not cls.ObjectHasDataLayerRadius(obj):

            cls.ObjectAddDataLayerRadius(obj)
            result['dataLayerWasAdded'] = True

        if not cls.is_attribute_bevel_exist_edge_domain(obj):
            cls.create_attribute_bevel_edge_domain(obj)
            result['edgeBevelAttrWasAdded'] = True

        if not cls.ObjectHasDataLayerUserDefined(obj):
            cls.ObjectAddDataLayerUserDefined(obj)

        if not ZBBQ_MaterialFunc.ObjectHasMaterialsFilled(obj):
            ZBBQ_MaterialFunc.ObjectFillMissingMatsWithDefaultZenBBQMaterial(obj)

        result['success'] = True
        return result

    @classmethod
    def ObjectCleanupFromForBevel(cls, obj):
        # Remove all traces of Zen BBQ usage from the object given

        print(f"Cleaning up object: {obj}")

        if not cls.ObjectIsMesh(obj):
            # We can't get object ready if it's not convenient at all
            return

        # Material/Shader handling

        if ZBBQ_MaterialFunc.ObjectHasMaterialsFilled(obj):

            for i in range(len(obj.material_slots)):
                mat = obj.material_slots[i].material

                # User's material.
                # Remove Zen BBQ node if present.
                ZBBQ_MaterialFunc.MaterialRemoveShaderNodeNormal(mat)

                # Remove nodes that are not linked:
                ZBBQ_MaterialFunc.MaterialRemoveShaderNodeGroupsByNodeTreeName(mat, ZBBQ_Consts.NORMAL_NODE_NAME)

                # Remove override node if present
                toggleNodeTreeName = ZBBQ_Consts.PREVIEW_SHADER_NAME  # To-Do: Normal to color mode
                ZBBQ_MaterialFunc.MaterialRemoveOverrideNode(mat)  # To-Do: Multiple options

                # Remove nodes that are not linked:
                ZBBQ_MaterialFunc.MaterialRemoveShaderNodeGroupsByNodeTreeName(mat, toggleNodeTreeName)

        # Data Layer Handling

        if cls.ObjectHasDataLayerRadius(obj):
            cls.ObjectRemoveDataLayerRadius(obj)

        if cls.ObjectHasDataLayerUserDefined(obj):
            cls.ObjectRemoveDataLayerUserDefined(obj)

        me: bpy.types.Mesh = obj.data
        p_attr = me.attributes.get(ZBBQ_Consts.edgeAttributeBevelWidthName, None)
        if p_attr is not None:
            me.attributes.remove(p_attr)

        me.update()

        obj.ZenBBQ_LiveBooleanRadius = 0

        return

    @classmethod
    def IsCyclesEnabled(cls, context: bpy.types.Context):
        if bpy.app.build_options.cycles:
            addon = context.preferences.addons.get("cycles")
            if addon:
                return True
        return False

    @classmethod
    def IsCyclesActive(cls, context: bpy.types.Context):
        return context.scene.render.engine == 'CYCLES'

    @classmethod
    def UseBakeGPU(cls, context: bpy.types.Context):
        try:
            from cycles.ui import get_device_type  # type: ignore
            return get_device_type(context) != 'NONE' and context.preferences.addons["cycles"].preferences.has_active_device()
        except Exception as e:
            Log.error(e)
        return False

    @classmethod
    def GlobalCleanup(cls, context: bpy.types.Context):
        if bpy.ops.zbbq.draw_highlight.poll():
            bpy.ops.zbbq.draw_highlight('INVOKE_DEFAULT', mode='OFF')

        for obj in ZBBQ_CommonFunc.GetMeshObjectsInMode(context):
            ZBBQ_CommonFunc.ObjectCleanupFromForBevel(obj)

        # We also must remove bevel nodes and override nodes from all materials in scene even it they are not currently used on objects!

        toggleNodeTreeName = ZBBQ_Consts.PREVIEW_SHADER_NAME  # To-Do: Normal to color mode

        for mat in bpy.data.materials:
            ZBBQ_MaterialFunc.MaterialRemoveShaderNodeNormal(mat)
            ZBBQ_MaterialFunc.MaterialRemoveOverrideNode(mat)  # To-Do: Multiple options

            # Remove nodes that are not linked:
            ZBBQ_MaterialFunc.MaterialRemoveShaderNodeGroupsByNodeTreeName(mat, ZBBQ_Consts.NORMAL_NODE_NAME)
            ZBBQ_MaterialFunc.MaterialRemoveShaderNodeGroupsByNodeTreeName(mat, toggleNodeTreeName)

        for node_name in ZBBQ_Consts.NODE_TREE_PREVIEW_MAP.values():
            ZBBQ_MaterialFunc.RemoveNodeTreeFromSceneIfPresent(node_name)

        for node_name in ZBBQ_Consts.NODE_TREE_SERVICE_MAP.values():
            ZBBQ_MaterialFunc.RemoveNodeTreeFromSceneIfPresent(node_name)

        from .sceneConfig import ZBBQ_SceneProperties

        p_scene_props: ZBBQ_SceneProperties = context.scene.zen_bbq
        p_scene_props.preview_mode = 'MATERIAL'

    # ==== Mesh Ops

    @classmethod
    def SetBevelRadiusToSelectedGeometry(cls, objects, radius, apply_to_selection_border):
        obj: bpy.types.Object
        for obj in objects:

            if not cls.ObjectIsMesh(obj):
                # Non-mesh objects are ignored
                continue

            me: bpy.types.Mesh = obj.data

            if me.total_vert_sel == 0:
                continue

            getObjectReadyForBevel = cls.ObjectGetReadyForBevel(obj)

            if not getObjectReadyForBevel['success']:
                # In a normal situation, this should never happen
                print('[Zen BBQ] Error: Unable to get the object ready for Zen BBQ! (In a normal situation, this should never happen)')
                continue

            bm = bmesh.from_edit_mesh(me)

            dataLayerRadius = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerRadiusName)
            dataLayerIntactness = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerUserDefinedName)
            edgeLayerBevelWidth = bm.edges.layers.float.get(ZBBQ_Consts.edgeAttributeBevelWidthName)

            if apply_to_selection_border:
                Log.debug("Bevels appying to selection border")

                for face in [f for f in bm.faces if f.select]:
                    for loop in face.loops:
                        if not loop.link_loop_radial_next.face.select:
                            loop.edge[edgeLayerBevelWidth] = radius
                        for vert in loop.edge.verts:
                            vert[dataLayerRadius] = radius
                            vert[dataLayerIntactness] = 1.0

                # XXX: Legacy
                # for v in [v for v in bm.verts if v.select]:
                #     # Check if this is boundary of the selection.
                #     # This means that at least one loop of the vertex has vertex not selected
                #     # OR this vertex has is_boundary True

                #     if v.is_boundary:
                #         v[dataLayerRadius] = radius
                #         v[dataLayerIntactness] = 1.0
                #     else:
                #         for edge in v.link_edges:
                #             if not edge.verts[0].select or not edge.verts[1].select:
                #                 # selection boundary
                #                 v[dataLayerRadius] = radius
                #                 v[dataLayerIntactness] = 1.0
                #                 break

            else:  # No need to check if this is selection boundary
                for v in [v for v in bm.verts if v.select]:
                    v[dataLayerRadius] = radius
                    v[dataLayerIntactness] = 1.0

                for edge in [e for e in bm.edges if e.select]:
                    edge[edgeLayerBevelWidth] = radius

            bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
            from .draw_sets import ZBBQ_EdgeLayerManager, mark_groups_modified
            mark_groups_modified(ZBBQ_EdgeLayerManager, obj)

    @classmethod
    def SetPreviewMode(cls, s_mode: str, context: bpy.types.Context, reset=False):
        from .sceneConfig import ZBBQ_SceneProperties

        addon_prefs = cls.GetPrefs()

        p_scene = context.scene
        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        s_pref_path = f"{p_scene_props.preview_mode.lower()}_shading_type"
        s_value = getattr(addon_prefs, s_pref_path)

        b_switch_cycles = addon_prefs.cycles_auto_activation and s_mode == 'SHADER' and s_value == 'RENDERED'

        res = {}
        if bpy.ops.object.zen_bbq_preview_shader_node_toggle.poll():
            res = bpy.ops.object.zen_bbq_preview_shader_node_toggle(
                mode=s_mode,
                reset_nodes=reset,
                shading_type=s_value,
                switch_to_cycles=b_switch_cycles
            )
        return res

    @classmethod
    def SetShaderPreviewMode(cls, context: bpy.types.Context, reset=False):
        return cls.SetPreviewMode("SHADER", context, reset=reset)

    @classmethod
    def SetImagePreviewMode(cls, context: bpy.types.Context, reset=False):
        return cls.SetPreviewMode("IMAGE", context, reset=reset)

    @classmethod
    def SetBevelRadiusToObjects(cls, objects, radius, units):
        obj: bpy.types.Object
        for obj in objects:

            if not cls.ObjectIsMesh(obj):
                # Non-mesh objects are ignored
                continue

            getObjectReadyForBevel = cls.ObjectGetReadyForBevel(obj)

            if not getObjectReadyForBevel['success']:
                # In a normal situation, this should never happen
                print('[Zen BBQ] Error: Unable to get the object ready for Zen BBQ! (In a normal situation, this should never happen)')
                continue

            cls.ObjectSetIntactBevel(obj, radius, units)

            needToFreeBM = False

            me: bpy.types.Mesh = obj.data

            if me.is_editmode:  # Happens on scene load
                bm = bmesh.from_edit_mesh(me)
            else:
                bm = bmesh.new()
                bm.from_mesh(me)
                needToFreeBM = True

            dataLayerRadius = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerRadiusName)
            dataLayerUserDefined = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerUserDefinedName)
            edgeLayerBevelWidth = bm.edges.layers.float.get(ZBBQ_Consts.edgeAttributeBevelWidthName)

            for v in bm.verts:
                v[dataLayerRadius] = radius
                v[dataLayerUserDefined] = 1.0

            for edge in bm.edges:
                edge[edgeLayerBevelWidth] = radius

            if needToFreeBM:
                bm.to_mesh(me)
                bm.free()  # Need to free memory if bm was created via new()
            else:
                bmesh.update_edit_mesh(me)

            from .draw_sets import ZBBQ_EdgeLayerManager, mark_groups_modified
            mark_groups_modified(ZBBQ_EdgeLayerManager, obj)

        update_view3d_in_all_screens()

    @classmethod
    def SmartSelectByRadiusValues(cls, objects, radii, threshold, addToSelection):

        for obj in objects:

            if not cls.ObjectIsMesh(obj):
                # Non-mesh objects are ignored
                continue

            bm = bmesh.from_edit_mesh(obj.data)

            if not cls.ObjectHasDataLayerRadius(obj):
                # We do not add Data Layer if there is none
                # Instead, we consider all vertices to have zero radius
                # And select them all if radii contains zero
                if 0 in radii:
                    for vert in bm.verts:
                        vert.select = True
            else:

                dataLayerRadius = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerRadiusName)
                dataLayerUserDefined = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerUserDefinedName)

                # vertsNotSelected = [vert for vert in bm.verts if not vert.select]

                if not addToSelection:
                    for vert in bm.verts:
                        vert.select = False
                    for edge in bm.edges:
                        edge.select = False
                    for face in bm.faces:
                        face.select = False

                for valueToCheck in radii:

                    # To-Do: iterate from end removing already selected vertices for optimization
                    for vert in bm.verts:

                        vertRadius = 0

                        if (vert[dataLayerUserDefined] == 0):
                            vertRadius = obj.get(ZBBQ_Consts.customPropertyIntactBevelRadiusName, 0)
                        else:
                            vertRadius = vert[dataLayerRadius]

                        if abs(vertRadius - valueToCheck) <= threshold*valueToCheck:
                            vert.select = True

                # Also selecting other types of elements: edges and polygons
                # To-Do: Some optimization can be done

                for edge in bm.edges:
                    if all(vert.select for vert in edge.verts):
                        edge.select = True
                for face in bm.faces:
                    if all(vert.select for vert in face.verts):
                        face.select = True

            bmesh.update_edit_mesh(obj.data)

    @classmethod
    def ReplaceBevelRadius(cls, p_objects: list, source_radius: list, target_radius: float, invert=False):
        from .draw_sets import mark_groups_modified, ZBBQ_EdgeLayerManager
        b_modified = False

        t_cache = {}

        def is_matched(val):
            if val in t_cache:
                return t_cache[val]

            res = False
            for source in source_radius:
                if abs(val - source) <= 0.00001:
                    res = True
                    break

            t_cache[val] = res

            return res

        for obj in p_objects:
            if obj.type != 'MESH':
                continue

            b_obj_modified = False

            me: bpy.types.Mesh = obj.data
            if me.is_editmode:
                bm = bmesh.from_edit_mesh(me)
                bm.verts.ensure_lookup_table()
                p_layer = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerRadiusName, None)
                if p_layer:
                    for v in bm.verts:
                        val = v[p_layer]
                        if val == target_radius:
                            continue
                        b_match = is_matched(val)
                        if (b_match and not invert) or (not b_match and invert):
                            v[p_layer] = target_radius
                            b_obj_modified = True
                            b_modified = True

                    if b_obj_modified:
                        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
                        mark_groups_modified(ZBBQ_EdgeLayerManager, obj)
            else:
                p_attr: bpy.types.FloatAttribute = me.attributes.get(ZBBQ_Consts.customDataLayerRadiusName, None)
                if p_attr:
                    for item in p_attr.data:
                        val = item.value
                        if val == target_radius:
                            continue
                        b_match = is_matched(val)
                        if (b_match and not invert) or (not b_match and invert):
                            item.value = target_radius
                            b_obj_modified = True
                            b_modified = True

                    if b_obj_modified:
                        me.update()
                        mark_groups_modified(ZBBQ_EdgeLayerManager, obj)
        return b_modified

    # ==== Common

    @staticmethod
    def Report(op, text):
        op.report({'INFO'}, '[Zen BBQ] '+text)

    @staticmethod
    def Log(op, text):  # For cases when OP.report is not available
        print('[Zen BBQ] '+text)

    StrConfirmQuestionCachedVriants = ["OK?", "proceed?", "right?", "confirm?", "mmkay?", "srsly?", "correct?", "shall we?"]
    StrConfirmQuestionAnchorObj = None
    StrConfirmQuestionCachedVal = random.choice(StrConfirmQuestionCachedVriants)

    @classmethod
    def StrConfirmQuestion(cls, anchorObj):
        return "OK?"

    @staticmethod
    def View3DIsModeRendered():
        for space in bpy.context.area.spaces:
            if space.type == 'VIEW_3D':
                if space.shading.type == "RENDERED":
                    return True
        return False

    @classmethod
    def IsRenderPreviewActive(cls):
        p_cycles = getattr(bpy.context.scene, "cycles", None)
        return bpy.context.scene.render.engine == 'CYCLES' and p_cycles and not p_cycles.preview_pause and cls.View3DIsModeRendered()

    # ==== Preferences

    # Returns pointer to the preferences object of the addon
    @staticmethod
    def GetPrefs():
        from .preferences import ZBBQ_Prefs
        addon_prefs: ZBBQ_Prefs = bpy.context.preferences.addons[ZenPolls.ADDON_PACKAGE].preferences
        return addon_prefs

    @classmethod
    def GetSessionUID(cls, bl_data: bpy.types.ID) -> str:
        if bl_data is not None:
            return getattr(bl_data, "session_uid", getattr(bl_data, "session_uuid", bl_data.name))
        return ""

    @staticmethod
    def GetAddonVersion():
        global _CACHE_ADDON_VERSION
        if _CACHE_ADDON_VERSION is None:
            for addon in addon_utils.modules():
                if addon.bl_info['name'] == 'Zen BBQ':
                    ver = addon.bl_info['version']
                    _CACHE_ADDON_VERSION = '%i.%i.%i' % (ver[0], ver[1], ver[2])
                    break

        return _CACHE_ADDON_VERSION if _CACHE_ADDON_VERSION else '0.0.0'

    # Returns currently selected presets if there is one or None otherwise
    @staticmethod
    def GetActiveBevelPresetGroup():
        return bpy.context.scene.ZBBQ_PresetsIncluded

    @classmethod
    def GetActiveBevelPreset(cls):
        return cls.GetActiveBevelPresetGroup().GetActiveBevelPreset()

    @classmethod
    def FillPreset(cls, bpg, units):
        unitInfo = ZBBQ_Units[units]

        colors = list(ZBBQ_Colors.values())

        for i in range(6):
            preset = bpg.bevelPresets.add()
            preset.unitSystem = unitInfo.unitSystem  # Need to set this first for correct list of Enum options
            preset.radius = unitInfo.defaultValues[i]  # To-Do: Have some standard values for each unit
            preset.units = units
            preset.colorId = [*ZBBQ_Colors][i]
            preset.color = colors[i].color

    @classmethod
    def CreateBevelPresetGroup(cls, title, units):

        prefs = cls.GetPrefs()

        bpg = prefs.bevelPresetGroups.add()
        _setnameex(bpg, title, collection_from_element=lambda self: prefs.bevelPresetGroups)
        bpg.title = bpg.name

        unitInfo = ZBBQ_Units[units]
        bpg.unitSystem = unitInfo.unitSystem

        cls.FillPreset(bpg, units)

        prefs.bevelPresetGroupsDropdown = bpg.name

        return bpg

    @classmethod
    def BevelPresetGroupsCreateDefaultIfNone(cls):
        prefs = cls.GetPrefs()

        for bpg in prefs.bevelPresetGroups:
            bpg.name = bpg.title

        if len(prefs.bevelPresetGroups) == 0:
            cls.BevelPresetGroupsCreateDefault()

    @classmethod
    def BevelPresetGroupsCreateDefault(cls):
        prefs = cls.GetPrefs()

        cls.CreateBevelPresetGroup('Default mm',     'MILLIMETERS')
        cls.CreateBevelPresetGroup('Default cm',     'CENTIMETERS')
        cls.CreateBevelPresetGroup('Default m',      'METERS')
        cls.CreateBevelPresetGroup('Default inches', 'INCHES')

        prefs.bevelPresetGroupsDropdown = ''

    @classmethod
    def BevelPresetGroupsResetToDefault(cls):
        prefs = cls.GetPrefs()

        for i in range(len(prefs.bevelPresetGroups)-1, -1, -1):
            prefs.bevelPresetGroups.remove(i)

        cls.BevelPresetGroupsCreateDefault()

    ULIndexToPieMenuNumKey = {
        0: 9,
        1: 6,
        2: 3,
        3: 1,
        4: 4,
        5: 7
    }

    PieMenuIndexToPieMenuNumKey = {
        0: 4,
        1: 6,
        2: 8,
        3: 2,
        4: 7,
        5: 9,
        6: 1,
        7: 3
    }

    @classmethod
    def ULIndexAndColorToPieMenuIconId(cls, index, color):
        return ZBBQ_Icons[f'{color}Position{cls.ULIndexToPieMenuNumKey[index]}'].id()

    @classmethod
    def PieMenuIndexAndColorToPieMenuIconId(cls, index, color):
        return ZBBQ_Icons[f'{color}Position{cls.PieMenuIndexToPieMenuNumKey[index]}'].id()

    @classmethod
    def GetSceneName(cls, context: bpy.types.Context):
        scene_name = bpy.path.display_name_from_filepath(bpy.data.filepath)

        return scene_name if scene_name else context.scene.name

    @classmethod
    def IsNodeLinked(cls, node):
        return any(s.is_linked for s in node.inputs) or any(s.is_linked for s in node.outputs)


class ZBBQ_MaterialFunc:

    @classmethod
    def get_material_map(cls, objects: list):
        p_material_map = defaultdict(dict)
        obj: bpy.types.Object
        for obj in objects:
            for idx, slot in enumerate(obj.material_slots):
                p_material = slot.material
                if p_material:
                    p_material_map[obj][p_material] = idx
        return p_material_map

    @staticmethod
    def ObjectHasMaterialsFilled(obj):

        if len(obj.material_slots) == 0:
            return False

        for matSlot in obj.material_slots:
            if matSlot.material is None:
                return False

        return True

    # ==== Node Trees

    @classmethod
    def GetNodeGroup(cls, node_group_name: str, node_base_name: str, reset=True):
        p_node: bpy.types.NodeTree = bpy.data.node_groups.get(node_group_name, None)

        if p_node:
            if not reset:
                if not cls.IsVersionValid(p_node, node_base_name):
                    reset = True

        if not reset:
            for sub_node_name in ZBBQ_Consts.NODE_TREE_DEPENDENCY.get(node_base_name, tuple()):
                p_sub_node = bpy.data.node_groups.get(sub_node_name, None)
                if p_sub_node:
                    if not cls.IsVersionValid(p_sub_node, sub_node_name):
                        reset = True
                        break

        if reset:
            for sub_node_name in ZBBQ_Consts.NODE_TREE_DEPENDENCY.get(node_base_name, tuple()):
                cls.RemoveNodeTreeFromSceneIfPresent(sub_node_name)

            if p_node:
                bpy.data.node_groups.remove(p_node)
            p_node = None

        return p_node

    @classmethod
    def GetOrCreateNodeTree(cls, node_base_name, reset=True, mat: bpy.types.Material = None, obj: bpy.types.Object = None):
        if node_base_name == ZBBQ_Consts.NORMAL_NODE_NAME:
            p_node = cls.GetNodeGroup(ZBBQ_Consts.NORMAL_NODE_NAME, ZBBQ_Consts.NORMAL_NODE_NAME, reset=reset)
            if p_node:
                return p_node
            else:
                return BbqShaderOverrider.build_service_normals_mixer_ng(is_user_mixer=False)
        elif node_base_name == ZBBQ_Consts.PREVIEW_SHADER_NAME:
            s_name = ZBBQ_MaterialFunc.GetNodeNameByMat(mat, ZBBQ_Consts.PREVIEW_SHADER_NAME)
            p_node = cls.GetNodeGroup(s_name, ZBBQ_Consts.PREVIEW_SHADER_NAME, reset=reset)
            if p_node:
                return p_node
            else:
                return cls.build_bbq_preview_shader(mat, reset=reset)
        elif node_base_name == ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME:
            s_name = ZBBQ_MaterialFunc.GetNodeNameByMat(mat, ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME)
            p_node = cls.GetNodeGroup(s_name, ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME, reset=reset)
            if p_node:
                return p_node
            else:
                return cls.CreateNodeTreePreviewNormalImage(mat, obj)
        elif node_base_name == ZBBQ_Consts.NORMAL_NODE_MIXER_NAME:
            p_node = cls.GetNodeGroup(ZBBQ_Consts.NORMAL_NODE_MIXER_NAME, ZBBQ_Consts.NORMAL_NODE_MIXER_NAME, reset=reset)
            if p_node:
                return p_node
            else:
                return BbqShaderOverrider.build_service_normals_mixer_ng(is_user_mixer=True)
        else:
            raise RuntimeError(f"Node tree: {node_base_name} is not defined!")

    @classmethod
    def CheckNodeTreesVersionsAndUpdateIfNecessary(cls):
        return
        if cls.NodeTreeNormalPresent():
            # We must check version of Normal Tree and update it if necessary before returning!
            if cls.NodeTreeNormalGetVersion() != ZBBQ_Consts.shaderNodeTreeNormalNameCurrentVersion:
                Log.debug(f"Need to update node tree from version: {cls.NodeTreeNormalGetVersion()} to: {ZBBQ_Consts.shaderNodeTreeNormalNameCurrentVersion}")

                snNormal = ZBBQ_MaterialFunc.GetOrCreateNodeTree(ZBBQ_Consts.NORMAL_NODE_NAME, reset=False)
                if snNormal:
                    ZBBQ_MaterialFunc.ClearNodeTreeStructure(snNormal)
                    ZBBQ_MaterialFunc.BuildNodeTreeStructureNormal(snNormal)

                snNormalMixer = ZBBQ_MaterialFunc.GetOrCreateNodeTree(ZBBQ_Consts.NORMAL_NODE_MIXER_NAME, reset=False)
                if snNormalMixer:
                    ZBBQ_MaterialFunc.ClearNodeTreeStructure(snNormalMixer)
                    ZBBQ_MaterialFunc.BuildNodeTreeStructureNormal(snNormalMixer, is_normals_mixer=True)
            else:
                Log.debug(f"Need to update node tree version is current: {cls.NodeTreeNormalGetVersion()}")

    @classmethod
    def RemoveNodeTreeFromSceneIfPresent(cls, nodeTreeName):
        for p_node_group in reversed(bpy.data.node_groups):
            if nodeTreeName in p_node_group.name:
                bpy.data.node_groups.remove(p_node_group)

    @classmethod
    def ClearNodeTreeStructure(cls, nodeGroup: bpy.types.NodeGroup):
        nodes_to_remove = [
            node for node in nodeGroup.nodes
            if node.type not in {'GROUP_INPUT', 'GROUP_OUTPUT'}
        ]

        for node in nodes_to_remove:
            nodeGroup.nodes.remove(node)

        nodeGroup.links.clear()

    @staticmethod
    def BuildNodeTreeStructureNormal(reset):
        return BbqShaderOverrider.build_service_normals_mixer_ng(reset)

    @classmethod
    def BuildNodeTreeStructureNormal_legacy(cls, nodeGroup):
        snInput = nodeGroup.nodes.new('NodeGroupInput')
        snInput.location = (0, -100)

        if ZenPolls.version_lower_4_0_0:
            nodeGroup.inputs.new('NodeSocketVectorXYZ', 'Normal')
        else:
            nodeGroup.interface.new_socket(
                name='Normal',
                socket_type='NodeSocketVector',
                in_out='INPUT'
            )

        snOutput = nodeGroup.nodes.new('NodeGroupOutput')
        snOutput.location = (400, 0)
        snOutput.name = "ver: " + ZBBQ_Consts.shaderNodeTreeNormalNameCurrentVersion

        if ZenPolls.version_lower_4_0_0:
            nodeGroup.outputs.new('NodeSocketVectorXYZ', 'Normal')
        else:
            nodeGroup.interface.new_socket(
                name='Normal',
                socket_type='NodeSocketVector',
                in_out='OUTPUT'
            )

        # print(len(nodeGroup.interface.items_tree))

        snAttributeGeoUserDefined = nodeGroup.nodes.new('ShaderNodeAttribute')
        snAttributeGeoUserDefined.attribute_name = ZBBQ_Consts.customDataLayerUserDefinedName
        snAttributeGeoUserDefined.location = (-200, 300)

        snAttributeObjIntactBevelRadius = nodeGroup.nodes.new('ShaderNodeAttribute')
        snAttributeObjIntactBevelRadius.attribute_type = "OBJECT"
        snAttributeObjIntactBevelRadius.attribute_name = ZBBQ_Consts.customPropertyIntactBevelRadiusName
        snAttributeObjIntactBevelRadius.location = (-200, 100)

        snAttributeGeoRadius = nodeGroup.nodes.new('ShaderNodeAttribute')
        snAttributeGeoRadius.attribute_name = ZBBQ_Consts.customDataLayerRadiusName
        snAttributeGeoRadius.location = (-200, -100)

        snMix = nodeGroup.nodes.new('ShaderNodeMix')
        snMix.location = (0, 100)

        snBevel = nodeGroup.nodes.new('ShaderNodeBevel')
        snBevel.samples = bpy.context.scene.ZBBQ_PreviewRenderUserConfig.bevelNodeSamples
        snBevel.location = (200, 5)

        # Mix

        nodeGroup.links.new(
            snMix.inputs['Factor'],
            snAttributeGeoUserDefined.outputs['Fac'])

        nodeGroup.links.new(
            snMix.inputs['A'],
            snAttributeObjIntactBevelRadius.outputs['Fac'])

        nodeGroup.links.new(
            snMix.inputs['B'],
            snAttributeGeoRadius.outputs['Fac'])

        # Output

        nodeGroup.links.new(
            snBevel.inputs['Radius'],
            snMix.outputs['Result'])

        if not ZenPolls.version_since_5_0_0:
            nodeGroup.links.new(
                snBevel.inputs['Normal'],
                snInput.outputs['Normal'])

        nodeGroup.links.new(snBevel.outputs[0], snOutput.inputs[0])

    @staticmethod
    def NodeTreeNormalPresent():
        return ZBBQ_Consts.NORMAL_NODE_NAME in bpy.data.node_groups.keys()

    @classmethod
    def NodeTreeNormalGetVersion(cls):

        if not cls.NodeTreeNormalPresent():
            return 0  # Zero = not found

        version = 1.0

        nodeTreeNormal = bpy.data.node_groups[ZBBQ_Consts.NORMAL_NODE_NAME]
        for node in nodeTreeNormal.nodes:
            if node.type == "GROUP_OUTPUT":
                splitResult = node.name.split(":")
                if len(splitResult) >= 2 and splitResult[0].strip() == "ver":
                    version = splitResult[1].strip()

        return version

    @classmethod
    def get_label_version_name(cls, node_group_name, node_base_name=None):
        if node_base_name is None:
            node_base_name = node_group_name

        return ZBBQ_Consts.NODE_TREE_VERSIONS[node_base_name]

    @classmethod
    def build_bbq_preview_shader(cls, mat: bpy.types.Material, reset=True):
        s_node_group_name = cls.GetNodeNameByMat(mat, ZBBQ_Consts.PREVIEW_SHADER_NAME)

        nodeGroup: bpy.types.NodeTree = bpy.data.node_groups.new(s_node_group_name, 'ShaderNodeTree')
        nodeGroup.zen_bbq_version = cls.get_label_version_name(s_node_group_name, node_base_name=ZBBQ_Consts.PREVIEW_SHADER_NAME)

        snInput = nodeGroup.nodes.new('NodeGroupInput')
        snInput.location = (0, -5)
        if ZenPolls.version_lower_4_0_0:
            nodeGroup.inputs.new('NodeSocketShader', 'Surface')
        else:
            nodeGroup.interface.new_socket(
                name='Surface',
                socket_type='NodeSocketShader',
                in_out='INPUT'
            )

        snOutput = nodeGroup.nodes.new('NodeGroupOutput')
        snOutput.location = (500, -5)
        if ZenPolls.version_lower_4_0_0:
            nodeGroup.outputs.new('NodeSocketShader', 'Surface')
        else:
            nodeGroup.interface.new_socket(
                name='Surface',
                socket_type='NodeSocketShader',
                in_out='OUTPUT'
            )

        BbqShaderOverrider.build_preview_shader(nodeGroup, mat, reset=reset)

        return nodeGroup

    @classmethod
    def CreateNodeTreePreviewNormalImage(cls, mat: bpy.types.Material, obj: bpy.types.Object):

        # addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        s_node_group_name = cls.GetNodeNameByMat(mat, ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME)

        nodeGroup = bpy.data.node_groups.new(s_node_group_name, 'ShaderNodeTree')

        # Basic Shader, Inout and Output

        snInput = nodeGroup.nodes.new('NodeGroupInput')
        snInput.location = (0, -5)
        if ZenPolls.version_lower_4_0_0:
            nodeGroup.inputs.new('NodeSocketShader', 'Surface')
        else:
            nodeGroup.interface.new_socket(
                name='Surface',
                socket_type='NodeSocketShader',
                in_out='INPUT'
            )

        snOutput = nodeGroup.nodes.new('NodeGroupOutput')
        snOutput.location = (500, -5)
        if ZenPolls.version_lower_4_0_0:
            nodeGroup.outputs.new('NodeSocketShader', 'Surface')
        else:
            nodeGroup.interface.new_socket(
                name='Surface',
                socket_type='NodeSocketShader',
                in_out='OUTPUT'
            )

        # Legacy

        # snShader = nodeGroup.nodes.new('ShaderNodeBsdfPrincipled')
        # snShader.location = (200, 0)

        # base_color = addon_prefs.image_preview_color
        # snShader.inputs['Base Color'].default_value = base_color
        # snShader.inputs['Metallic'].default_value = 1

        # nodeGroup.links.new(snShader.outputs['BSDF'], snOutput.inputs[0])

        # # ZenBBQ Node
        # node_normal_map = nodeGroup.nodes.new(type='ShaderNodeNormalMap')
        # node_normal_map.location = (0, -565)
        # node_normal_map.space = 'TANGENT'

        ctx = bpy.context
        p_scene = ctx.scene

        nodeGroup = BbqPreviewImageOverrider.build_preview_image_shader(nodeGroup)

        from .sceneConfig import ZBBQ_SceneProperties

        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        p_maps = p_scene_props.get_bake_maps()

        # NOTE: Temporary disbled
        # node_image = cls.AddShaderNodeBakingImageToNodes(mat, nodeGroup.nodes, s_image_name)

        node_normal_map = nodeGroup.nodes.get(ZBBQ_Consts.node_tree_preview_image_normal_image_node_name)

        node_other_images = nodeGroup.nodes.get(ZBBQ_Consts.node_tree_preview_image_other_image_node_name)

        s_normal_image_name = ZBBQ_MaterialFunc.GetBakeImageName(
            p_scene, mat, ctx.collection, obj, mat.pass_index, p_maps["normal"].bake_image_suffix)

        s_other_image_name = ZBBQ_MaterialFunc.GetBakeImageName(
            p_scene, mat, ctx.collection, obj, mat.pass_index, p_maps[p_scene_props.preview_map.lower()].bake_image_suffix)

        node_normal_map.image = bpy.data.images.get(s_normal_image_name)

        node_other_images.image = bpy.data.images.get(s_other_image_name)

        # Legacy
        # nodeGroup.links.new(node_image.outputs['Color'], node_normal_map.inputs['Color'])

        # nodeGroup.links.new(node_normal_map.outputs['Normal'], snShader.inputs['Normal'])

        return nodeGroup

    # ==== Material

    @classmethod
    def obj_has_materials_with_node(cls, context: bpy.types.Context, obj: bpy.types.Object, node_name: str, use_mat_suffix=False):
        if obj.type == 'MESH':
            for slot in obj.material_slots:
                material = slot.material
                if material is not None and material.use_nodes and hasattr(material, "node_tree"):
                    if hasattr(material.node_tree, "nodes"):
                        for node in material.node_tree.nodes:
                            if hasattr(node, "node_tree") and node.node_tree is not None:
                                s_name = cls.GetNodeNameByMat(material, node_name) if use_mat_suffix else node_name
                                if s_name == node.node_tree.name:
                                    return True
        return False

    @classmethod
    def has_any_objs_with_node(cls, context: bpy.types.Context, node_name: str, use_mat_suffix=False):
        p_objects = []
        if context.mode == 'OBJECT':
            p_objects = context.selected_objects
        elif context.mode == 'EDIT_MESH':
            p_objects = context.objects_in_mode
        for obj in p_objects:
            if cls.obj_has_materials_with_node(context, obj, node_name, use_mat_suffix=use_mat_suffix):
                return True
        return False

    @staticmethod
    def MaterialGetShaderNodeGroups(mat, nodeTreeName, usageCheck):

        # usageCheck:
        #
        # NOCHECK — don't check
        # ANY — for True answer, the node should have at least one active output
        # OVERRIDE — for True answer, the node should have at least one active output with type "surface" linked to Material Output

        result = []

        if not mat.use_nodes:
            return result

        for node in mat.node_tree.nodes:
            if node.type == 'GROUP':
                if node.node_tree and node.node_tree.name == nodeTreeName:

                    if usageCheck == 'NOCHECK':
                        result.append(node)

                    elif usageCheck in ['ANY', 'OVERRIDE']:

                        for output in node.outputs:
                            if len(output.links) > 0:
                                if usageCheck == 'ANY':
                                    result.append(node)
                                else:  # OVERRIDE, also check if it is really connected to the output
                                    for link in output.links:
                                        if link.to_node and link.to_node.type == 'OUTPUT_MATERIAL':
                                            result.append(node)
                                            break

        return result

    @staticmethod
    def MaterialGetShaderNodeImages(mat, node_name, image_name):
        p_nodes = []
        if mat.use_nodes:
            for node in mat.node_tree.nodes:
                if node.type == 'TEX_IMAGE' and node_name in node.name:
                    if node.image and node.image.name == image_name:
                        p_nodes.append(node)
        return p_nodes

    @staticmethod
    def MaterialRemoveShaderNodeGroupsByNodeTreeName(mat, nodeTreeName):

        # Important! This function does not restore links!
        # It just removed node by nodeTreeName!
        # If you need to save links,
        # please use MaterialRemoveShaderNodeNormal or MaterialRemoveOverrideNode instead!

        if mat.node_tree is None:
            return

        nodesToRemove = []

        for node in mat.node_tree.nodes:
            if node.type == 'GROUP':
                if node.node_tree and node.node_tree.name == nodeTreeName:
                    nodesToRemove.append(node)

        for node in nodesToRemove:
            mat.node_tree.nodes.remove(node)

    @classmethod
    def MaterialHasShaderNodesNormal(cls, mat):
        return cls.MaterialGetShaderNodeGroups(mat, ZBBQ_Consts.NORMAL_NODE_NAME, 'ANY')

    @classmethod
    def MaterialRemoveShaderNodeNormal(cls, mat: bpy.types.Material):
        if mat is None:
            return

        materialNeedsToBeManuallyUpdated = True

        if not mat.use_nodes:
            return

        matLinks = mat.node_tree.links
        matNodes = mat.node_tree.nodes

        nodesToRemove = cls.MaterialHasShaderNodesNormal(mat)
        for nodeToRemove in nodesToRemove:

            socketsToNormalOriginal = []
            socketFromNormalOriginal = None

            inNormal = nodeToRemove.inputs.get('Normal', None)
            outNormal = nodeToRemove.outputs.get('Normal', None)

            if inNormal and len(inNormal.links) > 0:
                socketFromNormalOriginal = inNormal.links[0].from_socket

                if outNormal:
                    for link in outNormal.links:
                        socketsToNormalOriginal.append(link.to_socket)

                for socketToNormalOriginal in socketsToNormalOriginal:
                    matLinks.new(socketToNormalOriginal, socketFromNormalOriginal)
                    materialNeedsToBeManuallyUpdated = False

            matNodes.remove(nodeToRemove)

        # Clutchy way to update material after node removal
        # is to re-create one of output links (for sure, currently all of them)
        # To-Do: Move this to separate function

        if materialNeedsToBeManuallyUpdated:

            for node in matNodes:
                if node.type == 'OUTPUT_MATERIAL':
                    for sockInput in node.inputs:
                        if len(sockInput.links) > 0:
                            originalFrom = sockInput.links[0].from_socket
                            originalTo = sockInput.links[0].to_socket

                            matLinks.remove(sockInput.links[0])
                            matLinks.new(originalFrom, originalTo)

    @classmethod
    def AssignImagesToNormalImageNodes(
            cls, context: bpy.types.Context, inner_nodes, p_scene: bpy.types.Scene,
            mat: bpy.types.Material, obj: bpy.types.Object, idx: int,
            folder: str, suffix: str):

        t_image_nodes = {
            ZBBQ_Consts.node_tree_preview_image_normal_image_node_name: None,
            ZBBQ_Consts.node_tree_preview_image_other_image_node_name: None
        }

        t_reason = dict()

        t_mixes = {
            ZBBQ_Consts.node_tree_preview_image_normal_image_node_name: None,
            ZBBQ_Consts.node_tree_preview_image_other_image_node_name: None
        }

        for image_node in inner_nodes:
            if image_node.type == 'TEX_IMAGE':
                s_image_node_name = image_node.name

                try:
                    if s_image_node_name == ZBBQ_Consts.node_tree_preview_image_normal_image_node_name:
                        s_image_name = ZBBQ_MaterialFunc.GetBakeImageName(
                            p_scene, mat, context.collection, obj, idx, p_scene.zen_bbq.bake_normal.bake_image_suffix)
                    elif s_image_node_name == ZBBQ_Consts.node_tree_preview_image_other_image_node_name:
                        s_image_name = ZBBQ_MaterialFunc.GetBakeImageName(
                            p_scene, mat, context.collection, obj, idx, suffix)
                    else:
                        continue

                    # NOTE: here can be the same image if 'Normal' is a preview mode
                    p_image: bpy.types.Image = bpy.data.images.get(s_image_name, None)
                    if p_image is None:
                        s_image_path = os.path.join(folder, s_image_name)
                        if os.path.exists(s_image_path):
                            p_image = bpy.data.images.load(s_image_path)
                        else:
                            raise RuntimeError(f"Image: {s_image_path} - not found!")

                    if p_image is None:
                        raise RuntimeError(f"Image: {s_image_name} is not valid! Object: {obj.name} Material: {mat.name}")

                    image_node.image = p_image
                    t_image_nodes[s_image_node_name] = p_image
                except Exception as e:
                    t_reason[s_image_node_name] = str(e)

            elif image_node.name == "Is Normal Baked":
                t_mixes[ZBBQ_Consts.node_tree_preview_image_normal_image_node_name] = image_node
            elif image_node.name == "Is Other Baked":
                t_mixes[ZBBQ_Consts.node_tree_preview_image_other_image_node_name] = image_node

        if len(t_image_nodes) < 2:
            raise RuntimeError("Can not find internal texture node! Object: {obj.name} Material: {mat.name}")
        else:
            for k, v in t_image_nodes.items():
                p_mix = t_mixes.get(k, None)
                if p_mix:
                    p_mix.inputs[0].default_value = 0.0 if v is None else 1.0

        if t_reason:
            raise RuntimeError(list(t_reason.values())[0])

    @classmethod
    def MaterialAddShaderNodeNormalImage(
            cls,
            p_scene: bpy.types.Scene, mat: bpy.types.Material, obj: bpy.types.Object, idx: int,
            folder: str, reset_nodes: bool, suffix: str):

        ctx = bpy.context

        p_override = ZBBQ_MaterialFunc.MaterialAddOverrideNode(
            obj,
            mat,
            ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME,
            ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME,
            reset=reset_nodes)
        if not p_override:
            raise RuntimeError("Can not create preview node! Object: {obj.name} Material: {mat.name}")

        cls.AssignImagesToNormalImageNodes(
            ctx, p_override.node_tree.nodes, p_scene, mat, obj, idx, folder, suffix)

    @classmethod
    def MaterialAddOverrideNode(cls, obj: bpy.types.Object, mat: bpy.types.Material, toggleNodeName, toggleNodeTreeName, reset=True):

        cls.MaterialRemoveOverrideNode(mat)  # Clear it in before just in case

        if not mat.use_nodes:
            mat.use_nodes = True

        matLinks = mat.node_tree.links
        matNodes = mat.node_tree.nodes

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        p_override_base_color = None
        if toggleNodeName == ZBBQ_Consts.PREVIEW_SHADER_NAME:
            p_override_base_color = addon_prefs.shader_preview_color
        elif toggleNodeName == ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME:
            p_override_base_color = addon_prefs.image_preview_color

        for node in matNodes:
            if node.type == 'OUTPUT_MATERIAL' and node.is_active_output:

                outSurface = node.inputs['Surface']

                snOverrideSurface = matNodes.new('ShaderNodeGroup')
                snOverrideSurface.name = cls.GetNodeNameByMat(mat, toggleNodeName)
                snOverrideSurface.node_tree = cls.GetOrCreateNodeTree(
                    toggleNodeTreeName, reset=reset, mat=mat, obj=obj)  # To-Do: Always use this func
                snOverrideSurface.location = (outSurface.node.location[0]-100, outSurface.node.location[1]+150)

                if p_override_base_color:
                    principled_node = next(
                        (node for node in snOverrideSurface.node_tree.nodes if node.type == 'BSDF_PRINCIPLED'),
                        None
                    )

                    if principled_node:
                        color_input = principled_node.inputs['Base Color']
                        color_input.default_value = p_override_base_color

                if len(outSurface.links) > 0:
                    originalFromSocket = outSurface.links[0].from_socket
                    matLinks.remove(outSurface.links[0])
                    matLinks.new(snOverrideSurface.inputs['Surface'], originalFromSocket)

                matLinks.new(snOverrideSurface.outputs['Surface'], node.inputs['Surface'])

                return snOverrideSurface

        return None

    @classmethod
    def GetNodeNameByMat(cls, mat: bpy.types.Material, node_name: str):
        s_uuid = ZBBQ_CommonFunc.GetSessionUID(mat)
        return f"{node_name}_for_{s_uuid}"

    @classmethod
    def IsVersionValid(cls, p_node_group: bpy.types.NodeTree, base_name: str):
        return cls.get_label_version_name(p_node_group.name, node_base_name=base_name) == p_node_group.zen_bbq_version

    @classmethod
    def MaterialRemoveOverrideNode(cls, mat: bpy.types.Material):
        if mat is not None:
            for node_name in [
                    ZBBQ_Consts.PREVIEW_SHADER_NAME,
                    ZBBQ_Consts.NORMAL_NODE_NAME,
                    ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME,

                    ZBBQ_Consts.LEGACY_OVERRIDER_NAME  # NOTE: Do not remove!!!

                    # cls.GetNodeNameByMat(mat, ZBBQ_Consts.PREVIEW_SHADER_NAME),
                    # cls.GetNodeNameByMat(mat, ZBBQ_Consts.NORMAL_NODE_NAME),
                    # cls.GetNodeNameByMat(mat, ZBBQ_Consts.PREVIEW_NORMAL_IMAGE_NAME)
            ]:
                cls._MaterialRemoveOverrideNodeInternal(mat, node_name)

    @classmethod
    def _MaterialRemoveOverrideNodeInternal(cls, mat: bpy.types.Material, toggleNodeTreeName):

        if not mat.use_nodes:
            return

        matLinks = mat.node_tree.links
        matNodes = mat.node_tree.nodes

        nodesMatOutput = [node for node in matNodes if node.type == 'OUTPUT_MATERIAL']
        overrideNodesToBeDeleted = []

        for nodeMatOutput in nodesMatOutput:

            nodeToCheck = nodeMatOutput

            while nodeToCheck is not None:

                socketsToCheck = [sockInShader for sockInShader in nodeToCheck.inputs if sockInShader.type == 'SHADER']
                nodeToCheck = None

                if len(socketsToCheck) == 0:
                    break

                for sockInShader in socketsToCheck:
                    if len(sockInShader.links) == 0:
                        continue  # Nothing is attached to output, nothing to do here

                    snSurfaceOut = sockInShader.links[0].from_node
                    sockSurfaceIn = sockInShader.links[0].to_socket

                    nodeToCheck = snSurfaceOut

                    if snSurfaceOut.type == 'GROUP' and snSurfaceOut.node_tree and toggleNodeTreeName in snSurfaceOut.node_tree.name:

                        inSurfaceOriginalSocket = None

                        if len(snSurfaceOut.inputs['Surface'].links) > 0:
                            inSurfaceOriginalSocket = snSurfaceOut.inputs['Surface'].links[0].from_socket

                        overrideNodesToBeDeleted.append(snSurfaceOut)
                        matLinks.remove(sockInShader.links[0])
                        if inSurfaceOriginalSocket is not None:
                            matLinks.new(sockSurfaceIn, inSurfaceOriginalSocket)

        p_legacy_node_trees = set()

        def check_to_remove_legacy(p_node):
            if ZBBQ_Consts.LEGACY_OVERRIDER_NAME in p_node.name:
                if p_node.node_tree:
                    p_legacy_node_trees.add(p_node.node_tree)

        for nodeToDelete in overrideNodesToBeDeleted:
            check_to_remove_legacy(nodeToDelete)
            matNodes.remove(nodeToDelete)

        # NOTE: nodes that are not connected to anything
        overrideNodesToBeDeleted = [node for node in matNodes if toggleNodeTreeName in node.name]
        for nodeToDelete in overrideNodesToBeDeleted:
            check_to_remove_legacy(nodeToDelete)
            matNodes.remove(nodeToDelete)

        while p_legacy_node_trees:
            p_node_group = p_legacy_node_trees.pop()
            bpy.data.node_groups.remove(p_node_group)

    @classmethod
    def ObjectHasShaderNodeNormal(cls, obj: bpy.types.Object):
        me: bpy.types.Mesh = obj.data
        if len(me.materials) == 0:
            return False

        # To-Do: Return True ONLY if all materials have Shader Node
        for mat in me.materials:
            # Default Material already has the needed node
            if len(cls.MaterialHasShaderNodesNormal(mat)) == 0:
                return False
        return True

    @classmethod
    def MaterialHasShaderNodesBakingImage(cls, mat: bpy.types.Material, s_image_name: str):
        return len(cls.MaterialGetShaderNodeImages(mat, ZBBQ_Consts.shaderNodeBakingImageName, s_image_name)) > 0

    @classmethod
    def MaterialGetShaderNodesBakingImages(cls, mat: bpy.types.Material, s_image_name: str):
        return cls.MaterialGetShaderNodeImages(mat, ZBBQ_Consts.shaderNodeBakingImageName, s_image_name)

    @classmethod
    def CheckBakeImageSize(cls, context: bpy.types.Context, mat: bpy.types.Material, p_image: bpy.types.Image):
        from .sceneConfig import ZBBQ_SceneProperties
        p_scene = context.scene
        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        p_map = p_scene_props.get_active_bake_map()

        if p_map.bake_image_size_override:
            p_size = (p_map.bake_image_width, p_map.bake_image_height)
        else:
            p_size = (p_scene_props.bake_image_width, p_scene_props.bake_image_height)

        if p_image.size[:] != p_size[:]:
            p_image.generated_width = p_size[0]
            p_image.generated_height = p_size[1]

            p_image.generated_color = p_map.IMAGE_COLOR

        return p_image

    @classmethod
    def AddShaderNodeBakingImageToNodes(cls, mat: bpy.types.Material, nodes: bpy.types.Nodes, s_image_name):
        ctx = bpy.context

        snZenBBQBakingImage = nodes.new('ShaderNodeTexImage')
        snZenBBQBakingImage.name = ZBBQ_Consts.shaderNodeBakingImageName

        p_image: bpy.types.Image = bpy.data.images.get(s_image_name)
        if p_image is None:
            im_width = ctx.scene.zen_bbq.bake_image_width
            im_height = ctx.scene.zen_bbq.bake_image_height
            p_image = bpy.data.images.new(
                s_image_name,
                width=im_width, height=im_height,
                alpha=True)
            p_image.colorspace_settings.name = 'Non-Color'

        p_image = cls.CheckBakeImageSize(ctx, mat, p_image)

        snZenBBQBakingImage.image = p_image

        BbqPreviewImageOverrider.add_interpolation_driver(snZenBBQBakingImage)

        # NOTE: this is size of the node widget
        snZenBBQBakingImage.width = 250
        snZenBBQBakingImage.height = 1024

        # Put the image node to the right of graph

        nodesMaxX = -math.inf
        nodesY = 0

        for node in nodes:
            if node != snZenBBQBakingImage and node.location.x + node.width > nodesMaxX:
                nodesMaxX = node.location.x + node.width
                nodesY = node.location.y

        snZenBBQBakingImage.location.x = nodesMaxX + 20
        snZenBBQBakingImage.location.y = nodesY

        return snZenBBQBakingImage

    @classmethod
    def GetBakeImageName(cls, scene: bpy.types.Scene, mat: bpy.types.Material, collection: bpy.types.Collection, obj: bpy.types.Object, mat_index: int, suffix: str):
        from .sceneConfig import ZBBQ_SceneProperties
        p_scene_props: ZBBQ_SceneProperties = scene.zen_bbq
        filename = p_scene_props.bake_batch_image_name if p_scene_props.bake_batch else p_scene_props.bake_image_name
        filename = ZenStrUtils.ireplace(filename, '%COLLECTION%', collection.name if collection else "%COLLECTION%")
        filename = ZenStrUtils.ireplace(filename, '%MATERIAL%', mat.name if mat else "%MATERIAL%")
        filename = ZenStrUtils.ireplace(filename, '%SCENE%', scene.name)
        filename = ZenStrUtils.ireplace(filename, '%BLEND%', ZBBQ_CommonFunc.GetSceneName(bpy.context))
        filename = ZenStrUtils.ireplace(filename, '%OBJECT%', obj.name if (obj and obj.type == 'MESH') else '%OBJECT%')
        filename = ZenStrUtils.ireplace(filename, '%MAT_ID%', f'{mat_index:03d}')
        filename = ZenStrUtils.ireplace(filename, '%SUFFIX%', suffix)
        return filename

    @classmethod
    def MaterialAddShaderNodeBakingImage(cls, mat: bpy.types.Material, s_image_name: str):

        # To-Do: Check if exists

        if not mat.use_nodes:
            mat.use_nodes = True

        matNodes = mat.node_tree.nodes
        return cls.AddShaderNodeBakingImageToNodes(mat, matNodes, s_image_name)

        # To-Do: Location
        # snZenBBQNormal.location = (sockNormalInput.node.location[0]-200, sockNormalInput.node.location[1])

    @classmethod
    def MaterialRemoveShaderNodeBakingImage(cls, mat: bpy.types.Material, s_image_name: str):
        # materialNeedsToBeManuallyUpdated = True

        if not mat.use_nodes:
            return

        # matLinks = mat.node_tree.links
        matNodes = mat.node_tree.nodes

        for nodeToRemove in cls.MaterialGetShaderNodesBakingImages(mat, s_image_name):
            matNodes.remove(nodeToRemove)

    @classmethod
    def CreateDefaultMaterial(cls):  # We must get a material to build into, for reasons

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        s_suffix = str(uuid.uuid4())[:8]
        s_mat_name = f"{ZBBQ_Consts.defaultMaterialName}.{s_suffix}"
        mat = bpy.data.materials.new(name=s_mat_name)
        mat.use_nodes = True

        if (b := next((n for n in mat.node_tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)):
            base_color = addon_prefs.material_default_color
            b.inputs['Base Color'].default_value = base_color
            b.inputs['Roughness'].default_value = 0.4
            b.inputs['Metallic'].default_value = 1.0

        return mat

    @classmethod
    def RemoveDefaultZenBBQMaterialFromSceneIfPresent(cls):
        for mat in reversed(bpy.data.materials):
            if ZBBQ_Consts.defaultMaterialName in mat.name:
                bpy.data.materials.remove(mat)

    @classmethod
    def ObjectFillMissingMatsWithDefaultZenBBQMaterial(cls, obj):
        if len(obj.material_slots) == 0:
            # print('Appending the default Zen BBQ material')
            obj.data.materials.append(cls.CreateDefaultMaterial())
        else:
            for matSlot in obj.material_slots:
                if matSlot.material is None:
                    matSlot.material = cls.CreateDefaultMaterial()

    @classmethod
    def ObjectRemoveShaderNodeNormal(cls, obj):
        for mat in obj.data.materials:
            cls.MaterialRemoveShaderNodeNormal(mat)

    @classmethod
    def ShaderNodeToggleModeAndObjects(cls, objects, toggleNodeTreeName, usageCheck='ANY'):

        # toggleMode switches to ON if at least one obj has preview not active
        result = {'toggleMode': 'OFF', 'objectsToToggle': []}

        for obj in objects:
            if not ZBBQ_CommonFunc.ObjectIsMesh(obj):
                continue

            addToResult = False

            if not cls.ObjectHasMaterialsFilled(obj):
                # Default material is already metallic and has bevel node so it does not switch
                if toggleNodeTreeName in [ZBBQ_Consts.PREVIEW_SHADER_NAME, ZBBQ_Consts.NORMAL_NODE_NAME]:
                    continue
                else:
                    addToResult = True
                    result['toggleMode'] = 'ON'
            else:

                for mat in obj.data.materials:

                    # if mat.name == ZBBQ_Consts.defaultMaterialName:
                    #     # Default material is already metallic and is has bevel node so it does not switch
                    #     if toggleNodeTreeName in [ZBBQ_Consts.PREVIEW_SHADER_NAME, ZBBQ_Consts.NORMAL_NODE_NAME]:
                    #         continue

                    addToResult = True

                    if len(cls.MaterialGetShaderNodeGroups(mat, toggleNodeTreeName, usageCheck)) == 0:
                        result['toggleMode'] = 'ON'

            if addToResult:
                result['objectsToToggle'].append(obj)

        return result

    @classmethod
    def shift_2d(cls, array, dy, dx):
        h, w, c = array.shape
        result = np.zeros_like(array)

        src_y_start = max(0, -dy)
        src_y_end = h - max(0, dy)
        src_x_start = max(0, -dx)
        src_x_end = w - max(0, dx)

        dst_y_start = max(0, dy)
        dst_y_end = h - max(0, -dy)
        dst_x_start = max(0, dx)
        dst_x_end = w - max(0, -dx)

        result[dst_y_start:dst_y_end, dst_x_start:dst_x_end] = array[src_y_start:src_y_end, src_x_start:src_x_end]
        return result

    @classmethod
    def apply_margin_fast(cls, img: bpy.types.Image, margin_pixels=16, default_color=(0.5, 0.5, 0.5)):
        width, height = img.size
        pixels = np.empty(width * height * 4, dtype=np.float32)
        img.pixels.foreach_get(pixels)

        rgba = pixels.reshape((height, width, 4))

        shifts = [
            (-1, -1), (-1, 0), (-1, 1),
            (0, -1),           (0, 1),
            (1, -1),  (1, 0),  (1, 1)
        ]

        for step in range(margin_pixels):
            is_transparent = rgba[:, :, 3] < 0.01

            if not np.any(is_transparent):
                break

            sum_colors = np.zeros_like(rgba)
            neighbor_count = np.zeros((height, width, 1), dtype=np.float32)

            for dy, dx in shifts:
                shifted_rgba = cls.shift_2d(rgba, dy, dx)
                shifted_has_alpha = shifted_rgba[:, :, 3] >= 0.01
                valid_mask = is_transparent & shifted_has_alpha

                sum_colors[valid_mask] += shifted_rgba[valid_mask]
                neighbor_count[valid_mask] += 1.0

            update_mask = neighbor_count[:, :, 0] > 0

            if not np.any(update_mask):
                break

            rgba[update_mask] = sum_colors[update_mask] / neighbor_count[update_mask]
            rgba[update_mask, 3] = 1.0

        still_transparent = rgba[:, :, 3] < 0.01

        if np.any(still_transparent):
            # num_filled = np.sum(still_transparent)
            rgba[still_transparent, 0:3] = default_color[:3]
            rgba[still_transparent, 3] = 1.0

        pixels = rgba.ravel()
        img.pixels.foreach_set(pixels)
        img.update()

    @staticmethod
    def set_alpha_channel_value(image, alpha_value: float):
        if not image:
            return

        width, height = image.size
        pixels = np.empty(width * height * 4, dtype=np.float32)
        image.pixels.foreach_get(pixels)

        rgba = pixels.reshape((height, width, 4))

        rgba[:, :, 3] = alpha_value

        image.pixels.foreach_set(rgba.ravel())
        image.update()


class ZBBQ_PropUtils:

    IMAGE_NAME_DESC = r"""Name of the baked image, available constants:
* %MATERIAL% - material name,
* %SCENE% - scene name,
* %BLEND% - blend file name without extension,
* %COLLECTION% - active collection name,
* %OBJECT% - object name,
* %SUFFIX% - bake type suffix (e.g., _Normal, _AO, _Curvature, etc.),
* %MAT_ID% - index of material in a bake list"""

    preview_mode = bpy.props.EnumProperty(
        name="Mode",
        items=[
            ("MATERIAL", "Material", "Switch off all previews and use only user material"),
            ("SHADER", "Shader", "Shaders bevel preview"),
            ("IMAGE", "Image", "Normals bake inspection by image preview"),
        ],
        default="MATERIAL",
        options={'HIDDEN', 'SKIP_SAVE'}
    )

    def on_bake_image_uniform_size_update(self, context: bpy.types.Context):
        if self.bake_image_uniform_size:
            self.bake_image_height = self.bake_image_width

    bake_image_size_override = bpy.props.BoolProperty(
            name="Override Bake Image Size",
            description="""If enabled, texture size is taken from the overroad data;
    otherwise, from the addon preferences""",
            default=False
        )

    bake_image_width = bpy.props.IntProperty(
            name="Baked image width",
            description="Baked image width in pixels",
            subtype='PIXEL',
            default=1024,
            min=128,
            max=32768,
            update=on_bake_image_uniform_size_update)

    bake_image_height = bpy.props.IntProperty(
            name="Baked image height",
            description="Baked image height in pixels",
            subtype='PIXEL',
            default=1024,
            min=128,
            max=32768)

    bake_image_uniform_size = bpy.props.BoolProperty(
        name="Uniform Size",
        description="Use the same value for both width and height to ensure a square texture",
        default=True,
        update=on_bake_image_uniform_size_update
    )

    bake_margin = bpy.props.IntProperty(
        name="Margin",
        description="Extends the baked image border, or padding, to prevent visual artifacts along UV seams",
        default=16,
        min=0,
        soft_max=64,
        subtype='PIXEL'
    )

    bevel_node_samples = bpy.props.IntProperty(
            name="Bevel Node Samples",
            description="Samples passed to the bevel node",
            default=16,
            min=2,
    )

    # NOTE: Bake recommendation: low: 16, med: 32, hi: 128
    ao_node_samples = bpy.props.IntProperty(
            name="AO Node Samples",
            description="Samples passed to the ambient occlusion node",
            default=16,
            min=2,
    )

    @classmethod
    def draw_bake_image_size(cls, layout: bpy.types.UILayout, p_props):
        row = layout.row(align=True)
        row.prop(p_props, "bake_margin")
        row = layout.row(align=True)
        row.prop(p_props, "bake_image_width", text="")
        s_icon = "LOCKED" if p_props.bake_image_uniform_size else 'UNLOCKED'
        row.prop(p_props, "bake_image_uniform_size", text="", icon=s_icon)
        r1 = row.row(align=True)
        r1.enabled = not p_props.bake_image_uniform_size
        r1.prop(p_props, "bake_image_height", text="")

    @classmethod
    def get_shading_type_locked(cls, p_default=True):
        return bpy.props.BoolProperty(
            name="Shading Type Locked",
            description="Lock shading type",
            default=p_default)

    @classmethod
    def get_shading_type(cls, p_default='SOLID', p_options=set(), fn_update: callable = None):
        return bpy.props.EnumProperty(
            name="Shading Type",
            description="Method to render/display objects in the 3D View",
            items=(
                ('NONE', "Skip", "Do not change shading mode", 'DOT', 0),
                ('WIREFRAME', "Wireframe", "Display the items as outline skeletons", 'SHADING_WIRE', 1),
                ('SOLID', "Solid", "Display the items using basic solid shading", 'SHADING_SOLID', 2),
                ('MATERIAL', "Material", "Display the items using material preview shading", 'SHADING_TEXTURE', 3),
                ('RENDERED', "Rendered", "Display the items using the active scene renderer", 'SHADING_RENDERED', 4),
            ),
            options=p_options,
            default=p_default,
            update=fn_update
        )

    @classmethod
    def get_shader_preview_mode(cls, p_options=set()):
        return bpy.props.EnumProperty(
            name="Mode",
            description="Objects viewport preview mode",
            items=[
                ("MATERIAL", "Material", "Switch off all previews and use only user material"),
                ("SHADER", "Shader", "Shader bevels preview"),
                ("IMAGE", "Image", "Normals bake inspection by image preview"),
            ],
            default="MATERIAL",
            options=p_options
        )

    @classmethod
    def get_bake_image_suffix(cls, p_default=""):
        return bpy.props.StringProperty(
            name="Image Suffix",
            description="Suffix appended to the baked image name (e.g., _Normal, _AO, _Curvature, etc.)",
            default=p_default
        )

    @classmethod
    def get_bake_enabled(cls, p_default=True):
        return bpy.props.BoolProperty(
            name="Enabled",
            description="Include this map type in the baking process",
            default=p_default
        )

    @classmethod
    def get_bake_samples(cls, p_default=8):
        return bpy.props.IntProperty(
            name="Render Samples",
            description="Number of samples to bake render for each pixel",
            default=p_default,
            min=1
        )

    bake_disable_explode_in_renders = bpy.props.BoolProperty(
        name="Disable Explode in Renders",
        description="If enabled, the Explode modifier will be disabled during rendering",
        default=True
    )

    bake_add_image_node_after_render = bpy.props.BoolProperty(
        name="Add Image Node To Material",
        description='''If enabled, the temporary texture node used for baking will be left once the process finishes;
otherwise, it will be removed from the material''',
        default=False
    )

    def on_ZenBBQ_LiveBooleanRadius_update(self, context: bpy.types.Context):
        try:
            context.view_layer.update()
        except Exception as e:
            Log.error("BEVEL RADIUS:", e)

    def get_ZenBBQ_LiveBooleanRadius(self):
        return self.get('ZenBBQ_IntactBevelRadius', 0.0)

    def set_ZenBBQ_LiveBooleanRadius(self, value):
        self['ZenBBQ_IntactBevelRadius'] = value

    ZenBBQ_LiveBooleanRadius = bpy.props.FloatProperty(
        name="Zen BBQ Live Boolean Radius",
        description=ZBBQ_Labels.ZBBQ_PROP_IntactBevelDisplayRadius_Desc,
        get=get_ZenBBQ_LiveBooleanRadius,
        set=set_ZenBBQ_LiveBooleanRadius,
        min=0.0,
        update=on_ZenBBQ_LiveBooleanRadius_update
    )

    def ZBBQ_IntactBevelDisplayRadiusSet(self, value):
        p_units = ZBBQ_Units.get(self.ZBBQ_IntactBevelDisplayUnits, None)
        if p_units is not None:
            self.ZenBBQ_LiveBooleanRadius = value * p_units.unitAndSceneScaleMultiplier()

    def ZBBQ_IntactBevelDisplayRadiusGet(self):
        p_units = ZBBQ_Units.get(self.ZBBQ_IntactBevelDisplayUnits, None)
        if p_units is not None:
            p_val = p_units.unitAndSceneScaleMultiplier()
            if p_val:
                return self.ZenBBQ_LiveBooleanRadius / p_val
        return 0

    ZBBQ_IntactBevelDisplayRadius = bpy.props.FloatProperty(
        name=ZBBQ_Labels.ZBBQ_PROP_IntactBevelDisplayRadius_Label,
        description=ZBBQ_Labels.ZBBQ_PROP_IntactBevelDisplayRadius_Desc,
        set=ZBBQ_IntactBevelDisplayRadiusSet,
        get=ZBBQ_IntactBevelDisplayRadiusGet,
        min=0,
        options={'HIDDEN', 'SKIP_SAVE'}
    )

    def get_IntactBevelDisplayUnits_items(self, context: bpy.types.Context):
        return ZBBQ_UnitsForEnumPropertyConsideringUnitSystem(ZBBQ_CommonFunc.GetActiveBevelPresetGroup().unitSystem)

    ZBBQ_IntactBevelDisplayUnits = bpy.props.EnumProperty(
        items=get_IntactBevelDisplayUnits_items,
        name=ZBBQ_Labels.ZBBQ_PROP_IntactBevelDisplayUnits_Label,
        description=ZBBQ_Labels.ZBBQ_PROP_IntactBevelDisplayUnits_Desc,
        options={'HIDDEN', 'SKIP_SAVE'}
    )


class NormalInspectStudio:

    @staticmethod
    def remove_studio_collection_and_items():
        collection_name = ZBBQ_Consts.normal_test_collection_name
        studio_collection = bpy.data.collections.get(collection_name)

        if studio_collection:
            for obj in list(studio_collection.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            bpy.data.collections.remove(studio_collection)

            for obj in bpy.data.objects:
                if obj.name in ZBBQ_Consts.normal_test_objects_names:
                    bpy.data.objects.remove(obj, do_unlink=True)

    @classmethod
    def create_studio(cls, target_location: Vector, distance_scalar: float):
        if not target_location:
            target_location = Vector((0.0, 0.0, 0.0))

        cam_n = ZBBQ_Consts.normal_test_camera_name
        key_n = ZBBQ_Consts.normal_test_key_light_name
        fill_n = ZBBQ_Consts.normal_test_fill_light_name
        rim_n = ZBBQ_Consts.normal_test_rim_light_name
        collection_name = ZBBQ_Consts.normal_test_collection_name
        st_position_name = ZBBQ_Consts.normal_test_empty_position_name
        st_target_name = ZBBQ_Consts.normal_test_empty_control_name

        cls.remove_studio_collection_and_items()

        studio_collection = bpy.data.collections.get(collection_name)
        if not studio_collection:
            studio_collection = bpy.data.collections.new(collection_name)
            bpy.context.scene.collection.children.link(studio_collection)

        # try:
        #     if context.scene.world:
        #         context.scene.world.use_nodes = False
        #         context.scene.world.color = (0.05, 0.05, 0.05)
        # except AttributeError as e:
        #     Log.debug(f"Possibly use_nodes removed in Blender 6.0 {e}")

        studio_objects = []

        studio_position = bpy.data.objects.new(st_position_name, None)
        studio_position.empty_display_type = 'PLAIN_AXES'
        studio_position.empty_display_size = 1.0
        studio_collection.objects.link(studio_position)

        studio_controller = bpy.data.objects.new(st_target_name, None)
        studio_controller.empty_display_type = 'PLAIN_AXES'
        studio_controller.empty_display_size = 2.0
        studio_collection.objects.link(studio_controller)
        studio_objects.append(studio_controller)

        cam_data = bpy.data.cameras.new(name=cam_n)
        cam_obj = bpy.data.objects.new(cam_n, cam_data)
        studio_collection.objects.link(cam_obj)
        cam_obj.location = Vector((3, -3, 2)) * distance_scalar
        cam_obj.constraints.new(type='TRACK_TO').target = studio_controller
        studio_objects.append(cam_obj)

        light_data_list = [
            (key_n, 'SUN', 3.0, (1.0, 1.0, 1.0), Vector((-3, -3, 4)), False),
            (fill_n, 'SUN', 1.0, (0.6, 0.8, 1.0), Vector((4, -2, 2)), False),
            (rim_n, 'SUN', 4.0, (1.0, 0.9, 0.7), Vector((1, 4, 3)), False)
        ]

        for name, type_light, energy, color, light_loc, use_shadow in light_data_list:
            light_data = bpy.data.lights.new(name=name, type=type_light)
            light_data.energy = energy
            light_data.color = color
            if type_light == 'SUN':
                light_data.angle = math.radians(5)
            light_data.use_shadow = use_shadow

            scaled_direction_vec = light_loc * distance_scalar

            light_obj = bpy.data.objects.new(name, light_data)
            studio_collection.objects.link(light_obj)
            light_obj.location = scaled_direction_vec
            light_obj.constraints.new(type='TRACK_TO').target = studio_controller
            studio_objects.append(light_obj)

        for obj in studio_objects:
            obj.parent = studio_position
            obj.matrix_parent_inverse = studio_position.matrix_world.inverted()

        studio_position.location = target_location


class NormalBakingSetup:

    @staticmethod
    def apply_weighted_normals_to_selected(objects: list[bpy.types.Object]):
        if not objects:
            return

        mod_name = ZBBQ_Consts.weighted_normal_mod_name

        for obj in objects:
            if obj.type != 'MESH':
                continue

            wn_mod = obj.modifiers.get(mod_name) or next(
                (m for m in obj.modifiers if m.type == 'WEIGHTED_NORMAL'), None
            )

            if not wn_mod:
                wn_mod = obj.modifiers.new(name=mod_name, type='WEIGHTED_NORMAL')

            wn_mod.mode = 'FACE_AREA_WITH_ANGLE'
            wn_mod.weight = 50
            wn_mod.keep_sharp = True

            bpy.context.view_layer.objects.active = obj

            current_idx = obj.modifiers.find(wn_mod.name)
            last_idx = len(obj.modifiers) - 1

            if current_idx != last_idx:
                try:

                    obj.modifiers.move(current_idx, last_idx)
                except RuntimeError:
                    pass


class ObjectAttributes:

    @classmethod
    def assign_random_color_to_obj_materials(cls, mesh_objects: list, is_fix_gray_only: bool):
        mat_colors = cls.generate_random_colors(mesh_objects)

        mat: bpy.types.Material
        for mat, color in mat_colors.items():
            vp_color = list(mat.diffuse_color)

            if is_fix_gray_only:
                is_default_gray = (
                        math.isclose(vp_color[0], 0.8, abs_tol=1e-4) and
                        math.isclose(vp_color[1], 0.8, abs_tol=1e-4) and
                        math.isclose(vp_color[2], 0.8, abs_tol=1e-4)
                    )

                if is_default_gray:
                    mat.diffuse_color = color
            else:
                mat.diffuse_color = color

    @classmethod
    def generate_random_colors(cls, mesh_objects: list):
        mat_colors = dict()

        # The Golden Ratio for Distribution of Hue on the Color Wheel
        gr_offset = 0.618033988749895

        hue = random.random()

        obj: bpy.types.Object
        for obj in mesh_objects:
            for slot in obj.material_slots:
                if slot.material:
                    hue = (hue + gr_offset) % 1.0

                    saturation = 0.85
                    value = 0.95
                    rgb = colorsys.hsv_to_rgb(hue, saturation, value)
                    mat_colors[slot.material] = (*rgb[:], 1.0)

        return mat_colors


class ZBBQ_Proxy:
    @classmethod
    def get_prefs(cls):
        return ZBBQ_CommonFunc.GetPrefs()

    @classmethod
    def get_combo_panel_props(cls):
        return cls.get_prefs().combo_panel

    @classmethod
    def get_combo_panel_map(cls):
        return ZBBQ_Consts.uv_enblr

    @classmethod
    def get_polls(cls):
        return ZenPolls

    @classmethod
    def get_log(cls):
        return Log
