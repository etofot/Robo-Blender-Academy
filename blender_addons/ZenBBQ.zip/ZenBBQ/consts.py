# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2022, Dmitry Aleksandrovich Maslov (ABTOMAT), Alex Zhornyak (alexander.zhornyak@gmail.com)

_CACHE_PANELS_ORDER = {}


zen_bbq_parented_panels = []


class ZBBQ_Consts:

    addonId = "ZenBBQ"
    addonName = "Zen BBQ"

    VertexColorMaskName = "G_ZenBBQ_VC_Mask"
    VertexColorMaskNameNodes = "N_ZenBBQ_VC_Mask"

    customDataLayerRadiusName = "ZenBBQ"
    customDataLayerUserDefinedName = "ZenBBQ_UserDefined"

    edgeAttributeBevelWidthName = "ZenBBQ_EdgeBevelWidth"

    customPropertyIntactBevelRadiusName = "ZenBBQ_LiveBooleanRadius"
    # customPropertyIntactBevelUnitsName = "ZenBBQ_IntactBevelUnits"

    MaterialIdAttributeName = "bbq_MaterialID"

    shaderNodeNormalName = "ZenBBQ_Normal"
    shaderNodeBakingImageName = "ZenBBQ_BakingImage"

    LEGACY_OVERRIDER_NAME = "ZenBBQ_PreviewMetallicNodeTree"

    NORMAL_NODE_NAME = "ZenBBQ_NormalNodeTree"
    shaderNodeTreeNormalNameCurrentVersion = "2.0"

    NORMAL_NODE_MIXER_NAME = "ZenBBQ_NormalsMixer"
    shaderNodeTreeNormalsMixerCurrentVersion = "1.1"

    PREVIEW_SHADER_NAME = "ZenBBQ_PreviewShader"
    PREVIEW_NORMAL_IMAGE_NAME = "ZenBBQ_PreviewNormalImage"

    node_tree_service_normal_mixer_name = "BbqServiceNormalsMixer"
    node_tree_service_ao_name = "BbqBakeAmbientOcclusion"
    node_tree_service_curvature = "BbqBakeCurvature"
    node_tree_service_convexity = "BbqBakeConvexityBevelsMask"
    node_tree_service_concavity = "BbqBakeConcavityBevelsMask"
    node_tree_service_bevels = "BbqBakeBevelsMask"
    node_tree_service_parts_id = "BbqBakePartsID"
    node_tree_service_mat_id = "BbqBakeMaterialsID"
    node_tree_service_space_normal = "BbqBakeObjectSpaceNormal"
    node_tree_service_tangent_space_normal = "BbqBakeTangentSpaceNormal"
    node_tree_service_bake_switch = "BbqBakeSwitch"
    node_tree_service_index_switch = "BbqIndexSwitch"

    node_tree_preview_image_normal_image_node_name = "BbqPreviewImageNormalImage"
    node_tree_preview_image_other_image_node_name = "BbqPreviewImageOtherImage"

    NODE_TREE_PREVIEW_MAP = {
        "IMAGE": PREVIEW_NORMAL_IMAGE_NAME,
        "SHADER": PREVIEW_SHADER_NAME
    }

    NODE_TREE_VERSIONS = {
        PREVIEW_SHADER_NAME: "1.11",
        PREVIEW_NORMAL_IMAGE_NAME: "1.11",

        NORMAL_NODE_NAME: "1.0",
        NORMAL_NODE_MIXER_NAME: "1.0",

        node_tree_service_normal_mixer_name: "1.14",
        node_tree_service_ao_name: "1.0",
        node_tree_service_curvature: "1.0",
        node_tree_service_convexity: "1.0",
        node_tree_service_concavity: "1.0",
        node_tree_service_bevels: "1.0",
        node_tree_service_parts_id: "1.0",
        node_tree_service_mat_id: "2.0",
        node_tree_service_space_normal: "1.0",
        node_tree_service_tangent_space_normal: "1.1",
        node_tree_service_bake_switch: "1.1",
        node_tree_service_index_switch: "1.1",
    }

    NODE_TREE_DEPENDENCY = {
        PREVIEW_SHADER_NAME: (
            node_tree_service_normal_mixer_name,
            node_tree_service_ao_name,
            node_tree_service_curvature,
            node_tree_service_convexity,
            node_tree_service_concavity,
            node_tree_service_bevels,
            node_tree_service_parts_id,
            node_tree_service_mat_id,
            node_tree_service_space_normal,
            node_tree_service_tangent_space_normal,
            node_tree_service_bake_switch,
            node_tree_service_index_switch
        )
    }

    NODE_TREE_SERVICE_MAP = {
        "NORMAL_MIXER": node_tree_service_normal_mixer_name,
        "CURVATURE": node_tree_service_curvature,
        "CONVEXITY": node_tree_service_convexity,
        "AO": node_tree_service_ao_name,
        "CONCAVITY": node_tree_service_concavity,
        "BEVELS": node_tree_service_bevels,
        "PARTS_ID": node_tree_service_parts_id,
        "MAT_ID": node_tree_service_mat_id,
        "SPACE_NORMAL": node_tree_service_space_normal,
        "TANGENT": node_tree_service_tangent_space_normal,
        "BAKE_SWITCH": node_tree_service_bake_switch,
        "INDEX_SWITCH": node_tree_service_index_switch
    }

    defaultMaterialName = "ZenBBQ_Default_Material"

    refPanelWidth = 400

    # Preset Defaults

    smartSelectRadiusThresholdDefault = 10

    # Geometry Overlay

    overlayEdgeColorUndetected = (0.2, 0.2, 0.2, 0.4)
    overlayEdgeColorDetectionAccuracy = 0.1

    normal_test_camera_name = "bbq_TestCamera"
    normal_test_key_light_name = "bbq_LightKey"
    normal_test_fill_light_name = "bbq_LightFill"
    normal_test_rim_light_name = "bbq_LightRim"
    normal_test_collection_name = "bbq_NormalCheckStudio"
    normal_test_empty_position_name = "bbq_StudioPosition"
    normal_test_empty_control_name = "bbq_StudioController"

    normal_test_objects_names = (
        normal_test_camera_name,
        normal_test_key_light_name,
        normal_test_fill_light_name,
        normal_test_rim_light_name,
        normal_test_empty_control_name,
    )

    weighted_normal_mod_name = "bbq Weighted Normal"

    bbq_default_material_base_color = (0.0781, 0.1169, 0.0975, 1.0)  # Linear (0.0781, 0.1169, 0.0975)  # sRGB (0.311, 0.375, 0.344)
    bbq_default_shader_mode_base_color = (0.1070, 0.0924, 0.1384, 1.0)  # Linear (0.1070, 0.0924, 0.1384)  # sRGB (0.361, 0.337, 0.403)
    bbq_default_normal_inspect_mode_base_color = (0.0975, 0.0975, 0.1882, 1.0)  # Linear (0.0975, 0.0975, 0.1882)  # sRGB (0.346, 0.346, 0.470)

    bbq_explode_modifier_name = "BBQ Explode System"
    bbq_explode_center_socket_name = "Explosion Center"

    bake_pinned_collection_name = "ZenBBQ_Bake_Objects"

    uv_enblr = {
        "enable_pt_main": {"VIEW_3D": 'ZBBQ_PT_Bevels', "UV": None},
        "enable_pt_bake": {"VIEW_3D": 'ZBBQ_PT_Bake', "UV": None},
        "enable_pt_tools": {"VIEW_3D": 'ZBBQ_PT_Tools', "UV": None},
        "enable_pt_preferences": {"VIEW_3D": 'ZBBQ_PT_Preferences', "UV": None},
        "enable_pt_help": {"VIEW_3D": 'ZBBQ_PT_Help', "UV": None},
    }

    modifier_mesh_bevels_name = "BBQ Mesh Bevels"

    @classmethod
    def get_combo_panel_order(cls, s_mode, s_panel_type):

        if s_mode not in _CACHE_PANELS_ORDER:
            _CACHE_PANELS_ORDER[s_mode] = [v.get(s_mode, None) for v in cls.uv_enblr.values() if v.get(s_mode, None) is not None]
            _CACHE_PANELS_ORDER[s_mode] = {it: idx for idx, it in enumerate(_CACHE_PANELS_ORDER[s_mode])}

        return _CACHE_PANELS_ORDER[s_mode][s_panel_type] + 1
