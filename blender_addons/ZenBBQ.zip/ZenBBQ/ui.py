# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2022, Dmitry Aleksandrovich Maslov (ABTOMAT), Alex Zhornyak (alexander.zhornyak@gmail.com)

import bpy
from bpy.types import UIList, Operator, Panel, Menu
from bl_ui.utils import PresetPanel
from mathutils import Color

import numpy as np
import textwrap
import os

from .ico import ZBBQ_Icons, ZBBQ_IconsRegistered
from .units import ZBBQ_UnitSystems, ZBBQ_Units
from .consts import ZBBQ_Consts, zen_bbq_parented_panels
from .commonFunc import ZBBQ_CommonFunc, ZBBQ_MaterialFunc
from .operators import (
    ZBBQ_OT_ActiveObjectGetReady,
    ZBBQ_OT_BakeOpenFolder, ZBBQ_OT_FixSceneUnitSystem,
    ZBBQ_OT_PieMenuGeometryOptionsTop,
    ZBBQ_OT_SetZeroBevelRadiusToSelection,
    ZBBQ_OT_ShaderNodeNormalAdd, ZBBQ_OT_DrawHighlight,
    ZBBQ_OT_GlobalAddonCleanup, ZBBQ_OT_Keymaps,
    ZBBQ_OT_ObjectAddonCleanup, ZBBQ_OT_PieMenuGeometryOptionsBottom,
    ZBBQ_OT_PresetsPresetGroupAdd, ZBBQ_OT_PresetsPresetGroupRemove,
    ZBBQ_OT_PreviewShaderNodeToggle, ZBBQ_OT_ShaderNodeNormalRemove,
    ZBBQ_OT_RenderPreviewToggle, ZBBQ_OT_ResetPreferences,
    ZBBQ_OT_SetBevelRadiusToSelection,
    ZBBQ_OT_SmartSelectByRadiusFromActivePreset,
    ZBBQ_OT_SmartSelectByRadiusOfSelectedVerts,
    ZBBQ_OT_PresetsPresetOrderChange,
    ZBBQ_OT_RemoveNormalInspectStudio, ZBBQ_OT_SetupNormalInspectStudio,
    ZBBQ_OT_SetWeightedNormalToObjs, ZBBQ_OT_ManageExplosionModifier,
    ZBBQ_OT_AddNormalsMixerToMaterial, ZBBQ_OT_GenerateMaterialId,
    ZBBQ_OT_CopyBevelsToEdgeBevelWeight, ZBBQ_OT_SelectHardEdges,
    ZBBQ_OT_ManageBevelModifier, ZBBQ_OT_RepairNormalMixerNodes)
from .vertex_color import (
    ZBBQ_OT_CreateVertexColorMask, ZBBQ_OT_ShowBevelByMaterial,
    ZBBQ_OT_CreateNodeBevelToVc)

from .labels import ZBBQ_Labels
from .blender_zen_utils import (
    ZsUiConstants, ZenPolls,
    parse_preset_to_dict,
    is_same_preset_as_context_data)

from .draw_sets import is_draw_handler_enabled, ZBBQ_EdgeLayerManager

from .zen_common.combo_panel import ComboPanelView3D


def draw_live_boolean(layout: bpy.types.UILayout, context: bpy.types.Context, is_menu=False):

    d_radius = 0

    s_suffix = ""

    p_units = None
    p_act_obj = context.active_object
    if p_act_obj and p_act_obj.type == 'MESH':
        d_radius = p_act_obj.ZenBBQ_LiveBooleanRadius
        d_radius_for_display = p_act_obj.ZBBQ_IntactBevelDisplayRadius
        p_units = p_act_obj.ZBBQ_IntactBevelDisplayUnits
        s_units = layout.enum_item_name(p_act_obj, "ZBBQ_IntactBevelDisplayUnits", p_act_obj.ZBBQ_IntactBevelDisplayUnits)
        s_suffix = f": {d_radius_for_display:.2f} {s_units}"

    op = layout.operator("object.zenbbq_set_live_boolean_default_radius", text="Set Default Radius" + s_suffix)
    op.ZenBBQ_LiveBooleanRadius = d_radius
    if p_units:
        op.ZBBQ_IntactBevelDisplayUnits = p_units


def check_cycles_enabled_in_layout(layout: bpy.types.UILayout, context: bpy.types.Context):
    if ZBBQ_CommonFunc.IsCyclesEnabled(context):
        return True

    layout.alert = True

    if bpy.app.build_options.cycles:
        addon = context.preferences.addons.get("cycles")
        if addon is None:
            layout.label(text="Enable Cycles Render Engine add-on", icon='ERROR')
    else:
        layout.label(text="Cycles is disabled in this build", icon='ERROR')

    return False


def draw_gpu_backend_select(p_layout: bpy.types.UILayout):
    row = p_layout.row(align=True)
    row.operator("wm.zbbq_cycles_setup", text="Select GPU Backend", icon="ERROR")


class ZBBQ_PT_3DV_ComboPanel(ComboPanelView3D, bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_label = 'Zen BBQ'
    bl_context = ''
    bl_region_type = 'UI'
    bl_category = ZsUiConstants.ZSTS_PANEL_CATEGORY
    bl_order = 0  # MUST BE ALWAYS '0' !!!

    @classmethod
    def get_subpanels(cls):
        return zen_bbq_parented_panels

    @classmethod
    def poll(cls, context: bpy.types.Context):
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        return (
            addon_prefs.dock_VIEW_3D_panels_enabled and
            context.mode in {'OBJECT', 'EDIT_MESH'})


class ZBBQ_PT_Bevels(Panel):
    bl_idname = "ZBBQ_PT_Bevels"
    bl_label = "Bevels"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = ZsUiConstants.ZSTS_PANEL_CATEGORY
    bl_order = ZBBQ_Consts.get_combo_panel_order('VIEW_3D', 'ZBBQ_PT_Bevels')

    @classmethod
    def get_icon(cls):
        return 'PRESET'

    @classmethod
    def do_poll(cls, context: bpy.types.Context):
        if context.mode in {'EDIT_MESH', 'OBJECT'}:
            return True
        return False

    @classmethod
    def poll_reason(cls, context: bpy.types.Context) -> str:
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            return 'Available in Object | Edit Mode'
        return ''

    @classmethod
    def combo_poll(cls, context: bpy.types.Context):
        return cls.do_poll(context)

    @classmethod
    def poll(cls, context):
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        return addon_prefs.float_VIEW_3D_panels.enable_pt_main and cls.do_poll(context)

    def draw(self, context: bpy.types.Context):
        from .sceneConfig import ZBBQ_SceneProperties

        layout = self.layout

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        bpg = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()

        p_scene = context.scene
        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        b_is_baking_active = p_scene_props.is_baking_active

        p_view3d: bpy.types.SpaceView3D = None
        if isinstance(context.space_data, bpy.types.SpaceView3D):
            p_view3d = context.space_data

        # Presets Dropdown, Add and Remove

        row = layout.row(align=True)
        rowLeft = row.row(align=True)

        if len(addon_prefs.bevelPresetGroups) > 0:
            s_preset_name = addon_prefs.bevelPresetGroupsDropdown
            if addon_prefs.bevelPresetGroups.find(s_preset_name) == -1:
                s_preset_name = ZBBQ_Labels.LITERAL_DEFAULT_PRESET_TEXT
            rowLeft.menu("ZBBQ_MT_BevelPresets", text=s_preset_name)
        else:
            rowLeft.enabled = False
            rowLeft.menu("ZBBQ_MT_BevelPresets", text=ZBBQ_Labels.LITERAL_DEFAULT_PRESET_TEXT)

        rowRight = row.row(align=True)
        rowRight.alignment = 'RIGHT'
        op = rowRight.operator(ZBBQ_OT_PresetsPresetGroupAdd.bl_idname, text="", icon="ADD")
        op.title = 'Untitled' if addon_prefs.bevelPresetGroups.find(addon_prefs.bevelPresetGroupsDropdown) == -1 else addon_prefs.bevelPresetGroupsDropdown

        rowRight.operator(ZBBQ_OT_PresetsPresetGroupRemove.bl_idname, text="", icon="REMOVE")

        # Wrong unit system warning

        if bpg and bpy.context.scene.unit_settings.system != 'NONE' and bpg.unitSystem != 'NONE' and bpy.context.scene.unit_settings.system != bpg.unitSystem:

            rowWrongUnitSystem = layout.row(align=False)
            rowLeft = rowWrongUnitSystem.row(align=False)
            rowLeft.alert = True
            rowRight = rowWrongUnitSystem.row(align=True)
            rowRight.alignment = 'RIGHT'

            rowLeft.label(text=f"Scene unit system is {ZBBQ_UnitSystems[bpy.context.scene.unit_settings.system]}", icon='ERROR')
            rowRight.operator(ZBBQ_OT_FixSceneUnitSystem.bl_idname, text="Fix")

        if bpg is None:
            layout.label(text="Please create a new preset group")

        else:

            rowToolbar = layout.row(align=False)
            rowLeft = rowToolbar.row(align=True)
            rowRight = rowToolbar.row(align=True)
            rowRight.alignment = 'RIGHT'

            b_is_highlight_enabled = is_draw_handler_enabled(ZBBQ_EdgeLayerManager)
            rowLeft.operator(ZBBQ_OT_DrawHighlight.bl_idname,  depress=b_is_highlight_enabled, text='', icon='OVERLAY')
            rowLeft.separator()
            rowLeft.operator("wm.zen_bbq_update_data")

            rowRight.separator()

            if context.mode == 'EDIT_MESH':
                rowRight.operator(ZBBQ_OT_SetZeroBevelRadiusToSelection.bl_idname, text='', icon="LOOP_BACK")
            elif context.mode == 'OBJECT':
                rowRight.operator(ZBBQ_OT_ObjectAddonCleanup.bl_idname, text='', icon="LOOP_BACK")

            row = layout.row()
            row.template_list(
                "ZBBQ_UL_Presets",
                "",
                bpg, "bevelPresets",
                bpg, "bevelPresetsIndex",
                rows=7, sort_lock=True)

            col = row.column(align=True)
            col.operator(ZBBQ_OT_SmartSelectByRadiusOfSelectedVerts.bl_idname, text='', icon='VIS_SEL_11')
            col.operator(ZBBQ_OT_SmartSelectByRadiusFromActivePreset.bl_idname, text='', icon='RESTRICT_SELECT_OFF')

            col.separator()

            col.operator("wm.zen_bbq_preset_item_add", text="", icon="ADD")
            col.operator("wm.zen_bbq_preset_item_remove", text="", icon="REMOVE")
            col.separator()

            col.menu(menu='ZBBQ_MT_PresetUtils', text='', icon='DOWNARROW_HLT')

            col.operator(ZBBQ_OT_PresetsPresetOrderChange.bl_idname, text="", icon='TRIA_UP').direction = 'UP'
            col.operator(ZBBQ_OT_PresetsPresetOrderChange.bl_idname, text="", icon='TRIA_DOWN').direction = 'DOWN'

            col = layout.column(align=False)
            col.enabled = not b_is_baking_active
            row_1 = col.row(align=True)
            row_2 = col.row(align=True)

            s_current_mode = 'MATERIAL'

            enum_item: bpy.types.EnumPropertyItem
            for enum_item in p_scene_props.bl_rna.properties['preview_mode'].enum_items:
                b_depress = p_scene_props.preview_mode == enum_item.identifier
                s_preview_mode_id = enum_item.identifier.lower()
                s_pref_path = f"{s_preview_mode_id}_shading_type"
                s_value = getattr(addon_prefs, s_pref_path)

                icon_id = layout.enum_item_icon(addon_prefs, s_pref_path, s_value)
                s_text = layout.enum_item_name(addon_prefs, s_pref_path, s_value)

                r_popover = row_1.row(align=True)
                if enum_item.identifier == 'SHADER':
                    r_popover.active = addon_prefs.shader_preview_enabled
                r_popover.popover(f"ZBBQ_PT_{enum_item.identifier.title()}Shading", text=s_text, icon_value=icon_id)

                r_op = row_2.row(align=True)
                if enum_item.identifier == 'SHADER':
                    r_op.active = addon_prefs.shader_preview_enabled
                op: ZBBQ_OT_PreviewShaderNodeToggle = r_op.operator(
                    ZBBQ_OT_PreviewShaderNodeToggle.bl_idname,
                    text=enum_item.name,
                    depress=b_depress
                )
                op.mode = enum_item.identifier
                op.reset_nodes = False
                op.shading_type = s_value
                op.switch_to_cycles = addon_prefs.cycles_auto_activation and enum_item.identifier == 'SHADER' and op.shading_type == 'RENDERED'
                if b_depress:
                    s_current_mode = enum_item.identifier

            if p_view3d:
                if p_view3d.shading.type == 'RENDERED':
                    s_icon = 'WORLD' if p_view3d.shading.use_scene_world_render else 'LIGHT'
                    row_1.prop(p_view3d.shading, "use_scene_world_render", text="", icon=s_icon)
                elif p_view3d.shading.type == 'MATERIAL':
                    s_icon = 'WORLD' if p_view3d.shading.use_scene_world else 'LIGHT'
                    row_1.prop(p_view3d.shading, "use_scene_world", text="", icon=s_icon)
            else:
                row_1.label(text="", icon='BLANK1')

            row_2.prop(p_scene_props, "bake_image_interpolation", text="", icon="NODE_TEXTURE")

            p_cycles = getattr(p_scene, "cycles", None)
            if p_cycles is not None:
                if p_cycles.device != 'GPU':
                    op = layout.operator("wm.context_set_enum", text="Enable GPU", icon="ERROR")
                    op.data_path = "scene.cycles.device"
                    op.value = "GPU"
                else:
                    if not ZBBQ_CommonFunc.UseBakeGPU(context):
                        draw_gpu_backend_select(layout)

            row = col.row(align=True)
            r1 = row.row(align=True)
            r1.enabled = p_scene_props.preview_mode != 'MATERIAL'
            r_split = r1.split(factor=0.325)
            r_left = r_split.row(align=True)
            r_left.alignment = 'RIGHT'
            # XXX: r_left.label(text=p_scene_props.bl_rna.properties["preview_map"].name)
            r_left.separator()
            r_right = r_split.row(align=True)
            r_right.prop(p_scene_props, "preview_map", text="")

            op = row.operator("wm.zen_bbq_repair_preview_nodes", text="", icon="MODIFIER_ON")
            op.mode = s_current_mode

    def DrawDebugInfo(self, context):

        layout = self.layout

        layout.operator(ZBBQ_OT_ShaderNodeNormalAdd.bl_idname)
        layout.operator(ZBBQ_OT_ShaderNodeNormalRemove.bl_idname)

        # Readiness for work

        obj = context.active_object

        if ZBBQ_CommonFunc.ObjectIsReadyForBevelSilent(obj):
            layout.label(text="Ready for Zen BBQ!")
        else:
            if not ZBBQ_CommonFunc.ObjectIsMesh(obj):
                layout.label(text="This object CAN NOT be used for Zen BBQ!")
            else:
                layout.label(text="This object can be used for Zen BBQ!")

                hasDataLayer = ZBBQ_CommonFunc.ObjectHasDataLayerRadius(obj)
                layout.label(text=f'Has Data Layer: {"YES" if hasDataLayer else "NO"}')

                hasMaterial = ZBBQ_MaterialFunc.ObjectHasMaterialsFilled(obj)
                layout.label(text=f'Has Material: {"YES" if hasMaterial else "NO"}')

                if hasMaterial:
                    hasShaderNode = ZBBQ_MaterialFunc.ObjectHasShaderNodeNormal(obj)
                    layout.label(text=f'Has Sahder Node: {"YES" if hasShaderNode else "NO"}')

        layout.label(text=f"Current scene unit system: {bpy.context.scene.unit_settings.system}")
        layout.label(text=f"Current scene unit scale: {bpy.context.scene.unit_settings.scale_length}")

        layout.operator(ZBBQ_OT_ActiveObjectGetReady.bl_idname)

        layout.prop(ZBBQ_CommonFunc.GetPrefs(), "smartSelectRadiusThreshold")


class ZBBQ_PT_Bevels_Sub_Quality(Panel):
    bl_idname = "ZBBQ_PT_Bevels_Sub_Quality"
    bl_label = "Shader Render Presets"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = ZsUiConstants.ZSTS_PANEL_CATEGORY
    bl_parent_id = "ZBBQ_PT_Bevels"
    bl_options = {"DEFAULT_CLOSED"}

    @classmethod
    def do_poll(cls, context: bpy.types.Context):
        if context.scene.zen_bbq.preview_mode == 'SHADER':
            return True
        return False

    @classmethod
    def poll_reason(cls, context: bpy.types.Context) -> str:
        if context.scene.zen_bbq.preview_mode != 'SHADER':
            return 'Available in Shader preview!'
        return ''

    @classmethod
    def combo_poll(cls, context: bpy.types.Context):
        return cls.do_poll(context)

    @classmethod
    def poll(cls, context):
        return cls.combo_poll(context)

    def draw_header_preset(self, context: bpy.types.Context):
        if self.poll(context):
            if ZBBQ_CommonFunc.IsCyclesEnabled(context):
                self.layout.active = ZBBQ_CommonFunc.IsCyclesActive(context)
                ZBBQ_PT_viewport_sampling_presets.draw_panel_header(self.layout)

    def draw(self, context):
        layout = self.layout

        if check_cycles_enabled_in_layout(layout, context):
            b_is_cycles_enabled = ZBBQ_CommonFunc.IsCyclesActive(context)

            if not b_is_cycles_enabled:
                row = layout.row(align=True)
                row.alignment = 'CENTER'
                row.label(text="Available in Cycles only!", icon="ERROR")

            col = layout.column()
            col.active = b_is_cycles_enabled
            draw_preview_presets(col, context, "viewport_sampling")


# MARK: Tools Panel
class ZBBQ_PT_Tools(Panel):
    bl_idname = "ZBBQ_PT_Tools"
    bl_label = "Tools"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = ZsUiConstants.ZSTS_PANEL_CATEGORY
    bl_options = {"DEFAULT_CLOSED"}
    bl_order = ZBBQ_Consts.get_combo_panel_order('VIEW_3D', 'ZBBQ_PT_Tools')

    @classmethod
    def get_icon(cls):
        return 'TOOL_SETTINGS'

    @classmethod
    def do_poll(cls, context: bpy.types.Context):
        if context.mode in {'EDIT_MESH', 'OBJECT'}:
            return True
        return False

    @classmethod
    def poll_reason(cls, context: bpy.types.Context) -> str:
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            return 'Available in Object | Edit Mode'
        return ''

    @classmethod
    def combo_poll(cls, context: bpy.types.Context):
        return cls.do_poll(context)

    @classmethod
    def poll(cls, context):
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        return addon_prefs.float_VIEW_3D_panels.enable_pt_tools and cls.do_poll(context)

    def draw(self, context):
        from .preferences import ZBBQ_AddonExpandProps
        layout = self.layout

        col_main = layout.column(align=True)

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        p_expand_props: ZBBQ_AddonExpandProps = addon_prefs.expand_props

        box = p_expand_props.prepare_layout_panel(col_main, "expand_live_boolean")
        if box:
            draw_live_boolean(box, context)
            col_main.separator()

        # MARK: Normal Map Tools
        box_vc = p_expand_props.prepare_layout_panel(col_main, "expand_normal_studio")
        if box_vc:
            row = box_vc.row(align=True)
            row.operator(ZBBQ_OT_SetupNormalInspectStudio.bl_idname)
            row.operator(ZBBQ_OT_RemoveNormalInspectStudio.bl_idname)

            studio_position_empty = context.scene.objects.get(ZBBQ_Consts.normal_test_empty_position_name)
            if studio_position_empty:
                box_vc.label(text="Studio Rotation:")
                box_vc.prop(studio_position_empty, "rotation_euler", index=2, text="Angle")
            else:
                box_vc.label(text="Studio is not created yet", icon='INFO')

            col_main.separator()

        box_normal_tools = p_expand_props.prepare_layout_panel(col_main, "expand_normal_map_tools")
        if box_normal_tools:
            box_normal_tools.operator(ZBBQ_OT_SetWeightedNormalToObjs.bl_idname)

            # Manage Explode modifier
            col = box_normal_tools.column(align=True)
            col.label(text="Explode Modifier: ")
            box_explode_modifier = col.box()

            col = box_explode_modifier.column(align=True)
            p_op_name = ZBBQ_OT_ManageExplosionModifier.bl_idname
            p_op_label = "Manage Explode"
            col.operator(p_op_name, text=p_op_label.replace("Manage", "Add"), icon='ADD').action = "ADD"
            row = col.row(align=True)
            row.operator(p_op_name, text=p_op_label.replace("Manage", "Enable"), icon='HIDE_OFF').action = "ENABLE"
            row.operator(p_op_name, text=p_op_label.replace("Manage", "Disable"), icon='HIDE_ON').action = "DISABLE"
            col.operator(p_op_name, text=p_op_label.replace("Manage", "Remove"), icon='TRASH').action = "REMOVE"

            col = box_normal_tools.column(align=True)
            col.label(text='Add Normals Mixer To:')
            box = col.box()
            row = box.row(align=True)
            row.operator(ZBBQ_OT_AddNormalsMixerToMaterial.bl_idname, text='All Materials').mixer_application_mode = 'ALL'
            row.operator(ZBBQ_OT_AddNormalsMixerToMaterial.bl_idname, text='Active Material').mixer_application_mode = 'ACTIVE'
            box.operator(ZBBQ_OT_RepairNormalMixerNodes.bl_idname, icon="MODIFIER_ON")

            col_main.separator()

        # MARK: Vertex Color Tools
        box = p_expand_props.prepare_layout_panel(col_main, "expand_vertex_color_mask")
        if box:
            col = box.column(align=True)
            col.operator(ZBBQ_OT_CreateVertexColorMask.bl_idname)
            col.operator(ZBBQ_OT_ShowBevelByMaterial.bl_idname)
            if ZenPolls.version_since_4_0_0:
                col.operator(ZBBQ_OT_CreateNodeBevelToVc.bl_idname)
            col_main.separator()

        # Mesh Tools
        # MARK: Mesh Tools
        box_mesh_tools = p_expand_props.prepare_layout_panel(col_main, "expand_mesh_tools")
        if box_mesh_tools:

            # Manage Bevel modifier
            col = box_mesh_tools.column(align=True)
            col.label(text="Bevel Modifier:")
            box_bev_modifier = col.box()

            col = box_bev_modifier.column(align=True)
            p_op_name = ZBBQ_OT_ManageBevelModifier.bl_idname
            p_op_label = "Manage Bevels"
            col.operator(p_op_name, text=p_op_label.replace("Manage", "Add"), icon='ADD').action = "ADD"

            row = col.row(align=True)
            row.operator(p_op_name, text=p_op_label.replace("Manage", "Enable"), icon='HIDE_OFF').action = "ENABLE"
            row.operator(p_op_name, text=p_op_label.replace("Manage", "Disable"), icon='HIDE_ON').action = "DISABLE"
            col.operator(p_op_name, text=p_op_label.replace("Manage", "Remove"), icon='TRASH').action = "REMOVE"

            row = box_mesh_tools.row()
            row.operator(ZBBQ_OT_SelectHardEdges.bl_idname)

            col_main.separator()

        # Misc Tools
        # MARK: Misc Tools
        box_misc_tools = p_expand_props.prepare_layout_panel(col_main, "expand_misc_tools")
        if box_misc_tools:
            col = box_misc_tools.column(align=True)
            col.operator(ZBBQ_OT_GenerateMaterialId.bl_idname)
            col.operator(ZBBQ_OT_CopyBevelsToEdgeBevelWeight.bl_idname)

            col_main.separator()  # NOTE: Must be at the end of block !!!

        # Debug
        # box = layout.box()
        # box.label(text='Debug ->')
        # box.operator(ZBBQ_OT_SystemGetVColor.bl_idname)


class ZBBQ_PT_Bake(Panel):
    bl_idname = "ZBBQ_PT_Bake"
    bl_label = "Bake"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = ZsUiConstants.ZSTS_PANEL_CATEGORY
    bl_order = ZBBQ_Consts.get_combo_panel_order('VIEW_3D', 'ZBBQ_PT_Bake')

    @classmethod
    def get_icon(cls):
        return 'RENDER_RESULT'

    @classmethod
    def do_poll(cls, context: bpy.types.Context):
        if context.mode in {'EDIT_MESH', 'OBJECT'}:
            return True
        return False

    @classmethod
    def poll_reason(cls, context: bpy.types.Context) -> str:
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            return 'Available in Object | Edit Mode'
        return ''

    @classmethod
    def combo_poll(cls, context: bpy.types.Context):
        return cls.do_poll(context)

    @classmethod
    def poll(cls, context):
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        return addon_prefs.float_VIEW_3D_panels.enable_pt_bake and cls.do_poll(context)

    def draw_header_preset(self, context: bpy.types.Context):
        from .sceneConfig import ZBBQ_SceneProperties
        p_scene = context.scene
        p_bbq_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        layout = self.layout
        layout.prop(p_bbq_props, "bake_process_state", text="", emboss=False)
        layout.operator(ZBBQ_OT_BakeOpenFolder.bl_idname, text='', icon='FILEBROWSER')

    def draw(self, context: bpy.types.Context):
        from .bake_model.bake_ui import WM_OT_ZBBQScxmlBakeTrigger, WM_OT_ZBBQScxmlBakeStart
        from .sceneConfig import ZBBQ_SceneProperties
        from .eventHandling import sm
        from .preferences import ZBBQ_AddonExpandProps

        layout = self.layout

        if not check_cycles_enabled_in_layout(layout, context):
            return

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        p_scene = context.scene
        p_bbq_props: ZBBQ_SceneProperties = p_scene.zen_bbq

        b_gpu_not_valid = p_bbq_props.bake_render_device == "GPU" and not ZBBQ_CommonFunc.UseBakeGPU(context)

        if b_gpu_not_valid:
            draw_gpu_backend_select(layout)

        b_is_bake_init = bool(sm and sm.In("BakeInit"))

        row = layout.row(align=True)
        row.enabled = b_is_bake_init
        r1 = row.row(align=True)
        r1.enabled = not p_bbq_props.bake_objects_pin
        r1.prop(p_bbq_props, "bake_objects_mode", expand=True)
        s_icon = 'PINNED' if p_bbq_props.bake_objects_pin else 'UNPINNED'
        row.prop(p_bbq_props, "bake_objects_pin", text="", icon=s_icon)

        row = layout.row(align=True)
        row.enabled = b_is_bake_init
        row.prop(p_bbq_props, "bake_material_mode", expand=True)
        row.label(text="", icon="BLANK1")

        row = layout.row()
        col = row.column()

        if p_bbq_props.bake_objects_pin or (sm and not sm.In("BakeInit")):
            p_object_data = p_bbq_props.bake_pinned_collection
            s_objects_attr = "objects"
        else:
            if p_bbq_props.bake_objects_mode == 'SELECTED':
                p_object_data = context.view_layer.objects
                s_objects_attr = "selected"
            else:
                p_object_data = context.collection
                s_objects_attr = "objects"

        col.template_list(
            "SCXML_UL_BakeList",
            "name",
            p_object_data,
            s_objects_attr,
            p_bbq_props,
            "bake_objects_index_ui",
            rows=5
        )

        row = layout.row(align=True)

        r1 = row.row(align=True)
        r1.enabled = sm.In("BakeInit") or sm.In("BakeSuccess")
        op = r1.operator(WM_OT_ZBBQScxmlBakeStart.bl_idname, text="Start", icon='PLAY')

        r2 = row.row(align=True)
        r2.enabled = sm.In("BakingActive")
        s_text = "Resume" if sm.In("BakingPaused") else "Pause"
        op = r2.operator(WM_OT_ZBBQScxmlBakeTrigger.bl_idname, text=s_text, icon="PAUSE")
        op.event_name = "bake.pause"
        op.desc = "Pause baking workflow"

        r3 = row.row(align=True)
        r3.enabled = sm.In("Baking")
        op = r3.operator(WM_OT_ZBBQScxmlBakeTrigger.bl_idname, text="Cancel", icon="CANCEL")
        op.event_name = "bake.cancel"
        op.desc = "Terminate baking workflow"

        if sm.In("BakeAllDone"):
            if sm.In("BakeError"):
                col = layout.column(align=True)
                col.alert = True
                col.label(text="Bake Workflow Failed:", icon='ERROR')
                short_lines = textwrap.wrap(sm.datamodel["BakeData"].s_BAKE_ERROR, width=60)
                for line in short_lines:
                    col.label(text=line)

            row = layout.row(align=True)
            op = row.operator(WM_OT_ZBBQScxmlBakeTrigger.bl_idname, text="Resume Monitoring", icon='FILE_REFRESH')
            op.event_name = "bake.reset"
            op.desc = "Continue to monitor selected objects and clear bake results"
        elif sm.In("BakeFinal") or sm.isFinished():
            col = layout.column(align=True)
            col.alert = True
            col.label(text="Bake Workflow Terminated:", icon='ERROR')

            if sm.datamodel["BakeData"].s_BAKE_ERROR != "":
                col.label(text=sm.datamodel["BakeData"].s_BAKE_ERROR)
            else:
                s_error_msg = 'Undefined Reason'
                p_exception = sm.datamodel["_event"].data
                if isinstance(p_exception, Exception):
                    if p_exception.__context__:
                        s_error_msg = str(p_exception.__context__)
                    else:
                        s_error_msg = str(p_exception)
                short_lines = textwrap.wrap(s_error_msg, width=60)
                for line in short_lines:
                    col.label(text=line)

        p_expand_props: ZBBQ_AddonExpandProps = addon_prefs.expand_props

        def fn_draw_render_header(p_header_layout: bpy.types.UILayout):
            r1 = p_header_layout.row(align=True)
            r1.label(text="Bake Render")

            r2 = p_header_layout.row(align=True)
            r2.active = not b_gpu_not_valid
            r2.alignment = 'RIGHT'
            r2.label(
                text=layout.enum_item_name(
                    p_bbq_props, "bake_render_device", p_bbq_props.bake_render_device))

        box_render: bpy.types.UILayout = p_expand_props.prepare_layout_panel(
            layout, "expand_bake_render",
            fn_draw_header=fn_draw_render_header,
            fn_create_body=lambda layout: layout.column(align=False))
        if box_render:
            col = box_render

            def fn_before_draw_props(p_layout: bpy.types.UILayout):
                row = p_layout.row(align=True)
                r1 = row.row(align=True)
                r1.active = ZBBQ_CommonFunc.UseBakeGPU(context)
                r1.prop_enum(p_bbq_props, "bake_render_device", "GPU")
                row.prop_enum(p_bbq_props, "bake_render_device", "CPU")

                from .commonFunc import ZBBQ_PropUtils
                ZBBQ_PropUtils.draw_bake_image_size(p_layout, p_bbq_props)

            fn_before_draw_props(col)

            row = col.row(align=True)
            row.label(text="Bake Render Presets")
            ZBBQ_PT_viewport_sampling_presets.draw_panel_header(row)

            draw_preview_presets(col, context, "render")

        def fn_draw_output_header(p_header_layout: bpy.types.UILayout):
            r1 = p_header_layout.row(align=True)
            r_left = r1.row(align=True)
            r_left.label(text="Bake Output")

            r2 = r1.row(align=True)
            r2.active = not b_gpu_not_valid
            r2.alignment = 'RIGHT'
            r2.prop(p_bbq_props, "bake_batch", text="")
            r2.label(text=p_bbq_props.bl_rna.properties["bake_batch"].name)

        box_output: bpy.types.UILayout = p_expand_props.prepare_layout_panel(
            layout, "expand_bake_output",
            fn_create_body=lambda layout: layout.column(align=True),
            fn_draw_header=fn_draw_output_header)
        if box_output:
            b_is_bake_dir_valid = bool(ZBBQ_OT_BakeOpenFolder.poll(context))

            box = box_output.box()
            box.label(text="Template:")
            box.alert = not b_is_bake_dir_valid

            col = box.column(align=True)

            r = col.row(align=True)
            r1 = r.row(align=True)
            r1.prop(p_bbq_props, "bake_template_output_directory")

            r2 = r.row(align=True)
            r2.alignment = 'RIGHT'
            r2.menu(menu="ZBBQ_MT_FolderTemplates", text="")
            r2.prop(p_bbq_props, "bake_output_directory", text="", icon_only=True)

            box = col.box()

            col1 = box.column(align=True)
            row = col1.row(align=True)
            row.active = not p_bbq_props.bake_batch
            r1 = row.row(align=True)
            r1.prop(p_bbq_props, 'bake_image_name', text="Individual")
            r2 = row.row(align=True)
            r2.alignment = 'RIGHT'
            r2.menu(menu="ZBBQ_MT_ImageNameTemplates", text="")
            r2.label(text='', icon='BLANK1')  # NOTE: do not use separator in this case

            row = col1.row(align=True)
            row.active = p_bbq_props.bake_batch
            r1 = row.row(align=True)
            r1.prop(p_bbq_props, 'bake_batch_image_name', text="Merged")
            r2 = row.row(align=True)
            r2.alignment = 'RIGHT'
            r2.menu(menu="ZBBQ_MT_ImageNameTemplates", text="")
            r2.label(text='', icon='BLANK1')  # NOTE: do not use separator in this case

            box = box_output.box()
            box.label(text="Evaluated:")
            col = box.column(align=True)
            col.alignment = 'RIGHT'

            row = col.row(align=True)
            r1 = row.row(align=True)
            r1.alignment = 'LEFT'
            r1.label(text="Dir Name:")
            r2 = row.row(align=True)
            r2.alignment = 'RIGHT'
            r2.label(text=p_bbq_props.bake_output_directory)

            p_act_obj = context.active_object
            p_act_material = None
            if p_act_obj and p_act_obj.type == 'MESH':
                p_act_material = p_act_obj.active_material

            s_image_filename = ZBBQ_MaterialFunc.GetBakeImageName(
                p_scene, p_act_material, p_scene.collection, p_act_obj, 0, p_bbq_props.bake_normal.bake_image_suffix
            )
            row = col.row(align=True)
            r1 = row.row(align=True)
            r1.alignment = 'LEFT'
            r1.label(text="Image Name:")
            r2 = row.row(align=True)
            r2.alignment = 'RIGHT'
            r2.label(text=s_image_filename)

        p_act_bake_maps = p_bbq_props.get_actve_bake_maps()
        n_active_maps_count = len(p_act_bake_maps)

        def fn_draw_bake_maps(p_layout: bpy.types.UILayout):
            row = p_layout.row(align=True)
            row.label(text="Bake Maps")

            r2 = row.row(align=True)
            r2.alignment = 'RIGHT'
            r2.alert = n_active_maps_count == 0
            if n_active_maps_count == 0:
                s_label = "No active maps"
            elif n_active_maps_count == 1:
                s_label = list(p_act_bake_maps.values())[0].TITLE
            else:
                p_maps = list(p_act_bake_maps.values())
                n_more = len(p_maps) - 1
                s_label = f"{p_maps[0].TITLE} and {n_more} more"
            r2.label(text=s_label)

        box_bake_maps: bpy.types.UILayout = p_expand_props.prepare_layout_panel(
            layout, "expand_bake_maps", fn_draw_header=fn_draw_bake_maps)
        if box_bake_maps:
            p_bbq_props.draw_bake_map_types(box_bake_maps, context)

        box_bake_misc: bpy.types.UILayout = p_expand_props.prepare_layout_panel(
            layout, "expand_bake_misc", fn_create_body=lambda layout: layout.column(align=True))
        if box_bake_misc:
            box_bake_misc.use_property_split = True
            box_bake_misc.use_property_decorate = False
            box_bake_misc.prop(addon_prefs, "bake_check_flipped_uvs")
            box_bake_misc.prop(addon_prefs, "bake_check_overlapped_uvs")


class ZBBQ_PT_Preferences(Panel):
    bl_idname = "ZBBQ_PT_Preferences"
    bl_label = "Preferences"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = ZsUiConstants.ZSTS_PANEL_CATEGORY
    bl_options = {"DEFAULT_CLOSED"}
    bl_order = ZBBQ_Consts.get_combo_panel_order('VIEW_3D', 'ZBBQ_PT_Preferences')

    @classmethod
    def get_icon(cls):
        return 'PREFERENCES'

    @classmethod
    def do_poll(cls, context: bpy.types.Context):
        if context.mode in {'EDIT_MESH', 'OBJECT'}:
            return True
        return False

    @classmethod
    def poll_reason(cls, context: bpy.types.Context) -> str:
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            return 'Available in Object | Edit Mode'
        return ''

    @classmethod
    def combo_poll(cls, context: bpy.types.Context):
        return cls.do_poll(context)

    @classmethod
    def poll(cls, context):
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        return addon_prefs.float_VIEW_3D_panels.enable_pt_preferences and cls.do_poll(context)

    def draw(self, context):

        layout = self.layout

        layout.operator(ZBBQ_OT_Keymaps.bl_idname, icon_value=ZBBQ_Icons['Addon-Logo'].id())
        layout.operator(ZBBQ_OT_ResetPreferences.bl_idname)
        layout.operator(ZBBQ_OT_GlobalAddonCleanup.bl_idname)


class ZBBQ_PT_Preferences_Sub_Common(Panel):
    bl_idname = "ZBBQ_PT_Preferences_Sub_Common"
    bl_parent_id = "ZBBQ_PT_Preferences"
    bl_label = "Common"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = ZsUiConstants.ZSTS_PANEL_CATEGORY
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context):

        prefs = ZBBQ_CommonFunc.GetPrefs()

        layout = self.layout
        prefs.draw_common(layout, context)


class ZBBQ_PT_Preferences_Sub_Panels(Panel):
    bl_idname = "ZBBQ_PT_Preferences_Sub_Panels"
    bl_parent_id = "ZBBQ_PT_Preferences"
    bl_label = "Panels"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = ZsUiConstants.ZSTS_PANEL_CATEGORY
    bl_options = {"DEFAULT_CLOSED"}

    def draw(self, context: bpy.types.Context):
        layout = self.layout
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        addon_prefs.combo_panel.draw_panels_enabler(context, layout, "VIEW_3D", is_combo=True)


class ZBBQ_PT_Help(bpy.types.Panel):
    bl_space_type = ZsUiConstants.ZSTS_SPACE_TYPE
    bl_idname = "ZBBQ_PT_Help"
    bl_label = "Help"
    bl_region_type = ZsUiConstants.ZSTS_REGION_TYPE
    bl_category = ZsUiConstants.ZSTS_PANEL_CATEGORY
    bl_options = {"DEFAULT_CLOSED"}
    bl_order = ZBBQ_Consts.get_combo_panel_order('VIEW_3D', 'ZBBQ_PT_Help')

    @classmethod
    def get_icon(cls):
        return 'HELP'

    @classmethod
    def do_poll(cls, context: bpy.types.Context):
        if context.mode in {'EDIT_MESH', 'OBJECT'}:
            return True
        return False

    @classmethod
    def poll_reason(cls, context: bpy.types.Context) -> str:
        if context.mode not in {'OBJECT', 'EDIT_MESH'}:
            return 'Available in Object | Edit Mode'
        return ''

    @classmethod
    def combo_poll(cls, context: bpy.types.Context):
        return cls.do_poll(context)

    @classmethod
    def poll(cls, context):
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        return addon_prefs.float_VIEW_3D_panels.enable_pt_help and cls.do_poll(context)

    def draw(self, context):
        layout = self.layout

        col = layout.column(align=False)

        row = col.row(align=True)
        row.operator(
            "wm.url_open",
            text=ZBBQ_Labels.PANEL_HELP_DOC_LABEL,
            icon="HELP"
        ).url = ZBBQ_Labels.PANEL_HELP_DOC_LINK
        row = col.row(align=True)
        row.operator(
            "wm.url_open",
            text=ZBBQ_Labels.PANEL_HELP_DISCORD_LABEL,
            icon_value=ZBBQ_Icons['Discord-Logo-White_32'].id()
        ).url = ZBBQ_Labels.PANEL_HELP_DISCORD_LINK

        try:
            row = layout.row(align=True)
            row.label(text='Version: ' + ZBBQ_CommonFunc.GetAddonVersion())
        except Exception:
            print('Zen BBQ: No version found. There may be several versions installed. Try uninstalling everything and installing the latest version.')

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        box = layout.box()
        addon_prefs.demo.draw(box, context)


t_PRESET_HASH = {
    "viewport_sampling": {
        "Low": None,
        "Med": None,
        "High": None
    },
    "render": {
        "Low": None,
        "Med": None,
        "High": None
    }
}


def compare_viewport_sampling_preset(preset_base, preset_name, filepath):
    if t_PRESET_HASH[preset_base][preset_name] is None:
        t_PRESET_HASH[preset_base][preset_name] = parse_preset_to_dict(filepath)
    return is_same_preset_as_context_data(t_PRESET_HASH[preset_base][preset_name])


def draw_preview_presets(
        layout: bpy.types.UILayout, context: bpy.types.Context, preset_base: str,
        fn_before_draw_props: callable = None):
    from .preferences import ZBBQ_AddonExpandProps

    if not check_cycles_enabled_in_layout(layout, context):
        return

    addon_prefs = ZBBQ_CommonFunc.GetPrefs()
    p_expand_props: ZBBQ_AddonExpandProps = addon_prefs.expand_props

    s_dir = os.path.dirname(__file__)

    def fn_draw_props_header(p_header_layout: bpy.types.UILayout):
        r1 = p_header_layout.row(align=True)
        r1.label(text="Preset Properties")

    b_match = False

    r2 = layout.row(align=True)

    for preset in ["Low", "Med", "High"]:
        s_file = os.path.join(s_dir, f"presets/{preset_base}/{preset}.py")

        b_depress = False
        if b_match is False:
            b_match = compare_viewport_sampling_preset(preset_base, preset, s_file)
            b_depress = b_match

        op = r2.operator("script.execute_preset", text=preset, depress=b_depress)
        op.menu_idname = f"ZBBQ_PT_{preset_base}_presets"
        op.filepath = s_file

    box_props: bpy.types.UILayout = p_expand_props.prepare_layout_panel(
        layout, f"expand_{preset_base}_preset_properties",
        fn_create_body=lambda layout: layout.column(align=True),
        fn_draw_header=fn_draw_props_header
    )
    if box_props:

        col_main = box_props.column(align=True)

        if fn_before_draw_props:
            fn_before_draw_props(col_main)

        def _draw_sampling(sampling_id: str, p_viewport_layout: bpy.types.UILayout, cls_viewport, cls_denoise):
            class FakePanel:
                def __init__(self, p_layout) -> None:
                    self.layout = p_layout

            box_viewport: bpy.types.UILayout = p_expand_props.prepare_layout_panel(
                p_viewport_layout, f"expand_{sampling_id}_viewport_preset_properties"
            )
            if box_viewport:
                p_fake_sampling_viewport_panel = FakePanel(box_viewport)
                cls_viewport.draw(p_fake_sampling_viewport_panel, context)

            def fn_draw_denoise_props_header(p_header_layout: bpy.types.UILayout):
                row = p_header_layout.row(align=True)
                row.use_property_split = False
                row.prop(
                    context.scene.cycles,
                    "use_preview_denoising" if sampling_id == 'viewport_sampling' else "use_denoising",
                    text="")
                row.label(text="Denoise")

            if sampling_id == 'viewport_sampling':
                box_denoise_props: bpy.types.UILayout = p_expand_props.prepare_layout_panel(
                    p_viewport_layout, f"expand_{sampling_id}_denoise_preset_properties",
                    fn_draw_header=fn_draw_denoise_props_header
                )
                if box_denoise_props:
                    p_fake_denoise_viewport_panel = FakePanel(box_denoise_props)
                    cls_denoise.draw(p_fake_denoise_viewport_panel, context)

        col_sub = box_props.column(align=True)

        for datablock, properties in t_PRESET_HASH[preset_base]["Low"].items():
            scene_engine_block = eval(datablock)
            if datablock == "bpy.context.scene.cycles":
                if preset_base == "viewport_sampling":
                    from cycles.ui import CYCLES_RENDER_PT_sampling_viewport, CYCLES_RENDER_PT_sampling_viewport_denoise  # type: ignore

                    _draw_sampling(preset_base, col_sub, CYCLES_RENDER_PT_sampling_viewport, CYCLES_RENDER_PT_sampling_viewport_denoise)
                    continue
                elif preset_base == "render":
                    from cycles.ui import CYCLES_RENDER_PT_sampling_render, CYCLES_RENDER_PT_sampling_render_denoise  # type: ignore

                    _draw_sampling(preset_base, col_sub, CYCLES_RENDER_PT_sampling_render, CYCLES_RENDER_PT_sampling_render_denoise)
                    continue

            elif datablock == "bpy.context.scene.zen_bbq":
                # box_addon: bpy.types.UILayout = p_expand_props.prepare_layout_panel(
                #     box_props, "expand_viewport_addon_properties"
                # )
                # if box_addon:

                box = col_main.box()
                col = box.column(align=True)

                for prop_name, _ in properties.items():
                    if not hasattr(scene_engine_block, prop_name):
                        continue

                    col.prop(scene_engine_block, prop_name)


def draw_shading_type(layout: bpy.types.UILayout, attr_name: str):
    addon_prefs = ZBBQ_CommonFunc.GetPrefs()

    row = layout.row(align=True)
    r_split = row.split(factor=1/2.5)

    r1 = r_split.row(align=False)
    r1.alignment = 'RIGHT'
    r1.label(text=addon_prefs.bl_rna.properties[attr_name].name)
    s_attr_locked = f"{attr_name}_locked"
    b_locked = getattr(addon_prefs, s_attr_locked)
    s_icon = "LOCKED" if b_locked else "UNLOCKED"
    r1.prop(addon_prefs, s_attr_locked, text="", icon=s_icon)

    r2 = r_split.row(align=True)
    col = r2.column(align=True)
    col.enabled = not b_locked

    for enum_item in addon_prefs.bl_rna.properties[attr_name].enum_items:
        col.prop_enum(addon_prefs, attr_name, enum_item.identifier)


class ZBBQ_PT_MaterialShading(bpy.types.Panel):
    bl_idname = "ZBBQ_PT_MaterialShading"
    bl_label = "Material Shading Properties"
    bl_context = "__POPUP__"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 14

    def draw(self, context: bpy.types.Context):
        draw_shading_type(self.layout, "material_shading_type")


class ZBBQ_PT_ShaderShading(bpy.types.Panel):
    bl_idname = "ZBBQ_PT_ShaderShading"
    bl_label = "Shader Shading Properties"
    bl_context = "__POPUP__"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 14

    def draw(self, context: bpy.types.Context):
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        layout = self.layout

        draw_shading_type(layout, "shader_shading_type")

        col = layout.column(align=True)
        col.use_property_decorate = False
        col.use_property_split = True

        col.active = addon_prefs.shader_preview_enabled
        col.prop(addon_prefs, "shader_preview_enabled")
        col.prop(addon_prefs, "shader_preview_color")


class ZBBQ_PT_ImageShading(bpy.types.Panel):
    bl_idname = "ZBBQ_PT_ImageShading"
    bl_label = "Image Shading Properties"
    bl_context = "__POPUP__"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 14

    def draw(self, context: bpy.types.Context):
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        layout = self.layout

        draw_shading_type(layout, "image_shading_type")

        col = layout.column(align=True)
        col.use_property_decorate = False
        col.use_property_split = True
        col.prop(addon_prefs, "image_preview_color")


class ZBBQ_MT_BevelPresets(bpy.types.Menu):
    bl_idname = "ZBBQ_MT_BevelPresets"
    bl_label = "Bevel Presets Groups"

    def draw(self, context: bpy.types.Context):
        prefs = ZBBQ_CommonFunc.GetPrefs()

        layout = self.layout

        for presetGroup in prefs.bevelPresetGroups:
            op = layout.operator("wm.zen_bbq_load_preset", text=presetGroup.name)
            op.preset_name = presetGroup.name


class ZBBQ_MT_FolderTemplates(bpy.types.Menu):
    bl_idname = "ZBBQ_MT_FolderTemplates"
    bl_label = "Folder Templates"

    def draw(self, context: bpy.types.Context):
        macro_descriptions = {
            "//": "Current scene file directory (temporary directory if not saved)",
            "%RENDER_OUTPUT%": "Render output directory path",
            "%TEXTURES%": "Texture directory path",
            "%BLENDER_TEMP%": "Blender temporary directory path",
        }

        layout = self.layout
        layout.label(text="Setup Folder:")
        for k, v in macro_descriptions.items():
            op = layout.operator("wm.context_set_string", text=f"{k} - {v}")
            op.data_path = "scene.zen_bbq.bake_template_output_directory"
            op.value = k


class ZBBQ_MT_ImageNameTemplates(bpy.types.Menu):
    bl_idname = "ZBBQ_MT_ImageNameTemplates"
    bl_label = "Image Name Templates"

    def draw(self, context: bpy.types.Context):
        macro_descriptions = {
            "%MATERIAL%": "Material name",
            "%OBJECT%": "Object name",
            "%SCENE%": "Scene name",
            "%BLEND%": "Blend file name without extension",
            "%COLLECTION%": "Collection name",
            "%SUFFIX%": "bake type suffix (e.g., _Normal, _AO, _Curvature, etc.)",
            "%MAT_ID%": "Index of material in a bake list",
        }

        layout = self.layout
        layout.label(text="Copy to clipboard:")
        for k, v in macro_descriptions.items():
            op = layout.operator("wm.zbbq_copy_to_clipboard", text=f"{k} - {v}")
            op.text = k


class ZBBQ_MT_PresetUtils(bpy.types.Menu):
    bl_idname = "ZBBQ_MT_PresetUtils"
    bl_label = "Bevel Preset Utils"

    def draw(self, context: bpy.types.Context):
        from .preferences import ZBBQ_Pref_BevelPreset, ZBBQ_Pref_BevelPresetGroup
        prefs = ZBBQ_CommonFunc.GetPrefs()
        bpg: ZBBQ_Pref_BevelPresetGroup = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()

        layout = self.layout

        op = layout.operator("wm.zen_bbq_preset_create", icon="DUPLICATE")
        op.unitSystem = context.scene.unit_settings.system
        layout.separator()

        active_radius_value: str = None
        target_radius = 0
        target_units = "MILLIMETERS"
        if bpg.bevelPresetsIndex in range(len(bpg.bevelPresets)):
            bp: ZBBQ_Pref_BevelPreset = bpg.bevelPresets[bpg.bevelPresetsIndex]
            active_units = layout.enum_item_name(bp, "units", bp.units)
            active_radius_value = f"{bp.radius:.2g} {active_units}"
            target_radius = bp.radius
            target_units = bp.units

        layout.operator(
            "object.zen_bbq_smart_select_by_radius_of_selected_verts",
            icon='VIS_SEL_11')
        layout.operator(
            "object.zen_bbq_smart_select_by_radius_from_active_preset",
            text="Select " + active_radius_value if active_radius_value else None,
            icon='RESTRICT_SELECT_OFF')

        layout.separator()

        op = layout.operator(
            "wm.zen_bbq_replace_radius",
            text="Replace " + active_radius_value if active_radius_value else None)
        op.preset_index = bpg.bevelPresetsIndex
        op.target_radius = target_radius
        op.units = target_units

        layout.operator("wm.zen_bbq_clear_extra_values")

        p_units = context.scene.unit_settings.length_unit
        if ZBBQ_Units.get(p_units, None):
            units_string = ZBBQ_Units[p_units].shortTitle
            p_mult = ZBBQ_Units[p_units].unitAndSceneScaleMultiplier()
        else:
            units_string = ''
            p_mult = 1.0

        d_max_bevel = (bpg.max_bevel_value / p_mult) if p_mult else bpg.max_bevel_value

        layout.separator()
        layout.operator("wm.zen_bbq_update_data", text=f"Max Bevel: {d_max_bevel:.2g} {units_string}")
        layout.prop(prefs, 'display_statistics')

        layout.separator()
        draw_live_boolean(layout, context, is_menu=True)


# === Pie Menus

class ZBBQ_MT_GeometryOptions(Menu):
    bl_idname = "ZBBQ_MT_GeometryOptions"
    bl_label = "Zen BBQ"
    bl_context = "mesh_edit"
    bl_space_type = 'VIEW_3D'

    def draw(self, context):
        pie = self.layout.menu_pie()

        bpg = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()

        if bpg is None:
            pie.label(text="Please have at least one Preset Group")
        else:

            # Works only with 6 PGs

            p_presets = bpg.bevelPresets

            if len(p_presets) > 0:

                bevelPresetsReSorted = [
                    p_presets[4] if len(p_presets) > 4 else None,
                    p_presets[1] if len(p_presets) > 1 else None,
                    p_presets[5] if len(p_presets) > 5 else None,
                    p_presets[0] if len(p_presets) > 0 else None,
                    p_presets[3] if len(p_presets) > 3 else None,
                    p_presets[2] if len(p_presets) > 2 else None,
                ]

                idxPresets = 0
                for i in range(8):
                    if i == 2:
                        if context.mode == 'EDIT_MESH':
                            pie.operator(ZBBQ_OT_PieMenuGeometryOptionsBottom.bl_idname, depress=ZBBQ_CommonFunc.IsRenderPreviewActive(), icon='HIDE_OFF')
                        elif context.mode == 'OBJECT':
                            pie.operator(ZBBQ_OT_RenderPreviewToggle.bl_idname, depress=ZBBQ_CommonFunc.IsRenderPreviewActive(), icon="HIDE_OFF")

                    elif i == 3:

                        if context.mode == 'EDIT_MESH':
                            pie.operator(ZBBQ_OT_PieMenuGeometryOptionsTop.bl_idname, icon='RESTRICT_SELECT_OFF')
                        elif context.mode == 'OBJECT':
                            pie.operator(ZBBQ_OT_ObjectAddonCleanup.bl_idname, icon="LOOP_BACK")

                    else:

                        bp = bevelPresetsReSorted[idxPresets]
                        if bp is not None:
                            unitTitle = bp.getUnitInfo().shortTitle

                            color = Color(bp.color)

                            s_color_value_name = f"color_value_{round(color.h, 3)}"
                            p_icon_preview = ZBBQ_IconsRegistered.get(s_color_value_name, None)
                            if p_icon_preview is None:
                                p_icon_preview = ZBBQ_IconsRegistered.new(s_color_value_name)
                                p_icon_preview.icon_size = (32, 32)
                                pixel_data = np.zeros((32, 32, 4), dtype=np.float32)
                                pixel_data[:, :] = (*color[:], 1)
                                p_icon_preview.icon_pixels_float = pixel_data.flatten()

                            id_icon = p_icon_preview.icon_id

                            OpSetRadius = pie.operator(
                                ZBBQ_OT_SetBevelRadiusToSelection.bl_idname,
                                text=f"{bp.radius:2g} {unitTitle}",
                                icon_value=id_icon,
                            )
                            OpSetRadius.radius = bp.radius  # *unitAndSceneScaleMultiplier
                            OpSetRadius.units = bp.units
                        else:
                            pie.separator()

                        idxPresets += 1


class ZBBQ_OT_CallPie_GeometryOptions(Operator):
    bl_idname = "object.zen_bbq_callpie_geometry_options"
    bl_label = ZBBQ_Labels.ZBBQ_OT_CallPie_GeometryOptions_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_CallPie_GeometryOptions_Desc

    def execute(self, context):

        bpg = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        if len(bpg.bevelPresets) == 0:
            return bpy.ops.wm.zen_bbq_preset_create('INVOKE_DEFAULT')

        bpy.ops.wm.call_menu_pie(name="ZBBQ_MT_GeometryOptions")

        return {'FINISHED'}


class ZBBQ_UL_Presets(UIList):

    def draw_item(self, context, layout: bpy.types.UILayout, data, item, icon, active_data,
                  active_propname, index):

        from .preferences import ZBBQ_Pref_BevelPreset, ZBBQ_Pref_BevelPresetGroup
        bpg: ZBBQ_Pref_BevelPresetGroup = data

        b_is_active_index = index == bpg.bevelPresetsIndex

        rowMain = layout.row(align=True)

        bp: ZBBQ_Pref_BevelPreset = item

        if len(bpg.bevelPresets) > 6:
            r0 = rowMain.row(align=True)
            r0.alignment = 'LEFT'
            r0.ui_units_x = 1
            s_idx = (str(index + 1) if index < 6 else " ")
            r0.label(text=s_idx)

        r1 = rowMain.row(align=False)
        r1.alignment = 'LEFT'
        r1.scale_x = 0.25
        r1.scale_y = 0.8
        r1.prop(item, "color", text="")

        r2 = rowMain.row(align=True)
        r2.alignment = 'EXPAND'

        # op = r2.operator(
        #     "wm.zen_bbq_replace_radius",
        #     text=f"{bp.radius}",
        #     emboss=False)
        # op.preset_index = bpg.bevelPresetsIndex
        # op.target_radius = target_radius
        # op.units = target_units

        if ZenPolls.version_since_5_0_0:
            if b_is_active_index:
                r2.prop(item, "radius", text="")
            else:
                op = r2.operator("wm.context_set_int", text=f"{item.radius:.02f}", emboss=False)
                op.data_path = "scene.ZBBQ_PresetsIncluded.bevelPresetsIndex"
                op.value = index
        else:
            r2.prop(item, 'radius' if b_is_active_index else 'radius_ui', text="", emboss=b_is_active_index)  # text=f'{item.radius:2g}

        r3 = rowMain.row(align=True)
        r3.alignment = 'RIGHT'

        if ZenPolls.version_since_5_0_0:
            r3.prop(item, "units", text="")
        else:
            r3.prop(item, 'units' if b_is_active_index else 'units_ui', text="", emboss=index == bpg.bevelPresetsIndex)  # text=f'{item.radius:2g}

        rowRight = rowMain.row(align=True)
        rowRight.alignment = 'RIGHT'
        opAssign = rowRight.operator(ZBBQ_OT_SetBevelRadiusToSelection.bl_idname, text="", icon='LAYER_ACTIVE')
        opAssign.radius = bp.radius
        opAssign.units = bp.units

        prefs = ZBBQ_CommonFunc.GetPrefs()
        if prefs.display_statistics:
            r_stat = rowMain.row(align=True)
            r_stat.alignment = 'RIGHT'
            r_stat.enabled = False
            r_stat.prop(bp, "statistics_objects", text='', emboss=False)


class ZBBQ_CyclesPresetPanel(PresetPanel, Panel):
    COMPAT_ENGINES = {'CYCLES'}
    preset_operator = "script.execute_preset"

    @staticmethod
    def post_cb(context: bpy.types.Context, _filepath=""):
        # Modify an arbitrary built-in scene property to force a depsgraph
        # update, because add-on properties don't. (see #62325)
        render = context.scene.render
        render.filter_size = render.filter_size

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()


class ZBBQ_PT_render_presets(ZBBQ_CyclesPresetPanel):
    bl_label = "Render Presets"
    preset_subdir = "zen_bbq/render"
    preset_add_operator = "render.zbbq_cycles_render_preset_add"


class ZBBQ_PT_viewport_sampling_presets(ZBBQ_CyclesPresetPanel):
    bl_label = "Viewport Sampling Presets"
    preset_subdir = "zen_bbq/viewport_sampling"
    preset_add_operator = "render.zbbq_cycles_viewport_sampling_preset_add"


classes = (
    ZBBQ_PT_render_presets,
    ZBBQ_PT_viewport_sampling_presets,

    ZBBQ_PT_Bevels,

    ZBBQ_PT_Bevels_Sub_Quality,

    ZBBQ_PT_Tools,
    ZBBQ_PT_Bake,
    ZBBQ_PT_Preferences,

    ZBBQ_PT_Preferences_Sub_Common,
    ZBBQ_PT_Preferences_Sub_Panels,

    ZBBQ_PT_MaterialShading,
    ZBBQ_PT_ShaderShading,
    ZBBQ_PT_ImageShading,

    ZBBQ_MT_BevelPresets,
    ZBBQ_MT_PresetUtils,

    ZBBQ_MT_GeometryOptions,
    ZBBQ_MT_FolderTemplates,
    ZBBQ_MT_ImageNameTemplates,

    ZBBQ_OT_CallPie_GeometryOptions,

    ZBBQ_UL_Presets,
    ZBBQ_PT_Help,

    ZBBQ_PT_3DV_ComboPanel
)


# === Registration

addonKeymaps = []


def register():

    zen_bbq_parented_panels.clear()

    for cls in classes:
        bpy.utils.register_class(cls)

        if issubclass(cls, bpy.types.Panel):
            s_parent = getattr(cls, "bl_parent_id", "")
            if s_parent:
                zen_bbq_parented_panels.append(cls)


def unregister():

    for cls in classes:
        bpy.utils.unregister_class(cls)
