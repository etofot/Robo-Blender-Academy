# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2026, Valeriy Yatsenko - lightbio@gmail.com


import bpy

from .shader_overrider import BbqShaderOverrider
from ..consts import ZBBQ_Consts
from ..blender_zen_utils import ZenPolls


class BbqPreviewImageOverrider:

    @classmethod
    def add_interpolation_driver(cls, node_image: bpy.types.ShaderNodeTexImage):
        driver_spec = node_image.driver_add("interpolation")
        driver = driver_spec.driver
        driver.type = "SUM"

        var = driver.variables.new()
        var.name = "bake_image_interpolation"
        var.type = "SINGLE_PROP"

        var.targets[0].id_type = "SCENE"
        var.targets[0].id = bpy.context.scene
        var.targets[0].data_path = "zen_bbq.bake_image_interpolation_internal"

    @classmethod
    def build_preview_image_shader(cls, nodeGroup, reset=True):

        from ..commonFunc import ZBBQ_CommonFunc

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        # Node BbqPreviewImageNormalShader
        node_shader_bsdf_preview_tangent_normal = nodeGroup.nodes.new("ShaderNodeBsdfPrincipled")
        node_shader_bsdf_preview_tangent_normal.name = "BbqPreviewImageNormalShader"
        node_shader_bsdf_preview_tangent_normal.show_options = True
        node_shader_bsdf_preview_tangent_normal.distribution = 'MULTI_GGX'
        node_shader_bsdf_preview_tangent_normal.subsurface_method = 'RANDOM_WALK'
        # Base Color
        node_shader_bsdf_preview_tangent_normal.inputs[0].default_value = addon_prefs.image_preview_color
        # Metallic
        node_shader_bsdf_preview_tangent_normal.inputs[1].default_value = 1.0
        # Roughness
        node_shader_bsdf_preview_tangent_normal.inputs[2].default_value = 0.5

        # Node BbqPreviewImageNormalStrength
        node_normal_strength = nodeGroup.nodes.new("ShaderNodeNormalMap")
        node_normal_strength.name = "BbqPreviewImageNormalStrength"
        node_normal_strength.show_options = True

        if ZenPolls.version_since_5_1_0:
            node_normal_strength.convention = bpy.context.scene.zen_bbq.normal_map_convention

            driver_spec = node_normal_strength.driver_add("convention")
            driver = driver_spec.driver
            driver.type = "SUM"

            var = driver.variables.new()
            var.name = "normal_map_convention"
            var.type = "SINGLE_PROP"

            var.targets[0].id_type = "SCENE"
            var.targets[0].id = bpy.context.scene
            var.targets[0].data_path = "zen_bbq.normal_map_convention"

        node_normal_strength.space = 'TANGENT'
        node_normal_strength.uv_map = ""
        # Strength
        node_normal_strength.inputs[0].default_value = 1.0

        # Node BbqPreviewImageNormalImage
        node_image_normal = nodeGroup.nodes.new("ShaderNodeTexImage")
        node_image_normal.name = ZBBQ_Consts.node_tree_preview_image_normal_image_node_name
        node_image_normal.show_options = True
        node_image_normal.extension = 'REPEAT'
        node_image_normal.image_user.frame_current = 0
        node_image_normal.image_user.frame_duration = 100
        node_image_normal.image_user.frame_offset = 0
        node_image_normal.image_user.frame_start = 1
        node_image_normal.image_user.tile = 0
        node_image_normal.image_user.use_auto_refresh = False
        node_image_normal.image_user.use_cyclic = False
        node_image_normal.interpolation = bpy.context.scene.zen_bbq.bake_image_interpolation_internal
        node_image_normal.projection = 'FLAT'
        node_image_normal.projection_blend = 0.0

        cls.add_interpolation_driver(node_image_normal)

        # Vector
        node_image_normal.inputs[0].default_value = (0.0, 0.0, 0.0)

        # Node BbqPreviewImageOtherImage
        node_image_other = nodeGroup.nodes.new("ShaderNodeTexImage")
        node_image_other.name = ZBBQ_Consts.node_tree_preview_image_other_image_node_name
        node_image_other.show_options = True
        node_image_other.show_texture = True
        node_image_other.extension = 'REPEAT'
        node_image_other.image_user.frame_current = 0
        node_image_other.image_user.frame_duration = 100
        node_image_other.image_user.frame_offset = 0
        node_image_other.image_user.frame_start = 1
        node_image_other.image_user.tile = 0
        node_image_other.image_user.use_auto_refresh = False
        node_image_other.image_user.use_cyclic = False
        node_image_other.interpolation = bpy.context.scene.zen_bbq.bake_image_interpolation_internal
        node_image_other.projection = 'FLAT'
        node_image_other.projection_blend = 0.0

        cls.add_interpolation_driver(node_image_other)

        # Vector
        node_image_other.inputs[0].default_value = (0.0, 0.0, 0.0)

        # Node BbqBakeSwitch
        ng_bbq_bakeswitch = nodeGroup.nodes.new("ShaderNodeGroup")
        ng_bbq_bakeswitch.name = ZBBQ_Consts.node_tree_service_bake_switch
        ng_bbq_bakeswitch.show_options = True
        ng_bbq_bakeswitch.node_tree = BbqShaderOverrider.build_types_switch_ng(reset)

        # Node BbqPreviewImagePreviewMapIndexAttributeGetter
        node_map_index_attribute = nodeGroup.nodes.new("ShaderNodeAttribute")
        node_map_index_attribute.name = "BbqPreviewImagePreviewMapIndexAttributeGetter"
        node_map_index_attribute.show_options = True
        node_map_index_attribute.attribute_name = "zen_bbq.preview_map_index"
        node_map_index_attribute.attribute_type = 'VIEW_LAYER'

        ng_bbq_index_switch = nodeGroup.nodes.new("ShaderNodeGroup")
        ng_bbq_index_switch.name = ZBBQ_Consts.node_tree_service_index_switch
        ng_bbq_index_switch.node_tree = BbqShaderOverrider.build_index_switch_ng(reset)
        ng_bbq_index_switch.inputs[1].default_value = 0.0

        # Node Is Normal Baked
        node_is_normal_baked = nodeGroup.nodes.new("ShaderNodeMix")
        node_is_normal_baked.name = "Is Normal Baked"
        node_is_normal_baked.show_options = True
        node_is_normal_baked.blend_type = 'MIX'
        node_is_normal_baked.clamp_factor = True
        node_is_normal_baked.clamp_result = False
        node_is_normal_baked.data_type = 'RGBA'
        node_is_normal_baked.factor_mode = 'UNIFORM'
        # Factor_Float
        node_is_normal_baked.inputs[0].default_value = 0.0

        # Node Fallback Checker Texture
        fallback_checker_texture = nodeGroup.nodes.new("ShaderNodeTexChecker")
        fallback_checker_texture.name = "Fallback Checker Texture"
        fallback_checker_texture.show_options = True
        # Color1
        fallback_checker_texture.inputs[1].default_value = (0.8, 0.8, 0.8, 1.0)
        # Color2
        fallback_checker_texture.inputs[2].default_value = (0.2, 0.2, 0.2, 1.0)
        # Scale
        fallback_checker_texture.inputs[3].default_value = 10.0

        # Node Is Other Baked
        node_is_other_baked = nodeGroup.nodes.new("ShaderNodeMix")
        node_is_other_baked.name = "Is Other Baked"
        node_is_other_baked.show_options = True
        node_is_other_baked.blend_type = 'MIX'
        node_is_other_baked.clamp_factor = True
        node_is_other_baked.clamp_result = False
        node_is_other_baked.data_type = 'RGBA'
        node_is_other_baked.factor_mode = 'UNIFORM'
        # Factor_Float
        node_is_other_baked.inputs[0].default_value = 0.0

        # Node Texture Coordinate
        texture_coordinate = nodeGroup.nodes.new("ShaderNodeTexCoord")
        texture_coordinate.name = "Texture Coordinate"
        texture_coordinate.show_options = True
        texture_coordinate.from_instancer = False

        # Set locations
        nodeGroup.nodes["Group Input"].location = (-1304.0, -11.0)
        nodeGroup.nodes["Group Output"].location = (500.0, 0.0)
        nodeGroup.nodes["BbqPreviewImageNormalShader"].location = (-100.0, 320.0)
        nodeGroup.nodes["BbqPreviewImageNormalStrength"].location = (-320.0, 320.0)
        node_image_normal.location = (-875.0, 5.0)
        node_image_other.location = (-455.0, -395.0)
        ng_bbq_bakeswitch.location = (280.0, 120.0)
        node_map_index_attribute.location = (-200.0, 740.0)
        ng_bbq_index_switch.location = (20.0, 740.0)
        nodeGroup.nodes["Is Normal Baked"].location = (-568.0, 319.0)
        nodeGroup.nodes["Fallback Checker Texture"].location = (-828.0, 316.0)
        nodeGroup.nodes["Is Other Baked"].location = (-109.0, -141.0)
        nodeGroup.nodes["Texture Coordinate"].location = (-1033.0, 320.0)

        # Initialize zenbbq_previewnormalimage_for_216_1 links
        nodeGroup.links.new(
            ng_bbq_bakeswitch.outputs[0],
            nodeGroup.nodes["Group Output"].inputs[0]
        )
        # nodeGroup.links.new(
        #     node_image_normal.outputs[0],
        #     nodeGroup.nodes["BbqPreviewImageNormalStrength"].inputs[1]
        # )
        nodeGroup.links.new(
            nodeGroup.nodes["BbqPreviewImageNormalStrength"].outputs[0],
            nodeGroup.nodes["BbqPreviewImageNormalShader"].inputs["Normal"]
        )
        nodeGroup.links.new(
            node_is_other_baked.outputs["Result"],
            ng_bbq_bakeswitch.inputs[1]
        )
        # bbqpreviewimageotherimage.Color -> bbqbakeswitch.AmbientOcclusion
        nodeGroup.links.new(
            node_is_other_baked.outputs["Result"],
            ng_bbq_bakeswitch.inputs[2]
        )
        nodeGroup.links.new(
            node_is_other_baked.outputs["Result"],
            ng_bbq_bakeswitch.inputs[3]
        )
        nodeGroup.links.new(
            node_is_other_baked.outputs["Result"],
            ng_bbq_bakeswitch.inputs[4]
        )
        nodeGroup.links.new(
            node_is_other_baked.outputs["Result"],
            ng_bbq_bakeswitch.inputs[5]
        )
        nodeGroup.links.new(
            node_is_other_baked.outputs["Result"],
            ng_bbq_bakeswitch.inputs[6]
        )
        nodeGroup.links.new(
            node_is_other_baked.outputs["Result"],
            ng_bbq_bakeswitch.inputs[7]
        )
        nodeGroup.links.new(
            node_is_other_baked.outputs["Result"],
            ng_bbq_bakeswitch.inputs[8]
        )
        nodeGroup.links.new(
            node_is_other_baked.outputs["Result"],
            ng_bbq_bakeswitch.inputs[9]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["BbqPreviewImageNormalShader"].outputs[0],
            ng_bbq_bakeswitch.inputs[10]
        )
        nodeGroup.links.new(
            node_map_index_attribute.outputs[2],
            ng_bbq_index_switch.inputs[0]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Fallback Checker Texture"].outputs[0],
            nodeGroup.nodes["Is Other Baked"].inputs[6]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["BbqPreviewImageOtherImage"].outputs[0],
            nodeGroup.nodes["Is Other Baked"].inputs[7]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Fallback Checker Texture"].outputs[0],
            nodeGroup.nodes["Is Normal Baked"].inputs[6]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Texture Coordinate"].outputs[0],
            nodeGroup.nodes["Fallback Checker Texture"].inputs[0]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["BbqPreviewImageNormalImage"].outputs[0],
            nodeGroup.nodes["Is Normal Baked"].inputs[7]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Is Normal Baked"].outputs[2],
            nodeGroup.nodes["BbqPreviewImageNormalStrength"].inputs[1]
        )

        nodeGroup.links.new(ng_bbq_index_switch.outputs[0], ng_bbq_bakeswitch.inputs["Index"])

        return nodeGroup
