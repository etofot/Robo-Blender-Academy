# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2026, Valeriy Yatsenko - lightbio@gmail.com


import bpy
import typing

from ..consts import ZBBQ_Consts


class BbqShaderOverrider:

    @staticmethod
    def build_material_id_node_with_drivers(nodeGroup, target_material):
        old_node = nodeGroup.nodes.get("VP_Color_Link")
        if old_node:
            nodeGroup.nodes.remove(old_node)

        node = nodeGroup.nodes.new(type="ShaderNodeCombineColor")
        node.name = "VP_Color_Link"
        node.label = "Viewport Color Link"
        node.mode = 'RGB'
        node.location = (-400, 300)

        for i in range(3):
            driver_spec = node.inputs[i].driver_add("default_value")
            driver = driver_spec.driver

            driver.type = 'SCRIPTED'
            driver.expression = f"var[{i}]"
            driver.use_self = False

            var = driver.variables.new()
            var.name = "var"
            var.type = 'SINGLE_PROP'

            target = var.targets[0]
            target.id_type = 'MATERIAL'
            target.id = target_material
            target.data_path = "diffuse_color"

        return node

    # MARK: BSDF
    @staticmethod
    def compound_bsdf_overrider_node(nodeGroup):
        from ..commonFunc import ZBBQ_CommonFunc

        bsdf = nodeGroup.nodes.new("ShaderNodeBsdfPrincipled")
        bsdf.name = "BbqPreviewTangentNormals"
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        base_color = addon_prefs.shader_preview_color

        bsdf.show_options = True
        bsdf.distribution = 'MULTI_GGX'
        bsdf.subsurface_method = 'RANDOM_WALK'
        # Base Color
        bsdf.inputs['Base Color'].default_value = base_color
        # Metallic
        bsdf.inputs['Metallic'].default_value = 1.0
        bsdf.inputs['Roughness'].default_value = 0.5
        bsdf.inputs['IOR'].default_value = 1.5
        bsdf.inputs['Alpha'].default_value = 1.0

        bsdf.inputs['Subsurface Weight'].default_value = 0.0
        bsdf.inputs['Subsurface Radius'].default_value = (1.0, 0.2, 0.1)
        bsdf.inputs['Subsurface Scale'].default_value = 0.05

        bsdf.inputs['Specular IOR Level'].default_value = 0.5
        bsdf.inputs['Specular Tint'].default_value = (1.0, 1.0, 1.0, 1.0)

        bsdf.inputs['Anisotropic'].default_value = 0.0
        bsdf.inputs['Anisotropic Rotation'].default_value = 0.0
        bsdf.inputs['Tangent'].default_value = (0.0, 0.0, 0.0)

        bsdf.inputs['Transmission Weight'].default_value = 0.0

        bsdf.inputs['Coat Weight'].default_value = 0.0
        bsdf.inputs['Coat Roughness'].default_value = 0.03
        bsdf.inputs['Coat IOR'].default_value = 1.5
        bsdf.inputs['Coat Tint'].default_value = (1.0, 1.0, 1.0, 1.0)
        bsdf.inputs['Coat Normal'].default_value = (0.0, 0.0, 0.0)

        bsdf.inputs['Sheen Weight'].default_value = 0.0
        bsdf.inputs['Sheen Roughness'].default_value = 0.5
        bsdf.inputs['Sheen Tint'].default_value = (1.0, 1.0, 1.0, 1.0)

        bsdf.inputs['Emission Color'].default_value = (1.0, 1.0, 1.0, 1.0)
        bsdf.inputs['Emission Strength'].default_value = 0.0

        return bsdf

    # MARK: Service Normal Mixer Group
    @staticmethod
    def build_service_normals_mixer_ng(is_user_mixer=False, reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc
        p_group_name = ZBBQ_Consts.NORMAL_NODE_MIXER_NAME if is_user_mixer else ZBBQ_Consts.node_tree_service_normal_mixer_name
        nodeGroup = bpy.data.node_groups.get(p_group_name)

        group_input = None
        group_output = None

        if nodeGroup:
            if not reset:
                return nodeGroup

            for node in list(nodeGroup.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    nodeGroup.nodes.remove(node)

            nodeGroup.links.clear()

        else:
            nodeGroup = bpy.data.node_groups.new(type='ShaderNodeTree', name=p_group_name)

        nodeGroup.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(p_group_name)

        if group_input is None:
            group_input = nodeGroup.nodes.new("NodeGroupInput")

            # Socket Normal
            normal_socket = nodeGroup.interface.new_socket(name="Normal", in_out='INPUT', socket_type='NodeSocketVector')
            normal_socket.default_value = (0.0, 0.0, 0.0)
            normal_socket.min_value = -3.4028234663852886e+38
            normal_socket.max_value = 3.4028234663852886e+38
            normal_socket.subtype = 'NONE'
            normal_socket.attribute_domain = 'POINT'

            # Socket Factor
            factor_socket = nodeGroup.interface.new_socket(name="Factor", in_out='INPUT', socket_type='NodeSocketFloat')
            factor_socket.default_value = 0.0
            factor_socket.min_value = 0.0
            factor_socket.max_value = 1.0
            factor_socket.subtype = 'FACTOR'
            factor_socket.attribute_domain = 'POINT'
            factor_socket.description = "Controls the intensity of the noise texture overlay on the procedural bevel.0.0 means crisp, smooth edges, while 1.0 applies maximum noise roughnesswithout losing the underlying bevel geometry"
        group_input.name = "Group Input"
        group_input.show_options = True

        if group_output is None:
            group_output = nodeGroup.nodes.new("NodeGroupOutput")

            # Socket Bevels
            bevels_socket = nodeGroup.interface.new_socket(name="Bevels", in_out='OUTPUT', socket_type='NodeSocketVector')
            bevels_socket.default_value = (0.0, 0.0, 0.0)
            bevels_socket.min_value = -3.4028234663852886e+38
            bevels_socket.max_value = 3.4028234663852886e+38
            bevels_socket.subtype = 'NONE'
            bevels_socket.attribute_domain = 'POINT'

            # Socket Mixed
            mixed_socket = nodeGroup.interface.new_socket(name="Mixed", in_out='OUTPUT', socket_type='NodeSocketVector')
            mixed_socket.default_value = (0.0, 0.0, 0.0)
            mixed_socket.min_value = -3.4028234663852886e+38
            mixed_socket.max_value = 3.4028234663852886e+38
            mixed_socket.subtype = 'NONE'
            mixed_socket.attribute_domain = 'POINT'

            # Socket Mask
            mask_socket = nodeGroup.interface.new_socket(name="Mask", in_out='OUTPUT', socket_type='NodeSocketFloat')
            mask_socket.default_value = 0.0
            mask_socket.min_value = -3.4028234663852886e+38
            mask_socket.max_value = 3.4028234663852886e+38
            mask_socket.subtype = 'NONE'
            mask_socket.attribute_domain = 'POINT'

        group_output.name = "Group Output"
        group_output.show_options = True
        group_output.is_active_output = True

        # Initialize zenbbq_normalsmixer_1 nodes

        # Node Attribute
        attribute = nodeGroup.nodes.new("ShaderNodeAttribute")
        attribute.name = "Attribute User Defined"
        attribute.show_options = True
        attribute.attribute_name = "ZenBBQ_UserDefined"
        attribute.attribute_type = 'GEOMETRY'

        # Node Attribute.001
        attribute_001 = nodeGroup.nodes.new("ShaderNodeAttribute")
        attribute_001.name = "Attribute Boolean Bevel"
        attribute_001.show_options = True
        attribute_001.attribute_name = "ZenBBQ_LiveBooleanRadius"
        attribute_001.attribute_type = 'OBJECT'

        # Node Attribute.002
        attribute_002 = nodeGroup.nodes.new("ShaderNodeAttribute")
        attribute_002.name = "Attribute Bevel Value Zen BBQ"
        attribute_002.show_options = True
        attribute_002.attribute_name = "ZenBBQ"
        attribute_002.attribute_type = 'GEOMETRY'

        # Node Geometry
        geometry = nodeGroup.nodes.new("ShaderNodeNewGeometry")
        geometry.name = "Geometry"
        geometry.show_options = True
        geometry.outputs[0].hide = True
        geometry.outputs[2].hide = True
        geometry.outputs[3].hide = True
        geometry.outputs[4].hide = True
        geometry.outputs[5].hide = True
        geometry.outputs[6].hide = True
        geometry.outputs[7].hide = True
        geometry.outputs[8].hide = True

        # Node BevelClear
        bevelclear = nodeGroup.nodes.new("ShaderNodeBevel")
        bevelclear.name = "BevelClear"
        bevelclear.show_options = True
        bevelclear.samples = 16

        # Node Mix
        mix = nodeGroup.nodes.new("ShaderNodeMix")
        mix.name = "Mix"
        mix.show_options = True
        mix.blend_type = 'MIX'
        mix.clamp_factor = True
        mix.clamp_result = False
        mix.data_type = 'FLOAT'
        mix.factor_mode = 'UNIFORM'

        # Node Vector Math
        vector_math = nodeGroup.nodes.new("ShaderNodeVectorMath")
        vector_math.name = "Vector Math"
        vector_math.show_options = True
        vector_math.operation = 'DOT_PRODUCT'

        # Node Map Range
        map_range = nodeGroup.nodes.new("ShaderNodeMapRange")
        map_range.name = "Map Range"
        map_range.show_options = True
        map_range.clamp = True
        map_range.data_type = 'FLOAT'
        map_range.interpolation_type = 'LINEAR'
        # From Min
        map_range.inputs[1].default_value = 0.9900000095367432
        # From Max
        map_range.inputs[2].default_value = 1.0
        # To Min
        map_range.inputs[3].default_value = 1.0
        # To Max
        map_range.inputs[4].default_value = 0.0

        if is_user_mixer:
            # Node Math
            math = nodeGroup.nodes.new("ShaderNodeMath")
            math.name = "Math"
            math.show_options = True
            math.operation = 'MULTIPLY'
            math.use_clamp = False

            # Node BevelMixed
            bevelmixed = nodeGroup.nodes.new("ShaderNodeBevel")
            bevelmixed.name = "BevelMixed"
            bevelmixed.show_options = True
            bevelmixed.samples = 16

            # Node Mix.001
            mix_001 = nodeGroup.nodes.new("ShaderNodeMix")
            mix_001.name = "Mix.001"
            mix_001.show_options = True
            mix_001.blend_type = 'MIX'
            mix_001.clamp_factor = True
            mix_001.clamp_result = False
            mix_001.data_type = 'VECTOR'
            mix_001.factor_mode = 'UNIFORM'

            # Node Vector Math.002
            vector_math_002 = nodeGroup.nodes.new("ShaderNodeVectorMath")
            vector_math_002.name = "Vector Math.002"
            vector_math_002.show_options = True
            vector_math_002.operation = 'DOT_PRODUCT'

            # Node Math.001
            math_001 = nodeGroup.nodes.new("ShaderNodeMath")
            math_001.name = "Math.001"
            math_001.show_options = True
            math_001.operation = 'LESS_THAN'
            math_001.use_clamp = False
            # Value_001
            math_001.inputs[1].default_value = 0.009999999776482582

            # Node Mix.002
            mix_002 = nodeGroup.nodes.new("ShaderNodeMix")
            mix_002.name = "Mix.002"
            mix_002.show_options = True
            mix_002.blend_type = 'MIX'
            mix_002.clamp_factor = True
            mix_002.clamp_result = False
            mix_002.data_type = 'VECTOR'
            mix_002.factor_mode = 'UNIFORM'

        if is_user_mixer:
            # Set locations
            nodeGroup.nodes["BevelMixed"].location = (313.07867431640625, -331.1278991699219)
            nodeGroup.nodes["Mix.001"].location = (1069.341552734375, 116.61981201171875)
            nodeGroup.nodes["Vector Math.002"].location = (-266.0964050292969, -477.84423828125)
            nodeGroup.nodes["Math.001"].location = (-90.17529296875, -472.64556884765625)
            nodeGroup.nodes["Mix.002"].location = (87.8153305053711, -470.55419921875)
            nodeGroup.nodes["Math"].location = (882.5451049804688, 114.16705322265625)

        nodeGroup.nodes["Vector Math"].location = (510.08209228515625, 112.5491943359375)
        nodeGroup.nodes["Map Range"].location = (694.4778442382812, 112.02532958984375)
        nodeGroup.nodes["Group Input"].location = (-500.0, -350.0)
        nodeGroup.nodes["Group Output"].location = (1600.0, 116.0)
        nodeGroup.nodes["Attribute User Defined"].location = (-500.0, 360.0)
        nodeGroup.nodes["Attribute Boolean Bevel"].location = (-500.0, 140.0)
        nodeGroup.nodes["Attribute Bevel Value Zen BBQ"].location = (-500.0, -100.0)
        nodeGroup.nodes["Geometry"].location = (-199.6045379638672, 46.195098876953125)
        nodeGroup.nodes["BevelClear"].location = (291.7015380859375, 299.735107421875)
        nodeGroup.nodes["Mix"].location = (-200.0, 250.0)

        # Initialize zenbbq_normalsmixer_1 links

        nodeGroup.links.new(
            nodeGroup.nodes["Mix"].outputs[0],
            nodeGroup.nodes["BevelClear"].inputs[0]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["BevelClear"].outputs[0],
            nodeGroup.nodes["Group Output"].inputs[0]
        )

        nodeGroup.links.new(
            nodeGroup.nodes["Geometry"].outputs[1],
            nodeGroup.nodes["BevelClear"].inputs[1]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Attribute User Defined"].outputs[2],
            nodeGroup.nodes["Mix"].inputs[0]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Attribute Bevel Value Zen BBQ"].outputs[2],
            nodeGroup.nodes["Mix"].inputs[3]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Attribute Boolean Bevel"].outputs[2],
            nodeGroup.nodes["Mix"].inputs[2]
        )

        # vector_math.Value -> map_range.Value
        nodeGroup.links.new(
            nodeGroup.nodes["Vector Math"].outputs[1],
            nodeGroup.nodes["Map Range"].inputs[0]
        )

        if is_user_mixer:
            # math.Value -> mix_001.Factor
            nodeGroup.links.new(
                nodeGroup.nodes["Math"].outputs[0],
                nodeGroup.nodes["Mix.001"].inputs[0]
            )
            # map_range.Result -> ver__1_1.Mask
            nodeGroup.links.new(
                nodeGroup.nodes["Map Range"].outputs[0],
                nodeGroup.nodes["Group Output"].inputs[2]
            )

            # map_range.Result -> math.Value
            nodeGroup.links.new(
                nodeGroup.nodes["Map Range"].outputs[0],
                nodeGroup.nodes["Math"].inputs[0]
            )
        else:
            # map_range.Result -> math.Value
            nodeGroup.links.new(
                nodeGroup.nodes["Map Range"].outputs[0],
                nodeGroup.nodes["Group Output"].inputs["Mask"]
            )

        # bevelclear.Normal -> vector_math.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["BevelClear"].outputs[0],
            nodeGroup.nodes["Vector Math"].inputs[0]
        )

        # geometry.Normal -> vector_math.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["Geometry"].outputs[1],
            nodeGroup.nodes["Vector Math"].inputs[1]
        )

        if is_user_mixer:
            # mix.Result -> bevelmixed.Radius
            nodeGroup.links.new(
                nodeGroup.nodes["Mix"].outputs[0],
                nodeGroup.nodes["BevelMixed"].inputs[0]
            )
            # bevelmixed.Normal -> mix_001.A
            nodeGroup.links.new(
                nodeGroup.nodes["BevelMixed"].outputs[0],
                nodeGroup.nodes["Mix.001"].inputs[4]
            )
            # mix_002.Result -> bevelmixed.Normal
            nodeGroup.links.new(
                nodeGroup.nodes["Mix.002"].outputs[1],
                nodeGroup.nodes["BevelMixed"].inputs[1]
            )
            # bevelclear.Normal -> mix_001.B
            nodeGroup.links.new(
                nodeGroup.nodes["BevelClear"].outputs[0],
                nodeGroup.nodes["Mix.001"].inputs[5]
            )
            # group_input.Factor -> math.Value
            nodeGroup.links.new(
                nodeGroup.nodes["Group Input"].outputs[1],
                nodeGroup.nodes["Math"].inputs[1]
            )
            # mix_001.Result -> ver__1_1.Mixed
            nodeGroup.links.new(
                nodeGroup.nodes["Mix.001"].outputs[1],
                nodeGroup.nodes["Group Output"].inputs[1]
            )
            # vector_math_002.Value -> math_001.Value
            nodeGroup.links.new(
                nodeGroup.nodes["Vector Math.002"].outputs[1],
                nodeGroup.nodes["Math.001"].inputs[0]
            )
            # math_001.Value -> mix_002.Factor
            nodeGroup.links.new(
                nodeGroup.nodes["Math.001"].outputs[0],
                nodeGroup.nodes["Mix.002"].inputs[0]
            )
            # geometry.Normal -> mix_002.B
            nodeGroup.links.new(
                nodeGroup.nodes["Geometry"].outputs[1],
                nodeGroup.nodes["Mix.002"].inputs[5]
            )
            # group_input.Normal -> vector_math_002.Vector
            nodeGroup.links.new(
                nodeGroup.nodes["Group Input"].outputs[0],
                nodeGroup.nodes["Vector Math.002"].inputs[0]
            )
            # group_input.Normal -> vector_math_002.Vector
            nodeGroup.links.new(
                nodeGroup.nodes["Group Input"].outputs[0],
                nodeGroup.nodes["Vector Math.002"].inputs[1]
            )
            # group_input.Normal -> mix_002.A
            nodeGroup.links.new(
                nodeGroup.nodes["Group Input"].outputs[0],
                nodeGroup.nodes["Mix.002"].inputs[4]
            )

        return nodeGroup

    # MARK: Curvature Group
    @staticmethod
    def build_curvature_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        bbqbakecurvature_1 = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_curvature)
        group_input = None
        group_output = None

        if bbqbakecurvature_1:
            if not reset:
                return bbqbakecurvature_1

            for node in list(bbqbakecurvature_1.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    bbqbakecurvature_1.nodes.remove(node)

            bbqbakecurvature_1.links.clear()

        else:
            bbqbakecurvature_1 = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_curvature)

        bbqbakecurvature_1.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_curvature)

        if group_input is None:
            group_input = bbqbakecurvature_1.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket B
            b_socket = bbqbakecurvature_1.interface.new_socket(name="B", in_out='INPUT', socket_type='NodeSocketColor')
            b_socket.default_value = (0.5, 0.5, 0.5, 1.0)
            b_socket.attribute_domain = 'POINT'
            b_socket.description = "Value of the second color input"

            # Socket B
            b_socket_1 = bbqbakecurvature_1.interface.new_socket(name="B", in_out='INPUT', socket_type='NodeSocketColor')
            b_socket_1.default_value = (0.5, 0.5, 0.5, 1.0)
            b_socket_1.attribute_domain = 'POINT'
            b_socket_1.description = "Value of the second color input"

        if group_output is None:
            group_output = bbqbakecurvature_1.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Result
            result_socket = bbqbakecurvature_1.interface.new_socket(name="Result", in_out='OUTPUT', socket_type='NodeSocketColor')
            result_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            result_socket.attribute_domain = 'POINT'

        # Initialize bbqbakecurvature_1 nodes

        # Node MixBaseCurvature
        mixbasecurvature = bbqbakecurvature_1.nodes.new("ShaderNodeMix")
        mixbasecurvature.label = "MixBaseCurvature"
        mixbasecurvature.name = "MixBaseCurvature"
        mixbasecurvature.show_options = True
        mixbasecurvature.blend_type = 'ADD'
        mixbasecurvature.clamp_factor = True
        mixbasecurvature.clamp_result = False
        mixbasecurvature.data_type = 'RGBA'
        mixbasecurvature.factor_mode = 'UNIFORM'
        # Factor_Float
        mixbasecurvature.inputs[0].default_value = 1.0
        # A_Color
        mixbasecurvature.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)

        # Node OutCurvature
        outcurvature = bbqbakecurvature_1.nodes.new("ShaderNodeMix")
        outcurvature.label = "OutCurvature"
        outcurvature.name = "OutCurvature"
        outcurvature.show_options = True
        outcurvature.blend_type = 'MULTIPLY'
        outcurvature.clamp_factor = True
        outcurvature.clamp_result = True
        outcurvature.data_type = 'RGBA'
        outcurvature.factor_mode = 'UNIFORM'
        # Factor_Float
        outcurvature.inputs[0].default_value = 1.0

        # Node Frame.002
        frame_002 = bbqbakecurvature_1.nodes.new("NodeFrame")
        frame_002.label = "Curvature"
        frame_002.name = "Frame.002"
        frame_002.show_options = True
        frame_002.label_size = 20
        frame_002.shrink = True

        # Set parents
        bbqbakecurvature_1.nodes["MixBaseCurvature"].parent = bbqbakecurvature_1.nodes["Frame.002"]
        bbqbakecurvature_1.nodes["OutCurvature"].parent = bbqbakecurvature_1.nodes["Frame.002"]

        # Set locations
        bbqbakecurvature_1.nodes["MixBaseCurvature"].location = (30.41668701171875, -36.470149993896484)
        bbqbakecurvature_1.nodes["OutCurvature"].location = (257.82562255859375, -197.42807006835938)
        bbqbakecurvature_1.nodes["Frame.002"].location = (-129.0, 99.0)
        bbqbakecurvature_1.nodes["Group Output"].location = (349.17437744140625, 0.0)
        bbqbakecurvature_1.nodes["Group Input"].location = (-328.82562255859375, 0.0)

        # Initialize bbqbakecurvature_1 links

        # mixbasecurvature.Result -> outcurvature.A
        bbqbakecurvature_1.links.new(
            bbqbakecurvature_1.nodes["MixBaseCurvature"].outputs[2],
            bbqbakecurvature_1.nodes["OutCurvature"].inputs[6]
        )
        # group_input.B -> outcurvature.B
        bbqbakecurvature_1.links.new(
            bbqbakecurvature_1.nodes["Group Input"].outputs[1],
            bbqbakecurvature_1.nodes["OutCurvature"].inputs[7]
        )
        # group_input.B -> mixbasecurvature.B
        bbqbakecurvature_1.links.new(
            bbqbakecurvature_1.nodes["Group Input"].outputs[0],
            bbqbakecurvature_1.nodes["MixBaseCurvature"].inputs[7]
        )
        # outcurvature.Result -> group_output.Result
        bbqbakecurvature_1.links.new(
            bbqbakecurvature_1.nodes["OutCurvature"].outputs[2],
            bbqbakecurvature_1.nodes["Group Output"].inputs[0]
        )

        return bbqbakecurvature_1

    # MARK: Convexity Group
    @staticmethod
    def build_convexity_bevels_mask_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        bbqbakeconvexitybevelsmask_1 = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_convexity)
        group_input = None
        group_output = None

        if bbqbakeconvexitybevelsmask_1:
            if not reset:
                return bbqbakeconvexitybevelsmask_1

            for node in list(bbqbakeconvexitybevelsmask_1.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    bbqbakeconvexitybevelsmask_1.nodes.remove(node)

            bbqbakeconvexitybevelsmask_1.links.clear()

        else:
            bbqbakeconvexitybevelsmask_1 = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_convexity)

        bbqbakeconvexitybevelsmask_1.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_convexity)

        if group_input is None:
            group_input = bbqbakeconvexitybevelsmask_1.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket Factor
            factor_socket = bbqbakeconvexitybevelsmask_1.interface.new_socket(name="Factor", in_out='INPUT', socket_type='NodeSocketFloat')
            factor_socket.default_value = 0.5
            factor_socket.min_value = 0.0
            factor_socket.max_value = 1.0
            factor_socket.subtype = 'FACTOR'
            factor_socket.attribute_domain = 'POINT'
            factor_socket.description = "The value used to map onto the color gradient. 0.0 results in the leftmost color, while 1.0 results in the rightmost"

            # Socket Factor
            factor_socket_1 = bbqbakeconvexitybevelsmask_1.interface.new_socket(name="Factor", in_out='INPUT', socket_type='NodeSocketFloat')
            factor_socket_1.default_value = 0.5
            factor_socket_1.min_value = 0.0
            factor_socket_1.max_value = 1.0
            factor_socket_1.subtype = 'FACTOR'
            factor_socket_1.attribute_domain = 'POINT'
            factor_socket_1.description = "The value used to map onto the color gradient. 0.0 results in the leftmost color, while 1.0 results in the rightmost"

        if group_output is None:
            group_output = bbqbakeconvexitybevelsmask_1.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Result
            result_socket = bbqbakeconvexitybevelsmask_1.interface.new_socket(name="Result", in_out='OUTPUT', socket_type='NodeSocketColor')
            result_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            result_socket.attribute_domain = 'POINT'

            # Socket Result
            result_socket_1 = bbqbakeconvexitybevelsmask_1.interface.new_socket(name="Result", in_out='OUTPUT', socket_type='NodeSocketColor')
            result_socket_1.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            result_socket_1.attribute_domain = 'POINT'

        # Initialize bbqbakeconvexitybevelsmask_1 nodes

        # Node Frame.001
        frame_001 = bbqbakeconvexitybevelsmask_1.nodes.new("NodeFrame")
        frame_001.label = "Convexity Bevels Mask"
        frame_001.name = "Frame.001"
        frame_001.show_options = True
        frame_001.label_size = 20
        frame_001.shrink = True

        # Node Color Ramp
        color_ramp = bbqbakeconvexitybevelsmask_1.nodes.new("ShaderNodeValToRGB")
        color_ramp.name = "Color Ramp"
        color_ramp.show_options = True
        color_ramp.color_ramp.color_mode = 'RGB'
        color_ramp.color_ramp.hue_interpolation = 'NEAR'
        color_ramp.color_ramp.interpolation = 'LINEAR'

        # Initialize color ramp elements
        color_ramp.color_ramp.elements.remove(color_ramp.color_ramp.elements[0])
        color_ramp_cre_0 = color_ramp.color_ramp.elements[0]
        color_ramp_cre_0.position = 0.8818180561065674
        color_ramp_cre_0.alpha = 1.0
        color_ramp_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        color_ramp_cre_1 = color_ramp.color_ramp.elements.new(0.968181848526001)
        color_ramp_cre_1.alpha = 1.0
        color_ramp_cre_1.color = (1.0, 1.0, 1.0, 1.0)

        # Node Invert Color
        invert_color = bbqbakeconvexitybevelsmask_1.nodes.new("ShaderNodeInvert")
        invert_color.name = "Invert Color"
        invert_color.show_options = True
        # Fac
        invert_color.inputs[0].default_value = 1.0

        # Node OutConvexity
        outconvexity = bbqbakeconvexitybevelsmask_1.nodes.new("ShaderNodeMix")
        outconvexity.label = "OutConvexity"
        outconvexity.name = "OutConvexity"
        outconvexity.show_options = True
        outconvexity.blend_type = 'SUBTRACT'
        outconvexity.clamp_factor = True
        outconvexity.clamp_result = True
        outconvexity.data_type = 'RGBA'
        outconvexity.factor_mode = 'UNIFORM'
        # Factor_Float
        outconvexity.inputs[0].default_value = 1.0

        # Node Color Ramp.007
        color_ramp_007 = bbqbakeconvexitybevelsmask_1.nodes.new("ShaderNodeValToRGB")
        color_ramp_007.name = "Color Ramp.007"
        color_ramp_007.show_options = True
        color_ramp_007.color_ramp.color_mode = 'RGB'
        color_ramp_007.color_ramp.hue_interpolation = 'NEAR'
        color_ramp_007.color_ramp.interpolation = 'LINEAR'

        # Initialize color ramp elements
        color_ramp_007.color_ramp.elements.remove(color_ramp_007.color_ramp.elements[0])
        color_ramp_007_cre_0 = color_ramp_007.color_ramp.elements[0]
        color_ramp_007_cre_0.position = 0.9272725582122803
        color_ramp_007_cre_0.alpha = 1.0
        color_ramp_007_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        color_ramp_007_cre_1 = color_ramp_007.color_ramp.elements.new(1.0)
        color_ramp_007_cre_1.alpha = 1.0
        color_ramp_007_cre_1.color = (1.0, 1.0, 1.0, 1.0)

        # Set parents
        bbqbakeconvexitybevelsmask_1.nodes["Color Ramp"].parent = bbqbakeconvexitybevelsmask_1.nodes["Frame.001"]
        bbqbakeconvexitybevelsmask_1.nodes["Invert Color"].parent = bbqbakeconvexitybevelsmask_1.nodes["Frame.001"]
        bbqbakeconvexitybevelsmask_1.nodes["OutConvexity"].parent = bbqbakeconvexitybevelsmask_1.nodes["Frame.001"]
        bbqbakeconvexitybevelsmask_1.nodes["Color Ramp.007"].parent = bbqbakeconvexitybevelsmask_1.nodes["Frame.001"]

        # Set locations
        bbqbakeconvexitybevelsmask_1.nodes["Frame.001"].location = (-383.0, 150.0)
        bbqbakeconvexitybevelsmask_1.nodes["Color Ramp"].location = (30.42694091796875, -289.7950744628906)
        bbqbakeconvexitybevelsmask_1.nodes["Invert Color"].location = (401.16082763671875, -300.2409362792969)
        bbqbakeconvexitybevelsmask_1.nodes["OutConvexity"].location = (765.692138671875, -43.9608154296875)
        bbqbakeconvexitybevelsmask_1.nodes["Color Ramp.007"].location = (30.92242431640625, -36.14237976074219)
        bbqbakeconvexitybevelsmask_1.nodes["Group Output"].location = (602.307861328125, 0.0)
        bbqbakeconvexitybevelsmask_1.nodes["Group Input"].location = (-582.692138671875, 0.0)

        # Initialize bbqbakeconvexitybevelsmask_1 links

        # color_ramp.Color -> invert_color.Color
        bbqbakeconvexitybevelsmask_1.links.new(
            bbqbakeconvexitybevelsmask_1.nodes["Color Ramp"].outputs[0],
            bbqbakeconvexitybevelsmask_1.nodes["Invert Color"].inputs[1]
        )
        # color_ramp_007.Color -> outconvexity.A
        bbqbakeconvexitybevelsmask_1.links.new(
            bbqbakeconvexitybevelsmask_1.nodes["Color Ramp.007"].outputs[0],
            bbqbakeconvexitybevelsmask_1.nodes["OutConvexity"].inputs[6]
        )
        # invert_color.Color -> outconvexity.B
        bbqbakeconvexitybevelsmask_1.links.new(
            bbqbakeconvexitybevelsmask_1.nodes["Invert Color"].outputs[0],
            bbqbakeconvexitybevelsmask_1.nodes["OutConvexity"].inputs[7]
        )
        # outconvexity.Result -> group_output.Result
        bbqbakeconvexitybevelsmask_1.links.new(
            bbqbakeconvexitybevelsmask_1.nodes["OutConvexity"].outputs[2],
            bbqbakeconvexitybevelsmask_1.nodes["Group Output"].inputs[0]
        )
        # outconvexity.Result -> group_output.Result
        bbqbakeconvexitybevelsmask_1.links.new(
            bbqbakeconvexitybevelsmask_1.nodes["OutConvexity"].outputs[2],
            bbqbakeconvexitybevelsmask_1.nodes["Group Output"].inputs[1]
        )
        # group_input.Factor -> color_ramp.Factor
        bbqbakeconvexitybevelsmask_1.links.new(
            bbqbakeconvexitybevelsmask_1.nodes["Group Input"].outputs[0],
            bbqbakeconvexitybevelsmask_1.nodes["Color Ramp"].inputs[0]
        )
        # group_input.Factor -> color_ramp_007.Factor
        bbqbakeconvexitybevelsmask_1.links.new(
            bbqbakeconvexitybevelsmask_1.nodes["Group Input"].outputs[1],
            bbqbakeconvexitybevelsmask_1.nodes["Color Ramp.007"].inputs[0]
        )

        return bbqbakeconvexitybevelsmask_1

    # MARK: AO Group
    @staticmethod
    def build_ambient_occlusion_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        s_node_group_name = ZBBQ_Consts.node_tree_service_ao_name

        bbqbakeambientocclusion_1 = bpy.data.node_groups.get(s_node_group_name)
        group_input = None
        group_output = None

        if bbqbakeambientocclusion_1:
            if not reset:
                return bbqbakeambientocclusion_1

            for node in list(bbqbakeambientocclusion_1.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    bbqbakeambientocclusion_1.nodes.remove(node)

            bbqbakeambientocclusion_1.links.clear()

        else:
            bbqbakeambientocclusion_1 = bpy.data.node_groups.new(type='ShaderNodeTree', name=s_node_group_name)

        bbqbakeambientocclusion_1.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(s_node_group_name)

        if group_input is None:
            group_input = bbqbakeambientocclusion_1.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket Factor
            factor_socket = bbqbakeambientocclusion_1.interface.new_socket(name="Factor", in_out='INPUT', socket_type='NodeSocketFloat')
            factor_socket.default_value = 1.0
            factor_socket.min_value = 0.0
            factor_socket.max_value = 1.0
            factor_socket.subtype = 'FACTOR'
            factor_socket.attribute_domain = 'POINT'
            factor_socket.description = "Amount of mixing between the A and B inputs"

            # Socket A
            a_socket = bbqbakeambientocclusion_1.interface.new_socket(name="A", in_out='INPUT', socket_type='NodeSocketVector')
            a_socket.default_value = (0.0, 0.0, 0.0)
            a_socket.min_value = -3.4028234663852886e+38
            a_socket.max_value = 3.4028234663852886e+38
            a_socket.subtype = 'NONE'
            a_socket.attribute_domain = 'POINT'
            a_socket.description = "Value of the first vector input"

            # Socket B
            b_socket = bbqbakeambientocclusion_1.interface.new_socket(name="B", in_out='INPUT', socket_type='NodeSocketVector')
            b_socket.default_value = (0.0, 0.0, 0.0)
            b_socket.min_value = -3.4028234663852886e+38
            b_socket.max_value = 3.4028234663852886e+38
            b_socket.subtype = 'NONE'
            b_socket.attribute_domain = 'POINT'
            b_socket.description = "Value of the second vector input"

            # Socket Distance
            distance_socket = bbqbakeambientocclusion_1.interface.new_socket(name="Distance", in_out='INPUT', socket_type='NodeSocketFloat')
            distance_socket.default_value = 0.08
            distance_socket.min_value = 0.0
            distance_socket.max_value = 1000.0
            distance_socket.subtype = 'NONE'
            distance_socket.attribute_domain = 'POINT'

        if group_output is None:
            group_output = bbqbakeambientocclusion_1.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Color
            color_socket = bbqbakeambientocclusion_1.interface.new_socket(name="Color", in_out='OUTPUT', socket_type='NodeSocketColor')
            color_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            color_socket.attribute_domain = 'POINT'

        # Initialize bbqbakeambientocclusion_1 nodes

        # Node Frame
        frame = bbqbakeambientocclusion_1.nodes.new("NodeFrame")
        frame.label = "Ambient Occlusion"
        frame.name = "Frame"
        frame.show_options = True
        frame.label_size = 20
        frame.shrink = True

        # Node OutAmbientOcclusion
        outambientocclusion = bbqbakeambientocclusion_1.nodes.new("ShaderNodeAmbientOcclusion")
        outambientocclusion.label = "OutAmbientOcclusion"
        outambientocclusion.name = "OutAmbientOcclusion"
        outambientocclusion.show_options = True
        outambientocclusion.inside = False
        outambientocclusion.only_local = False
        outambientocclusion.samples = bpy.context.scene.zen_bbq.ao_node_samples
        # Color
        outambientocclusion.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
        # Distance
        outambientocclusion.inputs[1].default_value = 0.08

        driver_spec = outambientocclusion.driver_add("samples")
        driver = driver_spec.driver
        driver.type = "SUM"

        var = driver.variables.new()
        var.name = "zbbq_ao_input_samples"
        var.type = "SINGLE_PROP"

        var.targets[0].id_type = "SCENE"
        var.targets[0].id = bpy.context.scene
        var.targets[0].data_path = "zen_bbq.ao_node_samples"

        # Node Mix.003
        mix_003 = bbqbakeambientocclusion_1.nodes.new("ShaderNodeMix")
        mix_003.name = "Mix.003"
        mix_003.show_options = True
        mix_003.blend_type = 'MIX'
        mix_003.clamp_factor = False
        mix_003.clamp_result = False
        mix_003.data_type = 'VECTOR'
        mix_003.factor_mode = 'UNIFORM'

        # Set parents
        bbqbakeambientocclusion_1.nodes["OutAmbientOcclusion"].parent = bbqbakeambientocclusion_1.nodes["Frame"]
        bbqbakeambientocclusion_1.nodes["Mix.003"].parent = bbqbakeambientocclusion_1.nodes["Frame"]

        # Set locations
        bbqbakeambientocclusion_1.nodes["Frame"].location = (-193.0, 25.0)
        bbqbakeambientocclusion_1.nodes["OutAmbientOcclusion"].location = (386.65093994140625, -35.77532958984375)
        bbqbakeambientocclusion_1.nodes["Mix.003"].location = (29.610504150390625, -50.49346923828125)
        bbqbakeambientocclusion_1.nodes["Group Output"].location = (413.34906005859375, 0.0)
        bbqbakeambientocclusion_1.nodes["Group Input"].location = (-393.65093994140625, 0.0)

        # Initialize bbqbakeambientocclusion_1 links

        # mix_003.Result -> outambientocclusion.Normal
        bbqbakeambientocclusion_1.links.new(
            bbqbakeambientocclusion_1.nodes["Mix.003"].outputs[1],
            bbqbakeambientocclusion_1.nodes["OutAmbientOcclusion"].inputs[2]
        )
        # group_input.A -> mix_003.A
        bbqbakeambientocclusion_1.links.new(
            bbqbakeambientocclusion_1.nodes["Group Input"].outputs[1],
            bbqbakeambientocclusion_1.nodes["Mix.003"].inputs[4]
        )
        # group_input.Factor -> mix_003.Factor
        bbqbakeambientocclusion_1.links.new(
            bbqbakeambientocclusion_1.nodes["Group Input"].outputs[0],
            bbqbakeambientocclusion_1.nodes["Mix.003"].inputs[0]
        )
        # outambientocclusion.Color -> group_output.Color
        bbqbakeambientocclusion_1.links.new(
            bbqbakeambientocclusion_1.nodes["OutAmbientOcclusion"].outputs[0],
            bbqbakeambientocclusion_1.nodes["Group Output"].inputs[0]
        )
        # group_input.B -> mix_003.B
        bbqbakeambientocclusion_1.links.new(
            bbqbakeambientocclusion_1.nodes["Group Input"].outputs[2],
            bbqbakeambientocclusion_1.nodes["Mix.003"].inputs[5]
        )
        # group_input.Distance -> outambientocclusion.Distance
        bbqbakeambientocclusion_1.links.new(
            bbqbakeambientocclusion_1.nodes["Group Input"].outputs[3],
            bbqbakeambientocclusion_1.nodes["OutAmbientOcclusion"].inputs[1]
        )

        return bbqbakeambientocclusion_1

    # MARK: Concavity Group
    @staticmethod
    def build_concavity_bevels_mask_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        bbqbakeconcavitybevelsmask_1 = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_concavity)
        group_input = None
        group_output = None

        if bbqbakeconcavitybevelsmask_1:
            if not reset:
                return bbqbakeconcavitybevelsmask_1

            for node in list(bbqbakeconcavitybevelsmask_1.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    bbqbakeconcavitybevelsmask_1.nodes.remove(node)

            bbqbakeconcavitybevelsmask_1.links.clear()

        else:
            bbqbakeconcavitybevelsmask_1 = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_concavity)

        bbqbakeconcavitybevelsmask_1.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_concavity)

        if group_input is None:
            group_input = bbqbakeconcavitybevelsmask_1.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket Factor
            factor_socket = bbqbakeconcavitybevelsmask_1.interface.new_socket(name="Factor", in_out='INPUT', socket_type='NodeSocketFloat')
            factor_socket.default_value = 0.5
            factor_socket.min_value = 0.0
            factor_socket.max_value = 1.0
            factor_socket.subtype = 'FACTOR'
            factor_socket.attribute_domain = 'POINT'
            factor_socket.description = "The value used to map onto the color gradient. 0.0 results in the leftmost color, while 1.0 results in the rightmost"

            # Socket Factor
            factor_socket_1 = bbqbakeconcavitybevelsmask_1.interface.new_socket(name="Factor", in_out='INPUT', socket_type='NodeSocketFloat')
            factor_socket_1.default_value = 0.5
            factor_socket_1.min_value = 0.0
            factor_socket_1.max_value = 1.0
            factor_socket_1.subtype = 'FACTOR'
            factor_socket_1.attribute_domain = 'POINT'
            factor_socket_1.description = "The value used to map onto the color gradient. 0.0 results in the leftmost color, while 1.0 results in the rightmost"

        if group_output is None:
            group_output = bbqbakeconcavitybevelsmask_1.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Color
            color_socket = bbqbakeconcavitybevelsmask_1.interface.new_socket(name="Color", in_out='OUTPUT', socket_type='NodeSocketColor')
            color_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            color_socket.attribute_domain = 'POINT'

            # Socket Color
            color_socket_1 = bbqbakeconcavitybevelsmask_1.interface.new_socket(name="Color", in_out='OUTPUT', socket_type='NodeSocketColor')
            color_socket_1.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            color_socket_1.attribute_domain = 'POINT'

            # Socket Color
            color_socket_2 = bbqbakeconcavitybevelsmask_1.interface.new_socket(name="Color", in_out='OUTPUT', socket_type='NodeSocketColor')
            color_socket_2.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            color_socket_2.attribute_domain = 'POINT'

        # Initialize bbqbakeconcavitybevelsmask_1 nodes

        # Node Color Ramp.003
        color_ramp_003 = bbqbakeconcavitybevelsmask_1.nodes.new("ShaderNodeValToRGB")
        color_ramp_003.name = "Color Ramp.003"
        color_ramp_003.show_options = True
        color_ramp_003.color_ramp.color_mode = 'RGB'
        color_ramp_003.color_ramp.hue_interpolation = 'NEAR'
        color_ramp_003.color_ramp.interpolation = 'LINEAR'

        # Initialize color ramp elements
        color_ramp_003.color_ramp.elements.remove(color_ramp_003.color_ramp.elements[0])
        color_ramp_003_cre_0 = color_ramp_003.color_ramp.elements[0]
        color_ramp_003_cre_0.position = 0.87727290391922
        color_ramp_003_cre_0.alpha = 1.0
        color_ramp_003_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        color_ramp_003_cre_1 = color_ramp_003.color_ramp.elements.new(1.0)
        color_ramp_003_cre_1.alpha = 1.0
        color_ramp_003_cre_1.color = (1.0, 1.0, 1.0, 1.0)

        # Node Frame.003
        frame_003 = bbqbakeconcavitybevelsmask_1.nodes.new("NodeFrame")
        frame_003.label = "Concavity Bevels Mask"
        frame_003.name = "Frame.003"
        frame_003.show_options = True
        frame_003.label_size = 20
        frame_003.shrink = True

        # Node Color Ramp.004
        color_ramp_004 = bbqbakeconcavitybevelsmask_1.nodes.new("ShaderNodeValToRGB")
        color_ramp_004.name = "Color Ramp.004"
        color_ramp_004.show_options = True
        color_ramp_004.color_ramp.color_mode = 'RGB'
        color_ramp_004.color_ramp.hue_interpolation = 'NEAR'
        color_ramp_004.color_ramp.interpolation = 'LINEAR'

        # Initialize color ramp elements
        color_ramp_004.color_ramp.elements.remove(color_ramp_004.color_ramp.elements[0])
        color_ramp_004_cre_0 = color_ramp_004.color_ramp.elements[0]
        color_ramp_004_cre_0.position = 0.6000000834465027
        color_ramp_004_cre_0.alpha = 1.0
        color_ramp_004_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        color_ramp_004_cre_1 = color_ramp_004.color_ramp.elements.new(0.6363638639450073)
        color_ramp_004_cre_1.alpha = 1.0
        color_ramp_004_cre_1.color = (1.0, 1.0, 1.0, 1.0)

        # Node Mix.001
        mix_001 = bbqbakeconcavitybevelsmask_1.nodes.new("ShaderNodeMix")
        mix_001.name = "Mix.001"
        mix_001.show_options = True
        mix_001.blend_type = 'SUBTRACT'
        mix_001.clamp_factor = True
        mix_001.clamp_result = True
        mix_001.data_type = 'RGBA'
        mix_001.factor_mode = 'UNIFORM'
        # Factor_Float
        mix_001.inputs[0].default_value = 1.0

        # Node OutConcavity
        outconcavity = bbqbakeconcavitybevelsmask_1.nodes.new("ShaderNodeInvert")
        outconcavity.label = "OutConcavity"
        outconcavity.name = "OutConcavity"
        outconcavity.show_options = True
        # Fac
        outconcavity.inputs[0].default_value = 1.0

        # Set parents
        bbqbakeconcavitybevelsmask_1.nodes["Color Ramp.003"].parent = bbqbakeconcavitybevelsmask_1.nodes["Frame.003"]
        bbqbakeconcavitybevelsmask_1.nodes["Color Ramp.004"].parent = bbqbakeconcavitybevelsmask_1.nodes["Frame.003"]
        bbqbakeconcavitybevelsmask_1.nodes["Mix.001"].parent = bbqbakeconcavitybevelsmask_1.nodes["Frame.003"]
        bbqbakeconcavitybevelsmask_1.nodes["OutConcavity"].parent = bbqbakeconcavitybevelsmask_1.nodes["Frame.003"]

        # Set locations
        bbqbakeconcavitybevelsmask_1.nodes["Color Ramp.003"].location = (29.99212646484375, -36.002166748046875)
        bbqbakeconcavitybevelsmask_1.nodes["Frame.003"].location = (-385.0, 150.0)
        bbqbakeconcavitybevelsmask_1.nodes["Color Ramp.004"].location = (227.17889404296875, -300.18768310546875)
        bbqbakeconcavitybevelsmask_1.nodes["Mix.001"].location = (563.6124877929688, -53.022857666015625)
        bbqbakeconcavitybevelsmask_1.nodes["OutConcavity"].location = (769.79638671875, -52.137786865234375)
        bbqbakeconcavitybevelsmask_1.nodes["Group Output"].location = (605.20361328125, 0.0)
        bbqbakeconcavitybevelsmask_1.nodes["Group Input"].location = (-584.79638671875, 0.0)

        # Initialize bbqbakeconcavitybevelsmask_1 links

        # color_ramp_003.Color -> mix_001.A
        bbqbakeconcavitybevelsmask_1.links.new(
            bbqbakeconcavitybevelsmask_1.nodes["Color Ramp.003"].outputs[0],
            bbqbakeconcavitybevelsmask_1.nodes["Mix.001"].inputs[6]
        )
        # color_ramp_004.Color -> mix_001.B
        bbqbakeconcavitybevelsmask_1.links.new(
            bbqbakeconcavitybevelsmask_1.nodes["Color Ramp.004"].outputs[0],
            bbqbakeconcavitybevelsmask_1.nodes["Mix.001"].inputs[7]
        )
        # mix_001.Result -> outconcavity.Color
        bbqbakeconcavitybevelsmask_1.links.new(
            bbqbakeconcavitybevelsmask_1.nodes["Mix.001"].outputs[2],
            bbqbakeconcavitybevelsmask_1.nodes["OutConcavity"].inputs[1]
        )
        # outconcavity.Color -> group_output.Color
        bbqbakeconcavitybevelsmask_1.links.new(
            bbqbakeconcavitybevelsmask_1.nodes["OutConcavity"].outputs[0],
            bbqbakeconcavitybevelsmask_1.nodes["Group Output"].inputs[1]
        )
        # group_input.Factor -> color_ramp_003.Factor
        bbqbakeconcavitybevelsmask_1.links.new(
            bbqbakeconcavitybevelsmask_1.nodes["Group Input"].outputs[0],
            bbqbakeconcavitybevelsmask_1.nodes["Color Ramp.003"].inputs[0]
        )
        # outconcavity.Color -> group_output.Color
        bbqbakeconcavitybevelsmask_1.links.new(
            bbqbakeconcavitybevelsmask_1.nodes["OutConcavity"].outputs[0],
            bbqbakeconcavitybevelsmask_1.nodes["Group Output"].inputs[2]
        )
        # outconcavity.Color -> group_output.Color
        bbqbakeconcavitybevelsmask_1.links.new(
            bbqbakeconcavitybevelsmask_1.nodes["OutConcavity"].outputs[0],
            bbqbakeconcavitybevelsmask_1.nodes["Group Output"].inputs[0]
        )
        # group_input.Factor -> color_ramp_004.Factor
        bbqbakeconcavitybevelsmask_1.links.new(
            bbqbakeconcavitybevelsmask_1.nodes["Group Input"].outputs[1],
            bbqbakeconcavitybevelsmask_1.nodes["Color Ramp.004"].inputs[0]
        )

        return bbqbakeconcavitybevelsmask_1

    # MARK: Bevels Mask Group
    @staticmethod
    def build_bevels_mask_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        bbqbakebevelsmask_1 = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_bevels)
        group_input = None
        group_output = None

        if bbqbakebevelsmask_1:
            if not reset:
                return bbqbakebevelsmask_1

            for node in list(bbqbakebevelsmask_1.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    bbqbakebevelsmask_1.nodes.remove(node)

            bbqbakebevelsmask_1.links.clear()

        else:
            bbqbakebevelsmask_1 = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_bevels)

        bbqbakebevelsmask_1.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_bevels)

        if group_input is None:
            group_input = bbqbakebevelsmask_1.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket Factor
            factor_socket = bbqbakebevelsmask_1.interface.new_socket(name="Factor", in_out='INPUT', socket_type='NodeSocketFloat')
            factor_socket.default_value = 0.5
            factor_socket.min_value = 0.0
            factor_socket.max_value = 1.0
            factor_socket.subtype = 'FACTOR'
            factor_socket.attribute_domain = 'POINT'
            factor_socket.description = "The value used to map onto the color gradient. 0.0 results in the leftmost color, while 1.0 results in the rightmost"

        if group_output is None:
            group_output = bbqbakebevelsmask_1.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Color
            color_socket = bbqbakebevelsmask_1.interface.new_socket(name="Color", in_out='OUTPUT', socket_type='NodeSocketColor')
            color_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            color_socket.attribute_domain = 'POINT'

        # Initialize bbqbakebevelsmask_1 nodes

        # Node OutBevelsMask
        outbevelsmask = bbqbakebevelsmask_1.nodes.new("ShaderNodeValToRGB")
        outbevelsmask.label = "OutBevelsMask"
        outbevelsmask.name = "OutBevelsMask"
        outbevelsmask.show_options = True
        outbevelsmask.color_ramp.color_mode = 'RGB'
        outbevelsmask.color_ramp.hue_interpolation = 'NEAR'
        outbevelsmask.color_ramp.interpolation = 'LINEAR'

        # Initialize color ramp elements
        outbevelsmask.color_ramp.elements.remove(outbevelsmask.color_ramp.elements[0])
        outbevelsmask_cre_0 = outbevelsmask.color_ramp.elements[0]
        outbevelsmask_cre_0.position = 0.19090905785560608
        outbevelsmask_cre_0.alpha = 1.0
        outbevelsmask_cre_0.color = (0.0, 0.0, 0.0, 1.0)

        outbevelsmask_cre_1 = outbevelsmask.color_ramp.elements.new(1.0)
        outbevelsmask_cre_1.alpha = 1.0
        outbevelsmask_cre_1.color = (1.0, 1.0, 1.0, 1.0)

        # Node Frame.004
        frame_004 = bbqbakebevelsmask_1.nodes.new("NodeFrame")
        frame_004.label = "Bevels Mask"
        frame_004.name = "Frame.004"
        frame_004.show_options = True
        frame_004.label_size = 20
        frame_004.shrink = True

        # Set parents
        bbqbakebevelsmask_1.nodes["OutBevelsMask"].parent = bbqbakebevelsmask_1.nodes["Frame.004"]

        # Set locations
        bbqbakebevelsmask_1.nodes["OutBevelsMask"].location = (30.157958984375, -35.9010009765625)
        bbqbakebevelsmask_1.nodes["Frame.004"].location = (-15.0, 18.0)
        bbqbakebevelsmask_1.nodes["Group Output"].location = (334.842041015625, 0.0)
        bbqbakebevelsmask_1.nodes["Group Input"].location = (-215.157958984375, 0.0)

        # Initialize bbqbakebevelsmask_1 links

        # outbevelsmask.Color -> group_output.Color
        bbqbakebevelsmask_1.links.new(
            bbqbakebevelsmask_1.nodes["OutBevelsMask"].outputs[0],
            bbqbakebevelsmask_1.nodes["Group Output"].inputs[0]
        )
        # group_input.Factor -> outbevelsmask.Factor
        bbqbakebevelsmask_1.links.new(
            bbqbakebevelsmask_1.nodes["Group Input"].outputs[0],
            bbqbakebevelsmask_1.nodes["OutBevelsMask"].inputs[0]
        )

        return bbqbakebevelsmask_1

    # MARK: Parts Mask Group
    @staticmethod
    def build_parts_id_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        bbqbakepartsid_1 = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_parts_id)
        group_input = None
        group_output = None

        if bbqbakepartsid_1:
            if not reset:
                return bbqbakepartsid_1

            for node in list(bbqbakepartsid_1.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    bbqbakepartsid_1.nodes.remove(node)

            bbqbakepartsid_1.links.clear()

        else:
            bbqbakepartsid_1 = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_parts_id)

        bbqbakepartsid_1.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_parts_id)

        if group_input is None:
            group_input = bbqbakepartsid_1.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket Vector
            vector_socket = bbqbakepartsid_1.interface.new_socket(name="Vector", in_out='INPUT', socket_type='NodeSocketVector')
            vector_socket.default_value = (0.0, 0.0, 0.0)
            vector_socket.min_value = -10000.0
            vector_socket.max_value = 10000.0
            vector_socket.subtype = 'NONE'
            vector_socket.attribute_domain = 'POINT'
            vector_socket.hide_value = True

        if group_output is None:
            group_output = bbqbakepartsid_1.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Color
            color_socket = bbqbakepartsid_1.interface.new_socket(name="Color", in_out='OUTPUT', socket_type='NodeSocketColor')
            color_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            color_socket.attribute_domain = 'POINT'

        # Initialize bbqbakepartsid_1 nodes

        # Node Object Info
        object_info = bbqbakepartsid_1.nodes.new("ShaderNodeObjectInfo")
        object_info.name = "Object Info"
        object_info.show_options = True

        # Node OutPartID
        outpartid = bbqbakepartsid_1.nodes.new("ShaderNodeTexWhiteNoise")
        outpartid.label = "OutPartID"
        outpartid.name = "OutPartID"
        outpartid.show_options = True
        outpartid.show_texture = True
        outpartid.noise_dimensions = '4D'

        # Node Frame.005
        frame_005 = bbqbakepartsid_1.nodes.new("NodeFrame")
        frame_005.label = "Part ID"
        frame_005.name = "Frame.005"
        frame_005.show_options = True
        frame_005.label_size = 20
        frame_005.shrink = True

        # Set parents
        bbqbakepartsid_1.nodes["Object Info"].parent = bbqbakepartsid_1.nodes["Frame.005"]
        bbqbakepartsid_1.nodes["OutPartID"].parent = bbqbakepartsid_1.nodes["Frame.005"]

        # Set locations
        bbqbakepartsid_1.nodes["Object Info"].location = (29.6614990234375, -35.6983642578125)
        bbqbakepartsid_1.nodes["OutPartID"].location = (347.91070556640625, -50.3665771484375)
        bbqbakepartsid_1.nodes["Frame.005"].location = (-174.0, 25.0)
        bbqbakepartsid_1.nodes["Group Output"].location = (394.0893249511719, 0.0)
        bbqbakepartsid_1.nodes["Group Input"].location = (-373.9106750488281, 0.0)

        # Initialize bbqbakepartsid_1 links

        # object_info.Random -> outpartid.W
        bbqbakepartsid_1.links.new(
            bbqbakepartsid_1.nodes["Object Info"].outputs[5],
            bbqbakepartsid_1.nodes["OutPartID"].inputs[1]
        )
        # outpartid.Color -> group_output.Color
        bbqbakepartsid_1.links.new(
            bbqbakepartsid_1.nodes["OutPartID"].outputs[1],
            bbqbakepartsid_1.nodes["Group Output"].inputs[0]
        )
        # group_input.Vector -> outpartid.Vector
        bbqbakepartsid_1.links.new(
            bbqbakepartsid_1.nodes["Group Input"].outputs[0],
            bbqbakepartsid_1.nodes["OutPartID"].inputs[0]
        )

        return bbqbakepartsid_1

    # MARK: Material ID Group
    @classmethod
    def build_materials_id_ng(cls, target_material, reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        nodeGroup = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_mat_id)
        group_input = None
        group_output = None

        if nodeGroup:
            if not reset:
                return nodeGroup

            for node in list(nodeGroup.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    nodeGroup.nodes.remove(node)

            nodeGroup.links.clear()

        else:
            node_group_name = ZBBQ_MaterialFunc.GetNodeNameByMat(target_material, ZBBQ_Consts.node_tree_service_mat_id)
            nodeGroup = bpy.data.node_groups.new(type='ShaderNodeTree', name=node_group_name)

        nodeGroup.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_mat_id)

        if group_input is None:
            group_input = nodeGroup.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

        if group_output is None:
            group_output = nodeGroup.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Color
            color_socket = nodeGroup.interface.new_socket(name="Color", in_out='OUTPUT', socket_type='NodeSocketColor')
            color_socket.default_value = (0.8, 0.8, 0.8, 1.0)
            color_socket.attribute_domain = 'POINT'

        # Initialize bbqbakematerialsid_1 nodes

        # Node OutMaterialID
        # outmaterialid = nodeGroup.nodes.new("ShaderNodeVertexColor")
        # outmaterialid.label = "OutMaterialID"
        # outmaterialid.name = "OutMaterialID"
        # outmaterialid.show_options = True
        # outmaterialid.layer_name = ZBBQ_Consts.MaterialIdAttributeName

        node_mat_id = cls.build_material_id_node_with_drivers(nodeGroup, target_material)

        # Node Frame.006
        frame_006 = nodeGroup.nodes.new("NodeFrame")
        frame_006.label = "Material ID"
        frame_006.name = "Frame.006"
        frame_006.show_options = True
        frame_006.label_size = 20
        frame_006.shrink = True

        # Set parents
        # nodeGroup.nodes["OutMaterialID"].parent = nodeGroup.nodes["Frame.006"]
        node_mat_id.parent = nodeGroup.nodes["Frame.006"]

        # Set locations
        # nodeGroup.nodes["OutMaterialID"].location = (30.128662109375, -36.0401611328125)
        # nodeGroup.nodes["Frame.006"].location = (-15.0, 18.0)
        nodeGroup.nodes["Group Output"].location = (234.871337890625, -6.103515625e-05)
        nodeGroup.nodes["Group Input"].location = (-215.128662109375, -6.103515625e-05)

        node_mat_id.location = (30.0, -36.0)

        # Initialize bbqbakematerialsid_1 links

        # outmaterialid.Color -> group_output.Color
        # nodeGroup.links.new(
        #     nodeGroup.nodes["OutMaterialID"].outputs[0],
        #     nodeGroup.nodes["Group Output"].inputs[0]
        # )
        nodeGroup.links.new(node_mat_id.outputs[0], nodeGroup.nodes["Group Output"].inputs[0])

        return nodeGroup

    # MARK: Object Space NM Group
    @staticmethod
    def build_object_space_normal_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        bbqbakeobjectspacenormal_1 = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_space_normal)
        group_input = None
        group_output = None

        if bbqbakeobjectspacenormal_1:
            if not reset:
                return bbqbakeobjectspacenormal_1

            for node in list(bbqbakeobjectspacenormal_1.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    bbqbakeobjectspacenormal_1.nodes.remove(node)

            bbqbakeobjectspacenormal_1.links.clear()

        else:
            bbqbakeobjectspacenormal_1 = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_space_normal)

        bbqbakeobjectspacenormal_1.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_space_normal)

        if group_input is None:
            group_input = bbqbakeobjectspacenormal_1.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket Vector
            vector_socket_1 = bbqbakeobjectspacenormal_1.interface.new_socket(name="Vector", in_out='INPUT', socket_type='NodeSocketVector')
            vector_socket_1.default_value = (0.0, 0.0, 0.0)
            vector_socket_1.min_value = -10000.0
            vector_socket_1.max_value = 10000.0
            vector_socket_1.subtype = 'NONE'
            vector_socket_1.attribute_domain = 'POINT'

        if group_output is None:
            group_output = bbqbakeobjectspacenormal_1.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Vector
            vector_socket = bbqbakeobjectspacenormal_1.interface.new_socket(name="Vector", in_out='OUTPUT', socket_type='NodeSocketVector')
            vector_socket.default_value = (0.0, 0.0, 0.0)
            vector_socket.min_value = -3.4028234663852886e+38
            vector_socket.max_value = 3.4028234663852886e+38
            vector_socket.subtype = 'NONE'
            vector_socket.attribute_domain = 'POINT'

        # Initialize bbqbakeobjectspacenormal_1 nodes

        # Node Vector Math
        vector_math = bbqbakeobjectspacenormal_1.nodes.new("ShaderNodeVectorMath")
        vector_math.name = "Vector Math"
        vector_math.show_options = True
        vector_math.operation = 'MULTIPLY'
        # Vector_001
        vector_math.inputs[1].default_value = (0.5, 0.5, 0.5)

        # Node OutObjectSpaceNormal
        outobjectspacenormal = bbqbakeobjectspacenormal_1.nodes.new("ShaderNodeVectorMath")
        outobjectspacenormal.label = "OutObjectSpaceNormal"
        outobjectspacenormal.name = "OutObjectSpaceNormal"
        outobjectspacenormal.show_options = True
        outobjectspacenormal.operation = 'ADD'
        # Vector_001
        outobjectspacenormal.inputs[1].default_value = (0.5, 0.5, 0.5)

        # Node Frame.008
        frame_008 = bbqbakeobjectspacenormal_1.nodes.new("NodeFrame")
        frame_008.label = "Object Space Normal"
        frame_008.name = "Frame.008"
        frame_008.show_options = True
        frame_008.label_size = 20
        frame_008.shrink = True

        # Set parents
        bbqbakeobjectspacenormal_1.nodes["Vector Math"].parent = bbqbakeobjectspacenormal_1.nodes["Frame.008"]
        bbqbakeobjectspacenormal_1.nodes["OutObjectSpaceNormal"].parent = bbqbakeobjectspacenormal_1.nodes["Frame.008"]

        # Set locations
        bbqbakeobjectspacenormal_1.nodes["Vector Math"].location = (29.666107177734375, -35.957275390625)
        bbqbakeobjectspacenormal_1.nodes["OutObjectSpaceNormal"].location = (260.5042724609375, -35.60595703125)
        bbqbakeobjectspacenormal_1.nodes["Frame.008"].location = (-130.0, 18.0)
        bbqbakeobjectspacenormal_1.nodes["Group Output"].location = (350.4957275390625, 0.0)
        bbqbakeobjectspacenormal_1.nodes["Group Input"].location = (-330.5042724609375, 0.0)

        # Initialize bbqbakeobjectspacenormal_1 links

        # vector_math.Vector -> outobjectspacenormal.Vector
        bbqbakeobjectspacenormal_1.links.new(
            bbqbakeobjectspacenormal_1.nodes["Vector Math"].outputs[0],
            bbqbakeobjectspacenormal_1.nodes["OutObjectSpaceNormal"].inputs[0]
        )
        # group_input.Vector -> vector_math.Vector
        bbqbakeobjectspacenormal_1.links.new(
            bbqbakeobjectspacenormal_1.nodes["Group Input"].outputs[0],
            bbqbakeobjectspacenormal_1.nodes["Vector Math"].inputs[0]
        )
        # outobjectspacenormal.Vector -> group_output.Vector
        bbqbakeobjectspacenormal_1.links.new(
            bbqbakeobjectspacenormal_1.nodes["OutObjectSpaceNormal"].outputs[0],
            bbqbakeobjectspacenormal_1.nodes["Group Output"].inputs[0]
        )

        return bbqbakeobjectspacenormal_1

    # MARK: Tangent Space NM Group
    @staticmethod
    def build_tangent_space_normal_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        nodeGroup = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_tangent_space_normal)
        group_input = None
        group_output = None

        if nodeGroup:
            if not reset:
                return nodeGroup

            for node in list(nodeGroup.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    nodeGroup.nodes.remove(node)

            nodeGroup.links.clear()

        else:
            nodeGroup = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_tangent_space_normal)

        nodeGroup.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_tangent_space_normal)

        if group_input is None:
            group_input = nodeGroup.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket Vector
            vector_socket = nodeGroup.interface.new_socket(name="Bevel Normal", in_out='INPUT', socket_type='NodeSocketVector')
            vector_socket.default_value = (0.0, 0.0, 0.0)
            vector_socket.min_value = -10000.0
            vector_socket.max_value = 10000.0
            vector_socket.subtype = 'NONE'
            vector_socket.attribute_domain = 'POINT'

            # Socket Vector
            vector_socket_1 = nodeGroup.interface.new_socket(name="Geometry Normal", in_out='INPUT', socket_type='NodeSocketVector')
            vector_socket_1.default_value = (0.0, 0.0, 0.0)
            vector_socket_1.min_value = -10000.0
            vector_socket_1.max_value = 10000.0
            vector_socket_1.subtype = 'NONE'
            vector_socket_1.attribute_domain = 'POINT'

            # Socket is DirectX
            try:
                is_directx_socket = nodeGroup.interface.new_socket(
                    name="is DirectX", in_out='INPUT', socket_type='NodeSocketBool'
                )
            except TypeError:
                is_directx_socket = nodeGroup.interface.new_socket(
                    name="is DirectX", in_out='INPUT', socket_type='NodeSocketFloat'
                )
                is_directx_socket.default_value = 0.0
                is_directx_socket.min_value = 0.0
                is_directx_socket.max_value = 1.0

        if group_output is None:
            group_output = nodeGroup.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Result
            result_socket = nodeGroup.interface.new_socket(name="Result", in_out='OUTPUT', socket_type='NodeSocketColor')
            result_socket.default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
            result_socket.attribute_domain = 'POINT'

        # Initialize bbqbaketangentspacenormal_1 nodes

        # Node Vector Math.002
        vector_math_002 = nodeGroup.nodes.new("ShaderNodeVectorMath")
        vector_math_002.name = "Vector Math.002"
        vector_math_002.show_options = True
        vector_math_002.operation = 'CROSS_PRODUCT'

        # Node Vector Math.003
        vector_math_003 = nodeGroup.nodes.new("ShaderNodeVectorMath")
        vector_math_003.name = "Vector Math.003"
        vector_math_003.show_options = True
        vector_math_003.operation = 'DOT_PRODUCT'

        # Node Vector Math.004
        vector_math_004 = nodeGroup.nodes.new("ShaderNodeVectorMath")
        vector_math_004.name = "Vector Math.004"
        vector_math_004.show_options = True
        vector_math_004.operation = 'DOT_PRODUCT'

        # Node Vector Math.005
        vector_math_005 = nodeGroup.nodes.new("ShaderNodeVectorMath")
        vector_math_005.name = "Vector Math.005"
        vector_math_005.show_options = True
        vector_math_005.operation = 'DOT_PRODUCT'

        # Node Combine XYZ
        combine_xyz = nodeGroup.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz.name = "Combine XYZ"
        combine_xyz.show_options = True

        # Node Vector Math.006
        vector_math_006 = nodeGroup.nodes.new("ShaderNodeVectorMath")
        vector_math_006.name = "Vector Math.006"
        vector_math_006.show_options = True
        vector_math_006.operation = 'MULTIPLY'
        # Vector_001
        vector_math_006.inputs[1].default_value = (0.5, 0.5, 0.5)

        # Node Vector Math.007
        vector_math_007 = nodeGroup.nodes.new("ShaderNodeVectorMath")
        vector_math_007.name = "Vector Math.007"
        vector_math_007.show_options = True
        vector_math_007.operation = 'ADD'
        # Vector_001
        vector_math_007.inputs[1].default_value = (0.5, 0.5, 0.5)

        # Node Tangent
        tangent = nodeGroup.nodes.new("ShaderNodeTangent")
        tangent.name = "Tangent"
        tangent.show_options = True
        tangent.axis = 'Z'
        tangent.direction_type = 'UV_MAP'
        tangent.uv_map = ""

        # Node Math
        math = nodeGroup.nodes.new("ShaderNodeMath")
        math.name = "Math"
        math.show_options = True
        math.operation = 'SUBTRACT'
        math.use_clamp = False
        # Value
        math.inputs[0].default_value = 1.0

        # Node Combine XYZ.001
        combine_xyz_001 = nodeGroup.nodes.new("ShaderNodeCombineXYZ")
        combine_xyz_001.name = "Combine XYZ.001"
        combine_xyz_001.show_options = True

        # Node Separate XYZ
        separate_xyz = nodeGroup.nodes.new("ShaderNodeSeparateXYZ")
        separate_xyz.name = "Separate XYZ"
        separate_xyz.show_options = True

        # Node OutTangentNormal
        outtangentnormal = nodeGroup.nodes.new("ShaderNodeMix")
        outtangentnormal.label = "OutTangentNormal"
        outtangentnormal.name = "OutTangentNormal"
        outtangentnormal.show_options = True
        outtangentnormal.blend_type = 'MIX'
        outtangentnormal.clamp_factor = True
        outtangentnormal.clamp_result = False
        outtangentnormal.data_type = 'RGBA'
        outtangentnormal.factor_mode = 'UNIFORM'

        # Node Frame.009
        frame_009 = nodeGroup.nodes.new("NodeFrame")
        frame_009.label = "Tangent Space Normal"
        frame_009.name = "Frame.009"
        frame_009.show_options = True
        frame_009.label_size = 20
        frame_009.shrink = True

        # Set parents
        nodeGroup.nodes["Vector Math.002"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Vector Math.003"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Vector Math.004"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Vector Math.005"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Combine XYZ"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Vector Math.006"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Vector Math.007"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Tangent"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Math"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Combine XYZ.001"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["Separate XYZ"].parent = nodeGroup.nodes["Frame.009"]
        nodeGroup.nodes["OutTangentNormal"].parent = nodeGroup.nodes["Frame.009"]

        # Set locations
        nodeGroup.nodes["Vector Math.002"].location = (375.7403564453125, -189.422607421875)
        nodeGroup.nodes["Vector Math.003"].location = (707.6465454101562, -36.171875)
        nodeGroup.nodes["Vector Math.004"].location = (709.240478515625, -345.88916015625)
        nodeGroup.nodes["Vector Math.005"].location = (707.6710815429688, -184.859130859375)
        nodeGroup.nodes["Combine XYZ"].location = (987.9862060546875, -175.92578125)
        nodeGroup.nodes["Vector Math.006"].location = (1191.819580078125, -172.931640625)
        nodeGroup.nodes["Vector Math.007"].location = (1391.481201171875, -174.09375)
        nodeGroup.nodes["Tangent"].location = (29.7315673828125, -132.75439453125)
        nodeGroup.nodes["Math"].location = (1903.560546875, -52.3388671875)
        nodeGroup.nodes["Combine XYZ.001"].location = (2072.960205078125, -48.38916015625)
        nodeGroup.nodes["Separate XYZ"].location = (1717.2548828125, -58.95166015625)
        nodeGroup.nodes["OutTangentNormal"].location = (2304.599365234375, -225.209228515625)
        nodeGroup.nodes["Frame.009"].location = (-1152.0, 173.0)
        nodeGroup.nodes["Group Output"].location = (1372.400634765625, 0.0)
        nodeGroup.nodes["Group Input"].location = (-1352.599365234375, 0.0)

        # Initialize bbqbaketangentspacenormal_1 links

        # vector_math_002.Vector -> vector_math_005.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["Vector Math.002"].outputs[0],
            nodeGroup.nodes["Vector Math.005"].inputs[1]
        )
        # vector_math_003.Value -> combine_xyz.X
        nodeGroup.links.new(
            nodeGroup.nodes["Vector Math.003"].outputs[1],
            nodeGroup.nodes["Combine XYZ"].inputs[0]
        )
        # vector_math_005.Value -> combine_xyz.Y
        nodeGroup.links.new(
            nodeGroup.nodes["Vector Math.005"].outputs[1],
            nodeGroup.nodes["Combine XYZ"].inputs[1]
        )
        # vector_math_004.Value -> combine_xyz.Z
        nodeGroup.links.new(
            nodeGroup.nodes["Vector Math.004"].outputs[1],
            nodeGroup.nodes["Combine XYZ"].inputs[2]
        )
        # combine_xyz.Vector -> vector_math_006.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["Combine XYZ"].outputs[0],
            nodeGroup.nodes["Vector Math.006"].inputs[0]
        )
        # vector_math_006.Vector -> vector_math_007.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["Vector Math.006"].outputs[0],
            nodeGroup.nodes["Vector Math.007"].inputs[0]
        )
        # tangent.Tangent -> vector_math_003.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["Tangent"].outputs[0],
            nodeGroup.nodes["Vector Math.003"].inputs[1]
        )
        # tangent.Tangent -> vector_math_002.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["Tangent"].outputs[0],
            nodeGroup.nodes["Vector Math.002"].inputs[1]
        )
        # vector_math_007.Vector -> separate_xyz.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["Vector Math.007"].outputs[0],
            nodeGroup.nodes["Separate XYZ"].inputs[0]
        )
        # separate_xyz.Y -> math.Value
        nodeGroup.links.new(
            nodeGroup.nodes["Separate XYZ"].outputs[1],
            nodeGroup.nodes["Math"].inputs[1]
        )
        # math.Value -> combine_xyz_001.Y
        nodeGroup.links.new(
            nodeGroup.nodes["Math"].outputs[0],
            nodeGroup.nodes["Combine XYZ.001"].inputs[1]
        )
        # separate_xyz.X -> combine_xyz_001.X
        nodeGroup.links.new(
            nodeGroup.nodes["Separate XYZ"].outputs[0],
            nodeGroup.nodes["Combine XYZ.001"].inputs[0]
        )
        # separate_xyz.Z -> combine_xyz_001.Z
        nodeGroup.links.new(
            nodeGroup.nodes["Separate XYZ"].outputs[2],
            nodeGroup.nodes["Combine XYZ.001"].inputs[2]
        )
        # vector_math_007.Vector -> outtangentnormal.A
        nodeGroup.links.new(
            nodeGroup.nodes["Vector Math.007"].outputs[0],
            nodeGroup.nodes["OutTangentNormal"].inputs[6]
        )
        # combine_xyz_001.Vector -> outtangentnormal.B
        nodeGroup.links.new(
            nodeGroup.nodes["Combine XYZ.001"].outputs[0],
            nodeGroup.nodes["OutTangentNormal"].inputs[7]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[0],
            nodeGroup.nodes["Vector Math.003"].inputs[0]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[0],
            nodeGroup.nodes["Vector Math.004"].inputs[0]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[0],
            nodeGroup.nodes["Vector Math.005"].inputs[0]
        )

        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[1],
            nodeGroup.nodes["Vector Math.002"].inputs[0]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[1],
            nodeGroup.nodes["Vector Math.004"].inputs[1]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[2],
            nodeGroup.nodes["OutTangentNormal"].inputs[0]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["OutTangentNormal"].outputs[2],
            nodeGroup.nodes["Group Output"].inputs[0]
        )

        return nodeGroup

    # MARK: Map Type Switch Group
    @staticmethod
    def build_types_switch_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        bbqbakeswitch_1 = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_bake_switch)
        group_input = None
        group_output = None

        if bbqbakeswitch_1:
            if not reset:
                return bbqbakeswitch_1

            for node in list(bbqbakeswitch_1.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    bbqbakeswitch_1.nodes.remove(node)

                bbqbakeswitch_1.links.clear()

        else:
            bbqbakeswitch_1 = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_bake_switch)

        bbqbakeswitch_1.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_bake_switch)

        if group_input is None:
            group_input = bbqbakeswitch_1.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket Index
            try:
                index_socket = bbqbakeswitch_1.interface.new_socket(
                    name="Index", in_out='INPUT', socket_type='NodeSocketInt'
                )
                index_socket.default_value = 0
                index_socket.min_value = -2147483648
                index_socket.max_value = 2147483647
            except TypeError:
                index_socket = bbqbakeswitch_1.interface.new_socket(
                    name="Index", in_out='INPUT', socket_type='NodeSocketFloat'
                )
                index_socket.default_value = 0.0
                index_socket.min_value = -3.4028234663852886e+38
                index_socket.max_value = 3.4028234663852886e+38

            index_socket.subtype = 'NONE'
            index_socket.attribute_domain = 'POINT'

            # Socket TangentSpaceNormalMap
            tangentspacenormalmap_socket = bbqbakeswitch_1.interface.new_socket(name="TangentSpaceNormalMap", in_out='INPUT', socket_type='NodeSocketColor')
            tangentspacenormalmap_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            tangentspacenormalmap_socket.attribute_domain = 'POINT'

            # Socket AmbientOcclusion
            ambientocclusion_socket = bbqbakeswitch_1.interface.new_socket(name="AmbientOcclusion", in_out='INPUT', socket_type='NodeSocketColor')
            ambientocclusion_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            ambientocclusion_socket.attribute_domain = 'POINT'

            # Socket Curvature
            curvature_socket = bbqbakeswitch_1.interface.new_socket(name="BbqBakeCurvature", in_out='INPUT', socket_type='NodeSocketColor')
            curvature_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            curvature_socket.attribute_domain = 'POINT'

            # Socket Convexity
            convexity_socket = bbqbakeswitch_1.interface.new_socket(name="Convexity", in_out='INPUT', socket_type='NodeSocketColor')
            convexity_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            convexity_socket.attribute_domain = 'POINT'

            # Socket Concavity
            concavity_socket = bbqbakeswitch_1.interface.new_socket(name="Concavity", in_out='INPUT', socket_type='NodeSocketColor')
            concavity_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            concavity_socket.attribute_domain = 'POINT'

            # Socket BevelsMask
            bevelsmask_socket = bbqbakeswitch_1.interface.new_socket(name="BevelsMask", in_out='INPUT', socket_type='NodeSocketColor')
            bevelsmask_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            bevelsmask_socket.attribute_domain = 'POINT'

            # Socket PartsID
            partsid_socket = bbqbakeswitch_1.interface.new_socket(name="PartsID", in_out='INPUT', socket_type='NodeSocketColor')
            partsid_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            partsid_socket.attribute_domain = 'POINT'

            # Socket MaterialsID
            materialsid_socket = bbqbakeswitch_1.interface.new_socket(name="MaterialsID", in_out='INPUT', socket_type='NodeSocketColor')
            materialsid_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            materialsid_socket.attribute_domain = 'POINT'

            # Socket ObjectSpaceNormalMap
            objectspacenormalmap_socket = bbqbakeswitch_1.interface.new_socket(name="ObjectSpaceNormalMap", in_out='INPUT', socket_type='NodeSocketColor')
            objectspacenormalmap_socket.default_value = (0.0, 0.0, 0.0, 1.0)
            objectspacenormalmap_socket.attribute_domain = 'POINT'

            # Socket BevelsPreview
            bevelspreview_socket = bbqbakeswitch_1.interface.new_socket(name="BevelsPreview", in_out='INPUT', socket_type='NodeSocketShader')
            bevelspreview_socket.attribute_domain = 'POINT'

        if group_output is None:
            group_output = bbqbakeswitch_1.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Shader
            shader_socket = bbqbakeswitch_1.interface.new_socket(name="Shader", in_out='OUTPUT', socket_type='NodeSocketShader')
            shader_socket.attribute_domain = 'POINT'

        # Initialize bbqbakeswitch_1 nodes

        # Node Math
        math = bbqbakeswitch_1.nodes.new("ShaderNodeMath")
        math.name = "Math"
        math.show_options = True
        math.operation = 'COMPARE'
        math.use_clamp = False
        # Value_001
        math.inputs[1].default_value = 1.0
        # Value_002
        math.inputs[2].default_value = 0.009999999776482582

        # Node Mix
        mix = bbqbakeswitch_1.nodes.new("ShaderNodeMix")
        mix.name = "Mix"
        mix.show_options = True
        mix.blend_type = 'MIX'
        mix.clamp_factor = True
        mix.clamp_result = False
        mix.data_type = 'RGBA'
        mix.factor_mode = 'UNIFORM'

        # Node Math.001
        math_001 = bbqbakeswitch_1.nodes.new("ShaderNodeMath")
        math_001.name = "Math.001"
        math_001.show_options = True
        math_001.operation = 'COMPARE'
        math_001.use_clamp = False
        # Value_001
        math_001.inputs[1].default_value = 2.0
        # Value_002
        math_001.inputs[2].default_value = 0.009999999776482582

        # Node Mix.001
        mix_001 = bbqbakeswitch_1.nodes.new("ShaderNodeMix")
        mix_001.name = "Mix.001"
        mix_001.show_options = True
        mix_001.blend_type = 'MIX'
        mix_001.clamp_factor = True
        mix_001.clamp_result = False
        mix_001.data_type = 'RGBA'
        mix_001.factor_mode = 'UNIFORM'

        # Node Math.002
        math_002 = bbqbakeswitch_1.nodes.new("ShaderNodeMath")
        math_002.name = "Math.002"
        math_002.show_options = True
        math_002.operation = 'COMPARE'
        math_002.use_clamp = False
        # Value_001
        math_002.inputs[1].default_value = 3.0
        # Value_002
        math_002.inputs[2].default_value = 0.009999999776482582

        # Node Mix.002
        mix_002 = bbqbakeswitch_1.nodes.new("ShaderNodeMix")
        mix_002.name = "Mix.002"
        mix_002.show_options = True
        mix_002.blend_type = 'MIX'
        mix_002.clamp_factor = True
        mix_002.clamp_result = False
        mix_002.data_type = 'RGBA'
        mix_002.factor_mode = 'UNIFORM'

        # Node Math.003
        math_003 = bbqbakeswitch_1.nodes.new("ShaderNodeMath")
        math_003.name = "Math.003"
        math_003.show_options = True
        math_003.operation = 'COMPARE'
        math_003.use_clamp = False
        # Value_001
        math_003.inputs[1].default_value = 4.0
        # Value_002
        math_003.inputs[2].default_value = 0.009999999776482582

        # Node Mix.003
        mix_003 = bbqbakeswitch_1.nodes.new("ShaderNodeMix")
        mix_003.name = "Mix.003"
        mix_003.show_options = True
        mix_003.blend_type = 'MIX'
        mix_003.clamp_factor = True
        mix_003.clamp_result = False
        mix_003.data_type = 'RGBA'
        mix_003.factor_mode = 'UNIFORM'

        # Node Math.004
        math_004 = bbqbakeswitch_1.nodes.new("ShaderNodeMath")
        math_004.name = "Math.004"
        math_004.show_options = True
        math_004.operation = 'COMPARE'
        math_004.use_clamp = False
        # Value_001
        math_004.inputs[1].default_value = 5.0
        # Value_002
        math_004.inputs[2].default_value = 0.009999999776482582

        # Node Mix.004
        mix_004 = bbqbakeswitch_1.nodes.new("ShaderNodeMix")
        mix_004.name = "Mix.004"
        mix_004.show_options = True
        mix_004.blend_type = 'MIX'
        mix_004.clamp_factor = True
        mix_004.clamp_result = False
        mix_004.data_type = 'RGBA'
        mix_004.factor_mode = 'UNIFORM'

        # Node Math.005
        math_005 = bbqbakeswitch_1.nodes.new("ShaderNodeMath")
        math_005.name = "Math.005"
        math_005.show_options = True
        math_005.operation = 'COMPARE'
        math_005.use_clamp = False
        # Value_001
        math_005.inputs[1].default_value = 6.0
        # Value_002
        math_005.inputs[2].default_value = 0.009999999776482582

        # Node Mix.005
        mix_005 = bbqbakeswitch_1.nodes.new("ShaderNodeMix")
        mix_005.name = "Mix.005"
        mix_005.show_options = True
        mix_005.blend_type = 'MIX'
        mix_005.clamp_factor = True
        mix_005.clamp_result = False
        mix_005.data_type = 'RGBA'
        mix_005.factor_mode = 'UNIFORM'

        # Node Math.006
        math_006 = bbqbakeswitch_1.nodes.new("ShaderNodeMath")
        math_006.name = "Math.006"
        math_006.show_options = True
        math_006.operation = 'COMPARE'
        math_006.use_clamp = False
        # Value_001
        math_006.inputs[1].default_value = 7.0
        # Value_002
        math_006.inputs[2].default_value = 0.009999999776482582

        # Node Mix.006
        mix_006 = bbqbakeswitch_1.nodes.new("ShaderNodeMix")
        mix_006.name = "Mix.006"
        mix_006.show_options = True
        mix_006.blend_type = 'MIX'
        mix_006.clamp_factor = True
        mix_006.clamp_result = False
        mix_006.data_type = 'RGBA'
        mix_006.factor_mode = 'UNIFORM'

        # Node Math.007
        math_007 = bbqbakeswitch_1.nodes.new("ShaderNodeMath")
        math_007.name = "Math.007"
        math_007.show_options = True
        math_007.operation = 'COMPARE'
        math_007.use_clamp = False
        # Value_001
        math_007.inputs[1].default_value = 8.0
        # Value_002
        math_007.inputs[2].default_value = 0.009999999776482582

        # Node Mix.007
        mix_007 = bbqbakeswitch_1.nodes.new("ShaderNodeMix")
        mix_007.name = "Mix.007"
        mix_007.show_options = True
        mix_007.blend_type = 'MIX'
        mix_007.clamp_factor = True
        mix_007.clamp_result = False
        mix_007.data_type = 'RGBA'
        mix_007.factor_mode = 'UNIFORM'

        # Node Math.008
        math_008 = bbqbakeswitch_1.nodes.new("ShaderNodeMath")
        math_008.name = "Math.008"
        math_008.show_options = True
        math_008.operation = 'COMPARE'
        math_008.use_clamp = False
        # Value_001
        math_008.inputs[1].default_value = 9.0
        # Value_002
        math_008.inputs[2].default_value = 0.009999999776482582

        # Node Mix Shader
        mix_shader = bbqbakeswitch_1.nodes.new("ShaderNodeMixShader")
        mix_shader.name = "Mix Shader"
        mix_shader.show_options = True

        # Node Emission
        emission = bbqbakeswitch_1.nodes.new("ShaderNodeEmission")
        emission.name = "Emission"
        emission.show_options = True
        # Strength
        emission.inputs[1].default_value = 1.0

        # Set locations
        bbqbakeswitch_1.nodes["Group Input"].location = (-400.0, 0.0)
        bbqbakeswitch_1.nodes["Group Output"].location = (3180.0, 0.0)
        bbqbakeswitch_1.nodes["Math"].location = (0.0, 160.0)
        bbqbakeswitch_1.nodes["Mix"].location = (0.0, -60.0)
        bbqbakeswitch_1.nodes["Math.001"].location = (360.0, 160.0)
        bbqbakeswitch_1.nodes["Mix.001"].location = (360.0, -60.0)
        bbqbakeswitch_1.nodes["Math.002"].location = (700.0, 160.0)
        bbqbakeswitch_1.nodes["Mix.002"].location = (700.0, -60.0)
        bbqbakeswitch_1.nodes["Math.003"].location = (1060.0, 160.0)
        bbqbakeswitch_1.nodes["Mix.003"].location = (1060.0, -60.0)
        bbqbakeswitch_1.nodes["Math.004"].location = (1400.0, 160.0)
        bbqbakeswitch_1.nodes["Mix.004"].location = (1400.0, -60.0)
        bbqbakeswitch_1.nodes["Math.005"].location = (1720.0, 160.0)
        bbqbakeswitch_1.nodes["Mix.005"].location = (1720.0, -60.0)
        bbqbakeswitch_1.nodes["Math.006"].location = (2000.0, 160.0)
        bbqbakeswitch_1.nodes["Mix.006"].location = (2000.0, -60.0)
        bbqbakeswitch_1.nodes["Math.007"].location = (2260.0, 160.0)
        bbqbakeswitch_1.nodes["Mix.007"].location = (2260.0, -60.0)
        bbqbakeswitch_1.nodes["Math.008"].location = (2580.0, 160.0)
        bbqbakeswitch_1.nodes["Mix Shader"].location = (2840.0, -240.0)
        bbqbakeswitch_1.nodes["Emission"].location = (2580.0, -140.0)

        # Initialize bbqbakeswitch_1 links

        # group_input.Index -> math.Value
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[0],
            bbqbakeswitch_1.nodes["Math"].inputs[0]
        )
        # math.Value -> mix.Factor
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Math"].outputs[0],
            bbqbakeswitch_1.nodes["Mix"].inputs[0]
        )
        # group_input.AmbientOcclusion -> mix.B
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[2],
            bbqbakeswitch_1.nodes["Mix"].inputs[7]
        )
        # group_input.Index -> math_001.Value
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[0],
            bbqbakeswitch_1.nodes["Math.001"].inputs[0]
        )
        # math_001.Value -> mix_001.Factor
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Math.001"].outputs[0],
            bbqbakeswitch_1.nodes["Mix.001"].inputs[0]
        )
        # mix.Result -> mix_001.A
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Mix"].outputs[2],
            bbqbakeswitch_1.nodes["Mix.001"].inputs[6]
        )
        # group_input.Curvature -> mix_001.B
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[3],
            bbqbakeswitch_1.nodes["Mix.001"].inputs[7]
        )
        # group_input.Index -> math_002.Value
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[0],
            bbqbakeswitch_1.nodes["Math.002"].inputs[0]
        )
        # math_002.Value -> mix_002.Factor
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Math.002"].outputs[0],
            bbqbakeswitch_1.nodes["Mix.002"].inputs[0]
        )
        # mix_001.Result -> mix_002.A
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Mix.001"].outputs[2],
            bbqbakeswitch_1.nodes["Mix.002"].inputs[6]
        )
        # group_input.Convexity -> mix_002.B
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[4],
            bbqbakeswitch_1.nodes["Mix.002"].inputs[7]
        )
        # group_input.Index -> math_003.Value
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[0],
            bbqbakeswitch_1.nodes["Math.003"].inputs[0]
        )
        # math_003.Value -> mix_003.Factor
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Math.003"].outputs[0],
            bbqbakeswitch_1.nodes["Mix.003"].inputs[0]
        )
        # mix_002.Result -> mix_003.A
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Mix.002"].outputs[2],
            bbqbakeswitch_1.nodes["Mix.003"].inputs[6]
        )
        # group_input.Concavity -> mix_003.B
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[5],
            bbqbakeswitch_1.nodes["Mix.003"].inputs[7]
        )
        # group_input.Index -> math_004.Value
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[0],
            bbqbakeswitch_1.nodes["Math.004"].inputs[0]
        )
        # math_004.Value -> mix_004.Factor
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Math.004"].outputs[0],
            bbqbakeswitch_1.nodes["Mix.004"].inputs[0]
        )
        # mix_003.Result -> mix_004.A
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Mix.003"].outputs[2],
            bbqbakeswitch_1.nodes["Mix.004"].inputs[6]
        )
        # group_input.BevelsMask -> mix_004.B
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[6],
            bbqbakeswitch_1.nodes["Mix.004"].inputs[7]
        )
        # math_005.Value -> mix_005.Factor
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Math.005"].outputs[0],
            bbqbakeswitch_1.nodes["Mix.005"].inputs[0]
        )
        # group_input.Index -> math_005.Value
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[0],
            bbqbakeswitch_1.nodes["Math.005"].inputs[0]
        )
        # mix_004.Result -> mix_005.A
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Mix.004"].outputs[2],
            bbqbakeswitch_1.nodes["Mix.005"].inputs[6]
        )
        # group_input.PartsID -> mix_005.B
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[7],
            bbqbakeswitch_1.nodes["Mix.005"].inputs[7]
        )
        # math_006.Value -> mix_006.Factor
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Math.006"].outputs[0],
            bbqbakeswitch_1.nodes["Mix.006"].inputs[0]
        )
        # math_007.Value -> mix_007.Factor
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Math.007"].outputs[0],
            bbqbakeswitch_1.nodes["Mix.007"].inputs[0]
        )
        # group_input.Index -> math_006.Value
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[0],
            bbqbakeswitch_1.nodes["Math.006"].inputs[0]
        )
        # group_input.Index -> math_007.Value
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[0],
            bbqbakeswitch_1.nodes["Math.007"].inputs[0]
        )
        # group_input.Index -> math_008.Value
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[0],
            bbqbakeswitch_1.nodes["Math.008"].inputs[0]
        )
        # group_input.MaterialsID -> mix_006.B
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[8],
            bbqbakeswitch_1.nodes["Mix.006"].inputs[7]
        )
        # mix_005.Result -> mix_006.A
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Mix.005"].outputs[2],
            bbqbakeswitch_1.nodes["Mix.006"].inputs[6]
        )
        # mix_006.Result -> mix_007.A
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Mix.006"].outputs[2],
            bbqbakeswitch_1.nodes["Mix.007"].inputs[6]
        )
        # group_input.ObjectSpaceNormalMap -> mix_007.B
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[9],
            bbqbakeswitch_1.nodes["Mix.007"].inputs[7]
        )
        # math_008.Value -> mix_shader.Factor
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Math.008"].outputs[0],
            bbqbakeswitch_1.nodes["Mix Shader"].inputs[0]
        )
        # mix_shader.Shader -> group_output.Shader
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Mix Shader"].outputs[0],
            bbqbakeswitch_1.nodes["Group Output"].inputs[0]
        )
        # mix_007.Result -> emission.Color
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Mix.007"].outputs[2],
            bbqbakeswitch_1.nodes["Emission"].inputs[0]
        )
        # emission.Emission -> mix_shader.Shader
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Emission"].outputs[0],
            bbqbakeswitch_1.nodes["Mix Shader"].inputs[1]
        )
        # group_input.BevelsPreview -> mix_shader.Shader
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[1],
            bbqbakeswitch_1.nodes["Mix"].inputs[6]
        )
        # group_input.TangentSpaceNormalMap -> mix.A
        bbqbakeswitch_1.links.new(
            bbqbakeswitch_1.nodes["Group Input"].outputs[10],
            bbqbakeswitch_1.nodes["Mix Shader"].inputs[2]
        )

        return bbqbakeswitch_1

    # MARK: Preview Shader Group
    @classmethod
    def build_preview_shader_ng(cls, nodeGroup, node_tree_names: dict[typing.Callable, str], target_material, reset=True):

        # Node Attribute Preview Type index
        attr_node_preview_map_index = nodeGroup.nodes.new("ShaderNodeAttribute")
        attr_node_preview_map_index.name = "PreviewTypeIndex"
        attr_node_preview_map_index.show_options = True
        attr_node_preview_map_index.attribute_name = 'zen_bbq.preview_map_index'
        attr_node_preview_map_index.attribute_type = 'VIEW_LAYER'

        # Node Attribute isDirectX
        attr_node_is_direct_x = nodeGroup.nodes.new("ShaderNodeAttribute")
        attr_node_is_direct_x.name = "IsDirectX"
        attr_node_is_direct_x.show_options = True
        attr_node_is_direct_x.attribute_name = 'zen_bbq.is_direct_x'
        attr_node_is_direct_x.attribute_type = 'VIEW_LAYER'

        # Node Attribute is Baking Active
        attr_node_is_baking_active = nodeGroup.nodes.new("ShaderNodeAttribute")
        attr_node_is_baking_active.name = "IsBakingActive"
        attr_node_is_baking_active.show_options = True
        attr_node_is_baking_active.attribute_name = 'zen_bbq.is_baking_active'
        attr_node_is_baking_active.attribute_type = 'VIEW_LAYER'

        # Node Attribute is DisableNormalOverride
        attr_node_disable_normal = nodeGroup.nodes.new("ShaderNodeAttribute")
        attr_node_disable_normal.name = "DisableNormalOverride"
        attr_node_disable_normal.show_options = True
        attr_node_disable_normal.attribute_name = 'zen_bbq.use_bbq_engine'
        attr_node_disable_normal.attribute_type = 'VIEW_LAYER'

        # Node Attribute Ambient Occlusion Distance
        attr_node_ao_distance = nodeGroup.nodes.new("ShaderNodeAttribute")
        attr_node_ao_distance.name = "AoDistance"
        attr_node_ao_distance.show_options = True
        attr_node_ao_distance.attribute_name = "zen_bbq.ao_distance"
        attr_node_ao_distance.attribute_type = 'VIEW_LAYER'

        # Node Cavity Distance
        attr_node_cavity_distance = nodeGroup.nodes.new("ShaderNodeAttribute")
        attr_node_cavity_distance.name = "Cavity Distance"
        attr_node_cavity_distance.show_options = True
        attr_node_cavity_distance.attribute_name = "zen_bbq.cavity_distance"
        attr_node_cavity_distance.attribute_type = 'VIEW_LAYER'

        # Node Normals Mixer
        ng_normals_mixer = nodeGroup.nodes.new("ShaderNodeGroup")
        ng_normals_mixer.name = ZBBQ_Consts.node_tree_service_normal_mixer_name
        ng_normals_mixer.show_options = True
        ng_normals_mixer.node_tree = cls.build_service_normals_mixer_ng(reset=reset)
        # Socket_3
        ng_normals_mixer.inputs["Normal"].default_value = (0.0, 0.0, 0.0)
        # Socket_4
        ng_normals_mixer.inputs["Factor"].default_value = 0.0

        # Node QualityAO
        node_quality_ao = nodeGroup.nodes.new("ShaderNodeAmbientOcclusion")
        node_quality_ao.label = "QualityAO"
        node_quality_ao.name = "QualityAO"
        node_quality_ao.show_options = True
        node_quality_ao.inside = False
        node_quality_ao.only_local = False
        node_quality_ao.samples = 32
        # Color
        node_quality_ao.inputs[0].default_value = (1.0, 1.0, 1.0, 1.0)
        # Distance
        node_quality_ao.inputs[1].default_value = 0.08
        # Normal
        node_quality_ao.inputs[2].default_value = (0.0, 0.0, 0.0)

        # Node Reroute
        reroute = nodeGroup.nodes.new("NodeReroute")
        reroute.name = "RerouteBevelNormal"
        reroute.show_options = True
        # reroute.socket_idname = "NodeSocketVector"
        # Node Reroute.001
        reroute_001 = nodeGroup.nodes.new("NodeReroute")
        reroute_001.name = "Reroute.001"
        reroute_001.show_options = True
        # reroute_001.socket_idname = "NodeSocketFloat"
        # Node RerouteGeomNormal
        reroute_002 = nodeGroup.nodes.new("NodeReroute")
        reroute_002.name = "RerouteGeomNormal"
        reroute_002.show_options = True
        # reroute_002.socket_idname = "NodeSocketVector"

        # Node Geometry.003
        geometry_003 = nodeGroup.nodes.new("ShaderNodeNewGeometry")
        geometry_003.name = "Geometry.003"
        geometry_003.show_options = True
        geometry_003.outputs[0].hide = True
        geometry_003.outputs[1].hide = False
        geometry_003.outputs[2].hide = True
        geometry_003.outputs[3].hide = True
        geometry_003.outputs[4].hide = True
        geometry_003.outputs[5].hide = True
        geometry_003.outputs[6].hide = True
        geometry_003.outputs[7].hide = True
        geometry_003.outputs[8].hide = False

        # Node BbqPreviewTangentNormals
        node_shader_bsdf_preview_tangent_normal = cls.compound_bsdf_overrider_node(nodeGroup)

        # Node BbqBakeCurvature
        curvature = nodeGroup.nodes.new("ShaderNodeGroup")
        curvature.name = "BbqBakeCurvature"
        curvature.show_options = True
        curvature.node_tree = bpy.data.node_groups[node_tree_names[cls.build_curvature_ng]]

        # Node Group
        convex_bev_mask_group = nodeGroup.nodes.new("ShaderNodeGroup")
        convex_bev_mask_group.name = "BbqBakeConvexityBevelsMask"
        convex_bev_mask_group.show_options = True
        convex_bev_mask_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_convexity_bevels_mask_ng]]

        # Node BbqBakeAmbientOcclusion
        ambient_occlusion_group = nodeGroup.nodes.new("ShaderNodeGroup")
        ambient_occlusion_group.name = ZBBQ_Consts.node_tree_service_ao_name
        ambient_occlusion_group.show_options = True
        ambient_occlusion_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_ambient_occlusion_ng]]

        # Node BbqBakeConcavityBevelsMask
        concav_bev_mask_group = nodeGroup.nodes.new("ShaderNodeGroup")
        concav_bev_mask_group.name = "BbqBakeConcavityBevelsMask"
        concav_bev_mask_group.show_options = True
        concav_bev_mask_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_concavity_bevels_mask_ng]]

        # Node BbqBakeBevelsMask
        bevels_mask_group = nodeGroup.nodes.new("ShaderNodeGroup")
        bevels_mask_group.name = "BbqBakeBevelsMask"
        bevels_mask_group.show_options = True
        bevels_mask_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_bevels_mask_ng]]

        # Node BbqBakePartsID
        parts_id_group = nodeGroup.nodes.new("ShaderNodeGroup")
        parts_id_group.name = "BbqBakePartsID"
        parts_id_group.show_options = True
        parts_id_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_parts_id_ng]]

        # Node BbqBakeMaterialsID
        materials_id_group = nodeGroup.nodes.new("ShaderNodeGroup")
        materials_id_group.name = "BbqBakeMaterialsID"
        materials_id_group.show_options = True
        # materials_id_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_materials_id_ng]]
        materials_id_group.node_tree = cls.build_materials_id_ng(target_material, reset)

        # Node BbqBakeObjectSpaceNormal
        obj_space_normals_group = nodeGroup.nodes.new("ShaderNodeGroup")
        obj_space_normals_group.name = "BbqBakeObjectSpaceNormal"
        obj_space_normals_group.show_options = True
        obj_space_normals_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_object_space_normal_ng]]

        # Node BbqBakeTangentSpaceNormal
        tang_space_normals_group = nodeGroup.nodes.new("ShaderNodeGroup")
        tang_space_normals_group.name = "BbqBakeTangentSpaceNormal"
        tang_space_normals_group.show_options = True
        tang_space_normals_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_tangent_space_normal_ng]]

        # Node BbqBakeSwitch
        types_switch_group = nodeGroup.nodes.new("ShaderNodeGroup")
        types_switch_group.name = "BbqBakeSwitch"
        types_switch_group.show_options = True
        types_switch_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_types_switch_ng]]

        # Node IndexSwitch
        types_switch_group = nodeGroup.nodes.new("ShaderNodeGroup")
        types_switch_group.name = "IndexSwitch"
        types_switch_group.show_options = True
        types_switch_group.node_tree = bpy.data.node_groups[node_tree_names[cls.build_index_switch_ng]]

        # Set locations
        nodeGroup.nodes["Group Input"].location = (-1356.0303955078125, -207.83897399902344)
        nodeGroup.nodes["Group Output"].location = (1240.0, -560.0)
        nodeGroup.nodes["BbqServiceNormalsMixer"].location = (-1020.0, -140.0)
        nodeGroup.nodes["QualityAO"].location = (-1020.0, 120.0)
        nodeGroup.nodes["RerouteBevelNormal"].location = (-440.0, -860.0)
        nodeGroup.nodes["Reroute.001"].location = (-520.0, -260.0)
        nodeGroup.nodes["Geometry.003"].location = (-1020.0, -420.0)
        nodeGroup.nodes["RerouteGeomNormal"].location = (-460.0, -1080.0)
        node_shader_bsdf_preview_tangent_normal.location = (-220.0, -1180.0)
        nodeGroup.nodes["BbqBakeCurvature"].location = (140.0, 140.0)
        nodeGroup.nodes["BbqBakeConvexityBevelsMask"].location = (-220.0, 40.0)
        nodeGroup.nodes["BbqBakeAmbientOcclusion"].location = (-220.0, 240.0)
        nodeGroup.nodes["BbqBakeConcavityBevelsMask"].location = (-220.0, -160.0)
        nodeGroup.nodes["BbqBakeBevelsMask"].location = (-220.0, -380.0)
        nodeGroup.nodes["BbqBakePartsID"].location = (-220.0, -540.0)
        nodeGroup.nodes["BbqBakeMaterialsID"].location = (-220.0, -700.0)
        nodeGroup.nodes["BbqBakeObjectSpaceNormal"].location = (-220.0, -840.0)
        nodeGroup.nodes["BbqBakeTangentSpaceNormal"].location = (-220.0, -1000.0)
        nodeGroup.nodes["BbqBakeSwitch"].location = (720.0, -400.0)

        nodeGroup.nodes["PreviewTypeIndex"].location = (-1020.0, -620.0)
        nodeGroup.nodes["IsDirectX"].location = (-1020.0, -820.0)
        nodeGroup.nodes["IsBakingActive"].location = (-1020.0, -1020.0)
        nodeGroup.nodes["DisableNormalOverride"].location = (-1020.0, -1220.0)
        nodeGroup.nodes["IndexSwitch"].location = (-685.0, -1089.0)
        nodeGroup.nodes["AoDistance"].location = (-1360.0, 260.0)
        nodeGroup.nodes["Cavity Distance"].location = (-1360.0, 40.0)

        # Initialize zenbbq_previewshader_1 links

        # IndexSwitch -> BbqBakeSwitch.index
        nodeGroup.links.new(
            nodeGroup.nodes["IndexSwitch"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs[0]
        )
        # outnormalshader.BSDF -> group_009.BevelsPreview
        nodeGroup.links.new(
            node_shader_bsdf_preview_tangent_normal.outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs["BevelsPreview"]
        )
        # group_002.Color -> group_009.AmbientOcclusion
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeAmbientOcclusion"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs[2]
        )
        # curvature.Result -> group_009.Curvature
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeCurvature"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs[3]
        )
        # group.Result -> group_009.Convexity
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeConvexityBevelsMask"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs[4]
        )
        # group_003.Color -> group_009.Concavity
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeConcavityBevelsMask"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs[5]
        )
        # group_004.Color -> group_009.BevelsMask
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeBevelsMask"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs[6]
        )
        # group_005.Color -> group_009.PartsID
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakePartsID"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs[7]
        )
        # group_006.Color -> group_009.MaterialID
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeMaterialsID"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs[8]
        )
        # group_007.Vector -> group_009.ObjectSpaceNormal
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeObjectSpaceNormal"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs[9]
        )
        # group_008.Result -> group_009.TangentSpaceNormal
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeTangentSpaceNormal"].outputs[0],
            nodeGroup.nodes["BbqBakeSwitch"].inputs["TangentSpaceNormalMap"]
        )
        # group_009.Shader -> group_output.Shader
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeSwitch"].outputs[0],
            nodeGroup.nodes["Group Output"].inputs[0]
        )
        # group_input.Index -> group_009.Index
        # nodeGroup.links.new(
        #     nodeGroup.nodes["Group Input"].outputs[1],
        #     nodeGroup.nodes["BbqBakeSwitch"].inputs[0]
        # )
        # group_001.Bevels -> reroute.Input
        nodeGroup.links.new(
            nodeGroup.nodes["BbqServiceNormalsMixer"].outputs["Bevels"],
            nodeGroup.nodes["RerouteBevelNormal"].inputs[0]
        )
        # group_001.Mask -> reroute_001.Input
        nodeGroup.links.new(
            nodeGroup.nodes["BbqServiceNormalsMixer"].outputs["Mask"],
            nodeGroup.nodes["Reroute.001"].inputs[0]
        )
        # geometry_003.Normal -> reroute_002.Input
        nodeGroup.links.new(
            nodeGroup.nodes["Geometry.003"].outputs[1],
            nodeGroup.nodes["RerouteGeomNormal"].inputs[0]
        )
        # reroute_001.Output -> group.Factor
        nodeGroup.links.new(
            nodeGroup.nodes["Reroute.001"].outputs[0],
            nodeGroup.nodes["BbqBakeConvexityBevelsMask"].inputs[0]
        )
        # qualityao.Color -> group.Factor
        nodeGroup.links.new(
            nodeGroup.nodes["QualityAO"].outputs[0],
            nodeGroup.nodes["BbqBakeConvexityBevelsMask"].inputs[1]
        )
        # group.Result -> curvature.B
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeConvexityBevelsMask"].outputs[1],
            nodeGroup.nodes["BbqBakeCurvature"].inputs[0]
        )
        # geometry_003.Normal -> group_002.A
        nodeGroup.links.new(
            nodeGroup.nodes["Geometry.003"].outputs[1],
            nodeGroup.nodes["BbqBakeAmbientOcclusion"].inputs[1]
        )
        # group_001.Bevels -> group_002.B
        nodeGroup.links.new(
            nodeGroup.nodes["BbqServiceNormalsMixer"].outputs[0],
            nodeGroup.nodes["BbqBakeAmbientOcclusion"].inputs[2]
        )
        # reroute_001.Output -> group_003.Factor
        nodeGroup.links.new(
            nodeGroup.nodes["Reroute.001"].outputs[0],
            nodeGroup.nodes["BbqBakeConcavityBevelsMask"].inputs[0]
        )
        # qualityao.Color -> group_003.Factor
        nodeGroup.links.new(
            nodeGroup.nodes["QualityAO"].outputs[0],
            nodeGroup.nodes["BbqBakeConcavityBevelsMask"].inputs[1]
        )
        # group_003.Color -> curvature.B
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeConcavityBevelsMask"].outputs[1],
            nodeGroup.nodes["BbqBakeCurvature"].inputs[1]
        )
        # group_003.Color -> group_002.Factor
        nodeGroup.links.new(
            nodeGroup.nodes["BbqBakeConcavityBevelsMask"].outputs[2],
            nodeGroup.nodes["BbqBakeAmbientOcclusion"].inputs[0]
        )
        # reroute_001.Output -> group_004.Factor
        nodeGroup.links.new(
            nodeGroup.nodes["Reroute.001"].outputs[0],
            nodeGroup.nodes["BbqBakeBevelsMask"].inputs[0]
        )
        # geometry_003.Random Per Island -> group_005.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["Geometry.003"].outputs[8],
            nodeGroup.nodes["BbqBakePartsID"].inputs[0]
        )
        # reroute.Output -> group_007.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["RerouteBevelNormal"].outputs[0],
            nodeGroup.nodes["BbqBakeObjectSpaceNormal"].inputs[0]
        )
        # reroute_002.Output -> group_008.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["RerouteGeomNormal"].outputs[0],
            nodeGroup.nodes["BbqBakeTangentSpaceNormal"].inputs[1]
        )
        # reroute.Output -> group_008.Vector
        nodeGroup.links.new(
            nodeGroup.nodes["RerouteBevelNormal"].outputs[0],
            nodeGroup.nodes["BbqBakeTangentSpaceNormal"].inputs[0]
        )
        # group_001.Bevels -> outnormalshader.Normal
        nodeGroup.links.new(
            nodeGroup.nodes["BbqServiceNormalsMixer"].outputs[0],
            node_shader_bsdf_preview_tangent_normal.inputs["Normal"]
        )
        # group_input.is DirectX -> group_008.is DirectX
        nodeGroup.links.new(
            nodeGroup.nodes["IsDirectX"].outputs[2],
            nodeGroup.nodes["BbqBakeTangentSpaceNormal"].inputs[2]
        )
        # previewtypeindex.Factor -> group_010.Value
        nodeGroup.links.new(
            nodeGroup.nodes["PreviewTypeIndex"].outputs[2],
            nodeGroup.nodes["IndexSwitch"].inputs[0]
        )
        # isbakingactive.Factor -> group_010.Value
        nodeGroup.links.new(
            nodeGroup.nodes["IsBakingActive"].outputs[2],
            nodeGroup.nodes["IndexSwitch"].inputs[1]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["DisableNormalOverride"].outputs[2],
            nodeGroup.nodes["IndexSwitch"].inputs[2]
        )

        socket_ao_factor = nodeGroup.nodes["AoDistance"].outputs.get("Factor", None)
        if socket_ao_factor is None:
            socket_ao_factor = nodeGroup.nodes["AoDistance"].outputs.get("Fac", None)

        socket_cavity_factor = nodeGroup.nodes["Cavity Distance"].outputs.get("Factor", None)
        if socket_cavity_factor is None:
            socket_cavity_factor = nodeGroup.nodes["Cavity Distance"].outputs.get("Fac", None)

        # # AoDistance.Factor -> qualityao.Distance
        # nodeGroup.links.new(
        #     p_factor,
        #     nodeGroup.nodes["QualityAO"].inputs["Distance"]
        # )
        # previewtypeindex_001.Factor -> bbqbakeambientocclusion.Distance
        nodeGroup.links.new(
            socket_ao_factor,
            nodeGroup.nodes["BbqBakeAmbientOcclusion"].inputs["Distance"]
        )
        nodeGroup.links.new(
            socket_cavity_factor,
            nodeGroup.nodes["QualityAO"].inputs[1]
        )

        return nodeGroup

    # MARK: Index Switch Group
    @staticmethod
    def build_index_switch_ng(reset=True):

        from ..commonFunc import ZBBQ_MaterialFunc

        nodeGroup = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_index_switch)
        group_input = None
        group_output = None

        if nodeGroup:
            if not reset:
                return nodeGroup

            for node in list(nodeGroup.nodes):
                if node.type == 'GROUP_INPUT':
                    group_input = node
                elif node.type == 'GROUP_OUTPUT':
                    group_output = node
                else:
                    nodeGroup.nodes.remove(node)

            nodeGroup.links.clear()

        else:
            nodeGroup = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_index_switch)

        nodeGroup.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_index_switch)

        if group_input is None:

            group_input = nodeGroup.nodes.new("NodeGroupInput")
            group_input.name = "Group Input"
            group_input.show_options = True

            # Socket Value
            value_socket_1 = nodeGroup.interface.new_socket(name="preview_map_index", in_out='INPUT', socket_type='NodeSocketFloat')
            value_socket_1.default_value = 0.5
            value_socket_1.min_value = -10000.0
            value_socket_1.max_value = 10000.0
            value_socket_1.subtype = 'NONE'
            value_socket_1.attribute_domain = 'POINT'

            # Socket Value
            value_socket_2 = nodeGroup.interface.new_socket(name="is_baking_active", in_out='INPUT', socket_type='NodeSocketFloat')
            value_socket_2.default_value = 0.5
            value_socket_2.min_value = -10000.0
            value_socket_2.max_value = 10000.0
            value_socket_2.subtype = 'NONE'
            value_socket_2.attribute_domain = 'POINT'

            # Socket use_bbq_engine
            use_bbq_engine_socket = nodeGroup.interface.new_socket(name="use_bbq_engine", in_out='INPUT', socket_type='NodeSocketBool')
            use_bbq_engine_socket.default_value = True
            use_bbq_engine_socket.attribute_domain = 'POINT'

        if group_output is None:
            # Socket Value
            value_socket = nodeGroup.interface.new_socket(name="Value", in_out='OUTPUT', socket_type='NodeSocketFloat')
            value_socket.default_value = 0.0
            value_socket.min_value = -3.4028234663852886e+38
            value_socket.max_value = 3.4028234663852886e+38
            value_socket.subtype = 'NONE'
            value_socket.attribute_domain = 'POINT'

            group_output = nodeGroup.nodes.new("NodeGroupOutput")
            group_output.name = "Group Output"
            group_output.show_options = True
            group_output.is_active_output = True

            # Socket Value
            value_socket = nodeGroup.interface.new_socket(name="Value", in_out='OUTPUT', socket_type='NodeSocketFloat')
            value_socket.default_value = 0.0
            value_socket.min_value = -3.4028234663852886e+38
            value_socket.max_value = 3.4028234663852886e+38
            value_socket.subtype = 'NONE'
            value_socket.attribute_domain = 'POINT'

        # Initialize indexswitch_1 nodes

        # Node Math
        math = nodeGroup.nodes.new("ShaderNodeMath")
        math.name = "Math"
        math.show_options = True
        math.operation = 'COMPARE'
        math.use_clamp = False
        # Value_001
        math.inputs[1].default_value = 0.0
        # Value_002
        math.inputs[2].default_value = 0.001

        # Node Math.001
        math_001 = nodeGroup.nodes.new("ShaderNodeMath")
        math_001.name = "Math.001"
        math_001.show_options = True
        math_001.operation = 'SUBTRACT'
        math_001.use_clamp = False
        # Value
        math_001.inputs[0].default_value = 1.0

        # Node Math.002
        math_002 = nodeGroup.nodes.new("ShaderNodeMath")
        math_002.name = "Math.002"
        math_002.show_options = True
        math_002.operation = 'MULTIPLY'
        math_002.use_clamp = False

        # Node Math.003
        math_003 = nodeGroup.nodes.new("ShaderNodeMath")
        math_003.name = "Math.003"
        math_003.show_options = True
        math_003.operation = 'ADD'
        math_003.use_clamp = False

        # Node Math.004
        math_004 = nodeGroup.nodes.new("ShaderNodeMath")
        math_004.name = "Math.004"
        math_004.show_options = True
        math_004.operation = 'MULTIPLY'
        math_004.use_clamp = False
        # Value_001
        math_004.inputs[1].default_value = 9.0

        math_not_engine = nodeGroup.nodes.new("ShaderNodeMath")
        math_not_engine.name = "Math.NotEngine"
        math_not_engine.operation = 'SUBTRACT'
        math_not_engine.inputs[0].default_value = 1.0

        math_baking_no_engine = nodeGroup.nodes.new("ShaderNodeMath")
        math_baking_no_engine.name = "Math.BakingNoEngine"
        math_baking_no_engine.operation = 'MULTIPLY'

        math_add_condition = nodeGroup.nodes.new("ShaderNodeMath")
        math_add_condition.name = "Math.AddCondition"
        math_add_condition.operation = 'ADD'

        # Set locations
        # nodeGroup.nodes["Group Input"].location = (-420.0, 0.0)
        # nodeGroup.nodes["Group Output"].location = (760.0, 0.0)
        # nodeGroup.nodes["Math"].location = (-180.0, 140.0)
        # nodeGroup.nodes["Math.001"].location = (-180.0, -80.0)
        # nodeGroup.nodes["Math.002"].location = (180.0, 140.0)
        # nodeGroup.nodes["Math.003"].location = (560.0, 40.0)
        # nodeGroup.nodes["Math.004"].location = (360.0, 140.0)

        # math_not_engine.location = (-180.0, -240.0)
        # math_baking_no_engine.location = (0.0, -160.0)
        # math_add_condition.location = (0.0, -20.0)

        nodeGroup.nodes['Group Input'].location = (-420.0, 0.0)
        nodeGroup.nodes['Group Output'].location = (1000.0, -20.0)
        nodeGroup.nodes['Math'].location = (-180.0, 140.0)
        nodeGroup.nodes['Math.001'].location = (-180.0, -80.0)
        nodeGroup.nodes['Math.002'].location = (420.0, 120.0)
        nodeGroup.nodes['Math.003'].location = (800.0, 20.0)
        nodeGroup.nodes['Math.004'].location = (600.0, 120.0)
        nodeGroup.nodes['Math.NotEngine'].location = (-180.0, -460.0)
        nodeGroup.nodes['Math.BakingNoEngine'].location = (0.0, -280.0)
        nodeGroup.nodes['Math.AddCondition'].location = (200.0, -120.0)

        # Initialize indexswitch_1 links

        # group_input.Value -> math.Value
        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[0],
            nodeGroup.nodes["Math"].inputs[0]
        )
        # math_003.Value -> group_output.Value
        nodeGroup.links.new(
            nodeGroup.nodes["Math.003"].outputs[0],
            nodeGroup.nodes["Group Output"].inputs[0]
        )
        # math.Value -> math_002.Value
        nodeGroup.links.new(
            nodeGroup.nodes["Math"].outputs[0],
            nodeGroup.nodes["Math.002"].inputs[0]
        )
        # math_002.Value -> math_004.Value
        nodeGroup.links.new(
            nodeGroup.nodes["Math.002"].outputs[0],
            nodeGroup.nodes["Math.004"].inputs[0]
        )
        # math_004.Value -> math_003.Value
        nodeGroup.links.new(
            nodeGroup.nodes["Math.004"].outputs[0],
            nodeGroup.nodes["Math.003"].inputs[0]
        )
        # group_input.Value -> math_003.Value
        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[0],
            nodeGroup.nodes["Math.003"].inputs[1]
        )
        # group_input.Value -> math_001.Value
        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[1],
            nodeGroup.nodes["Math.001"].inputs[1]
        )

        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[2],
            math_not_engine.inputs[1]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Group Input"].outputs[1],
            math_baking_no_engine.inputs[0]
        )
        nodeGroup.links.new(
            math_not_engine.outputs[0],
            math_baking_no_engine.inputs[1]
        )
        nodeGroup.links.new(
            nodeGroup.nodes["Math.001"].outputs[0],
            math_add_condition.inputs[0]
        )
        nodeGroup.links.new(
            math_baking_no_engine.outputs[0],
            math_add_condition.inputs[1]
        )
        nodeGroup.links.new(
            math_add_condition.outputs[0],
            nodeGroup.nodes["Math.002"].inputs[1]
        )

        return nodeGroup

    # # MARK: Index Switch Group
    # @staticmethod
    # def build_index_switch_ng(reset=True):
    #     """Initialize IndexSwitch node group"""

    #     from ..commonFunc import ZBBQ_MaterialFunc

    #     nodeGroup = bpy.data.node_groups.get(ZBBQ_Consts.node_tree_service_index_switch)
    #     group_input = None
    #     group_output = None

    #     if nodeGroup:
    #         if not reset:
    #             return nodeGroup

    #         for node in list(nodeGroup.nodes):
    #             if node.type == 'GROUP_INPUT':
    #                 group_input = node
    #             elif node.type == 'GROUP_OUTPUT':
    #                 group_output = node
    #             else:
    #                 nodeGroup.nodes.remove(node)

    #         nodeGroup.links.clear()

    #     else:
    #         nodeGroup = bpy.data.node_groups.new(type='ShaderNodeTree', name=ZBBQ_Consts.node_tree_service_index_switch)

    #     nodeGroup.zen_bbq_version = ZBBQ_MaterialFunc.get_label_version_name(ZBBQ_Consts.node_tree_service_index_switch)

    #     if group_input is None:

    #         group_input = nodeGroup.nodes.new("NodeGroupInput")
    #         group_input.name = "Group Input"
    #         group_input.show_options = True

    #         # Socket Value
    #         value_socket_1 = nodeGroup.interface.new_socket(name="preview_map_index", in_out='INPUT', socket_type='NodeSocketFloat')
    #         value_socket_1.default_value = 0.5
    #         value_socket_1.min_value = -10000.0
    #         value_socket_1.max_value = 10000.0
    #         value_socket_1.subtype = 'NONE'
    #         value_socket_1.attribute_domain = 'POINT'

    #         # Socket Value
    #         value_socket_2 = nodeGroup.interface.new_socket(name="is_baking_active", in_out='INPUT', socket_type='NodeSocketFloat')
    #         value_socket_2.default_value = 0.5
    #         value_socket_2.min_value = -10000.0
    #         value_socket_2.max_value = 10000.0
    #         value_socket_2.subtype = 'NONE'
    #         value_socket_2.attribute_domain = 'POINT'

    #         # Socket use_bbq_engine
    #         use_bbq_engine_socket = nodeGroup.interface.new_socket(name="use_bbq_engine", in_out='INPUT', socket_type='NodeSocketBool')
    #         use_bbq_engine_socket.default_value = True
    #         use_bbq_engine_socket.attribute_domain = 'POINT'

    #     if group_output is None:
    #         # Socket Value
    #         value_socket = nodeGroup.interface.new_socket(name="Value", in_out='OUTPUT', socket_type='NodeSocketFloat')
    #         value_socket.default_value = 0.0
    #         value_socket.min_value = -3.4028234663852886e+38
    #         value_socket.max_value = 3.4028234663852886e+38
    #         value_socket.subtype = 'NONE'
    #         value_socket.attribute_domain = 'POINT'

    #         group_output = nodeGroup.nodes.new("NodeGroupOutput")
    #         group_output.name = "Group Output"
    #         group_output.show_options = True
    #         group_output.is_active_output = True

    #         # Socket Value
    #         value_socket = nodeGroup.interface.new_socket(name="Value", in_out='OUTPUT', socket_type='NodeSocketFloat')
    #         value_socket.default_value = 0.0
    #         value_socket.min_value = -3.4028234663852886e+38
    #         value_socket.max_value = 3.4028234663852886e+38
    #         value_socket.subtype = 'NONE'
    #         value_socket.attribute_domain = 'POINT'

    #     # Initialize indexswitch_1 nodes

    #     # Node Math
    #     math = nodeGroup.nodes.new("ShaderNodeMath")
    #     math.name = "Math"
    #     math.show_options = True
    #     math.operation = 'COMPARE'
    #     math.use_clamp = False
    #     # Value_001
    #     math.inputs[1].default_value = 0.0
    #     # Value_002
    #     math.inputs[2].default_value = 0.001

    #     # Node Math.001
    #     math_001 = nodeGroup.nodes.new("ShaderNodeMath")
    #     math_001.name = "Math.001"
    #     math_001.show_options = True
    #     math_001.operation = 'SUBTRACT'
    #     math_001.use_clamp = False
    #     # Value
    #     math_001.inputs[0].default_value = 1.0

    #     # Node Math.002
    #     math_002 = nodeGroup.nodes.new("ShaderNodeMath")
    #     math_002.name = "Math.002"
    #     math_002.show_options = True
    #     math_002.operation = 'MULTIPLY'
    #     math_002.use_clamp = False

    #     # Node Math.003
    #     math_003 = nodeGroup.nodes.new("ShaderNodeMath")
    #     math_003.name = "Math.003"
    #     math_003.show_options = True
    #     math_003.operation = 'ADD'
    #     math_003.use_clamp = False

    #     # Node Math.004
    #     math_004 = nodeGroup.nodes.new("ShaderNodeMath")
    #     math_004.name = "Math.004"
    #     math_004.show_options = True
    #     math_004.operation = 'MULTIPLY'
    #     math_004.use_clamp = False
    #     # Value_001
    #     math_004.inputs[1].default_value = 9.0

    #     # Set locations
    #     nodeGroup.nodes["Group Input"].location = (-420.0, 0.0)
    #     nodeGroup.nodes["Group Output"].location = (760.0, 0.0)
    #     nodeGroup.nodes["Math"].location = (-180.0, 140.0)
    #     nodeGroup.nodes["Math.001"].location = (-180.0, -80.0)
    #     nodeGroup.nodes["Math.002"].location = (40.0, 140.0)
    #     nodeGroup.nodes["Math.003"].location = (500.0, 40.0)
    #     nodeGroup.nodes["Math.004"].location = (240.0, 140.0)

    #     # Initialize indexswitch_1 links

    #     # group_input.Value -> math.Value
    #     nodeGroup.links.new(
    #         nodeGroup.nodes["Group Input"].outputs[0],
    #         nodeGroup.nodes["Math"].inputs[0]
    #     )
    #     # math_003.Value -> group_output.Value
    #     nodeGroup.links.new(
    #         nodeGroup.nodes["Math.003"].outputs[0],
    #         nodeGroup.nodes["Group Output"].inputs[0]
    #     )
    #     # math.Value -> math_002.Value
    #     nodeGroup.links.new(
    #         nodeGroup.nodes["Math"].outputs[0],
    #         nodeGroup.nodes["Math.002"].inputs[0]
    #     )
    #     # math_002.Value -> math_004.Value
    #     nodeGroup.links.new(
    #         nodeGroup.nodes["Math.002"].outputs[0],
    #         nodeGroup.nodes["Math.004"].inputs[0]
    #     )
    #     # math_004.Value -> math_003.Value
    #     nodeGroup.links.new(
    #         nodeGroup.nodes["Math.004"].outputs[0],
    #         nodeGroup.nodes["Math.003"].inputs[0]
    #     )
    #     # group_input.Value -> math_003.Value
    #     nodeGroup.links.new(
    #         nodeGroup.nodes["Group Input"].outputs[0],
    #         nodeGroup.nodes["Math.003"].inputs[1]
    #     )
    #     # group_input.Value -> math_001.Value
    #     nodeGroup.links.new(
    #         nodeGroup.nodes["Group Input"].outputs[1],
    #         nodeGroup.nodes["Math.001"].inputs[1]
    #     )
    #     # math_001.Value -> math_002.Value
    #     nodeGroup.links.new(
    #         nodeGroup.nodes["Math.001"].outputs[0],
    #         nodeGroup.nodes["Math.002"].inputs[1]
    #     )

    #     return nodeGroup

    # MARK: MAIN Build Preview Shader
    @classmethod
    def build_preview_shader(cls, nodeGroup, target_material, reset=True):

        node_tree_names: dict[typing.Callable, str] = {}

        normals_mixer = cls.build_service_normals_mixer_ng(reset=reset)
        node_tree_names[cls.build_service_normals_mixer_ng] = normals_mixer.name

        curvature = cls.build_curvature_ng(reset=reset)
        node_tree_names[cls.build_curvature_ng] = curvature.name

        convexity_bevels_mask = cls.build_convexity_bevels_mask_ng(reset=reset)
        node_tree_names[cls.build_convexity_bevels_mask_ng] = convexity_bevels_mask.name

        ambient_occlusion = cls.build_ambient_occlusion_ng(reset=reset)
        node_tree_names[cls.build_ambient_occlusion_ng] = ambient_occlusion.name

        concavity_bevels_mask = cls.build_concavity_bevels_mask_ng(reset=reset)
        node_tree_names[cls.build_concavity_bevels_mask_ng] = concavity_bevels_mask.name

        bevels_mask = cls.build_bevels_mask_ng(reset=reset)
        node_tree_names[cls.build_bevels_mask_ng] = bevels_mask.name

        parts_id = cls.build_parts_id_ng(reset=reset)
        node_tree_names[cls.build_parts_id_ng] = parts_id.name

        materials_id = cls.build_materials_id_ng(target_material, reset=reset)
        node_tree_names[cls.build_materials_id_ng] = materials_id.name

        objectspace_normal = cls.build_object_space_normal_ng(reset=reset)
        node_tree_names[cls.build_object_space_normal_ng] = objectspace_normal.name

        tangent_space_normal = cls.build_tangent_space_normal_ng(reset=reset)
        node_tree_names[cls.build_tangent_space_normal_ng] = tangent_space_normal.name

        types_switch = cls.build_types_switch_ng(reset=reset)
        node_tree_names[cls.build_types_switch_ng] = types_switch.name

        indexswitch = cls.build_index_switch_ng(reset=reset)
        node_tree_names[cls.build_index_switch_ng] = indexswitch.name

        preview_shader = cls.build_preview_shader_ng(nodeGroup, node_tree_names, target_material, reset=reset)
        node_tree_names[cls.build_preview_shader_ng] = preview_shader.name

        return nodeGroup
