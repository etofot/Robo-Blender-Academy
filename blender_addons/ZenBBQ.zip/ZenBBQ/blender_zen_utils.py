# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2021, Alex Zhornyak

import bpy

import ctypes
import platform
import re
import os
import ast
import math

from enum import IntEnum

from .vlog import Log

_ATTR_DEPSGRAPH_UPDATE_LOCK = 'zen_sets_depsgraph_update_lock'
_ATTR_DEPSGRAPH_UPDATE_ONE_LOCK = 'zen_sets_depsgraph_update_one_lock'
_ATTR_LAY_COL_UPDATE_ONE_LOCK = 'zen_sets_lay_col_update_one_lock'
_ATTR_NOTIFY_EDIT_LOCK = 'zen_sets_notify_edit_lock'
_ATTR_SCENE_GROUP_INDEX_LOCK = 'zen_sets_index_lock'
_ATTR_LOOKUP_BUILD_LOCK = 'zen_sets_lookup_build_lock'


_ATTR_OBJ_COLOR_STATE = 'zen_sets_object_color_state'


app_version = bpy.app.version


class ZenPolls:

    ADDON_PACKAGE = "ZenBBQ"
    ADDON_DIR = ""
    ADDON_VERSION = (0, 0, 0)

    BLENDER_MIN_VERSION = (0, 0)
    BLENDER_MAX_VERSION = (5, 2)
    BLENDER_IS_SUPPORTED = True

    # Will be taken from 'ZenMastersTeam/Zen-UV/main/README.md'
    new_addon_version = None

    # Will be taken from bl_info['doc_url'] !!!
    doc_url = ''

    # Will be taken from bl_info['traker_url'] !!!
    support_url = ""

    version_since_3_0_0 = app_version >= (3, 0, 0)

    version_since_3_2_0 = app_version >= (3, 2, 0)

    version_since_3_3_0 = app_version >= (3, 3, 0)

    version_since_2_93_0 = app_version >= (2, 93, 0)

    version_lower_3_5_0 = app_version < (3, 5, 0)

    version_lower_3_4_0 = app_version < (3, 4, 0)

    version_lower_4_0_0 = app_version < (4, 0, 0)

    # Reason: Geometry Nodes for vertex color generation
    version_since_4_0_0 = app_version >= (4, 0, 0)

    version_since_4_1_0 = app_version >= (4, 1, 0)

    # Reason: Improved Geometry Nodes for vertex color generation
    version_since_4_5_0 = app_version >= (4, 5, 0)

    version_since_5_0_0 = app_version >= (5, 0, 0)

    # Reason: Added socket Convention (OpenGL / DirectX) то Normal Map Node
    version_since_5_1_0 = app_version >= (5, 1, 0)

    # Reason: changes in Geo Nodes
    version_since_5_2_0 = app_version >= (5, 2, 0)

    @classmethod
    def draw_blender_check(cls, layout: bpy.types.UILayout):
        pass


class ZsPresets:

    @classmethod
    def get_preset_path(cls, s_preset_subdir):
        return os.path.join('zen_bbq', s_preset_subdir)

    @classmethod
    def force_full_preset_path(cls, s_preset_dir):
        target_path = os.path.join("presets", cls.get_preset_path(s_preset_dir))
        target_path = bpy.utils.user_resource('SCRIPTS', path=target_path, create=True)

        if not target_path:
            raise RuntimeError(f"Can not find or create: {s_preset_dir}")

        return target_path


class ZenStrUtils:
    @classmethod
    def ireplace(cls, text, find, repl):
        return re.sub('(?i)' + re.escape(find), lambda m: repl, text)

    @classmethod
    def smart_replace(cls, text, props):
        err = ''
        new_name = ''
        try:
            if props.find != '':
                if props.use_regex:
                    new_name = re.sub(props.find, props.replace, text)
                else:
                    if props.match_case:
                        new_name = text.replace(props.find, props.replace)
                    else:
                        new_name = cls.ireplace(text, props.find, props.replace)
            else:
                new_name = props.replace
        except Exception as e:
            err = str(e)

        if new_name == '':
            new_name = text

        return (new_name, err)


class ZenLocks:
    @staticmethod
    def is_depsgraph_update_locked():
        return (_ATTR_DEPSGRAPH_UPDATE_LOCK in bpy.app.driver_namespace.keys()) \
                and bpy.app.driver_namespace[_ATTR_DEPSGRAPH_UPDATE_LOCK]

    @staticmethod
    def lock_depsgraph_update():
        bpy.app.driver_namespace[_ATTR_DEPSGRAPH_UPDATE_LOCK] = True

    @staticmethod
    def unlock_depsgraph_update():
        bpy.app.driver_namespace[_ATTR_DEPSGRAPH_UPDATE_LOCK] = False

    @staticmethod
    def is_depsgraph_update_one_locked():
        return (_ATTR_DEPSGRAPH_UPDATE_ONE_LOCK in bpy.app.driver_namespace.keys()) \
                and bpy.app.driver_namespace[_ATTR_DEPSGRAPH_UPDATE_ONE_LOCK]

    @staticmethod
    def lock_depsgraph_update_one():
        bpy.app.driver_namespace[_ATTR_DEPSGRAPH_UPDATE_ONE_LOCK] = True

    @staticmethod
    def unlock_depsgraph_update_one():
        bpy.app.driver_namespace[_ATTR_DEPSGRAPH_UPDATE_ONE_LOCK] = False

    @staticmethod
    def is_lay_col_update_one_locked():
        return (_ATTR_LAY_COL_UPDATE_ONE_LOCK in bpy.app.driver_namespace.keys()) \
                and bpy.app.driver_namespace[_ATTR_LAY_COL_UPDATE_ONE_LOCK]

    @staticmethod
    def lock_lay_col_update_one():
        bpy.app.driver_namespace[_ATTR_LAY_COL_UPDATE_ONE_LOCK] = True

    @staticmethod
    def unlock_lay_col_update_one():
        bpy.app.driver_namespace[_ATTR_LAY_COL_UPDATE_ONE_LOCK] = False

    @staticmethod
    def is_notify_edit_locked():
        return (_ATTR_NOTIFY_EDIT_LOCK in bpy.app.driver_namespace.keys()) \
                and bpy.app.driver_namespace[_ATTR_NOTIFY_EDIT_LOCK]

    @staticmethod
    def lock_notify_edit():
        bpy.app.driver_namespace[_ATTR_NOTIFY_EDIT_LOCK] = True

    @staticmethod
    def unlock_notify_edit():
        bpy.app.driver_namespace[_ATTR_NOTIFY_EDIT_LOCK] = False

    @staticmethod
    def is_lookup_build_locked():
        return (_ATTR_LOOKUP_BUILD_LOCK in bpy.app.driver_namespace.keys()) \
                and bpy.app.driver_namespace[_ATTR_LOOKUP_BUILD_LOCK]

    @staticmethod
    def lock_lookup_build():
        bpy.app.driver_namespace[_ATTR_LOOKUP_BUILD_LOCK] = True

    @staticmethod
    def unlock_lookup_build():
        bpy.app.driver_namespace[_ATTR_LOOKUP_BUILD_LOCK] = False

    @staticmethod
    def is_group_index_locked(id_group):
        return ((_ATTR_SCENE_GROUP_INDEX_LOCK + id_group) in bpy.app.driver_namespace.keys()) \
                and bpy.app.driver_namespace[_ATTR_SCENE_GROUP_INDEX_LOCK + id_group]

    @staticmethod
    def lock_group_index(id_group):
        bpy.app.driver_namespace[_ATTR_SCENE_GROUP_INDEX_LOCK + id_group] = True

    @staticmethod
    def unlock_group_index(id_group):
        bpy.app.driver_namespace[_ATTR_SCENE_GROUP_INDEX_LOCK + id_group] = False


class ZenStates:
    @staticmethod
    def set_obj_color_state():
        bpy.app.driver_namespace[_ATTR_OBJ_COLOR_STATE] = True

    @staticmethod
    def unset_obj_color_state():
        bpy.app.driver_namespace[_ATTR_OBJ_COLOR_STATE] = False

    @staticmethod
    def is_obj_color_state():
        return (_ATTR_OBJ_COLOR_STATE in bpy.app.driver_namespace.keys()) \
                and bpy.app.driver_namespace[_ATTR_OBJ_COLOR_STATE]


class ZsViewLayerStoredType(IntEnum):
    HideSelect = 0,
    HideViewport = 1,
    HideGet = 2,
    SelectGet = 3,
    WasEditable = 4


def save_viewlayer_layers_state(parent_layer, layers_state):
    for child_layer in parent_layer.children:
        layers_state[child_layer.name] = (child_layer.exclude, child_layer.hide_viewport)
        save_viewlayer_layers_state(child_layer, layers_state)


def show_all_viewlayers(parent_layer):
    for child_layer in parent_layer.children:
        child_layer.exclude = False
        child_layer.hide_viewport = False
        show_all_viewlayers(child_layer)


def restore_viewlayer_layers(parent_layer, layers_state):
    for child_layer in parent_layer.children:
        if child_layer.name in layers_state:
            is_excluded, is_viewport_hidden = layers_state[child_layer.name]
            if child_layer.exclude != is_excluded:
                child_layer.exclude = is_excluded
            if child_layer.hide_viewport != is_viewport_hidden:
                child_layer.hide_viewport = is_viewport_hidden
        restore_viewlayer_layers(child_layer, layers_state)


def save_viewlayer_objects_state():
    view_layer = bpy.context.view_layer
    act_obj_name = view_layer.objects.active.name if view_layer.objects.active else ''
    were_objects = {obj.name: (obj.hide_select,
                               obj.hide_viewport,
                               obj.hide_get(),
                               obj.select_get(),
                               obj.data.is_editmode if obj.type == 'MESH' else (act_obj_name == obj.name))
                    for obj in view_layer.objects}
    return (were_objects, act_obj_name)


def restore_viewlayer_objects(were_objects):
    obj_list = bpy.context.view_layer.objects
    for obj_name, obj_data in were_objects.items():
        obj = obj_list.get(obj_name)
        if obj:
            if obj.hide_get() != obj_data[ZsViewLayerStoredType.HideGet]:
                obj.hide_set(obj_data[ZsViewLayerStoredType.HideGet])

            if obj.hide_select != obj_data[ZsViewLayerStoredType.HideSelect]:
                obj.hide_select = obj_data[ZsViewLayerStoredType.HideSelect]
            if obj.hide_viewport != obj_data[ZsViewLayerStoredType.HideViewport]:
                obj.hide_viewport = obj_data[ZsViewLayerStoredType.HideViewport]

            if obj.select_get() != obj_data[ZsViewLayerStoredType.SelectGet]:
                obj.select_set(obj_data[ZsViewLayerStoredType.SelectGet])
        else:
            Log.error('Can not restore:', obj_name)


def ensure_object_in_viewlayer(obj, parent_layer):
    for child_layer in parent_layer.children:
        if obj.name in child_layer.collection.objects:
            child_layer.exclude = False
            child_layer.hide_viewport = False

        ensure_object_in_viewlayer(obj, child_layer)


def unhide_and_select_all_viewlayer_objects(act_obj_name):
    view_layer = bpy.context.view_layer
    for obj in view_layer.objects:
        if obj.type == 'MESH':
            obj.hide_viewport = False
            obj.hide_select = False
            obj.hide_set(False)
            obj.select_set(True)
        if obj.name == act_obj_name:
            view_layer.objects.active = obj


def prepare_stored_objects_for_edit(were_objects, act_obj_name):
    view_layer = bpy.context.view_layer
    for obj in view_layer.objects:
        if obj.name in were_objects:
            was_in_edit_mode = were_objects[obj.name][ZsViewLayerStoredType.WasEditable]
            if was_in_edit_mode:
                try:
                    obj.hide_viewport = False
                    obj.hide_select = False
                    obj.hide_set(False)
                    obj.select_set(True)
                except Exception:
                    pass
            else:
                try:
                    obj.hide_viewport = were_objects[obj.name][ZsViewLayerStoredType.HideViewport]
                    obj.hide_select = were_objects[obj.name][ZsViewLayerStoredType.HideSelect]
                    obj.hide_set(were_objects[obj.name][ZsViewLayerStoredType.HideGet])
                    obj.select_set(False)
                except Exception:
                    pass

        if obj.name == act_obj_name:
            view_layer.objects.active = obj


class ZenModeSwitcher:
    def __init__(self, mode='OBJECT'):
        self.were_objects, self.act_obj_name = save_viewlayer_objects_state()
        ctx_mode = bpy.context.mode
        if ctx_mode == 'OBJECT':
            self.was_mode = 'OBJECT'
        else:
            self.was_mode = 'EDIT'
        if mode != self.was_mode:
            if bpy.ops.object.mode_set.poll():
                bpy.ops.object.mode_set(mode=mode)

    def return_to_edit_mode(self):
        prepare_stored_objects_for_edit(self.were_objects, self.act_obj_name)
        bpy.ops.object.mode_set(mode='EDIT')
        restore_viewlayer_objects(self.were_objects)

    def return_to_mode(self):
        if self.was_mode == 'EDIT':
            prepare_stored_objects_for_edit(self.were_objects, self.act_obj_name)
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode=self.was_mode)
        restore_viewlayer_objects(self.were_objects)


def fix_undo_push_edit_mode(msg):
    try:
        ZenLocks.lock_depsgraph_update()

        active_object = bpy.context.view_layer.objects.active
        if active_object and active_object.mode == "EDIT":
            try:
                ZenLocks.lock_notify_edit()
                mode_switcher = ZenModeSwitcher()

                bpy.ops.mesh.primitive_cube_add(enter_editmode=False)
                bpy.ops.object.delete(use_global=True, confirm=False)

                bpy.ops.object.select_all(action='DESELECT')

                mode_switcher.return_to_edit_mode()
            except Exception as e:
                Log.error('FIX_UNDO:', e)

        bpy.ops.ed.undo_push(message=msg)
    finally:
        ZenLocks.unlock_depsgraph_update()
    pass


def view_selected_in_center():
    for area in bpy.context.screen.areas:
        if area.type == 'VIEW_3D':
            ctx = bpy.context.copy()
            ctx['area'] = area
            ctx['region'] = area.regions[-1]
            bpy.ops.view3d.view_selected(ctx)


def update_view3d_in_all_screens():
    context = bpy.context

    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()


def is_property_modified(obj_prop):
    for prop in obj_prop.bl_rna.properties:
        if hasattr(prop, "default"):
            is_array = getattr(prop, "is_array", False)
            if is_array:
                default_array = [p for p in prop.default_array]
                current_value = [p for p in getattr(obj_prop, prop.identifier)]
                if default_array != current_value:
                    return True
            else:
                current = getattr(obj_prop, prop.identifier)
                if current != prop.default:
                    return True
    return False


def reset_property_modified(obj_prop):
    for prop in obj_prop.bl_rna.properties:
        if hasattr(prop, "default"):
            is_array = getattr(prop, "is_array", False)
            if is_array:
                cur_array = getattr(obj_prop, prop.identifier)

                default_values = [(i, p) for i, p in enumerate(prop.default_array)]
                current_values = [(i, p) for i, p in enumerate(cur_array)]
                if default_values != current_values:
                    if len(default_values) == len(current_values):
                        for i, p in default_values:
                            cur_array[i] = p
            else:
                current = getattr(obj_prop, prop.identifier)
                if current != prop.default:
                    setattr(obj_prop, prop.identifier, prop.default)


def get_operator_attr(op_name, attr_name, default=None):
    wm = bpy.context.window_manager
    op_last = wm.operator_properties_last(op_name)
    if op_last:
        return getattr(op_last, attr_name)
    return default


def get_unique_mesh_objects(p_objects: list):
    return list({obj.data: obj for obj in p_objects if obj.type == 'MESH'}.values())


def set_operator_attr(op_name, attr_name, value):
    wm = bpy.context.window_manager
    op_last = wm.operator_properties_last(op_name)
    if op_last:
        setattr(op_last, attr_name, value)


def ireplace(text, find, repl):
    return re.sub('(?i)' + re.escape(find), lambda m: repl, text)


def win_emulate_escape():
    try:
        if platform.system() == 'Windows':
            VK_ESCAPE = 0x1B
            ctypes.windll.user32.keybd_event(VK_ESCAPE)
    except Exception as e:
        Log.error('Can not emulate ESC!', e)


def dump_context_objects(context):
    def _dump_object(idx, p_obj, s_category):
        Log.debug('\tCategory:', s_category, '[', idx, ']:', p_obj.name)

    categories = (
        'visible_objects',
        'selectable_objects',
        'selected_objects',
        'editable_objects',
        'selected_editable_objects',
        'selected_editable_objects',
        'selected_editable_objects_unique_data'
    )

    for s_cat in categories:
        Log.debug('===========> Category:', s_cat, '<=============')
        for i, obj in enumerate(getattr(context, s_cat, [])):
            _dump_object(i, obj, s_cat)


def _collection_from_element(self):
    # this gets the collection that the element is in
    path = self.path_from_id()
    match = re.match(r'(.*)\[\d*\]', path)
    parent = self.id_data
    try:
        coll_path = match.group(1)
    except AttributeError:
        raise TypeError("Propery not element in a collection.")
    else:
        return parent.path_resolve(coll_path)


def _setnameex(self, value, collection_from_element=_collection_from_element):

    def new_val(stem, nbr):
        # simply for formatting
        return '{st}.{nbr:03d}'.format(st=stem, nbr=nbr)

    # =====================================================
    if value == self.get('name', ''):
        # check for assignement of current value
        return

    coll = collection_from_element(self)
    if value not in coll:
        # if value is not in the collection, just assign
        self['name'] = value
        return

    # see if value is already in a format like 'name.012'
    match = re.match(r'^(.*)\.(\d{3,})$', value)
    if match is None:
        stem, nbr = value, 1
    else:
        stem, nbr = match.groups()
        try:
            nbr = int(nbr)
        except Exception:
            nbr = 1

    # check for each value if in collection
    new_value = new_val(stem, nbr)
    while new_value in coll:
        nbr += 1
        new_value = new_val(stem, nbr)

    self['name'] = new_value


def setnameex(self, value):
    _setnameex(self, value)


def parse_preset_to_dict(file_path):
    with open(file_path, "r", encoding="utf-8") as f:
        tree = ast.parse(f.read())

    t_dict = {}
    # Словарь для хранения полных путей локальных переменных
    # Например: {'cycles': 'bpy.context.scene.cycles'}
    local_vars = {}

    # Вспомогательная функция для рекурсивной сборки пути из AST-узлов (Attribute и Name)
    def get_full_attr_path(node):
        if isinstance(node, ast.Name):
            return node.id
        elif isinstance(node, ast.Attribute):
            parent_path = get_full_attr_path(node.value)
            if parent_path:
                return f"{parent_path}.{node.attr}"
        return None

    for node in tree.body:
        if isinstance(node, ast.Assign):
            # 1. Проверяем присвоение переменной (cycles = bpy.context.scene.cycles)
            # Ожидаем, что справа находится цепочка атрибутов
            if isinstance(node.value, ast.Attribute):
                full_path = get_full_attr_path(node.value)

                if full_path:
                    for target in node.targets:
                        if isinstance(target, ast.Name):
                            local_vars[target.id] = full_path
                    continue  # Переходим к следующей строке

            # 2. Проверяем присвоение свойства (cycles.preview_samples = 1024)
            if isinstance(node.targets[0], ast.Attribute):
                target = node.targets[0]
                value_node = node.value

                # Находим базовое имя переменной (например, 'cycles')
                if isinstance(target.value, ast.Name):
                    base_name = target.value.id
                    prop_name = target.attr

                    # Получаем полный путь для этой переменной из нашего словаря local_vars
                    # Если переменной там нет, оставляем её имя как есть
                    parent_key = local_vars.get(base_name, base_name)

                    try:
                        val = ast.literal_eval(value_node)
                    except ValueError:
                        continue  # Пропускаем сложные выражения

                    # Записываем в словарь под полным ключом
                    if parent_key not in t_dict:
                        t_dict[parent_key] = {}
                    t_dict[parent_key][prop_name] = val

    return t_dict


def is_same_preset_as_context_data(t_dict: dict, rel_tol=1e-5):
    for datablock, properties in t_dict.items():
        scene_engine_block = eval(datablock)

        for prop_name, expected_value in properties.items():
            if not hasattr(scene_engine_block, prop_name):
                continue

            current_value = getattr(scene_engine_block, prop_name)

            if isinstance(expected_value, float) or isinstance(
                current_value, float
            ):
                is_match = math.isclose(
                    float(current_value),
                    float(expected_value),
                    rel_tol=rel_tol,
                )
            else:
                is_match = current_value == expected_value

            if not is_match:
                return False

    return len(t_dict) > 0


class ZsDrawConstans:
    DEFAULT_VERT_ACTIVE_ALPHA = 60
    DEFAULT_VERT_INACTIVE_ALPHA = 40
    DEFAULT_VERT_ACTIVE_POINT_SIZE = 10
    DEFAULT_VERT_INACTIVE_POINT_SIZE = 6

    DEFAULT_EDGE_ACTIVE_ALPHA = 60
    DEFAULT_EDGE_INACTIVE_ALPHA = 40
    DEFAULT_EDGE_ACTIVE_LINE_WIDTH = 3
    DEFAULT_EDGE_INACTIVE_LINE_WIDTH = 2

    DEFAULT_FACE_ACTIVE_ALPHA = 60
    DEFAULT_FACE_INACTIVE_ALPHA = 20

    DEFAULT_OBJECT_ACTIVE_ALPHA = 40
    DEFAULT_OBJECT_INACTIVE_ALPHA = 20
    DEFAULT_OBJECT_COLLECTION_BOUNDBOX_WIDTH = 2
    DEFAULT_OBJECT_COLLECTION_LABEL_SIZE = 12


class ZsUiConstants:
    ZSTS_PANEL_CATEGORY = "Zen BBQ"
    ZSTS_REGION_TYPE = "UI"
    ZSTS_CONTEXT = "mesh_edit"
    ZSTS_SPACE_TYPE = "VIEW_3D"
