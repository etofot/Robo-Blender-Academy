﻿# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2022, Dmitry Aleksandrovich Maslov (ABTOMAT), Valeriy Yatsenko, Alex Zhornyak (alexander.zhornyak@gmail.com)

import bpy

import importlib
import sys
import os

from .zen_common.addon_check_utils import (
    check_addon_duplicated
)
from .zen_common.zen_context import ZenContext
from .blender_zen_utils import ZenPolls
from .vlog import Log
from .consts import ZBBQ_Consts


# ORDER IS IMPORTANT !
module_names = (
    (".keymap_manager", __package__),
    (".ico",  __package__),
    (".preferences", __package__),
    (".sceneConfig", __package__),
    (".operators", __package__),
    (".ui", __package__),
    (".eventHandling", __package__),
    (".vertex_color", __package__)
)


bl_info = {
    "name": "Zen BBQ",
    "author": "Valeriy Yatsenko, Sergey Tyapkin, Viktor [VAN] Teplov, Alex Zhornyak,  Dmitry [ABTOMAT] Maslov",
    "version": (2, 0, 4, 1),
    "description": "Create, adjust and visually control bevel effect without actually changing geometry.",
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Zen BBQ > Zen BBQ",
    "warning": "",
    "category": "Mesh",
    "tracker_url": "https://support.zenmasters.team/",
    "doc_url": "https://zen-masters.github.io/Zen-BBQ/"
}


# NOTE: something weird happens with Blender extension system,
#       it does not recognize 'bl_info' variable, seems to be removed,
#       so, we are using proxy dictionary
proxy_info = bl_info.copy()


APP_BACKGROUND = bpy.app.background


def register():

    if APP_BACKGROUND:
        return

    # NOTE: weird behaviour in Blender when 2 or more same extensions are allowed to be active in the moment
    #       https://projects.blender.org/blender/blender/issues/144187
    #       so, prevent it by ourselves
    check_addon_duplicated(ZBBQ_Consts.addonId, __package__, proxy_info['version'])

    # NOTE: we should detect addon package name to support extensions
    ZenPolls.ADDON_PACKAGE = __package__
    ZenPolls.ADDON_DIR = os.path.abspath(os.path.dirname(__file__))
    ZenPolls.ADDON_VERSION = proxy_info['version']
    ZenPolls.doc_url = proxy_info['doc_url']
    ZenPolls.support_url = proxy_info['tracker_url']
    ZenPolls.BLENDER_MIN_VERSION = proxy_info['blender'][:2]
    app_version_v2 = bpy.app.version[:2]
    ZenPolls.BLENDER_IS_SUPPORTED = ZenPolls.BLENDER_MIN_VERSION <= app_version_v2 <= ZenPolls.BLENDER_MAX_VERSION

    Log.info(f">>> Registering {ZBBQ_Consts.addonId}:", proxy_info['version'], "   Blender:", bpy.app.version[:], "-> Supported:", ZenPolls.BLENDER_IS_SUPPORTED)

    from .commonFunc import ZBBQ_CommonFunc, ZBBQ_Proxy
    ZenContext.PROXY = ZBBQ_Proxy

    for name, package in module_names:
        mod = importlib.import_module(name, package)
        mod.register()

        if name == ".preferences":
            from .blender_zen_utils import ZsUiConstants

            addon_prefs = ZBBQ_CommonFunc.GetPrefs()

            ZsUiConstants.ZSTS_PANEL_CATEGORY = bpy.types.UILayout.enum_item_name(
                addon_prefs, "n_panel_name", addon_prefs.n_panel_name)


def unregister():

    if APP_BACKGROUND:
        return

    for name, package in reversed(module_names):
        mod_name = package + name
        mod = sys.modules.get(mod_name)
        if mod:
            mod.unregister()


if __name__ == "__main__":
    pass
