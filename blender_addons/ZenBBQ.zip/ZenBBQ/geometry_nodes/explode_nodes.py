# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2026, Valeriy Yatsenko - lightbio@gmail.com


import bpy
from ..consts import ZBBQ_Consts
from ..blender_zen_utils import ZenPolls


def create_explode_node_group():
    explode_node_group = bpy.data.node_groups.new(type='GeometryNodeTree', name="BBQ Explode System")

    geometry_socket = explode_node_group.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'

    geometry_socket_1 = explode_node_group.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'

    socket_name = ZBBQ_Consts.bbq_explode_center_socket_name
    explosion_center_socket = explode_node_group.interface.new_socket(name=socket_name, in_out='INPUT', socket_type='NodeSocketObject')
    explosion_center_socket.attribute_domain = 'POINT'
    explosion_center_socket.description = "The object used as the origin. Its position, rotation, and scale will directly affect the direction and spread of the explosion"

    explosion_force_socket = explode_node_group.interface.new_socket(name="Explosion Force", in_out='INPUT', socket_type='NodeSocketFloat')
    explosion_force_socket.subtype = 'NONE'
    explosion_force_socket.attribute_domain = 'POINT'
    explosion_force_socket.description = "The base speed multiplier for the scattering islands. Combined with the Explosion Center's scale"
    explosion_force_socket.default_value = 1.0

    scale_speed_by_size_socket = explode_node_group.interface.new_socket(name="Scale Speed by Size", in_out='INPUT', socket_type='NodeSocketBool')
    scale_speed_by_size_socket.attribute_domain = 'POINT'
    scale_speed_by_size_socket.description = "Enable to make larger UV islands fly away faster than smaller ones"
    scale_speed_by_size_socket.default_value = True

    random_max_socket = explode_node_group.interface.new_socket(name="Random Max", in_out='INPUT', socket_type='NodeSocketFloat')
    random_max_socket.subtype = 'NONE'
    random_max_socket.attribute_domain = 'POINT'
    random_max_socket.description = "Adds chaotic randomness to the explosion direction and speed"
    random_max_socket.default_value = 0.0

    seed_socket = explode_node_group.interface.new_socket(name="Seed", in_out='INPUT', socket_type='NodeSocketInt')
    seed_socket.subtype = 'NONE'
    seed_socket.attribute_domain = 'POINT'
    seed_socket.description = "Seed value for the random variation. Change to get a different scatter pattern"
    seed_socket.default_value = 123

    vgroup_socket = explode_node_group.interface.new_socket(name="Vertex Group", in_out='INPUT', socket_type='NodeSocketString')
    vgroup_socket.attribute_domain = 'POINT'
    vgroup_socket.description = "Optional vertex group to mask the explosion. If empty or missing, affects everything."

    vector_math = explode_node_group.nodes.new("ShaderNodeVectorMath")
    vector_math.name = "Vector Math"
    vector_math.operation = 'DIVIDE'

    vector_math_001 = explode_node_group.nodes.new("ShaderNodeVectorMath")
    vector_math_001.name = "Vector Math.001"
    vector_math_001.operation = 'SUBTRACT'

    vector_math_002 = explode_node_group.nodes.new("ShaderNodeVectorMath")
    vector_math_002.name = "Vector Math.002"
    vector_math_002.operation = 'NORMALIZE'

    group_input = explode_node_group.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    accumulate_field_001 = explode_node_group.nodes.new("GeometryNodeAccumulateField")
    accumulate_field_001.name = "Accumulate Field.001"
    accumulate_field_001.data_type = 'INT'
    accumulate_field_001.domain = 'POINT'
    accumulate_field_001.inputs["Value"].default_value = 1

    accumulate_field = explode_node_group.nodes.new("GeometryNodeAccumulateField")
    accumulate_field.name = "Accumulate Field"
    accumulate_field.data_type = 'FLOAT_VECTOR'
    accumulate_field.domain = 'POINT'

    position = explode_node_group.nodes.new("GeometryNodeInputPosition")
    position.name = "Position"

    mesh_island = explode_node_group.nodes.new("GeometryNodeInputMeshIsland")
    mesh_island.name = "Mesh Island"

    face_area = explode_node_group.nodes.new("GeometryNodeInputMeshFaceArea")
    face_area.name = "Face Area"

    accumulate_field_003 = explode_node_group.nodes.new("GeometryNodeAccumulateField")
    accumulate_field_003.name = "Accumulate Field.003"
    accumulate_field_003.data_type = 'FLOAT'
    accumulate_field_003.domain = 'POINT'

    math = explode_node_group.nodes.new("ShaderNodeMath")
    math.name = "Math"
    math.operation = 'ADD'

    map_range = explode_node_group.nodes.new("ShaderNodeMapRange")
    map_range.name = "Map Range"
    map_range.clamp = True
    map_range.data_type = 'FLOAT'
    map_range.interpolation_type = 'LINEAR'
    map_range.inputs[1].default_value = 0.0
    map_range.inputs[2].default_value = 2.0
    map_range.inputs[3].default_value = 0.10000000149011612
    map_range.inputs[4].default_value = 2.200000047683716

    random_value = explode_node_group.nodes.new("FunctionNodeRandomValue")
    random_value.name = "Random Value"
    random_value.data_type = 'FLOAT'
    random_value.inputs[2].default_value = 0

    set_position = explode_node_group.nodes.new("GeometryNodeSetPosition")
    set_position.name = "Set Position"

    group_output = explode_node_group.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    vector_math_006 = explode_node_group.nodes.new("ShaderNodeVectorMath")
    vector_math_006.name = "Vector Math.006"
    vector_math_006.operation = 'SCALE'

    math_003 = explode_node_group.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'MULTIPLY'

    math_002 = explode_node_group.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'SUBTRACT'
    math_002.inputs[1].default_value = 1.0

    math_001 = explode_node_group.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'

    vector_math_003 = explode_node_group.nodes.new("ShaderNodeVectorMath")
    vector_math_003.name = "Vector Math.003"
    vector_math_003.operation = 'SCALE'

    vector_rotate = explode_node_group.nodes.new("ShaderNodeVectorRotate")
    vector_rotate.name = "Vector Rotate"
    vector_rotate.rotation_type = 'EULER_XYZ'

    object_info = explode_node_group.nodes.new("GeometryNodeObjectInfo")
    object_info.name = "Object Info"
    object_info.transform_space = 'ORIGINAL'

    vector_math_004 = explode_node_group.nodes.new("ShaderNodeVectorMath")
    vector_math_004.name = "Vector Math.004"
    vector_math_004.operation = 'ABSOLUTE'

    switch_001 = explode_node_group.nodes.new("GeometryNodeSwitch")
    switch_001.name = "Switch.001"
    switch_001.input_type = 'FLOAT'
    switch_001.inputs["False"].default_value = 1.0

    named_attribute = explode_node_group.nodes.new("GeometryNodeInputNamedAttribute")
    named_attribute.name = "Named Attribute (VGroup)"
    named_attribute.data_type = 'FLOAT'

    switch_vgroup = explode_node_group.nodes.new("GeometryNodeSwitch")
    switch_vgroup.name = "Switch (VGroup Check)"
    switch_vgroup.input_type = 'FLOAT'
    switch_vgroup.inputs["False"].default_value = 1.0

    vector_math_vgroup_scale = explode_node_group.nodes.new("ShaderNodeVectorMath")
    vector_math_vgroup_scale.name = "Vector Math (VGroup Mask)"
    vector_math_vgroup_scale.operation = 'SCALE'

    named_attribute.location = (1400.0, 1400.0)
    switch_vgroup.location = (1650.0, 1400.0)
    vector_math_vgroup_scale.location = (1800.0, 950.0)
    explode_node_group.nodes["Vector Math"].location = (-7.87, 907.02)
    explode_node_group.nodes["Vector Math.001"].location = (192.12, 907.02)
    explode_node_group.nodes["Vector Math.002"].location = (392.12, 907.02)
    explode_node_group.nodes["Group Input"].location = (-568.88, 1106.87)
    explode_node_group.nodes["Accumulate Field.001"].location = (-257.87, 707.02)
    explode_node_group.nodes["Accumulate Field"].location = (-257.87, 907.02)
    explode_node_group.nodes["Position"].location = (-574.59, 853.68)
    explode_node_group.nodes["Mesh Island"].location = (-581.01, 621.27)
    explode_node_group.nodes["Face Area"].location = (-480.19, 167.44)
    explode_node_group.nodes["Accumulate Field.003"].location = (-256.82, 308.91)
    explode_node_group.nodes["Math"].location = (1424.95, 637.96)
    explode_node_group.nodes["Map Range"].location = (33.01, 35.85)
    explode_node_group.nodes["Random Value"].location = (965.84, 219.40)
    explode_node_group.nodes["Set Position"].location = (2000.0, 1104.92)
    explode_node_group.nodes["Group Output"].location = (2250.0, 1034.81)
    explode_node_group.nodes["Vector Math.006"].location = (1600.0, 946.68)
    explode_node_group.nodes["Math.003"].location = (774.73, 333.83)
    explode_node_group.nodes["Math.002"].location = (290.12, 315.87)
    explode_node_group.nodes["Math.001"].location = (505.89, 448.48)
    explode_node_group.nodes["Vector Math.003"].location = (1030.89, 948.89)
    explode_node_group.nodes["Vector Rotate"].location = (1331.19, 947.92)
    explode_node_group.nodes["Object Info"].location = (-101.13, 529.88)
    explode_node_group.nodes["Vector Math.004"].location = (108.71, 346.55)
    explode_node_group.nodes["Switch.001"].location = (382.39, 54.74)

    # Node Group Links
    links = explode_node_group.links

    if ZenPolls.version_since_5_2_0:
        nodes = explode_node_group.nodes

        links.new(nodes['Position'].outputs[0], nodes['Accumulate Field'].inputs[0])
        links.new(nodes['Vector Math'].outputs[0], nodes['Vector Math.001'].inputs[0])
        links.new(nodes['Vector Math.001'].outputs[0], nodes['Vector Math.002'].inputs[0])
        links.new(nodes['Vector Math.002'].outputs[0], nodes['Vector Math.003'].inputs[0])
        links.new(nodes['Mesh Island'].outputs[0], nodes['Accumulate Field'].inputs[1])
        links.new(nodes['Mesh Island'].outputs[0], nodes['Accumulate Field.001'].inputs[1])
        links.new(nodes['Accumulate Field'].outputs[2], nodes['Vector Math'].inputs[0])
        links.new(nodes['Accumulate Field.001'].outputs[2], nodes['Vector Math'].inputs[1])
        links.new(nodes['Object Info'].outputs[1], nodes['Vector Math.001'].inputs[1])
        links.new(nodes['Set Position'].outputs[0], nodes['Group Output'].inputs[0])
        links.new(nodes['Group Input'].outputs[1], nodes['Object Info'].inputs[0])
        links.new(nodes['Group Input'].outputs[0], nodes['Set Position'].inputs[0])
        links.new(nodes['Object Info'].outputs[2], nodes['Vector Rotate'].inputs[4])
        links.new(nodes['Vector Math.003'].outputs[0], nodes['Vector Rotate'].inputs[0])
        links.new(nodes['Group Input'].outputs[2], nodes['Math.001'].inputs[0])
        links.new(nodes['Math.002'].outputs[0], nodes['Math.001'].inputs[1])
        links.new(nodes['Vector Rotate'].outputs[0], nodes['Vector Math.006'].inputs[0])
        links.new(nodes['Math.001'].outputs[0], nodes['Math'].inputs[0])
        links.new(nodes['Face Area'].outputs[0], nodes['Accumulate Field.003'].inputs[0])
        links.new(nodes['Mesh Island'].outputs[0], nodes['Accumulate Field.003'].inputs[1])
        links.new(nodes['Math.003'].outputs[0], nodes['Vector Math.003'].inputs[3])
        links.new(nodes['Accumulate Field.003'].outputs[2], nodes['Map Range'].inputs[0])
        links.new(nodes['Math.001'].outputs[0], nodes['Math.003'].inputs[0])
        links.new(nodes['Math'].outputs[0], nodes['Vector Math.006'].inputs[3])
        links.new(nodes['Object Info'].outputs[3], nodes['Vector Math.004'].inputs[0])
        links.new(nodes['Vector Math.004'].outputs[0], nodes['Math.002'].inputs[0])
        links.new(nodes['Map Range'].outputs[0], nodes['Switch.001'].inputs[2])
        links.new(nodes['Group Input'].outputs[3], nodes['Switch.001'].inputs[0])
        links.new(nodes['Switch.001'].outputs[0], nodes['Math.003'].inputs[1])
        links.new(nodes['Group Input'].outputs[5], nodes['Random Value'].inputs[3])
        links.new(nodes['Mesh Island'].outputs[0], nodes['Random Value'].inputs[2])
        links.new(nodes['Group Input'].outputs[4], nodes['Random Value'].inputs[1])
        links.new(nodes['Random Value'].outputs[0], nodes['Math'].inputs[1])
        links.new(nodes['Vector Math (VGroup Mask)'].outputs[0], nodes['Set Position'].inputs[3])
        links.new(nodes['Vector Math.006'].outputs[0], nodes['Vector Math (VGroup Mask)'].inputs[0])
        links.new(nodes['Switch (VGroup Check)'].outputs[0], nodes['Vector Math (VGroup Mask)'].inputs[3])
        links.new(nodes['Named Attribute (VGroup)'].outputs[1], nodes['Switch (VGroup Check)'].inputs[0])
        links.new(nodes['Named Attribute (VGroup)'].outputs[0], nodes['Switch (VGroup Check)'].inputs[2])
        links.new(nodes['Group Input'].outputs[6], nodes['Named Attribute (VGroup)'].inputs[0])

    else:
        links.new(position.outputs[0], accumulate_field.inputs[0])
        links.new(vector_math.outputs[0], vector_math_001.inputs[0])
        links.new(vector_math_001.outputs[0], vector_math_002.inputs[0])
        links.new(vector_math_002.outputs[0], vector_math_003.inputs[0])
        links.new(mesh_island.outputs[0], accumulate_field.inputs["Group ID"])
        links.new(mesh_island.outputs[0], accumulate_field_001.inputs["Group ID"])
        links.new(accumulate_field.outputs["Total"], vector_math.inputs[0])
        links.new(accumulate_field_001.outputs["Total"], vector_math.inputs[1])
        links.new(object_info.outputs["Location"], vector_math_001.inputs[1])
        links.new(set_position.outputs[0], group_output.inputs[0])
        links.new(group_input.outputs[1], object_info.inputs[0])
        links.new(group_input.outputs[0], set_position.inputs[0])
        links.new(object_info.outputs["Rotation"], vector_rotate.inputs[4])
        links.new(vector_math_003.outputs[0], vector_rotate.inputs[0])
        links.new(group_input.outputs[2], math_001.inputs[0])
        links.new(math_002.outputs[0], math_001.inputs[1])
        links.new(vector_rotate.outputs[0], vector_math_006.inputs[0])
        links.new(mesh_island.outputs[0], random_value.inputs[7])
        links.new(math_001.outputs[0], math.inputs[0])
        links.new(face_area.outputs[0], accumulate_field_003.inputs["Value"])
        links.new(mesh_island.outputs[0], accumulate_field_003.inputs["Group ID"])
        links.new(math_003.outputs[0], vector_math_003.inputs[3])
        links.new(accumulate_field_003.outputs["Total"], map_range.inputs["Value"])
        links.new(math_001.outputs[0], math_003.inputs[0])
        links.new(math.outputs[0], vector_math_006.inputs[3])
        links.new(group_input.outputs[5], random_value.inputs[8])
        links.new(group_input.outputs[4], random_value.inputs[3])
        links.new(object_info.outputs["Scale"], vector_math_004.inputs[0])
        links.new(vector_math_004.outputs[0], math_002.inputs[0])
        links.new(map_range.outputs["Result"], switch_001.inputs["True"])
        links.new(group_input.outputs[3], switch_001.inputs[0])
        links.new(switch_001.outputs[0], math_003.inputs[1])
        links.new(random_value.outputs[1], math.inputs[1])
        links.new(group_input.outputs[6], named_attribute.inputs["Name"])
        links.new(named_attribute.outputs["Exists"], switch_vgroup.inputs["Switch"])
        links.new(named_attribute.outputs["Attribute"], switch_vgroup.inputs["True"])
        links.new(vector_math_006.outputs[0], vector_math_vgroup_scale.inputs[0])
        links.new(switch_vgroup.outputs[0], vector_math_vgroup_scale.inputs[3])
        links.new(vector_math_vgroup_scale.outputs[0], set_position.inputs[3])

    return explode_node_group
