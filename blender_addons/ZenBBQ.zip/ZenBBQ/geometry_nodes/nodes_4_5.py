# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2025, Valeriy Yatsenko - lightbio@gmail.com

import bpy

from ..consts import ZBBQ_Consts
from ..blender_zen_utils import ZenPolls


# initialize from_srgb_to_linear node group
def from_srgb_to_linear_node_group():
    GN_FromFrgbToLinear = bpy.data.node_groups.new(type='GeometryNodeTree', name="From_sRGB_to_Linear")

    # from_srgb_to_linear interface
    # Socket Float
    float_socket = GN_FromFrgbToLinear.interface.new_socket(name="Float", in_out='OUTPUT', socket_type='NodeSocketFloat')
    float_socket.default_value = 0.0
    float_socket.min_value = -3.4028234663852886e+38
    float_socket.max_value = 3.4028234663852886e+38
    float_socket.subtype = 'NONE'
    float_socket.attribute_domain = 'POINT'
    float_socket.structure_type = 'AUTO'

    # Socket Float
    float_socket_1 = GN_FromFrgbToLinear.interface.new_socket(name="Float", in_out='INPUT', socket_type='NodeSocketVector')
    float_socket_1.default_value = (0.0, 0.0, 0.0)
    float_socket_1.min_value = -3.4028234663852886e+38
    float_socket_1.max_value = 3.4028234663852886e+38
    float_socket_1.subtype = 'NONE'
    float_socket_1.attribute_domain = 'POINT'
    float_socket_1.structure_type = 'AUTO'

    # initialize from_srgb_to_linear nodes
    # node Group Input
    group_input = GN_FromFrgbToLinear.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    # node Group Output
    group_output = GN_FromFrgbToLinear.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    # node Compare
    compare = GN_FromFrgbToLinear.nodes.new("FunctionNodeCompare")
    compare.name = "Compare"
    compare.data_type = 'FLOAT'
    compare.mode = 'ELEMENT'
    compare.operation = 'LESS_THAN'

    # node Math.001
    math_001 = GN_FromFrgbToLinear.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = False
    # Value_001
    math_001.inputs[1].default_value = 0.05

    # node Math.002
    math_002 = GN_FromFrgbToLinear.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'DIVIDE'
    math_002.use_clamp = False
    # Value_001
    math_002.inputs[1].default_value = 1.05

    # node Math.003
    math_003 = GN_FromFrgbToLinear.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'POWER'
    math_003.use_clamp = False
    # Value_001
    math_003.inputs[1].default_value = 2.4

    # node Mix
    mix = GN_FromFrgbToLinear.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'FLOAT'
    mix.factor_mode = 'UNIFORM'

    # node Math.004
    math_004 = GN_FromFrgbToLinear.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'DIVIDE'
    math_004.use_clamp = False
    # Value_001
    math_004.inputs[1].default_value = 12.920000076293945

    # Set locations
    group_input.location = (-1344.46826171875, -2.769836187362671)
    group_output.location = (568.9783935546875, -28.121002197265625)
    compare.location = (-36.55250549316406, 159.51365661621094)
    math_001.location = (-968.44873046875, 85.7568359375)
    math_002.location = (-768.44873046875, 85.7568359375)
    math_003.location = (-568.44873046875, 85.7568359375)
    mix.location = (341.6607971191406, -28.566307067871094)
    math_004.location = (-970.995361328125, -151.551513671875)

    # initialize from_srgb_to_linear links

    links = GN_FromFrgbToLinear.links
    nodes = GN_FromFrgbToLinear.nodes

    if ZenPolls.version_since_5_2_0:
        # MARK: Blender 5.2

        links.new(nodes['Math.001'].outputs[0], nodes['Math.002'].inputs[0])
        links.new(nodes['Math.002'].outputs[0], nodes['Math.003'].inputs[0])
        links.new(nodes['Compare'].outputs[0], nodes['Mix'].inputs[0])
        links.new(nodes['Math.003'].outputs[0], nodes['Mix'].inputs[2])
        links.new(nodes['Mix'].outputs[0], nodes['Group Output'].inputs[0])
        links.new(nodes['Math.004'].outputs[0], nodes['Mix'].inputs[3])
        links.new(nodes['Math.004'].outputs[0], nodes['Compare'].inputs[1])
        links.new(nodes['Math.003'].outputs[0], nodes['Compare'].inputs[0])
        links.new(nodes['Group Input'].outputs[0], nodes['Math.001'].inputs[0])
        links.new(nodes['Group Input'].outputs[0], nodes['Math.004'].inputs[0])
    else:
        # MARK: below Blender 5.2

        links.new(math_001.outputs[0], math_002.inputs[0])
        links.new(math_002.outputs[0], math_003.inputs[0])
        links.new(compare.outputs[0], mix.inputs[0])
        links.new(math_003.outputs[0], mix.inputs[2])
        links.new(mix.outputs[0], group_output.inputs[0])
        links.new(math_004.outputs[0], mix.inputs[3])
        links.new(math_004.outputs[0], compare.inputs[1])
        links.new(math_003.outputs[0], compare.inputs[0])
        links.new(group_input.outputs[0], math_001.inputs[0])
        links.new(group_input.outputs[0], math_004.inputs[0])

    return GN_FromFrgbToLinear


def zenbbq_bevelstovertexcolor_node_group():
    GN_BevToVc = bpy.data.node_groups.new(type='GeometryNodeTree', name="ZenBBQ_BevelsToVertexColor")

    GN_BevToVc.is_modifier = True

    # zenbbq_bevelstovertexcolor interface
    # Socket Geometry
    geometry_socket = GN_BevToVc.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'
    geometry_socket.structure_type = 'AUTO'

    # Socket Geometry
    geometry_socket_1 = GN_BevToVc.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'
    geometry_socket_1.structure_type = 'AUTO'

    # Socket Layer Name
    layer_name_socket = GN_BevToVc.interface.new_socket(name="Layer Name", in_out='INPUT', socket_type='NodeSocketString')
    layer_name_socket.default_value = "N_ZenBBQ_VC_Mask"
    layer_name_socket.subtype = 'NONE'
    layer_name_socket.attribute_domain = 'POINT'
    layer_name_socket.description = "Vertex color layer name"
    layer_name_socket.structure_type = 'AUTO'

    # Socket R
    r_socket = GN_BevToVc.interface.new_socket(name="R", in_out='INPUT', socket_type='NodeSocketBool')
    r_socket.default_value = True
    r_socket.attribute_domain = 'POINT'
    r_socket.description = "Vertex Color Channel Red"
    r_socket.structure_type = 'AUTO'

    # Socket G
    g_socket = GN_BevToVc.interface.new_socket(name="G", in_out='INPUT', socket_type='NodeSocketBool')
    g_socket.default_value = False
    g_socket.attribute_domain = 'POINT'
    g_socket.description = "Vertex Color Channel Green"
    g_socket.structure_type = 'AUTO'

    # Socket B
    b_socket = GN_BevToVc.interface.new_socket(name="B", in_out='INPUT', socket_type='NodeSocketBool')
    b_socket.default_value = False
    b_socket.attribute_domain = 'POINT'
    b_socket.description = "Vertex Color Channel Blue"
    b_socket.structure_type = 'AUTO'

    # Socket Default Radius
    default_radius_socket = GN_BevToVc.interface.new_socket(name="Default Radius", in_out='INPUT', socket_type='NodeSocketFloat')
    default_radius_socket.default_value = 0.0
    default_radius_socket.min_value = -3.4028234663852886e+38
    default_radius_socket.max_value = 3.4028234663852886e+38
    default_radius_socket.subtype = 'NONE'
    default_radius_socket.attribute_domain = 'POINT'
    default_radius_socket.description = "Live Boolean (default) bevel radius"
    default_radius_socket.structure_type = 'AUTO'

    # Socket Units Mult
    units_mult_socket = GN_BevToVc.interface.new_socket(name="Units Mult", in_out='INPUT', socket_type='NodeSocketFloat')
    units_mult_socket.default_value = 0.0
    units_mult_socket.min_value = -3.4028234663852886e+38
    units_mult_socket.max_value = 3.4028234663852886e+38
    units_mult_socket.subtype = 'NONE'
    units_mult_socket.attribute_domain = 'POINT'
    units_mult_socket.hide_in_modifier = True
    units_mult_socket.structure_type = 'AUTO'

    # Panel Max Bevel Value
    max_bevel_value_panel = GN_BevToVc.interface.new_panel("Max Bevel Value")
    # Socket Use Global Bevel Value
    use_global_bevel_value_socket = GN_BevToVc.interface.new_socket(name="Use Global Bevel Value", in_out='INPUT', socket_type='NodeSocketBool', parent=max_bevel_value_panel)
    use_global_bevel_value_socket.default_value = True
    use_global_bevel_value_socket.attribute_domain = 'POINT'
    use_global_bevel_value_socket.structure_type = 'AUTO'

    # Socket Max Global Value
    max_global_value_socket = GN_BevToVc.interface.new_socket(name="Max Global Value", in_out='INPUT', socket_type='NodeSocketFloat', parent=max_bevel_value_panel)
    max_global_value_socket.default_value = 0.0
    max_global_value_socket.min_value = -3.4028234663852886e+38
    max_global_value_socket.max_value = 3.4028234663852886e+38
    # max_global_value_socket.subtype = 'NONE'
    max_global_value_socket.attribute_domain = 'POINT'
    max_global_value_socket.description = "Click the Update button in the main panel to update the value"
    max_global_value_socket.structure_type = 'AUTO'

    # initialize zenbbq_bevelstovertexcolor nodes
    # node Group Input
    group_input_1 = GN_BevToVc.nodes.new("NodeGroupInput")
    group_input_1.name = "Group Input"

    # node Group Output
    group_output_1 = GN_BevToVc.nodes.new("NodeGroupOutput")
    group_output_1.name = "Group Output"
    group_output_1.is_active_output = True

    # node Named Attribute
    named_attribute = GN_BevToVc.nodes.new("GeometryNodeInputNamedAttribute")
    named_attribute.name = "Named Attribute"
    named_attribute.data_type = 'FLOAT'
    # Name
    named_attribute.inputs[0].default_value = "ZenBBQ"

    # node Store Named Attribute
    store_named_attribute = GN_BevToVc.nodes.new("GeometryNodeStoreNamedAttribute")
    store_named_attribute.name = "Store Named Attribute"
    store_named_attribute.data_type = 'FLOAT_COLOR'
    store_named_attribute.domain = 'CORNER'
    # Selection
    store_named_attribute.inputs[1].default_value = True
    # Name
    store_named_attribute.inputs[2].default_value = ZBBQ_Consts.VertexColorMaskNameNodes

    # node Attribute Statistic
    attribute_statistic = GN_BevToVc.nodes.new("GeometryNodeAttributeStatistic")
    attribute_statistic.name = "Attribute Statistic"
    attribute_statistic.data_type = 'FLOAT'
    attribute_statistic.domain = 'CORNER'
    # Selection
    attribute_statistic.inputs[1].default_value = True

    # node Math
    math = GN_BevToVc.nodes.new("ShaderNodeMath")
    math.label = "x-a1"
    math.name = "Math"
    math.operation = 'SUBTRACT'
    math.use_clamp = False

    # node Math.001
    math_001_1 = GN_BevToVc.nodes.new("ShaderNodeMath")
    math_001_1.label = "b2-b1"
    math_001_1.name = "Math.001"
    math_001_1.operation = 'SUBTRACT'
    math_001_1.use_clamp = False

    # node Math.002
    math_002_1 = GN_BevToVc.nodes.new("ShaderNodeMath")
    math_002_1.label = "a2-a1"
    math_002_1.name = "Math.002"
    math_002_1.operation = 'SUBTRACT'
    math_002_1.use_clamp = False

    # node Value
    value = GN_BevToVc.nodes.new("ShaderNodeValue")
    value.label = "b1"
    value.name = "Value"

    value.outputs[0].default_value = 0.0
    # node Value.001
    value_001 = GN_BevToVc.nodes.new("ShaderNodeValue")
    value_001.label = "b2"
    value_001.name = "Value.001"

    value_001.outputs[0].default_value = 1.0
    # node Math.003
    math_003_1 = GN_BevToVc.nodes.new("ShaderNodeMath")
    math_003_1.label = "b1+"
    math_003_1.name = "Math.003"
    math_003_1.operation = 'ADD'
    math_003_1.use_clamp = False

    # node Math.004
    math_004_1 = GN_BevToVc.nodes.new("ShaderNodeMath")
    math_004_1.label = "mult"
    math_004_1.name = "Math.004"
    math_004_1.operation = 'MULTIPLY'
    math_004_1.use_clamp = False

    # node Math.005
    math_005 = GN_BevToVc.nodes.new("ShaderNodeMath")
    math_005.label = "a2-a1"
    math_005.name = "Math.005"
    math_005.operation = 'DIVIDE'
    math_005.use_clamp = False

    # node Frame
    frame = GN_BevToVc.nodes.new("NodeFrame")
    frame.name = "Frame"
    frame.label_size = 20
    frame.shrink = True

    # node From_sRGB_to_Linear
    from_srgb_to_linear_1 = GN_BevToVc.nodes.new("GeometryNodeGroup")
    from_srgb_to_linear_1.name = "From_sRGB_to_Linear"
    from_srgb_to_linear_1.node_tree = from_srgb_to_linear_node_group()

    # node Combine XYZ
    combine_xyz = GN_BevToVc.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.name = "Combine XYZ"

    # node Mix
    mix_1 = GN_BevToVc.nodes.new("ShaderNodeMix")
    mix_1.name = "Mix"
    mix_1.blend_type = 'MIX'
    mix_1.clamp_factor = True
    mix_1.clamp_result = False
    mix_1.data_type = 'FLOAT'
    mix_1.factor_mode = 'UNIFORM'
    # A_Float
    mix_1.inputs[2].default_value = 0.0

    # node Mix.001
    mix_001 = GN_BevToVc.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'FLOAT'
    mix_001.factor_mode = 'UNIFORM'
    # A_Float
    mix_001.inputs[2].default_value = 0.0

    # node Mix.002
    mix_002 = GN_BevToVc.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'FLOAT'
    mix_002.factor_mode = 'UNIFORM'
    # A_Float
    mix_002.inputs[2].default_value = 0.0

    # node Named Attribute.001
    named_attribute_001 = GN_BevToVc.nodes.new("GeometryNodeInputNamedAttribute")
    named_attribute_001.name = "Named Attribute.001"
    named_attribute_001.data_type = 'FLOAT'
    # Name
    named_attribute_001.inputs[0].default_value = "ZenBBQ_UserDefined"

    # node Mix.003
    mix_003 = GN_BevToVc.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'FLOAT'
    mix_003.factor_mode = 'UNIFORM'

    # node Math.006
    math_006 = GN_BevToVc.nodes.new("ShaderNodeMath")
    math_006.label = "LivePremult"
    math_006.name = "Math.006"
    math_006.operation = 'MULTIPLY'
    math_006.use_clamp = False

    # node Value.002
    value_002 = GN_BevToVc.nodes.new("ShaderNodeValue")
    value_002.label = "min"
    value_002.name = "Value.002"

    value_002.outputs[0].default_value = 0.0
    # node Switch
    switch = GN_BevToVc.nodes.new("GeometryNodeSwitch")
    switch.name = "Switch"
    switch.input_type = 'FLOAT'

    # Set parents
    math.parent = frame
    math_001_1.parent = frame
    math_002_1.parent = frame
    math_003_1.parent = frame
    math_004_1.parent = frame
    math_005.parent = frame

    # Set locations
    group_input_1.location = (-385.075439453125, 116.0099105834961)
    group_output_1.location = (3408.727783203125, 90.6146469116211)
    named_attribute.location = (-382.45782470703125, -409.5552673339844)
    store_named_attribute.location = (3198.736083984375, 141.54383850097656)
    attribute_statistic.location = (295.73553466796875, -156.34494018554688)
    math.location = (30.28546142578125, -198.13485717773438)
    math_001_1.location = (413.22021484375, -380.47930908203125)
    math_002_1.location = (414.100341796875, -30.110633850097656)
    value.location = (294.09918212890625, -569.9877319335938)
    value_001.location = (296.0908203125, -637.1307983398438)
    math_003_1.location = (411.786865234375, -206.79095458984375)
    math_004_1.location = (670.597412109375, -194.95852661132812)
    math_005.location = (947.135498046875, -89.65211486816406)
    frame.location = (838.0, -85.0)
    from_srgb_to_linear_1.location = (2039.763671875, -127.03800964355469)
    combine_xyz.location = (2808.235107421875, -510.5343933105469)
    mix_1.location = (2418.663330078125, -231.48121643066406)
    mix_001.location = (2418.663330078125, -451.84747314453125)
    mix_002.location = (2423.825927734375, -674.0969848632812)
    named_attribute_001.location = (-381.52349853515625, -268.28631591796875)
    mix_003.location = (35.707237243652344, -304.61419677734375)
    math_006.location = (-181.66200256347656, -12.359786987304688)
    value_002.location = (294.015869140625, -69.81167602539062)
    switch.location = (555.0208129882812, -395.06207275390625)

    # Set dimensions
    group_input_1.width, group_input_1.height = 140.0, 100.0
    group_output_1.width, group_output_1.height = 140.0, 100.0
    named_attribute.width, named_attribute.height = 140.0, 100.0
    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    math_001_1.width, math_001_1.height = 140.0, 100.0
    math_002_1.width, math_002_1.height = 140.0, 100.0
    value.width, value.height = 140.0, 100.0
    value_001.width, value_001.height = 140.0, 100.0
    math_003_1.width, math_003_1.height = 140.0, 100.0
    math_004_1.width, math_004_1.height = 140.0, 100.0
    math_005.width, math_005.height = 140.0, 100.0
    frame.width, frame.height = 1117.0, 558.0
    from_srgb_to_linear_1.width, from_srgb_to_linear_1.height = 140.0, 100.0
    combine_xyz.width, combine_xyz.height = 140.0, 100.0
    mix_1.width, mix_1.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    named_attribute_001.width, named_attribute_001.height = 138.95523071289062, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    math_006.width, math_006.height = 140.0, 100.0
    value_002.width, value_002.height = 140.0, 100.0
    switch.width, switch.height = 140.0, 100.0

    # initialize zenbbq_bevelstovertexcolor links
    # MARK: Links Blender 5.2
    links = GN_BevToVc.links
    nodes = GN_BevToVc.nodes
    if ZenPolls.version_since_5_2_0:
        links.new(nodes['Group Input'].outputs[0], nodes['Store Named Attribute'].inputs[0])
        links.new(nodes['Store Named Attribute'].outputs[0], nodes['Group Output'].inputs[0])
        links.new(nodes['Group Input'].outputs[0], nodes['Attribute Statistic'].inputs[0])
        links.new(nodes['Value'].outputs[0], nodes['Math.003'].inputs[0])
        links.new(nodes['Math'].outputs[0], nodes['Math.003'].inputs[1])
        links.new(nodes['Math.003'].outputs[0], nodes['Math.004'].inputs[0])
        links.new(nodes['Math.001'].outputs[0], nodes['Math.004'].inputs[1])
        links.new(nodes['Math.004'].outputs[0], nodes['Math.005'].inputs[0])
        links.new(nodes['Math.002'].outputs[0], nodes['Math.005'].inputs[1])
        links.new(nodes['Value.001'].outputs[0], nodes['Math.001'].inputs[0])
        links.new(nodes['Value'].outputs[0], nodes['Math.001'].inputs[1])
        links.new(nodes['Math.005'].outputs[0], nodes['From_sRGB_to_Linear'].inputs[0])
        links.new(nodes['Group Input'].outputs[2], nodes['Mix'].inputs[0])
        links.new(nodes['Mix'].outputs[0], nodes['Combine XYZ'].inputs[0])
        links.new(nodes['From_sRGB_to_Linear'].outputs[0], nodes['Mix'].inputs[3])
        links.new(nodes['From_sRGB_to_Linear'].outputs[0], nodes['Mix.001'].inputs[3])
        links.new(nodes['From_sRGB_to_Linear'].outputs[0], nodes['Mix.002'].inputs[3])
        links.new(nodes['Group Input'].outputs[3], nodes['Mix.001'].inputs[0])
        links.new(nodes['Group Input'].outputs[4], nodes['Mix.002'].inputs[0])
        links.new(nodes['Mix.001'].outputs[0], nodes['Combine XYZ'].inputs[1])
        links.new(nodes['Mix.002'].outputs[0], nodes['Combine XYZ'].inputs[2])
        links.new(nodes['Mix.003'].outputs[0], nodes['Math'].inputs[0])
        links.new(nodes['Mix.003'].outputs[0], nodes['Attribute Statistic'].inputs[2])
        links.new(nodes['Group Input'].outputs[5], nodes['Math.006'].inputs[0])
        links.new(nodes['Group Input'].outputs[6], nodes['Math.006'].inputs[1])
        links.new(nodes['Math.006'].outputs[0], nodes['Mix.003'].inputs[2])
        links.new(nodes['Value.002'].outputs[0], nodes['Math.002'].inputs[1])
        links.new(nodes['Value.002'].outputs[0], nodes['Math'].inputs[1])
        links.new(nodes['Group Input'].outputs[7], nodes['Switch'].inputs[0])
        links.new(nodes['Switch'].outputs[0], nodes['Math.002'].inputs[0])
        links.new(nodes['Group Input'].outputs[1], nodes['Store Named Attribute'].inputs[2])
        links.new(nodes['Named Attribute.001'].outputs[0], nodes['Mix.003'].inputs[0])
        links.new(nodes['Named Attribute'].outputs[0], nodes['Mix.003'].inputs[3])
        links.new(nodes['Attribute Statistic'].outputs[4], nodes['Switch'].inputs[1])
        links.new(nodes['Group Input'].outputs[8], nodes['Switch'].inputs[2])
        links.new(nodes['Combine XYZ'].outputs[0], nodes['Store Named Attribute'].inputs[3])
    else:
        # MARK: Links below Blender 5.2
        links.new(group_input_1.outputs[0], store_named_attribute.inputs[0])
        links.new(store_named_attribute.outputs[0], group_output_1.inputs[0])
        links.new(group_input_1.outputs[0], attribute_statistic.inputs[0])
        links.new(value.outputs[0], math_003_1.inputs[0])
        links.new(math.outputs[0], math_003_1.inputs[1])
        links.new(math_003_1.outputs[0], math_004_1.inputs[0])
        links.new(math_001_1.outputs[0], math_004_1.inputs[1])
        links.new(math_004_1.outputs[0], math_005.inputs[0])
        links.new(math_002_1.outputs[0], math_005.inputs[1])
        links.new(value_001.outputs[0], math_001_1.inputs[0])
        links.new(value.outputs[0], math_001_1.inputs[1])
        links.new(math_005.outputs[0], from_srgb_to_linear_1.inputs[0])
        links.new(combine_xyz.outputs[0], store_named_attribute.inputs[3])
        links.new(group_input_1.outputs[2], mix_1.inputs[0])
        links.new(mix_1.outputs[0], combine_xyz.inputs[0])
        links.new(from_srgb_to_linear_1.outputs[0], mix_1.inputs[3])
        links.new(from_srgb_to_linear_1.outputs[0], mix_001.inputs[3])
        links.new(from_srgb_to_linear_1.outputs[0], mix_002.inputs[3])
        links.new(group_input_1.outputs[3], mix_001.inputs[0])
        links.new(group_input_1.outputs[4], mix_002.inputs[0])
        links.new(mix_001.outputs[0], combine_xyz.inputs[1])
        links.new(mix_002.outputs[0], combine_xyz.inputs[2])
        links.new(mix_003.outputs[0], math.inputs[0])
        links.new(mix_003.outputs[0], attribute_statistic.inputs[2])
        links.new(named_attribute.outputs[0], mix_003.inputs[3])
        links.new(named_attribute_001.outputs[0], mix_003.inputs[0])
        links.new(group_input_1.outputs[5], math_006.inputs[0])
        links.new(group_input_1.outputs[6], math_006.inputs[1])
        links.new(math_006.outputs[0], mix_003.inputs[2])
        links.new(value_002.outputs[0], math_002_1.inputs[1])
        links.new(value_002.outputs[0], math.inputs[1])
        links.new(group_input_1.outputs[7], switch.inputs[0])
        links.new(attribute_statistic.outputs[4], switch.inputs[1])
        links.new(group_input_1.outputs[8], switch.inputs[2])
        links.new(switch.outputs[0], math_002_1.inputs[0])
        links.new(group_input_1.outputs[1], store_named_attribute.inputs[2])

    return GN_BevToVc


def ensure_zenbbq_bevelstovertexcolor_node_group_blen_4_5():
    p_node = bpy.data.node_groups.get("ZenBBQ_BevelsToVertexColor")
    if not p_node:
        return zenbbq_bevelstovertexcolor_node_group()
    return p_node


if __name__ == "__main__":
    pass
