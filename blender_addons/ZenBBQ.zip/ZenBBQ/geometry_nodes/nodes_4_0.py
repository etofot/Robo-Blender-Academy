# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2025, Valeriy Yatsenko - lightbio@gmail.com


import bpy


# initialize from_srgb_to_linear node group
def from_srgb_to_linear_node_group():
    from_srgb_to_linear = bpy.data.node_groups.new(type='GeometryNodeTree', name="From_sRGB_to_Linear")

    # initialize from_srgb_to_linear nodes
    # from_srgb_to_linear interface
    # Socket Float
    float_socket = from_srgb_to_linear.interface.new_socket(name="Float", in_out='OUTPUT', socket_type='NodeSocketFloat')
    float_socket.subtype = 'NONE'
    float_socket.default_value = 0.0
    float_socket.min_value = -3.4028234663852886e+38
    float_socket.max_value = 3.4028234663852886e+38
    float_socket.attribute_domain = 'POINT'

    # Socket Float
    float_socket_1 = from_srgb_to_linear.interface.new_socket(name="Float", in_out='INPUT', socket_type='NodeSocketVector')
    float_socket_1.subtype = 'NONE'
    float_socket_1.default_value = (0.0, 0.0, 0.0)
    float_socket_1.min_value = -3.4028234663852886e+38
    float_socket_1.max_value = 3.4028234663852886e+38
    float_socket_1.attribute_domain = 'POINT'

    # node Group Input
    group_input = from_srgb_to_linear.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    # node Group Output
    group_output = from_srgb_to_linear.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    # node Compare
    compare = from_srgb_to_linear.nodes.new("FunctionNodeCompare")
    compare.name = "Compare"
    compare.data_type = 'FLOAT'
    compare.mode = 'ELEMENT'
    compare.operation = 'LESS_THAN'
    # A_INT
    compare.inputs[2].default_value = 0
    # B_INT
    compare.inputs[3].default_value = 0
    # A_VEC3
    compare.inputs[4].default_value = (0.0, 0.0, 0.0)
    # B_VEC3
    compare.inputs[5].default_value = (0.0, 0.0, 0.0)
    # A_COL
    compare.inputs[6].default_value = (0.0, 0.0, 0.0, 0.0)
    # B_COL
    compare.inputs[7].default_value = (0.0, 0.0, 0.0, 0.0)
    # A_STR
    compare.inputs[8].default_value = ""
    # B_STR
    compare.inputs[9].default_value = ""
    # C
    compare.inputs[10].default_value = 0.8999999761581421
    # Angle
    compare.inputs[11].default_value = 0.08726649731397629
    # Epsilon
    compare.inputs[12].default_value = 0.0010000000474974513

    # node Math.001
    math_001 = from_srgb_to_linear.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = False
    # Value_001
    math_001.inputs[1].default_value = 0.054999999701976776
    # Value_002
    math_001.inputs[2].default_value = 0.5

    # node Math.002
    math_002 = from_srgb_to_linear.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'DIVIDE'
    math_002.use_clamp = False
    # Value_001
    math_002.inputs[1].default_value = 1.0549999475479126
    # Value_002
    math_002.inputs[2].default_value = 0.5

    # node Math.003
    math_003 = from_srgb_to_linear.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'POWER'
    math_003.use_clamp = False
    # Value_001
    math_003.inputs[1].default_value = 2.4000000953674316
    # Value_002
    math_003.inputs[2].default_value = 0.5

    # node Mix
    mix = from_srgb_to_linear.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'FLOAT'
    mix.factor_mode = 'UNIFORM'
    # Factor_Vector
    mix.inputs[1].default_value = (0.5, 0.5, 0.5)
    # A_Vector
    mix.inputs[4].default_value = (0.0, 0.0, 0.0)
    # B_Vector
    mix.inputs[5].default_value = (0.0, 0.0, 0.0)
    # A_Color
    mix.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
    # B_Color
    mix.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    # A_Rotation
    mix.inputs[8].default_value = (0.0, 0.0, 0.0)
    # B_Rotation
    mix.inputs[9].default_value = (0.0, 0.0, 0.0)

    # node Math.004
    math_004 = from_srgb_to_linear.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'DIVIDE'
    math_004.use_clamp = False
    # Value_001
    math_004.inputs[1].default_value = 12.920000076293945
    # Value_002
    math_004.inputs[2].default_value = 0.5

    # Set locations
    group_input.location = (-1344.46826171875, -2.769836187362671)
    group_output.location = (568.9783935546875, -28.121002197265625)
    compare.location = (-36.55250549316406, 159.51365661621094)
    math_001.location = (-968.44873046875, 85.7568359375)
    math_002.location = (-768.44873046875, 85.7568359375)
    math_003.location = (-568.44873046875, 85.7568359375)
    mix.location = (341.6607971191406, -28.566307067871094)
    math_004.location = (-970.995361328125, -151.551513671875)

    # Set dimensions
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    compare.width, compare.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    math_004.width, math_004.height = 140.0, 100.0

    # initialize from_srgb_to_linear links
    # math_001.Value -> math_002.Value
    from_srgb_to_linear.links.new(math_001.outputs[0], math_002.inputs[0])
    # math_002.Value -> math_003.Value
    from_srgb_to_linear.links.new(math_002.outputs[0], math_003.inputs[0])
    # compare.Result -> mix.Factor
    from_srgb_to_linear.links.new(compare.outputs[0], mix.inputs[0])
    # math_003.Value -> mix.A
    from_srgb_to_linear.links.new(math_003.outputs[0], mix.inputs[2])
    # mix.Result -> group_output.Float
    from_srgb_to_linear.links.new(mix.outputs[0], group_output.inputs[0])
    # math_004.Value -> mix.B
    from_srgb_to_linear.links.new(math_004.outputs[0], mix.inputs[3])
    # math_004.Value -> compare.B
    from_srgb_to_linear.links.new(math_004.outputs[0], compare.inputs[1])
    # math_003.Value -> compare.A
    from_srgb_to_linear.links.new(math_003.outputs[0], compare.inputs[0])
    # group_input.Float -> math_001.Value
    from_srgb_to_linear.links.new(group_input.outputs[0], math_001.inputs[0])
    # group_input.Float -> math_004.Value
    from_srgb_to_linear.links.new(group_input.outputs[0], math_004.inputs[0])
    return from_srgb_to_linear


# initialize zenbbq_bevelstovertexcolor node group
def zenbbq_bevelstovertexcolor_node_group():
    zenbbq_bevelstovertexcolor = bpy.data.node_groups.new(type='GeometryNodeTree', name="ZenBBQ_BevelsToVertexColor")

    zenbbq_bevelstovertexcolor.is_modifier = True

    # initialize zenbbq_bevelstovertexcolor nodes
    # zenbbq_bevelstovertexcolor interface
    # Socket Geometry
    geometry_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'

    # Socket Geometry
    geometry_socket_1 = zenbbq_bevelstovertexcolor.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'

    # Socket Layer Name
    layer_name_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="Layer Name", in_out='INPUT', socket_type='NodeSocketString')
    layer_name_socket.attribute_domain = 'POINT'
    layer_name_socket.description = "Vertex color layer name"
    layer_name_socket.default_value = "N_ZenBBQ_VC_Mask"

    # Socket R
    r_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="R", in_out='INPUT', socket_type='NodeSocketBool')
    r_socket.attribute_domain = 'POINT'
    r_socket.description = "Vertex Color Channel Red"
    r_socket.default_value = True

    # Socket G
    g_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="G", in_out='INPUT', socket_type='NodeSocketBool')
    g_socket.attribute_domain = 'POINT'
    g_socket.description = "Vertex Color Channel Green"

    # Socket B
    b_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="B", in_out='INPUT', socket_type='NodeSocketBool')
    b_socket.attribute_domain = 'POINT'
    b_socket.description = "Vertex Color Channel Blue"

    # Socket Default Radius
    default_radius_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="Default Radius", in_out='INPUT', socket_type='NodeSocketFloat')
    default_radius_socket.subtype = 'NONE'
    default_radius_socket.default_value = 0.0
    default_radius_socket.min_value = -3.4028234663852886e+38
    default_radius_socket.max_value = 3.4028234663852886e+38
    default_radius_socket.attribute_domain = 'POINT'
    default_radius_socket.description = "Live Boolean (default) bevel radius"

    # Socket Units Mult
    units_mult_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="Units Mult", in_out='INPUT', socket_type='NodeSocketFloat')
    units_mult_socket.subtype = 'NONE'
    units_mult_socket.default_value = 0.0
    units_mult_socket.min_value = -3.4028234663852886e+38
    units_mult_socket.max_value = 3.4028234663852886e+38
    units_mult_socket.attribute_domain = 'POINT'
    units_mult_socket.hide_in_modifier = True

    # Panel Max Bevel Value
    max_bevel_value_panel = zenbbq_bevelstovertexcolor.interface.new_panel("Max Bevel Value")
    # Socket Use Global Bevel Value
    use_global_bevel_value_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="Use Global Bevel Value", in_out='INPUT', socket_type='NodeSocketBool', parent=max_bevel_value_panel)
    use_global_bevel_value_socket.attribute_domain = 'POINT'
    use_global_bevel_value_socket.default_value = True

    # Socket Max Global Value
    max_global_value_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="Max Global Value", in_out='INPUT', socket_type='NodeSocketFloat', parent=max_bevel_value_panel)
    max_global_value_socket.subtype = 'NONE'
    max_global_value_socket.default_value = 0.0
    max_global_value_socket.min_value = -3.4028234663852886e+38
    max_global_value_socket.max_value = 3.4028234663852886e+38
    max_global_value_socket.attribute_domain = 'POINT'
    max_global_value_socket.description = "Click the Update button in the main panel to update the value"

    # node Frame
    frame = zenbbq_bevelstovertexcolor.nodes.new("NodeFrame")
    frame.name = "Frame"
    frame.label_size = 20
    frame.shrink = True

    # node Group Output
    group_output_1 = zenbbq_bevelstovertexcolor.nodes.new("NodeGroupOutput")
    group_output_1.name = "Group Output"
    group_output_1.is_active_output = True

    # node Store Named Attribute
    store_named_attribute = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeStoreNamedAttribute")
    store_named_attribute.name = "Store Named Attribute"
    store_named_attribute.data_type = 'FLOAT_COLOR'
    store_named_attribute.domain = 'CORNER'
    # Selection
    store_named_attribute.inputs[1].default_value = True
    # Value_Float
    store_named_attribute.inputs[4].default_value = 0.0
    # Value_Bool
    store_named_attribute.inputs[6].default_value = False
    # Value_Int
    store_named_attribute.inputs[7].default_value = 0
    # Value_Rotation
    store_named_attribute.inputs[8].default_value = (0.0, 0.0, 0.0)

    # node Math
    math = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math.label = "x-a1"
    math.name = "Math"
    math.operation = 'SUBTRACT'
    math.use_clamp = False
    # Value_002
    math.inputs[2].default_value = 0.5

    # node Math.001
    math_001_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_001_1.label = "b2-b1"
    math_001_1.name = "Math.001"
    math_001_1.operation = 'SUBTRACT'
    math_001_1.use_clamp = False
    # Value_002
    math_001_1.inputs[2].default_value = 0.5

    # node Math.002
    math_002_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_002_1.label = "a2-a1"
    math_002_1.name = "Math.002"
    math_002_1.operation = 'SUBTRACT'
    math_002_1.use_clamp = False
    # Value_002
    math_002_1.inputs[2].default_value = 0.5

    # node Value
    value = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeValue")
    value.label = "b1"
    value.name = "Value"

    value.outputs[0].default_value = 0.0
    # node Math.003
    math_003_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_003_1.label = "b1+"
    math_003_1.name = "Math.003"
    math_003_1.operation = 'ADD'
    math_003_1.use_clamp = False
    # Value_002
    math_003_1.inputs[2].default_value = 0.5

    # node Math.004
    math_004_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_004_1.label = "mult"
    math_004_1.name = "Math.004"
    math_004_1.operation = 'MULTIPLY'
    math_004_1.use_clamp = False
    # Value_002
    math_004_1.inputs[2].default_value = 0.5

    # node Math.005
    math_005 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_005.label = "a2-a1"
    math_005.name = "Math.005"
    math_005.operation = 'DIVIDE'
    math_005.use_clamp = False
    # Value_002
    math_005.inputs[2].default_value = 0.5

    # node Combine XYZ
    combine_xyz = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.name = "Combine XYZ"

    # node Mix
    mix_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMix")
    mix_1.name = "Mix"
    mix_1.blend_type = 'MIX'
    mix_1.clamp_factor = True
    mix_1.clamp_result = False
    mix_1.data_type = 'FLOAT'
    mix_1.factor_mode = 'UNIFORM'
    # Factor_Vector
    mix_1.inputs[1].default_value = (0.5, 0.5, 0.5)
    # A_Float
    mix_1.inputs[2].default_value = 0.0
    # A_Vector
    mix_1.inputs[4].default_value = (0.0, 0.0, 0.0)
    # B_Vector
    mix_1.inputs[5].default_value = (0.0, 0.0, 0.0)
    # A_Color
    mix_1.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
    # B_Color
    mix_1.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    # A_Rotation
    mix_1.inputs[8].default_value = (0.0, 0.0, 0.0)
    # B_Rotation
    mix_1.inputs[9].default_value = (0.0, 0.0, 0.0)

    # node Mix.001
    mix_001 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'FLOAT'
    mix_001.factor_mode = 'UNIFORM'
    # Factor_Vector
    mix_001.inputs[1].default_value = (0.5, 0.5, 0.5)
    # A_Float
    mix_001.inputs[2].default_value = 0.0
    # A_Vector
    mix_001.inputs[4].default_value = (0.0, 0.0, 0.0)
    # B_Vector
    mix_001.inputs[5].default_value = (0.0, 0.0, 0.0)
    # A_Color
    mix_001.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
    # B_Color
    mix_001.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    # A_Rotation
    mix_001.inputs[8].default_value = (0.0, 0.0, 0.0)
    # B_Rotation
    mix_001.inputs[9].default_value = (0.0, 0.0, 0.0)

    # node Mix.002
    mix_002 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'FLOAT'
    mix_002.factor_mode = 'UNIFORM'
    # Factor_Vector
    mix_002.inputs[1].default_value = (0.5, 0.5, 0.5)
    # A_Float
    mix_002.inputs[2].default_value = 0.0
    # A_Vector
    mix_002.inputs[4].default_value = (0.0, 0.0, 0.0)
    # B_Vector
    mix_002.inputs[5].default_value = (0.0, 0.0, 0.0)
    # A_Color
    mix_002.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
    # B_Color
    mix_002.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    # A_Rotation
    mix_002.inputs[8].default_value = (0.0, 0.0, 0.0)
    # B_Rotation
    mix_002.inputs[9].default_value = (0.0, 0.0, 0.0)

    # node Named Attribute.001
    named_attribute_001 = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeInputNamedAttribute")
    named_attribute_001.name = "Named Attribute.001"
    named_attribute_001.data_type = 'FLOAT'
    # Name
    named_attribute_001.inputs[0].default_value = "ZenBBQ_UserDefined"

    # node Mix.003
    mix_003 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'FLOAT'
    mix_003.factor_mode = 'UNIFORM'
    # Factor_Vector
    mix_003.inputs[1].default_value = (0.5, 0.5, 0.5)
    # A_Vector
    mix_003.inputs[4].default_value = (0.0, 0.0, 0.0)
    # B_Vector
    mix_003.inputs[5].default_value = (0.0, 0.0, 0.0)
    # A_Color
    mix_003.inputs[6].default_value = (0.5, 0.5, 0.5, 1.0)
    # B_Color
    mix_003.inputs[7].default_value = (0.5, 0.5, 0.5, 1.0)
    # A_Rotation
    mix_003.inputs[8].default_value = (0.0, 0.0, 0.0)
    # B_Rotation
    mix_003.inputs[9].default_value = (0.0, 0.0, 0.0)

    # node Math.006
    math_006 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_006.label = "LivePremult"
    math_006.name = "Math.006"
    math_006.operation = 'MULTIPLY'
    math_006.use_clamp = False
    # Value_002
    math_006.inputs[2].default_value = 0.5

    # node Value.002
    value_002 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeValue")
    value_002.label = "min"
    value_002.name = "Value.002"

    value_002.outputs[0].default_value = 0.0
    # node Switch
    switch = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeSwitch")
    switch.name = "Switch"
    switch.input_type = 'FLOAT'
    # False_001
    switch.inputs[4].default_value = 0
    # True_001
    switch.inputs[5].default_value = 0
    # False_002
    switch.inputs[6].default_value = False
    # True_002
    switch.inputs[7].default_value = True
    # False_003
    switch.inputs[8].default_value = (0.0, 0.0, 0.0)
    # True_003
    switch.inputs[9].default_value = (0.0, 0.0, 0.0)
    # False_004
    switch.inputs[10].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    # True_004
    switch.inputs[11].default_value = (0.800000011920929, 0.800000011920929, 0.800000011920929, 1.0)
    # False_005
    switch.inputs[12].default_value = ""
    # True_005
    switch.inputs[13].default_value = ""
    # False_012
    switch.inputs[26].default_value = (0.0, 0.0, 0.0)
    # True_012
    switch.inputs[27].default_value = (0.0, 0.0, 0.0)

    # node Named Attribute
    named_attribute = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeInputNamedAttribute")
    named_attribute.name = "Named Attribute"
    named_attribute.data_type = 'FLOAT'
    # Name
    named_attribute.inputs[0].default_value = "ZenBBQ"

    # node Attribute Statistic
    attribute_statistic = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeAttributeStatistic")
    attribute_statistic.name = "Attribute Statistic"
    attribute_statistic.data_type = 'FLOAT'
    attribute_statistic.domain = 'CORNER'
    # Selection
    attribute_statistic.inputs[1].default_value = True
    # Attribute_001
    attribute_statistic.inputs[3].default_value = (0.0, 0.0, 0.0)

    # node Group Input
    group_input_1 = zenbbq_bevelstovertexcolor.nodes.new("NodeGroupInput")
    group_input_1.name = "Group Input"

    # node Value.001
    value_001 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeValue")
    value_001.label = "b2"
    value_001.name = "Value.001"

    value_001.outputs[0].default_value = 1.0
    # node From_sRGB_to_Linear
    from_srgb_to_linear_1 = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeGroup")
    from_srgb_to_linear_1.name = "From_sRGB_to_Linear"
    from_srgb_to_linear_1.node_tree = from_srgb_to_linear_node_group()

    # Set parents
    math.parent = frame
    math_001_1.parent = frame
    math_002_1.parent = frame
    math_003_1.parent = frame
    math_004_1.parent = frame
    math_005.parent = frame

    # Set locations
    frame.location = (838.0, -85.0)
    group_output_1.location = (3408.727783203125, 90.6146469116211)
    store_named_attribute.location = (3198.736083984375, 141.54383850097656)
    math.location = (30.28546142578125, -198.13485717773438)
    math_001_1.location = (413.22021484375, -380.47930908203125)
    math_002_1.location = (414.100341796875, -30.110633850097656)
    value.location = (294.09918212890625, -569.9877319335938)
    math_003_1.location = (411.786865234375, -206.79095458984375)
    math_004_1.location = (670.597412109375, -194.95852661132812)
    math_005.location = (947.135498046875, -89.65211486816406)
    combine_xyz.location = (2808.235107421875, -510.5343933105469)
    mix_1.location = (2418.663330078125, -231.48121643066406)
    mix_001.location = (2418.663330078125, -451.84747314453125)
    mix_002.location = (2423.825927734375, -674.0969848632812)
    named_attribute_001.location = (-381.52349853515625, -268.28631591796875)
    mix_003.location = (35.707237243652344, -304.61419677734375)
    math_006.location = (-181.66200256347656, -12.359786987304688)
    value_002.location = (294.015869140625, -69.81167602539062)
    switch.location = (555.0208129882812, -395.06207275390625)
    named_attribute.location = (-382.45782470703125, -409.5552673339844)
    attribute_statistic.location = (295.73553466796875, -156.34494018554688)
    group_input_1.location = (-385.075439453125, 116.0099105834961)
    value_001.location = (294.4894104003906, -656.3595581054688)
    from_srgb_to_linear_1.location = (2039.763671875, -127.03800964355469)

    # Set dimensions
    frame.width, frame.height = 1117.0, 558.0
    group_output_1.width, group_output_1.height = 140.0, 100.0
    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    math_001_1.width, math_001_1.height = 140.0, 100.0
    math_002_1.width, math_002_1.height = 140.0, 100.0
    value.width, value.height = 140.0, 100.0
    math_003_1.width, math_003_1.height = 140.0, 100.0
    math_004_1.width, math_004_1.height = 140.0, 100.0
    math_005.width, math_005.height = 140.0, 100.0
    combine_xyz.width, combine_xyz.height = 140.0, 100.0
    mix_1.width, mix_1.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    named_attribute_001.width, named_attribute_001.height = 138.95523071289062, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    math_006.width, math_006.height = 140.0, 100.0
    value_002.width, value_002.height = 140.0, 100.0
    switch.width, switch.height = 140.0, 100.0
    named_attribute.width, named_attribute.height = 140.0, 100.0
    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
    group_input_1.width, group_input_1.height = 140.0, 100.0
    value_001.width, value_001.height = 140.0, 100.0
    from_srgb_to_linear_1.width, from_srgb_to_linear_1.height = 140.0, 100.0

    # initialize zenbbq_bevelstovertexcolor links
    # group_input_1.Geometry -> store_named_attribute.Geometry
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[0], store_named_attribute.inputs[0])
    # store_named_attribute.Geometry -> group_output_1.Geometry
    zenbbq_bevelstovertexcolor.links.new(store_named_attribute.outputs[0], group_output_1.inputs[0])
    # group_input_1.Geometry -> attribute_statistic.Geometry
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[0], attribute_statistic.inputs[0])
    # value.Value -> math_003_1.Value
    zenbbq_bevelstovertexcolor.links.new(value.outputs[0], math_003_1.inputs[0])
    # math.Value -> math_003_1.Value
    zenbbq_bevelstovertexcolor.links.new(math.outputs[0], math_003_1.inputs[1])
    # math_003_1.Value -> math_004_1.Value
    zenbbq_bevelstovertexcolor.links.new(math_003_1.outputs[0], math_004_1.inputs[0])
    # math_001_1.Value -> math_004_1.Value
    zenbbq_bevelstovertexcolor.links.new(math_001_1.outputs[0], math_004_1.inputs[1])
    # math_004_1.Value -> math_005.Value
    zenbbq_bevelstovertexcolor.links.new(math_004_1.outputs[0], math_005.inputs[0])
    # math_002_1.Value -> math_005.Value
    zenbbq_bevelstovertexcolor.links.new(math_002_1.outputs[0], math_005.inputs[1])
    # value_001.Value -> math_001_1.Value
    zenbbq_bevelstovertexcolor.links.new(value_001.outputs[0], math_001_1.inputs[0])
    # value.Value -> math_001_1.Value
    zenbbq_bevelstovertexcolor.links.new(value.outputs[0], math_001_1.inputs[1])
    # math_005.Value -> from_srgb_to_linear_1.Float
    zenbbq_bevelstovertexcolor.links.new(math_005.outputs[0], from_srgb_to_linear_1.inputs[0])
    # combine_xyz.Vector -> store_named_attribute.Value
    zenbbq_bevelstovertexcolor.links.new(combine_xyz.outputs[0], store_named_attribute.inputs[3])
    # group_input_1.R -> mix_1.Factor
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[2], mix_1.inputs[0])
    # mix_1.Result -> combine_xyz.X
    zenbbq_bevelstovertexcolor.links.new(mix_1.outputs[0], combine_xyz.inputs[0])
    # from_srgb_to_linear_1.Float -> mix_1.B
    zenbbq_bevelstovertexcolor.links.new(from_srgb_to_linear_1.outputs[0], mix_1.inputs[3])
    # from_srgb_to_linear_1.Float -> mix_001.B
    zenbbq_bevelstovertexcolor.links.new(from_srgb_to_linear_1.outputs[0], mix_001.inputs[3])
    # from_srgb_to_linear_1.Float -> mix_002.B
    zenbbq_bevelstovertexcolor.links.new(from_srgb_to_linear_1.outputs[0], mix_002.inputs[3])
    # group_input_1.G -> mix_001.Factor
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[3], mix_001.inputs[0])
    # group_input_1.B -> mix_002.Factor
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[4], mix_002.inputs[0])
    # mix_001.Result -> combine_xyz.Y
    zenbbq_bevelstovertexcolor.links.new(mix_001.outputs[0], combine_xyz.inputs[1])
    # mix_002.Result -> combine_xyz.Z
    zenbbq_bevelstovertexcolor.links.new(mix_002.outputs[0], combine_xyz.inputs[2])
    # mix_003.Result -> math.Value
    zenbbq_bevelstovertexcolor.links.new(mix_003.outputs[0], math.inputs[0])
    # mix_003.Result -> attribute_statistic.Attribute
    zenbbq_bevelstovertexcolor.links.new(mix_003.outputs[0], attribute_statistic.inputs[2])
    # group_input_1.Default Radius -> math_006.Value
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[5], math_006.inputs[0])
    # group_input_1.Units Mult -> math_006.Value
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[6], math_006.inputs[1])
    # math_006.Value -> mix_003.A
    zenbbq_bevelstovertexcolor.links.new(math_006.outputs[0], mix_003.inputs[2])
    # value_002.Value -> math_002_1.Value
    zenbbq_bevelstovertexcolor.links.new(value_002.outputs[0], math_002_1.inputs[1])
    # value_002.Value -> math.Value
    zenbbq_bevelstovertexcolor.links.new(value_002.outputs[0], math.inputs[1])
    # group_input_1.Use Global Bevel Value -> switch.Switch
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[7], switch.inputs[0])
    # attribute_statistic.Max -> switch.Switch
    zenbbq_bevelstovertexcolor.links.new(attribute_statistic.outputs[4], switch.inputs[1])
    # switch.Output -> math_002_1.Value
    zenbbq_bevelstovertexcolor.links.new(switch.outputs[0], math_002_1.inputs[0])
    # group_input_1.Layer Name -> store_named_attribute.Name
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[1], store_named_attribute.inputs[2])
    # named_attribute_001.Attribute -> mix_003.Factor
    zenbbq_bevelstovertexcolor.links.new(named_attribute_001.outputs[1], mix_003.inputs[0])
    # named_attribute.Attribute -> mix_003.B
    zenbbq_bevelstovertexcolor.links.new(named_attribute.outputs[1], mix_003.inputs[3])
    # attribute_statistic.Max -> switch.False
    zenbbq_bevelstovertexcolor.links.new(attribute_statistic.outputs[4], switch.inputs[2])
    # group_input_1.Max Global Value -> switch.True
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[8], switch.inputs[3])
    # combine_xyz.Vector -> store_named_attribute.Value
    zenbbq_bevelstovertexcolor.links.new(combine_xyz.outputs[0], store_named_attribute.inputs[5])
    return zenbbq_bevelstovertexcolor


def ensure_zenbbq_bevelstovertexcolor_node_group_blen_4_0():
    p_node = bpy.data.node_groups.get("ZenBBQ_BevelsToVertexColor")
    if not p_node:
        return zenbbq_bevelstovertexcolor_node_group()
    return p_node


if __name__ == "__main__":
    pass
