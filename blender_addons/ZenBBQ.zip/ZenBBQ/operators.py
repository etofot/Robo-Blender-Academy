# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2022, Dmitry Aleksandrovich Maslov (ABTOMAT), Alex Zhornyak (alexander.zhornyak@gmail.com)

import bmesh
import bpy

import addon_utils

from bpy.types import Operator
from bpy.props import StringProperty, EnumProperty
from bl_operators.presets import AddPresetBase

import random
from collections import defaultdict
import os
import math
from timeit import default_timer as timer

from mathutils import Vector

from .blender_zen_utils import (
    ZenLocks,
    update_view3d_in_all_screens,
    get_unique_mesh_objects)
from .vlog import Log

from .consts import ZBBQ_Consts
from .labels import ZBBQ_Labels

from .commonFunc import (
    ZBBQ_CommonFunc, ZBBQ_MaterialFunc, ZBBQ_PropUtils,
    NormalInspectStudio, NormalBakingSetup, ObjectAttributes)
from .units import (
    ZBBQ_UnitSystems, ZBBQ_UnitSystemsForEnumProperty,
    ZBBQ_Unit, ZBBQ_Units,
    ZBBQ_UnitsForEnumPropertyConsideringUnitSystem,
    ZBBQ_UnitsForEnumPropertyUnitSystemForCurrentPresetGroup
    )
from .sceneConfig import ZBBQ_SceneConfigFunc

from .draw_sets import (
    ZBBQ_EdgeLayerManager,
    remove_draw_handler,
    is_draw_handler_enabled,
    check_update_cache,
    _do_add_draw_handler,
    _do_remove_draw_handler,
    reset_all_draw_cache
)
from .blender_zen_utils import _setnameex, ZenPolls
from .vertex_color import DriverUtils
from .geometry_nodes import explode_nodes
from .zen_common.combo_panel import (
    ZenExpandComboPanel,
    ZenPinComboPanel,
    ZenSetComboPanel)


class ZBBQ_OT_PresetReplaceRadius(Operator):
    bl_idname = "wm.zen_bbq_replace_radius"
    bl_label = "Replace Radius Value"
    bl_description = "Replace radius value with the new value"
    bl_options = {'REGISTER', 'UNDO'}

    influence: bpy.props.EnumProperty(
        name="Influence",
        items=[
            ("ACTIVE", "Active Object", ""),
            ("SELECTED", "Selected Objects", ""),
            ("ALL", "All Objects", "")
        ],
        default="ALL"
    )

    preset_index: bpy.props.IntProperty(
        name="Preset Index",
        default=-1
    )

    target_radius: bpy.props.FloatProperty(
        name="Target Radius",
        description="Value that will replace the source radius value",
        default=0, min=0, soft_max=500, subtype='FACTOR')

    units: EnumProperty(
            name=ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Prop_Units_Name,
            description=ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Prop_Units_Desc,
            items=lambda self, context: ZBBQ_UnitsForEnumPropertyUnitSystemForCurrentPresetGroup(),
    )

    def draw(self, context: bpy.types.Context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False
        layout.prop(self, "influence")

        from .preferences import ZBBQ_Pref_BevelPreset, ZBBQ_Pref_BevelPresetGroup
        bpg: ZBBQ_Pref_BevelPresetGroup = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        p_presets = bpg.bevelPresets
        b_index_valid = self.preset_index in range(len(p_presets))

        # row = layout.row(align=True)
        # row.active = b_index_valid
        # row.prop(self, "preset_index")

        row = layout.row(align=True)
        if b_index_valid:
            bp: ZBBQ_Pref_BevelPreset = p_presets[self.preset_index]
            r1 = row.row(align=True)
            r1.prop(bp, "radius_ui", text="Source Radius")
            r2 = row.row(align=True)
            r2.enabled = False
            # r2.alignment = 'RIGHT'
            r2.prop(bp, "units", text="")
        else:
            row.alignment = 'CENTER'
            row.alert = True
            row.label(text="Bevel preset is not defined!", icon="ERROR")

        row = layout.row(align=True)
        r1 = row.row(align=True)
        r1.prop(self, "target_radius")
        r2 = row.row(align=True)
        r2.prop(self, "units", text="")

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context: bpy.types.Context):
        p_objects = context.objects_in_mode if context.mode == 'EDIT_MESH' else context.selected_objects
        if self.influence == 'ACTIVE':
            p_objects = [context.active_object]
        elif self.influence == 'ALL':
            p_objects = context.scene.objects

        p_objects = get_unique_mesh_objects(p_objects)

        from .preferences import ZBBQ_Pref_BevelPreset, ZBBQ_Pref_BevelPresetGroup
        bpg: ZBBQ_Pref_BevelPresetGroup = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        p_presets = bpg.bevelPresets
        if self.preset_index not in range(len(p_presets)):
            self.report({'ERROR'}, "Bevel preset is not defined!")
            return {'CANCELLED'}

        bp: ZBBQ_Pref_BevelPreset = p_presets[self.preset_index]
        source_radius = [bp.radius * bp.unitAndSceneScaleMultiplier()]
        target_radius = self.target_radius * ZBBQ_Unit.unitAndSceneScaleMultiplierByUnitsName(self.units)

        b_modified = ZBBQ_CommonFunc.ReplaceBevelRadius(p_objects, source_radius, target_radius)

        if not b_modified:
            self.report({'INFO'}, f"Radius: {source_radius} was not found!")

        return {"FINISHED"}


class ZBBQ_OT_PresetClearExtraValues(Operator):
    bl_idname = "wm.zen_bbq_clear_extra_values"
    bl_label = "Clear Extra Values"
    bl_description = "Remove all bevel values that are not present in the preset"
    bl_options = {'REGISTER', 'UNDO'}

    influence: bpy.props.EnumProperty(
        name="Influence",
        items=[
            ("ACTIVE", "Active Object", ""),
            ("SELECTED", "Selected Objects", ""),
            ("ALL", "All Objects", "")
        ],
        default="ALL"
    )

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    @classmethod
    def poll(cls, context: bpy.types.Context):
        from .preferences import ZBBQ_Pref_BevelPresetGroup
        bpg: ZBBQ_Pref_BevelPresetGroup = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        p_presets = bpg.bevelPresets
        return len(p_presets) != 0

    def execute(self, context: bpy.types.Context):
        p_objects = context.objects_in_mode if context.mode == 'EDIT_MESH' else context.selected_objects
        if self.influence == 'ACTIVE':
            p_objects = [context.active_object]
        elif self.influence == 'ALL':
            p_objects = context.scene.objects

        p_objects = get_unique_mesh_objects(p_objects)

        from .preferences import ZBBQ_Pref_BevelPresetGroup
        bpg: ZBBQ_Pref_BevelPresetGroup = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        p_presets = bpg.bevelPresets
        if len(p_presets) == 0:
            self.report({'ERROR'}, "Bevel preset is not filled!")
            return {'CANCELLED'}

        source_radius = [bp.radius * bp.unitAndSceneScaleMultiplier() for bp in p_presets]

        b_modified = ZBBQ_CommonFunc.ReplaceBevelRadius(p_objects, source_radius, 0, invert=True)

        if not b_modified:
            self.report({'INFO'}, f"Radius: {source_radius} was not found!")

        return {"FINISHED"}


class ZBBQ_OT_PresetItemAdd(Operator):
    bl_idname = "wm.zen_bbq_preset_item_add"
    bl_label = "Add Entry"
    bl_description = "Add bevel preset"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from .preferences import ZBBQ_Pref_BevelPreset, ZBBQ_Pref_BevelPresetGroup
        bpg: ZBBQ_Pref_BevelPresetGroup = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        p_presets = bpg.bevelPresets

        p_active_item = p_presets[bpg.bevelPresetsIndex] if bpg.bevelPresetsIndex in range(len(p_presets)) else None

        bpStored: ZBBQ_Pref_BevelPreset = p_presets.add()

        bpStored.unitSystem = bpg.unitSystem

        if p_active_item:
            bpStored.units = p_active_item.units

        bpStored.radius = 0

        bpStored.color = [random.random() for i in range(3)]

        bpg.bevelPresetsIndex = len(p_presets) - 1

        return {'FINISHED'}


class ZBBQ_OT_PresetItemRemove(Operator):
    bl_idname = "wm.zen_bbq_preset_item_remove"
    bl_label = "Remove Entry"
    bl_description = "Remove active bevel preset"
    bl_options = {'REGISTER', 'UNDO'}

    clear: bpy.props.BoolProperty(
        name="Cleanup Objects",
        description="Clear bever radius values in all objects",
        default=True
    )

    def draw(self, context: bpy.types.Context):
        layout = self.layout

        from .preferences import ZBBQ_Pref_BevelPreset, ZBBQ_Pref_BevelPresetGroup
        bpg: ZBBQ_Pref_BevelPresetGroup = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        p_presets = bpg.bevelPresets
        active_index = bpg.bevelPresetsIndex

        if active_index in range(len(p_presets)):
            bp: ZBBQ_Pref_BevelPreset = p_presets[active_index]
            s_units = layout.enum_item_name(bp, "units", bp.units)
            layout.label(text=f"Bevel radius: {bp.radius:.2g} {s_units}")

        layout.prop(self, "clear")

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context):
        from .preferences import ZBBQ_Pref_BevelPreset, ZBBQ_Pref_BevelPresetGroup
        bpg: ZBBQ_Pref_BevelPresetGroup = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        p_presets = bpg.bevelPresets
        active_index = bpg.bevelPresetsIndex

        if active_index in range(len(p_presets)):
            bp: ZBBQ_Pref_BevelPreset = p_presets[active_index]
            source_radius = [bp.radius * bp.unitAndSceneScaleMultiplier()]
            p_presets.remove(active_index)

            bpg.bevelPresetsIndex = min(active_index, len(p_presets) - 1)

            if self.clear:
                ZBBQ_CommonFunc.ReplaceBevelRadius(context.scene.objects, source_radius, 0)

            reset_all_draw_cache()

            update_view3d_in_all_screens()

        return {'FINISHED'}


class ZBBQ_OT_LoadPreset(Operator):
    bl_idname = "wm.zen_bbq_load_preset"
    bl_label = "Load Preset"
    bl_description = "Load Zen BBQ bevel values preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset_name: bpy.props.StringProperty(
        name="Preset Name",
        default=""
    )

    mode: bpy.props.EnumProperty(
        name="Mode",
        items=[
            ("ADD", "Add", "Add items to the existing ones"),
            ("REPLACE", "Replace", "Replace existing items"),
            ],
        default='REPLACE'
    )

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context: bpy.types.Context):
        try:
            from .preferences import ZBBQ_Pref_BevelPresetGroup, ZBBQ_Pref_BevelPreset
            prefs = ZBBQ_CommonFunc.GetPrefs()
            p_preset_group: ZBBQ_Pref_BevelPresetGroup = prefs.bevelPresetGroups.get(self.preset_name, None)
            if p_preset_group is None:
                raise RuntimeError(f"Can not find preset {self.preset_name}!")

            bpgScene: ZBBQ_Pref_BevelPresetGroup = bpy.context.scene.ZBBQ_PresetsIncluded

            if self.mode == 'REPLACE':
                for prop_name in bpgScene.__annotations__.keys():
                    source = getattr(p_preset_group, prop_name)
                    p_prop: bpy.types.Property = p_preset_group.bl_rna.properties[prop_name]
                    if not p_prop.is_skip_save and not p_prop.is_readonly:
                        setattr(bpgScene, prop_name, source)

                bpgScene.bevelPresets.clear()

            for item in p_preset_group.bevelPresets:

                preset: ZBBQ_Pref_BevelPreset = bpgScene.bevelPresets.add()

                for prop_name in item.__annotations__.keys():
                    p_prop: bpy.types.Property = preset.bl_rna.properties[prop_name]
                    if not p_prop.is_skip_save and not p_prop.is_readonly:
                        source = getattr(item, prop_name)
                        setattr(preset, prop_name, source)

            prefs.bevelPresetGroupsDropdown = self.preset_name

            reset_all_draw_cache()
        except Exception as e:
            self.report({'ERROR'}, str(e))

        return {'FINISHED'}


class ZBBQ_OT_UpdateData(Operator):

    bl_idname = "wm.zen_bbq_update_data"
    bl_label = "Update"
    bl_description = "Update Zen BBQ bevel data"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: bpy.types.Context):

        t_objects = defaultdict(list)
        for idx, obj in enumerate(context.scene.objects):
            if obj.type == 'MESH':
                obj_in_mode = (
                    obj in context.objects_in_mode
                    if context.mode == 'EDIT_MESH' else
                    obj in context.selected_objects)
                multi = 1 if obj_in_mode else -1
                t_objects[obj.data].append((idx + 1) * multi)

        p_values = defaultdict(set)

        me: bpy.types.Mesh
        for me, objs in t_objects.items():

            if me.is_editmode:
                bm = bmesh.from_edit_mesh(me)
                bm.verts.ensure_lookup_table()
                p_layer = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerRadiusName, None)
                if p_layer:
                    for v in bm.verts:
                        p_values[v[p_layer]].update(objs)
            else:
                p_attr: bpy.types.FloatAttribute = me.attributes.get(ZBBQ_Consts.customDataLayerRadiusName, None)
                if p_attr:
                    for item in p_attr.data:
                        p_values[item.value].update(objs)

        if p_values:
            context.scene.ZBBQ_PresetsIncluded.max_bevel_value = max(p_values.keys())

        bpg = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        p_presets = bpg.bevelPresets

        p_active_item = p_presets[0] if len(p_presets) else None

        t_cache = {}

        def get_radius_item(val):
            if val in t_cache:
                return t_cache[val]

            res = None
            for bp in p_presets:
                radius = bp.radius * bp.unitAndSceneScaleMultiplier()
                if abs(val - radius) <= 0.00001:
                    res = bp
                    break

            t_cache[val] = res

            return res

        b_modified = False

        for val in sorted(p_values.keys()):
            if val == 0:
                continue

            p_item = get_radius_item(val)
            if p_item is None:
                bpStored = p_presets.add()

                t_cache[val] = bpStored

                bpStored.unitSystem = bpg.unitSystem

                if p_active_item:
                    bpStored.units = p_active_item.units

                bpStored.radius = val / bpStored.unitAndSceneScaleMultiplier()

                bpStored.color = [random.random() for i in range(3)]

                b_modified = True

        if b_modified:
            context.preferences.is_dirty = True

        for val, bp in t_cache.items():
            objs = p_values.get(val, None)
            if objs:
                bp.statistics_objects = len(objs)
                bp.statistics_objects_in_mode = sum(1 for number in objs if number > 0)

        reset_all_draw_cache()

        update_view3d_in_all_screens()

        return {"FINISHED"}


class ZBBQ_OT_ActiveObjectGetReady(Operator):  # Deprecated, debug use only!

    bl_idname = "object.zen_bbq_active_object_get_ready"
    bl_label = ZBBQ_Labels.ZBBQ_OT_ActiveObjectGetReady_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_ActiveObjectGetReady_Desc
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        ZBBQ_CommonFunc.Report(self, ZBBQ_Labels.ZBBQ_OT_ActiveObjectGetReady_Report)
        ZBBQ_CommonFunc.ObjectGetReadyForBevel(context.active_object)

        return {"FINISHED"}


class ZBBQ_OT_ShaderNodeNormalAdd(Operator):  # Deprecated. For debug purposes only.

    # For debug purposes only.
    # Adding bevel node is performed automatically when needed

    bl_idname = "object.zen_bbq_shader_node_normal_add"
    bl_label = ZBBQ_Labels.ZBBQ_OT_ShaderNodeNormalAdd_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_ShaderNodeNormalAdd_Desc
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        p_act_obj = context.active_object
        if p_act_obj and p_act_obj.active_material:
            ZBBQ_MaterialFunc.MaterialAddShaderNodeNormal(p_act_obj.active_material, p_act_obj)

        return {'FINISHED'}


class ZBBQ_OT_ShaderNodeNormalRemove(Operator):  # Deprecated. For debug purposes only.

    bl_idname = "object.zen_bbq_shader_node_normal_remove"
    bl_label = ZBBQ_Labels.ZBBQ_OT_ShaderNodeNormalRemove_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_ShaderNodeNormalRemove_Desc
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        ZBBQ_MaterialFunc.MaterialRemoveShaderNodeNormal(context.active_object.active_material)

        return {'FINISHED'}


class ZBBQ_OT_SetBevelRadiusToSelection(Operator):

    bl_idname = "object.zen_bbq_set_radius_to_selection"
    bl_label = ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Desc
    bl_options = {'REGISTER', 'UNDO'}

    radius: bpy.props.FloatProperty(name=ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Prop_Radius_Name,
                                    description=ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Prop_Radius_Desc,
                                    default=100, min=0, soft_max=500, subtype='FACTOR')
    units: EnumProperty(
            name=ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Prop_Units_Name,
            description=ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Prop_Units_Desc,
            items=lambda self, context: ZBBQ_UnitsForEnumPropertyUnitSystemForCurrentPresetGroup(),
    )
    bevel_mode: bpy.props.EnumProperty(
        name="Bevel Mode",
        description="Select which edges will be beveled",
        items=[
            ('ALL', "All Selected", "Apply bevel to all selected edges (inner and outer)"),
            ('BORDER', "Border Only", "Apply bevel only to the boundary edges of the selection")
        ],
        default='ALL'
    )

    @classmethod
    def poll(cls, context):

        if context.mode == 'EDIT_MESH':
            for obj in context.objects_in_mode:
                if not ZBBQ_CommonFunc.ObjectIsMesh(obj):
                    continue

                if obj.data.total_vert_sel > 0:
                    return True

            return False

        elif context.mode == 'OBJECT':
            return len(context.selected_editable_objects) > 0
        else:
            return False

    def execute(self, context):

        unitsInfo = ZBBQ_Units[self.units]
        radius = self.radius * unitsInfo.unitAndSceneScaleMultiplier()

        if context.mode == 'EDIT_MESH':
            ZBBQ_CommonFunc.SetBevelRadiusToSelectedGeometry(context.objects_in_mode, radius, self.bevel_mode == 'BORDER')
            ZBBQ_CommonFunc.Report(self, f'Applying bevel radius {self.radius:2g} {unitsInfo.shortTitle} to the selected geometry!')
        else:
            ZBBQ_CommonFunc.SetBevelRadiusToObjects(context.selected_editable_objects, radius, self.units)
            ZBBQ_CommonFunc.Report(self, f'Applying bevel radius {self.radius:2g} {unitsInfo.shortTitle} to the selected objects!')

        return {"FINISHED"}


class ZBBQ_OT_SetZeroBevelRadiusToSelection(Operator):

    bl_idname = "object.zen_bbq_set_zero_radius_to_selection"
    bl_label = ZBBQ_Labels.ZBBQ_OT_SetZeroBevelRadiusToSelection_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_SetZeroBevelRadiusToSelection_Desc
    bl_options = {'REGISTER', 'UNDO'}

    affect_selected_only: bpy.props.BoolProperty(
        name="Selected Only",
        description="If enabled, applies only to the selection; otherwise, applies to the entire object",
        default=True
    )

    bevel_mode: bpy.props.EnumProperty(
        name="Bevel Mode",
        description="Select which edges will be beveled",
        items=[
            ('ALL', "All Selected", "Apply bevel to all selected edges (inner and outer)"),
            ('BORDER', "Border Only", "Apply bevel only to the boundary edges of the selection")
        ],
        default='ALL'
    )

    @classmethod
    def poll(cls, context):

        if context.mode == 'EDIT_MESH':
            for obj in context.objects_in_mode:
                if not ZBBQ_CommonFunc.ObjectIsMesh(obj):
                    continue
                return True

            return False
        else:
            return False

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True

        layout.prop(self, 'affect_selected_only')
        row = layout.row()
        row.enabled = self.affect_selected_only
        row.prop(self, 'bevel_mode')

    def execute(self, context):

        if self.affect_selected_only:
            ZBBQ_CommonFunc.SetBevelRadiusToSelectedGeometry(context.objects_in_mode, 0, self.bevel_mode == 'BORDER')
            ZBBQ_CommonFunc.Report(self, 'Applying zero bevel radius to the selected geometry!')
        else:
            ZBBQ_CommonFunc.SetBevelRadiusToObjects(context.objects_in_mode, 0, None)

        return {"FINISHED"}

    def invoke(self, context, event):

        for obj in context.objects_in_mode:
            if obj.data.total_vert_sel > 0:
                return self.execute(context)

        self.forWholeObject = True
        return context.window_manager.invoke_props_dialog(self)


class ZBBQ_OT_SmartSelectByRadiusOfSelectedVerts(Operator):
    bl_idname = "object.zen_bbq_smart_select_by_radius_of_selected_verts"
    bl_label = ZBBQ_Labels.ZBBQ_OT_SmartSelectByRadiusOfSelectedVerts_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_SmartSelectByRadiusOfSelectedVerts_Desc
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):

        if context.mode == 'EDIT_MESH':
            for obj in context.objects_in_mode:
                if not ZBBQ_CommonFunc.ObjectIsMesh(obj):
                    continue
                if obj.data.total_vert_sel > 0:
                    return True
            return False
        else:
            return False

    def execute(self, context):

        valuesToCheck = []

        for obj in context.objects_in_mode:

            if not ZBBQ_CommonFunc.ObjectIsMesh(obj):
                # Non-mesh objects are ignored
                continue

            if obj.data.total_vert_sel == 0:
                continue

            bm = bmesh.from_edit_mesh(obj.data)

            if not ZBBQ_CommonFunc.ObjectHasDataLayerRadius(obj):
                # We do not add Data Layer if there is none
                # Instead, we consider all vertices to have zero radius
                valuesToCheck.append(0)
                continue

            dataLayerRadius = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerRadiusName)
            dataLayerUserDefined = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerUserDefinedName)
            if dataLayerRadius is None:
                dataLayerRadius = bm.verts.layers.float.new(ZBBQ_Consts.customDataLayerRadiusName)

            for vert in [vert for vert in bm.verts if vert.select]:
                vertRadius = 0

                if (vert[dataLayerUserDefined] == 0):
                    vertRadius = obj.get(ZBBQ_Consts.customPropertyIntactBevelRadiusName, 0)
                else:
                    vertRadius = vert[dataLayerRadius]

                if vertRadius not in valuesToCheck:
                    valuesToCheck.append(vertRadius)

        p_units = context.scene.unit_settings.length_unit
        if ZBBQ_Units.get(p_units, None):
            units_string = ZBBQ_Units[p_units].shortTitle
            p_mult = ZBBQ_Units[p_units].unitAndSceneScaleMultiplier()
        else:
            units_string = ''
            p_mult = 1.0

        ZBBQ_CommonFunc.Report(self, f"Selecting geometry with Bevel Radius {[round(v, 5) / p_mult for v in valuesToCheck]} {units_string}")

        ZBBQ_CommonFunc.SmartSelectByRadiusValues(context.objects_in_mode, valuesToCheck, ZBBQ_CommonFunc.GetPrefs().smartSelectRadiusThreshold*0.01, True)

        return {"FINISHED"}

    def draw(self, context):
        self.layout.prop(ZBBQ_CommonFunc.GetPrefs(), 'smartSelectRadiusThreshold')


class ZBBQ_OT_SmartSelectByRadiusFromActivePreset(Operator):  # Deprecated
    bl_idname = "object.zen_bbq_smart_select_by_radius_from_active_preset"
    bl_label = ZBBQ_Labels.ZBBQ_OT_SmartSelectByRadiusFromActivePreset_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_SmartSelectByRadiusFromActivePreset_Desc
    bl_options = {'REGISTER', 'UNDO'}

    addToSelection: bpy.props.BoolProperty(
            name=ZBBQ_Labels.ZBBQ_OT_SmartSelectByRadiusFromActivePreset_Prop_AddToSelection_Name,
            description=ZBBQ_Labels.ZBBQ_OT_SmartSelectByRadiusFromActivePreset_Prop_AddToSelection_Desc,
            default=False)

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):
        bpg = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        bp = bpg.bevelPresets[bpg.bevelPresetsIndex]

        ZBBQ_CommonFunc.SmartSelectByRadiusValues(context.objects_in_mode, [bp.radius*bp.unitAndSceneScaleMultiplier()], ZBBQ_CommonFunc.GetPrefs().smartSelectRadiusThreshold*0.01, self.addToSelection)

        return {"FINISHED"}

    def draw(self, context):
        self.layout.prop(ZBBQ_CommonFunc.GetPrefs(), 'smartSelectRadiusThreshold')
        self.layout.prop(self, 'addToSelection')


class ZBBQ_OT_PreviewShaderNodeToggle(Operator):
    bl_idname = "object.zen_bbq_preview_shader_node_toggle"
    bl_label = "Set Preview Mode"
    bl_description = "Change the view mode to original material, bevel shader, or baked image texture"
    bl_options = {'REGISTER', 'UNDO'}

    mode: ZBBQ_PropUtils.get_shader_preview_mode(p_options={'HIDDEN', 'SKIP_SAVE'})

    reset_nodes: bpy.props.BoolProperty(
        name="Reset Nodes",
        description="All preview cached nodes will be removed and re-created again",
        default=False,
        options={'HIDDEN', 'SKIP_SAVE'}
    )

    shading_type: ZBBQ_PropUtils.get_shading_type(p_options={'HIDDEN', 'SKIP_SAVE'})

    switch_to_cycles: bpy.props.BoolProperty(
        name="Switch To Cycles",
        default=False,
        options={'HIDDEN', 'SKIP_SAVE'}
    )

    @classmethod
    def description(cls, context, properties):
        if properties:
            return bpy.types.UILayout.enum_item_description(properties, 'mode', properties.mode)

        return cls.description

    @classmethod
    def poll(cls, context: bpy.types.Context):
        objects = ZBBQ_CommonFunc.GetMeshObjectsInMode(context)
        return len(objects) > 0 and not context.scene.zen_bbq.is_baking_active

    def execute(self, context: bpy.types.Context):
        from .sceneConfig import ZBBQ_SceneProperties

        p_scene = context.scene

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        p_scene_props: ZBBQ_SceneProperties = p_scene.zen_bbq
        p_scene_props.preview_mode = self.mode

        if self.switch_to_cycles:
            if ZBBQ_CommonFunc.IsCyclesEnabled(context):
                if context.scene.render.engine != 'CYCLES':
                    context.scene.render.engine = 'CYCLES'
            else:
                self.report({"ERROR"}, "Cycles engine is not available!")

        for mat in bpy.data.materials:
            ZBBQ_MaterialFunc.MaterialRemoveOverrideNode(mat)

        if self.reset_nodes:
            for node_name in ZBBQ_Consts.NODE_TREE_PREVIEW_MAP.values():
                ZBBQ_MaterialFunc.RemoveNodeTreeFromSceneIfPresent(node_name)

            for node_name in ZBBQ_Consts.NODE_TREE_SERVICE_MAP.values():
                ZBBQ_MaterialFunc.RemoveNodeTreeFromSceneIfPresent(node_name)

        if self.mode == "SHADER":
            if addon_prefs.shader_preview_enabled:
                p_handled_mats = set()

                for obj in ZBBQ_CommonFunc.GetMeshObjectsInMode(context):
                    me: bpy.types.Mesh = obj.data
                    ZBBQ_MaterialFunc.ObjectFillMissingMatsWithDefaultZenBBQMaterial(obj)

                    for mat in me.materials:

                        if mat in p_handled_mats:
                            continue
                        else:
                            p_handled_mats.add(mat)

                        ZBBQ_MaterialFunc.MaterialAddOverrideNode(
                            obj,
                            mat,
                            ZBBQ_Consts.PREVIEW_SHADER_NAME,
                            ZBBQ_Consts.PREVIEW_SHADER_NAME,
                            reset=False)

        elif self.mode == 'IMAGE':
            p_handled_mats = set()

            folder = p_scene_props.bake_output_directory

            p_bake_map = p_scene_props.get_active_bake_map()

            s_suffix = p_bake_map.bake_image_suffix

            for obj in ZBBQ_CommonFunc.GetMeshObjectsInMode(context):
                me: bpy.types.Mesh = obj.data
                ZBBQ_MaterialFunc.ObjectFillMissingMatsWithDefaultZenBBQMaterial(obj)

                for idx, mat in enumerate(me.materials):

                    if mat in p_handled_mats:
                        continue
                    else:
                        p_handled_mats.add(mat)

                    try:
                        ZBBQ_MaterialFunc.MaterialAddShaderNodeNormalImage(
                            p_scene, mat, obj, idx, folder, False,
                            s_suffix
                        )
                    except Exception as e:
                        self.report({'INFO'}, str(e))
        else:

            if self.mode == 'MATERIAL':
                for obj in ZBBQ_CommonFunc.GetMeshObjectsInMode(context):
                    me: bpy.types.Mesh = obj.data
                    ZBBQ_MaterialFunc.ObjectFillMissingMatsWithDefaultZenBBQMaterial(obj)

        try:
            if self.shading_type != 'NONE':

                p_active_3d = context.space_data
                if isinstance(p_active_3d, bpy.types.SpaceView3D):
                    if p_active_3d.shading.type != self.shading_type:
                        p_active_3d.shading.type = self.shading_type
                else:
                    for area in context.screen.areas:
                        if area.type == 'VIEW_3D':
                            if isinstance(area.spaces.active, bpy.types.SpaceView3D):
                                if area.spaces.active.shading.type != self.shading_type:
                                    area.spaces.active.shading.type = self.shading_type
        except Exception:
            self.report({'ERROR'}, f"Can not set shading type: {self.shading_type}")

        return {'FINISHED'}


class ZBBQ_OT_RepairPreviewNodes(Operator):
    bl_idname = "wm.zen_bbq_repair_preview_nodes"
    bl_label = "Repair Preview Nodes"
    bl_description = "All preview cached nodes will be removed and re-created again"
    bl_options = {'REGISTER', 'UNDO'}

    mode: ZBBQ_PropUtils.preview_mode

    @classmethod
    def poll(cls, context: bpy.types.Context):
        return not context.scene.zen_bbq.is_baking_active

    def execute(self, context: bpy.types.Context):
        res = ZBBQ_CommonFunc.SetPreviewMode(self.mode, context, reset=True)
        if 'FINISHED' in res:
            self.report({'INFO'}, "Preview nodes were repaired!")
        else:
            self.report({'ERROR'}, "Can not repair preview nodes!")
        return {'FINISHED'}


class ZBBQ_OT_FixSceneUnitSystem(Operator):
    bl_idname = "object.zen_bbq_fix_scene_unit_system"
    bl_label = ZBBQ_Labels.ZBBQ_OT_FixSceneUnitSystem_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_FixSceneUnitSystem_Desc
    bl_options = {'REGISTER', 'UNDO'}

    unitSystem = 'METRIC'

    def execute(self, context):
        context.scene.unit_settings.system = self.unitSystem
        return {'FINISHED'}

    def invoke(self, context, event):

        bpg = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        if bpg:
            self.unitSystem = bpg.unitSystem
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):

        self.layout.label(text=ZBBQ_Labels.ZBBQ_OT_FixSceneUnitSystem_Confirm+ZBBQ_UnitSystems[self.unitSystem]+", "+ZBBQ_CommonFunc.StrConfirmQuestion(self))


class ZBBQ_OT_RenderPreviewToggle(Operator):
    bl_idname = "object.zen_bbq_render_preview_toggle"
    bl_label = ZBBQ_Labels.ZBBQ_OT_RenderPreviewToggle_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_RenderPreviewToggle_Desc
    bl_options = {'REGISTER', 'UNDO'}

    poll = ZBBQ_OT_PreviewShaderNodeToggle.poll

    def execute(self, context: bpy.types.Context):
        from .sceneConfig import ZBBQ_SceneProperties

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        p_scene_props: ZBBQ_SceneProperties = context.scene.zen_bbq

        if bpy.ops.object.zen_bbq_preview_shader_node_toggle.poll():
            if p_scene_props.preview_mode == 'SHADER':
                bpy.ops.object.zen_bbq_preview_shader_node_toggle(
                    'INVOKE_DEFAULT',
                    mode='MATERIAL', reset_nodes=False, shading_type='SOLID', switch_to_cycles=False)
            else:
                b_switch_to_cycles = addon_prefs.cycles_auto_activation and addon_prefs.shader_shading_type == 'RENDERED'
                bpy.ops.object.zen_bbq_preview_shader_node_toggle(
                    'INVOKE_DEFAULT',
                    mode='SHADER', reset_nodes=False, shading_type='RENDERED', switch_to_cycles=b_switch_to_cycles)

        return {'FINISHED'}


class ZBBQ_OT_PieMenuGeometryOptionsTop(Operator):
    bl_idname = "object.zen_bbq_pie_menu_geometry_options_top"
    bl_label = ZBBQ_Labels.ZBBQ_OT_PieMenuGeometryOptionsTop_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_PieMenuGeometryOptionsTop_Desc
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):  # Check if we have some verts selected
        if context.mode == 'EDIT_MESH':
            for obj in context.objects_in_mode:
                if not ZBBQ_CommonFunc.ObjectIsMesh(obj):
                    continue
                if obj.data.total_vert_sel > 0:
                    return True
            return False
        else:
            return False

    def invoke(self, context, event):

        modCtrl = getattr(event, 'ctrl', False)

        if not modCtrl:
            if bpy.ops.object.zen_bbq_smart_select_by_radius_of_selected_verts.poll():
                bpy.ops.object.zen_bbq_smart_select_by_radius_of_selected_verts('INVOKE_DEFAULT')
        else:
            if bpy.ops.object.zen_bbq_set_zero_radius_to_selection.poll():
                bpy.ops.object.zen_bbq_set_zero_radius_to_selection('INVOKE_DEFAULT')

        return {'FINISHED'}


class ZBBQ_OT_PieMenuGeometryOptionsBottom(Operator):
    bl_idname = "object.zen_bbq_pie_menu_geometry_options_bottom"
    bl_label = ZBBQ_Labels.ZBBQ_OT_PieMenuGeometryOptionsBottom_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_PieMenuGeometryOptionsBottom_Desc
    bl_options = {'REGISTER', 'UNDO'}

    opName = ""

    def invoke(self, context, event):

        self.opName = ZBBQ_OT_RenderPreviewToggle.bl_idname

        # ctrlUsageAllowed = event.type == "LEFTMOUSE"  or event.type == "TWO" or event.type.startswith("NUMPAD_")

        if getattr(event, 'ctrl', False):
            # User was holding Ctrl while activating this operator
            # print(f'CTRL is used! Event Type: {event.type}')

            self.opName = ZBBQ_OT_DrawHighlight.bl_idname

        return self.execute(context)

    def execute(self, context):

        OpEval = eval("bpy.ops."+self.opName)

        if OpEval.poll():
            OpEval('INVOKE_DEFAULT')
        else:
            ZBBQ_CommonFunc.Report(self, text=ZBBQ_Labels.ZBBQ_OT_PieMenuGeometryOptionsBottom_Report_MeshEditOnly)

        return {'FINISHED'}


class ZBBQ_OT_BakeOpenFolder(Operator):
    bl_idname = "wm.zen_bbq_bake_open_folder"
    bl_label = ZBBQ_Labels.ZBBQ_OT_BakeOpenFolder_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_BakeOpenFolder_Desc
    bl_options = {'REGISTER'}

    def execute(self, context: bpy.types.Context):
        s_dir = context.scene.zen_bbq.bake_output_directory
        return bpy.ops.wm.path_open(filepath=s_dir)

    @classmethod
    def poll(cls, context: bpy.types.Context):
        s_dir = context.scene.zen_bbq.bake_output_directory
        return (os.path.exists(s_dir) and os.path.isdir(s_dir))


# Preferences and Cleanup
class ZBBQ_OT_ObjectAddonCleanup(Operator):
    bl_idname = "object.zen_bbq_addon_cleanup"
    bl_label = ZBBQ_Labels.ZBBQ_OT_ObjectAddonCleanup_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_ObjectAddonCleanup_Desc
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return len(ZBBQ_CommonFunc.GetMeshObjectsInMode(context)) > 0

    def execute(self, context):

        objectsToReset = ZBBQ_CommonFunc.GetMeshObjectsInMode(context)
        if objectsToReset:

            if bpy.ops.object.zen_bbq_preview_shader_node_toggle.poll():
                bpy.ops.object.zen_bbq_preview_shader_node_toggle(
                    mode='MATERIAL', reset_nodes=False, shading_type='MATERIAL', switch_to_cycles=False)

            try:
                ZenLocks.lock_depsgraph_update()

                for obj in objectsToReset:
                    ZBBQ_CommonFunc.ObjectCleanupFromForBevel(obj)

            finally:
                ZenLocks.unlock_depsgraph_update()
            pass

            ZBBQ_CommonFunc.Report(self, text=f"Successfully reset {len(objectsToReset)} object(s)!")

        return {"FINISHED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):

        objectsToReset = []
        if context.mode == 'EDIT_MESH':
            objectsToReset = context.objects_in_mode
        elif context.mode == 'OBJECT':
            objectsToReset = context.selected_editable_objects

        self.layout.label(text=f"This will cleanup {len(objectsToReset)} object(s) from Zen BBQ, "+ZBBQ_CommonFunc.StrConfirmQuestion(self))


class ZBBQ_OT_GlobalAddonCleanup(Operator):

    bl_idname = "global.zen_bbq_addon_cleanup"
    bl_label = ZBBQ_Labels.ZBBQ_OT_GlobalAddonCleanup_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_GlobalAddonCleanup_Desc
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        return not context.scene.zen_bbq.is_baking_active

    def execute(self, context: bpy.types.Context):

        ZBBQ_CommonFunc.GlobalCleanup(context)

        ZBBQ_CommonFunc.Report(self, text=ZBBQ_Labels.ZBBQ_OT_GlobalAddonCleanup_Report_Success)

        return {"CANCELLED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.label(text=ZBBQ_Labels.ZBBQ_OT_GlobalAddonCleanup_Confirm+ZBBQ_CommonFunc.StrConfirmQuestion(self))


class ZBBQ_OT_Keymaps(bpy.types.Operator):
    bl_idname = "global.zen_bbq_show_keymaps"
    bl_label = ZBBQ_Labels.ZBBQ_OT_Keymaps_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_Keymaps_Desc
    bl_options = {'INTERNAL'}

    def execute(self, context):

        addon_utils.modules_refresh()

        try:
            mod = addon_utils.addons_fake_modules.get(ZenPolls.ADDON_PACKAGE)
            info = addon_utils.module_bl_info(mod)
            info["show_expanded"] = True  # or False to Collapse
        except Exception as e:
            print(e)

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        addon_prefs.tabs = 'KEYMAP'

        context.preferences.active_section = "ADDONS"
        bpy.ops.screen.userpref_show("INVOKE_DEFAULT")
        bpy.data.window_managers['WinMan'].addon_search = ZBBQ_Consts.addonName

        return {'FINISHED'}


# Managing presets


class ZBBQ_OT_PresetsPresetGroupAdd(Operator):

    bl_idname = "zbv_ul_presets.preset_group_add"
    bl_label = ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupAdd_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupAdd_Desc

    title: StringProperty(
           name=ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupAdd_Prop_Title_Name,
           description=ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupAdd_Prop_Title_Desc,
           default="Untitled"
    )

    overwrite: bpy.props.BoolProperty(
        name="Overwrite",
        description="Allow to overwrite preset with the existing name",
        default=True
    )

    @classmethod
    def poll(cls, context):
        return len(bpy.context.scene.ZBBQ_PresetsIncluded.bevelPresets) > 0

    def execute(self, context):
        try:
            from .preferences import ZBBQ_Pref_BevelPresetGroup, ZBBQ_Pref_BevelPreset
            prefs = ZBBQ_CommonFunc.GetPrefs()

            bpgScene: ZBBQ_Pref_BevelPresetGroup = bpy.context.scene.ZBBQ_PresetsIncluded

            if len(bpgScene.bevelPresets) == 0:
                raise RuntimeError("There are no bevel values! Add some data to continue!")

            p_preset_group: ZBBQ_Pref_BevelPresetGroup = None

            if self.overwrite:
                p_preset_group = prefs.bevelPresetGroups.get(self.title, None)

            if p_preset_group is None:
                p_preset_group = prefs.bevelPresetGroups.add()
                _setnameex(p_preset_group, self.title, collection_from_element=lambda self: prefs.bevelPresetGroups)
                s_unique_name = p_preset_group.name
            else:
                s_unique_name = p_preset_group.name

            for prop_name in bpgScene.__annotations__.keys():
                if prop_name in {'name', 'title'}:
                    continue

                source = getattr(bpgScene, prop_name)
                p_prop: bpy.types.Property = bpgScene.bl_rna.properties[prop_name]
                if not p_prop.is_skip_save and not p_prop.is_readonly:
                    setattr(p_preset_group, prop_name, source)

            p_preset_group.title = s_unique_name

            for item in bpgScene.bevelPresets:

                preset: ZBBQ_Pref_BevelPreset = p_preset_group.bevelPresets.add()

                for prop_name in item.__annotations__.keys():
                    p_prop: bpy.types.Property = preset.bl_rna.properties[prop_name]
                    if not p_prop.is_skip_save and not p_prop.is_readonly:
                        source = getattr(item, prop_name)
                        setattr(preset, prop_name, source)

            prefs.bevelPresetGroupsDropdown = s_unique_name
        except Exception as e:
            self.report({'ERROR'}, str(e))

        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=200)


class ZBBQ_OT_PresetsCreate(Operator):
    bl_idname = "wm.zen_bbq_preset_create"
    bl_label = "Create Preset"
    bl_description = "Generate bevel values depending on units"

    clear: bpy.props.BoolProperty(
        name="Clear",
        description="Clear all existing items in a preset",
        default=True
    )

    unitSystem: EnumProperty(
            name=ZBBQ_Labels.ZBBQ_Pref_BevelPresetGroup_Prop_UnitSystem_Name,
            description=ZBBQ_Labels.ZBBQ_Pref_BevelPresetGroup_Prop_UnitSystem_Desc,
            items=ZBBQ_UnitSystemsForEnumProperty,
            default="METRIC"
    )

    units: EnumProperty(
            name=ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupAdd_Prop_Units_Name,
            description=ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupAdd_Prop_Units_Desc,
            items=lambda self, context: ZBBQ_UnitsForEnumPropertyConsideringUnitSystem(self.unitSystem),
    )

    def execute(self, context):
        bpg = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        bpg.unitSystem = self.unitSystem
        if self.clear:
            bpg.bevelPresets.clear()
        ZBBQ_CommonFunc.FillPreset(bpg, self.units)

        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=200)


class ZBBQ_OT_PresetsPresetGroupRemove(Operator):

    bl_idname = "zbv_ul_presets.preset_group_remove"
    bl_label = ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupRemove_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupRemove_Desc

    @classmethod
    def poll(cls, context):
        return len(ZBBQ_CommonFunc.GetPrefs().bevelPresetGroups) > 0

    def execute(self, context):

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()

        s_preset_name = addon_prefs.bevelPresetGroupsDropdown

        idx = addon_prefs.bevelPresetGroups.find(s_preset_name)
        if idx == -1:
            self.report({'ERROR'}, f"Can not find preset: {s_preset_name}")
            return {'CANCELLED'}

        addon_prefs.bevelPresetGroups.remove(idx)
        n_count = len(addon_prefs.bevelPresetGroups)
        if n_count > 0:
            new_idx = min(idx, n_count - 1)
            addon_prefs.bevelPresetGroupsDropdown = addon_prefs.bevelPresetGroups[new_idx].name
        else:
            addon_prefs.bevelPresetGroupsDropdown = ""
        return {'FINISHED'}

    def draw(self, context: bpy.types.Context):
        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        s_preset_name = addon_prefs.bevelPresetGroupsDropdown

        layout = self.layout
        layout.label(text=f"Preset name: {s_preset_name}")
        layout.label(text="Confirm?")

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)


class ZBBQ_OT_PresetsPresetGroupOrderChange(Operator):

    bl_idname = "zbv_ul_presets.preset_group_order_change"
    bl_label = ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupOrderChange_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_PresetsPresetGroupOrderChange_Desc

    direction: bpy.props.EnumProperty(items=(('UP', 'Up', "Move the selected preset group in order up"),
                                             ('DOWN', 'Down', "Move the selected preset group in order down"),))

    @classmethod
    def poll(cls, context):
        return len(ZBBQ_CommonFunc.GetPrefs().bevelPresetGroups) > 0

    def OrderChange(self):

        prefs = ZBBQ_CommonFunc.GetPrefs()
        bpgIndex = int(prefs.bevelPresetGroupsDropdown)

        if len(prefs.bevelPresetGroups) > 0:
            prefs.bevelPresetGroupsDropdown = str(max(
                0, min(bpgIndex + (-1 if self.direction == 'UP' else 1),
                       len(prefs.bevelPresetGroups) - 1)))

    def execute(self, context):

        prefs = ZBBQ_CommonFunc.GetPrefs()
        bpgIndex = int(prefs.bevelPresetGroupsDropdown)

        prefs.bevelPresetGroups.move(bpgIndex + (-1 if self.direction == 'UP' else 1), bpgIndex)

        self.OrderChange()

        return {'FINISHED'}


class ZBBQ_OT_PresetsPresetOrderChange(Operator):

    bl_idname = "zbv_ul_presets.preset_order_change"
    bl_label = ZBBQ_Labels.ZBBQ_OT_PresetsPresetOrderChange_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_PresetsPresetOrderChange_Desc

    direction: bpy.props.EnumProperty(items=(('UP', 'Up', "Move the selected preset in order up"),
                                             ('DOWN', 'Down', "Move the selected preset in order down"),))

    @classmethod
    def poll(cls, context):
        return len(ZBBQ_CommonFunc.GetPrefs().bevelPresetGroups) > 0

    def execute(self, context):

        bpg = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        bpg.bevelPresets.move(bpg.bevelPresetsIndex + (-1 if self.direction == 'UP' else 1), bpg.bevelPresetsIndex)

        if len(bpg.bevelPresets) > 0:
            bpg.bevelPresetsIndex = max(
                0, min(bpg.bevelPresetsIndex + (-1 if self.direction == 'UP' else 1),
                       len(bpg.bevelPresets) - 1))
        return {'FINISHED'}


class ZBBQ_OT_ResetPreferences(Operator):

    bl_idname = "global.zen_bbq_reset_preferences"
    bl_label = ZBBQ_Labels.ZBBQ_OT_ResetPreferences_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_ResetPreferences_Desc
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):

        ZBBQ_CommonFunc.BevelPresetGroupsResetToDefault()

        prefs = ZBBQ_CommonFunc.GetPrefs()
        prefs.smartSelectRadiusThreshold = ZBBQ_Consts.smartSelectRadiusThresholdDefault
        prefs.cyclesActivatingConfirmation = True

        if context.mode == 'EDIT_MESH':
            eval("bpy.ops."+ZBBQ_OT_DrawHighlight.bl_idname+"('INVOKE_DEFAULT', mode='OFF')")

        ZBBQ_CommonFunc.Report(self, text=ZBBQ_Labels.ZBBQ_OT_ResetPreferences_Report_Success)

        return {"CANCELLED"}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        self.layout.label(text=ZBBQ_Labels.ZBBQ_OT_ResetPreferences_Confirm+ZBBQ_CommonFunc.StrConfirmQuestion(self))


class ZBBQ_OT_DrawHighlight(bpy.types.Operator):
    bl_idname = 'zbbq.draw_highlight'
    bl_label = ZBBQ_Labels.ZBBQ_OT_DrawHighlight_Label
    bl_description = ZBBQ_Labels.ZBBQ_OT_DrawHighlight_Desc
    bl_options = {'REGISTER'}

    mode: bpy.props.EnumProperty(
        items=[("NONE", "None", ""),
               ("ON", "On", ""),
               ("OFF", "Off", "")],
        default='NONE')

    @classmethod
    def poll(cls, context):
        if context.mode not in {'EDIT_MESH'}:
            return False

        return True

    def modal(self, context, event):
        p_cls_mgr = ZBBQ_EdgeLayerManager
        if p_cls_mgr:
            if is_draw_handler_enabled(p_cls_mgr):
                if hasattr(context, "area"):
                    if context.area is not None:
                        context.area.tag_redraw()
            return {'PASS_THROUGH'}
        else:
            return {'CANCELLED'}

    def cancel(self, context):
        p_cls_mgr = ZBBQ_EdgeLayerManager
        if p_cls_mgr:
            remove_draw_handler(p_cls_mgr, context)

    def invoke(self, context, event):
        if context.mode in {'EDIT_MESH'}:
            p_cls_mgr = ZBBQ_EdgeLayerManager
            if p_cls_mgr:
                b_modal = False
                if not is_draw_handler_enabled(p_cls_mgr):
                    if self.mode != 'OFF':
                        interval = timer()
                        for p_obj in context.objects_in_mode:
                            Log.debug('Checking cache:', p_obj.name)
                            interval_obj = timer()
                            check_update_cache(p_cls_mgr, p_obj)
                            Log.debug('Check cache completed:', p_obj.name, timer() - interval_obj)
                        _do_add_draw_handler(p_cls_mgr, context)

                        context.window_manager.modal_handler_add(self)
                        b_modal = True
                        elapsed = timer() - interval

                        ZBBQ_SceneConfigFunc.CbOnBBQOverlayOn()

                        bpy.context.scene.ZBBQ_ZenBBQOverlayShow = True  # Need to storee this for furter use on scene load/addon init
                        Log.debug('ZBBQ_OT_DrawHighlight - ON:', elapsed)
                else:
                    if self.mode != 'ON':
                        _do_remove_draw_handler(p_cls_mgr.id_group, context)

                        ZBBQ_SceneConfigFunc.CbOnBBQOverlayOff()

                        bpy.context.scene.ZBBQ_ZenBBQOverlayShow = False  # Need to storee this for furter use on scene load/addon init
                        Log.debug('ZBBQ_OT_DrawHighlight - OFF')

                return {'RUNNING_MODAL'} if b_modal else {'CANCELLED'}

        return {'CANCELLED'}

    @classmethod
    def InvokeManually(cls, mode):
        op = eval("bpy.ops."+cls.bl_idname)
        if op.poll():
            op('INVOKE_DEFAULT', mode=mode)


class ZBBQ_OT_RemoveNormalInspectStudio(bpy.types.Operator):

    bl_idname = "zbbq.remove_normal_inspect_sudio"
    bl_label = "Remove Studio"
    bl_description = "Delete the test studio light sources and clean up the scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context: bpy.types.Context):

        NormalInspectStudio.remove_studio_collection_and_items()

        return {"FINISHED"}


class ZBBQ_OT_SetupNormalInspectStudio(bpy.types.Operator):

    bl_idname = "zbbq.setup_normal_inspect_studio"
    bl_label = "Setup Studio"
    bl_description = "Create studio lights and environment to inspect baked normal map quality"
    bl_options = {'REGISTER', 'UNDO'}

    activate_scene_lights_material: bpy.props.BoolProperty(
        name="Material Preview",
        description=(
            "When enabled, forces the 3D Viewport to use actual scene lights in Material Preview mode.\n"
            "When disabled, leaves the viewport shading state as is, making no further automated changes."
        ),
        default=True
    )

    activate_scene_lights_render: bpy.props.BoolProperty(
        name="Renderer",
        description=(
            "When enabled, forces the 3D Viewport to use actual scene lights in Rendered shading mode.\n"
            "When disabled, leaves the viewport shading state as is, making no further automated changes."
        ),
        default=True
    )

    disable_scene_world_material: bpy.props.BoolProperty(
        name="Material Preview",
        description=(
            "When enabled, disables 'Scene World' in Material Preview mode, forcing the viewport to use built-in studio HDRI.\n"
            "When disabled, leaves the viewport shading state as is, making no further automated changes."
        ),
        default=True
    )

    disable_scene_world_render: bpy.props.BoolProperty(
        name="Renderer",
        description=(
            "When enabled, disables 'Scene World' in Rendered shading mode, forcing the viewport to use built-in studio HDRI.\n"
            "When disabled, leaves the viewport shading state as is, making no further automated changes."
        ),
        default=True
    )

    distance_scalar: bpy.props.FloatProperty(
        name="Distance Scalar",
        description="Distance multiplier from the light source to the target",
        default=1.0,
        min=0.01,
        max=10.0
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        row = box.row()

        col = row.column(align=True)
        col.label(text="Activate Scene Light in:", icon='LIGHT')
        col.prop(self, "activate_scene_lights_material", text="Material Preview")
        col.prop(self, "activate_scene_lights_render", text="Render")

        col = row.column(align=True)
        col.label(text="Disable Scene World in:", icon='LIGHT')
        col.prop(self, "activate_scene_lights_material", text="Material Preview")
        col.prop(self, "activate_scene_lights_render", text="Render")

        layout.prop(self, "distance_scalar")

    def execute(self, context: bpy.types.Context):
        objs = ZBBQ_CommonFunc.GetMeshObjectsInMode(context)
        if not objs:
            self.report({"WARNING"}, 'No mesh objects selected')
            return {"CANCELLED"}

        spaceView3D = context.area.spaces.active
        if spaceView3D:
            if self.activate_scene_lights_material:
                spaceView3D.shading.use_scene_lights = True
            if self.activate_scene_lights_render:
                spaceView3D.shading.use_scene_lights_render = True

            if self.disable_scene_world_material:
                spaceView3D.shading.use_scene_world = False
            if self.disable_scene_world_render:
                spaceView3D.shading.use_scene_world_render = False

        target_location = sum((obj.location for obj in objs), Vector()) / len(objs)
        NormalInspectStudio.create_studio(target_location, self.distance_scalar)

        return {"FINISHED"}


class ZBBQ_OT_SetWeightedNormalToObjs(bpy.types.Operator):
    bl_idname = "zbbq.set_weighted_normal_to_objs"
    bl_label = "Set Weighted Normal"
    bl_description = "Add or update the Weighted Normal modifier with optimal settings for normal map baking"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        return active_object is not None and active_object.type == 'MESH'

    def execute(self, context: bpy.types.Context):
        objs = ZBBQ_CommonFunc.GetMeshObjectsInMode(context)
        if not objs:
            message = "No mesh object selected"
            Log.debug(message)
            self.report({"INFO"}, message)
            return {'FINISHED'}

        NormalBakingSetup.apply_weighted_normals_to_selected(objs)

        return {"FINISHED"}


class ZBBQ_OT_CopyToClipboard(bpy.types.Operator):
    bl_idname = "wm.zbbq_copy_to_clipboard"
    bl_label = "Copy To Clipboard"
    bl_description = "Copy text data to clipboard"
    bl_options = {'REGISTER'}

    text: bpy.props.StringProperty(
        name="Text",
        description="Text data",
        default=""
    )

    def execute(self, context: bpy.types.Context):
        wm = context.window_manager

        wm.clipboard = self.text

        self.report({'INFO'}, f"{self.text} - copied to clipboard!")

        return {'FINISHED'}


class ZBBQ_OT_ManageExplosionModifier(bpy.types.Operator):
    bl_idname = "zbbq.add_explosion_modifier"
    bl_label = "Manage Explode Modifier"
    bl_description = "Add, remove, or toggle visibility of the Explode modifier"
    bl_options = {'REGISTER', 'UNDO'}

    action: bpy.props.EnumProperty(
        name="Action",
        description="Choose what to do with the modifier",
        items=[
            ('ADD', "Add", "Add modifier to selected objects"),
            ('REMOVE', "Remove", "Remove modifier from selected objects"),
            ('ENABLE', "Enable Visibility", "Enable modifier in viewport and render"),
            ('DISABLE', "Disable Visibility", "Disable modifier in viewport and render"),
        ],
        default='ADD'
    )

    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        return active_object is not None and active_object.type == 'MESH'

    @classmethod
    def description(cls, context, props):
        if props:
            return bpy.types.UILayout.enum_item_description(props, 'action', props.action)

        return cls.bl_description

    def execute(self, context):
        if not ZenPolls.version_since_4_0_0:
            self.report({'ERROR'}, 'Requires Blender v4.0.0 or higher')
            return {'CANCELLED'}

        p_objs = set(context.objects_in_mode) | set(context.selected_objects)
        objs = get_unique_mesh_objects(p_objs)

        if not objs:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}

        group_name = ZBBQ_Consts.bbq_explode_modifier_name

        if self.action == 'REMOVE':
            for obj in objs:
                mod = obj.modifiers.get(group_name)
                if mod:
                    obj.modifiers.remove(mod)
            self.report({'INFO'}, f"Removed '{group_name}' from selected objects")
            return {"FINISHED"}

        elif self.action in {'ENABLE', 'DISABLE'}:
            visible = (self.action == 'ENABLE')
            for obj in objs:
                mod = obj.modifiers.get(group_name)
                if mod:
                    mod.show_viewport = visible
                    mod.show_render = visible
            return {"FINISHED"}

        elif self.action == 'ADD':
            explosion_group = bpy.data.node_groups.get(group_name)
            exp_socket_name = ZBBQ_Consts.bbq_explode_center_socket_name

            if not explosion_group:
                Log.debug(f"Node group {group_name} not found. New will be created.")
                explosion_group = explode_nodes.create_explode_node_group()
            else:
                Log.debug(f"Node group {group_name} found in datablocs.")

            for obj in objs:
                mod = obj.modifiers.get(group_name)
                if not mod:
                    mod = obj.modifiers.new(name=group_name, type="NODES")

                mod.node_group = explosion_group

                mod.show_viewport = True
                mod.show_render = True

                input_socket = DriverUtils.get_identifier(mod, exp_socket_name)

                if input_socket:
                    if hasattr(mod, "properties") and hasattr(mod.properties, "inputs"):
                        inputs_container = mod.properties.inputs
                        if hasattr(inputs_container, input_socket):
                            socket_object = getattr(inputs_container, input_socket)
                            socket_object.value = obj
                    else:
                        try:
                            mod[input_socket] = obj
                        except Exception as e:
                            Log.debug(f"Failed to assign the socket using the old method: {e}")

            return {"FINISHED"}

        return {"CANCELLED"}


class ZBBQ_OT_ManageBevelModifier(bpy.types.Operator):
    bl_idname = "zbbq.manage_bevel_modifier"
    bl_label = "Manage BBQ Mesh Bevels"
    bl_description = "Add, remove, or toggle visibility of the Bevel modifier"
    bl_options = {'REGISTER', 'UNDO'}

    action: bpy.props.EnumProperty(
        name="Action",
        description="Choose what to do with the modifier",
        items=[
            ('ADD', "Add", "Add Bevel modifier to selected objects"),
            ('REMOVE', "Remove", "Remove Bevel modifier from selected objects"),
            ('ENABLE', "Enable Visibility", "Enable modifier in viewport and render"),
            ('DISABLE', "Disable Visibility", "Disable modifier in viewport and render"),
        ],
        default='ADD'
    )

    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        return active_object is not None and active_object.type == 'MESH'

    @classmethod
    def description(cls, context, props):
        if props:
            return bpy.types.UILayout.enum_item_description(props, 'action', props.action)
        return cls.bl_description

    def execute(self, context):
        if not ZenPolls.version_since_4_0_0:
            self.report({'ERROR'}, 'Requires Blender v4.0.0 or higher')
            return {'CANCELLED'}

        p_objs = set(context.objects_in_mode) | set(context.selected_objects)
        objs = get_unique_mesh_objects(p_objs)

        if not objs:
            self.report({'WARNING'}, "No mesh objects selected")
            return {'CANCELLED'}

        group_name = ZBBQ_Consts.modifier_mesh_bevels_name

        if self.action == 'REMOVE':
            for obj in objs:
                mod = obj.modifiers.get(group_name)
                if mod:
                    obj.modifiers.remove(mod)
            self.report({'INFO'}, f"Removed '{group_name}' from selected objects")
            return {"FINISHED"}

        elif self.action in {'ENABLE', 'DISABLE'}:
            visible = (self.action == 'ENABLE')
            for obj in objs:
                mod = obj.modifiers.get(group_name)
                if mod:
                    mod.show_viewport = visible
                    mod.show_render = visible
            return {"FINISHED"}

        elif self.action == 'ADD':
            for obj in objs:
                mod = obj.modifiers.get(group_name)

                if not mod:
                    mod = obj.modifiers.new(name=group_name, type="BEVEL")

                mod.width = 1.0
                mod.limit_method = 'WEIGHT'
                try:
                    mod.edge_weight = "ZenBBQ_EdgeBevelWidth"
                except Exception as e:
                    Log.debug(e)

                mod.show_viewport = True
                mod.show_render = True

            return {"FINISHED"}

        return {"CANCELLED"}


class ZBBQ_OT_DescriptionHolder(bpy.types.Operator):
    bl_idname = "wm.zbbq_description_holder"
    bl_label = "Description Holder"
    bl_description = "Special operator to fix Blender hints"
    bl_options = {'INTERNAL'}

    desc: bpy.props.StringProperty(
        name="Description",
        default=""
    )

    @classmethod
    def description(cls, context, props):
        if props:
            if props.desc:
                return props.desc
        return cls.bl_description

    def execute(self, context):
        return {'FINISHED'}


class ZBBQ_OT_CyclesSetup(bpy.types.Operator):
    bl_idname = "wm.zbbq_cycles_setup"
    bl_label = "Cycles Setup"
    bl_description = "Call cycles setup panel"
    bl_options = {'INTERNAL'}

    def draw(self, context: bpy.types.Context):
        if bpy.app.build_options.cycles:
            addon: bpy.types.Addon = context.preferences.addons.get("cycles")
            if addon:
                addon.preferences.draw_impl(self.layout, context)

    def invoke(self, context: bpy.types.Context, event: bpy.types.Event):
        wm = context.window_manager
        return wm.invoke_popup(self)

    def execute(self, context):
        return {'FINISHED'}


class ZBBQ_OT_ActivateObject(bpy.types.Operator):
    bl_idname = "wm.zbbq_activate_object"
    bl_label = "Activate Object"
    bl_description = "Call cycles setup panel"
    bl_options = {'REGISTER', 'UNDO'}

    clear_selection: bpy.props.BoolProperty(
        name="Clear Selection",
        default=True
    )

    object_name: bpy.props.StringProperty(
        name="Object Name",
        options={'HIDDEN', 'SKIP_SAVE'}
    )

    def execute(self, context: bpy.types.Context):
        p_obj: bpy.types.Object = context.view_layer.objects.get(self.object_name, None)
        if p_obj is None:
            self.report({'WARNING'}, f"Can not find: {self.object_name}")
            return {'CANCELLED'}

        if p_obj not in set(context.selectable_objects):
            self.report({'WARNING'}, f"Can not activate: {self.object_name}")
            return {'CANCELLED'}

        if self.clear_selection:
            if context.mode == 'OBJECT':
                bpy.ops.object.select_all(action='DESELECT')
            elif context.mode == 'EDIT_MESH':
                bpy.ops.mesh.select_all(action='DESELECT')

        if context.view_layer.objects.active != p_obj:
            context.view_layer.objects.active = p_obj

        if context.mode == 'OBJECT':
            p_obj.select_set(True)
        elif context.mode == 'EDIT_MESH':
            if p_obj.type == 'MESH':
                me: bpy.types.Mesh = p_obj.data
                bm = bmesh.from_edit_mesh(me)
                face: bmesh.types.BMFace
                for face in bm.faces:
                    face.select_set(True)
                bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

        return {'FINISHED'}


class ZBBQ_OT_AddNormalsMixerToMaterial(bpy.types.Operator):
    bl_idname = "object.zen_bbq_add_normals_mixer_to_material"
    bl_label = "Add Normals Mixer"
    bl_description = "Inject a Node Mixer setup into the object's materials for advanced shader blending"
    bl_options = {'REGISTER', 'UNDO'}

    reset_nodes: bpy.props.BoolProperty(
        name="Reset Nodes",
        description="All preview cached nodes will be removed and re-created again",
        default=False,
        options={'HIDDEN', 'SKIP_SAVE'}
    )

    mixer_application_mode: bpy.props.EnumProperty(
        name="Apply Mixer To",
        description="Select which material slots will receive the Node Mixer setup",
        items=(
            ("ACTIVE", "Active Material Only", "Inject the Node Mixer only into the currently active material slot", 'MATERIAL_DATA', 0),
            ("ALL", "All Material Slots", "Inject the Node Mixer into every material slot assigned to the object", 'MATERIAL', 1),
        ),
        default="ALL"
    )

    @classmethod
    def description(cls, context, properties):
        if properties:
            return bpy.types.UILayout.enum_item_description(properties, 'mixer_application_mode', properties.mixer_application_mode)

        return cls.description

    @classmethod
    def poll(cls, context):
        objects = ZBBQ_CommonFunc.GetMeshObjectsInMode(context)
        return len(objects) > 0

    def execute(self, context: bpy.types.Context):
        user_normal_mixer_name = ZBBQ_Consts.NORMAL_NODE_MIXER_NAME
        ref_position = [0.0, 0.0]

        for obj in ZBBQ_CommonFunc.GetMeshObjectsInMode(context):
            me: bpy.types.Mesh = obj.data
            ZBBQ_MaterialFunc.ObjectFillMissingMatsWithDefaultZenBBQMaterial(obj)

            materials_to_mix = []
            if self.mixer_application_mode == 'ACTIVE':
                if obj.active_material:
                    materials_to_mix.append(obj.active_material)
            else:
                materials_to_mix = [mat for mat in me.materials]

            for mat in materials_to_mix:
                if not mat.use_nodes:
                    mat.use_nodes = True

                matNodes = mat.node_tree.nodes

                p_node = next((n for n in mat.node_tree.nodes if n.type == 'GROUP' and n.node_tree and n.node_tree.name == user_normal_mixer_name), None)
                if p_node:
                    continue

                for node in matNodes:
                    if node.type == 'BSDF_PRINCIPLED':
                        ref_position = node.location

                mixer_node_group = matNodes.new('ShaderNodeGroup')
                mixer_node_group.node_tree = ZBBQ_MaterialFunc.GetOrCreateNodeTree(user_normal_mixer_name, reset=False, mat=mat)
                mixer_node_group.location = (ref_position[0] - mixer_node_group.width - 50, ref_position[1])

        return {'FINISHED'}


class ZBBQ_OT_RepairNormalMixerNodes(Operator):
    bl_idname = "wm.zen_bbq_repair_normal_mixer_nodes"
    bl_label = "Repair Mixer Nodes"
    bl_description = "Normal Mixer nodes will be removed and re-created again"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context: bpy.types.Context):
        return not context.scene.zen_bbq.is_baking_active

    def execute(self, context: bpy.types.Context):
        from .shader_nodes.shader_overrider import BbqShaderOverrider
        if bpy.data.node_groups.get(ZBBQ_Consts.NORMAL_NODE_MIXER_NAME, None):
            BbqShaderOverrider.build_service_normals_mixer_ng(is_user_mixer=True, reset=True)
            self.report({'INFO'}, "Normal Mixer nodes were repaired!")

        return {'FINISHED'}


class ZBBQ_OT_GenerateMaterialId(bpy.types.Operator):
    bl_idname = "mesh.zen_bbq_generate_material_id"
    bl_label = "Generate BBQ Material ID"
    bl_options = {'REGISTER', 'UNDO'}

    fix_default_gray: bpy.props.BoolProperty(
        name="Default Gray Colors Only",
        description="Only randomize materials that still have the default gray viewport color. If disabled, all materials are randomized",
        default=True
    )

    seed: bpy.props.IntProperty(
        name="Seed",
        description="Seed value for the random distribution",
        default=132,
    )

    @classmethod
    def poll(cls, context):
        objects = ZBBQ_CommonFunc.GetMeshObjectsInMode(context)
        return len(objects) > 0

    def execute(self, context):
        objs = ZBBQ_CommonFunc.GetMeshObjectsInMode(context)
        if not objs:
            self.report({'INFO'}, "No mesh objects selected")

        ObjectAttributes.assign_random_color_to_obj_materials(objs, self.fix_default_gray)

        return {'FINISHED'}


class ZBBQ_OT_CopyBevelsToEdgeBevelWeight(bpy.types.Operator):
    bl_idname = "mesh.zen_bbq_copy_bevels_to_edge_weights"
    bl_label = "Remap ZenBBQ Weights"
    bl_description = "Remap ZenBBQ_EdgeBevelWidth attribute to standard Edge Bevel Weight"
    bl_options = {'REGISTER', 'UNDO'}

    operation_mode: bpy.props.EnumProperty(
        name="Mode",
        description="Choose how to transfer attribute values to Bevel Weight",
        items=[
            ("REMAP", "Remap (0-1)", "Proportionally fit all values into a 0.0 to 1.0 range"),
            ("COPY", "Copy Directly", "Copy raw values 1:1"),
        ],
        default="COPY",
    )

    @classmethod
    def poll(cls, context):
        return ZBBQ_CommonFunc.PollMeshObjectsInMode(context)

    def execute(self, context):
        objs = ZBBQ_CommonFunc.GetMeshObjectsInMode(context)
        if not objs:
            self.report({'INFO'}, 'No mesh objects selected')

        for obj in objs:

            attr_name = ZBBQ_Consts.edgeAttributeBevelWidthName
            target_attr_name = "bevel_weight_edge"

            if obj.mode == 'EDIT':

                bm = bmesh.from_edit_mesh(obj.data)
                if attr_name not in bm.edges.layers.float:
                    continue

                src_layer = bm.edges.layers.float[attr_name]
                if not src_layer:
                    continue

                target_layer = bm.edges.layers.float[target_attr_name]
                if not target_layer:
                    target_layer = bm.edges.layers.new[target_attr_name]

                raw_values = [edge[src_layer] for edge in bm.edges]

                if not raw_values:
                    continue

                # min_val = min(raw_values)
                min_val = 0.0
                max_val = max(raw_values)
                val_range = max_val - min_val

                if self.operation_mode == 'REMAP':
                    if val_range == 0:
                        for edge in bm.edges:
                            edge[target_layer] = 1.0
                        continue
                    else:
                        for edge in bm.edges:
                            normalized_weight = (edge[src_layer] - min_val) / val_range
                            edge[target_layer] = normalized_weight

                elif self.operation_mode == "COPY":
                    for edge in bm.edges:
                        edge[target_layer] = edge[src_layer]

                bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

            elif obj.mode == 'OBJECT':
                mesh = obj.data

                if attr_name not in mesh.attributes:
                    continue

                attr = mesh.attributes[attr_name]

                if attr.domain != "EDGE" or attr.data_type != "FLOAT":
                    continue

                raw_values = [data.value for data in attr.data]

                if not raw_values:
                    continue

                if target_attr_name in mesh.attributes:
                    target_attr = mesh.attributes[target_attr_name]
                else:
                    target_attr = mesh.attributes.new(
                        name=target_attr_name, type="FLOAT", domain="EDGE"
                    )

                target_data = target_attr.data

                if self.operation_mode == "REMAP":
                    min_val = min(raw_values)
                    max_val = max(raw_values)
                    val_range = max_val - min_val

                    if val_range == 0:
                        for data in target_data:
                            data.value = 1.0
                    else:
                        for i, data in enumerate(target_data):
                            data.value = (raw_values[i] - min_val) / val_range

                elif self.operation_mode == "COPY":
                    for i, data in enumerate(target_data):
                        data.value = raw_values[i]

        update_view3d_in_all_screens()

        return {'FINISHED'}


class ZBBQ_OT_SetLiveBooleanDefaultRadius(bpy.types.Operator):
    bl_idname = "object.zenbbq_set_live_boolean_default_radius"
    bl_label = "Set Live Boolean Default Bevel"
    bl_description = "Change live boolean default bevel radius in selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    ZenBBQ_LiveBooleanRadius: ZBBQ_PropUtils.ZenBBQ_LiveBooleanRadius

    ZBBQ_IntactBevelDisplayUnits: ZBBQ_PropUtils.ZBBQ_IntactBevelDisplayUnits

    ZBBQ_IntactBevelDisplayRadius: ZBBQ_PropUtils.ZBBQ_IntactBevelDisplayRadius

    def draw(self, context: bpy.types.Context):
        layout = self.layout
        row = layout.row(align=True)
        r1 = row.row(align=True)
        r1.prop(self, "ZBBQ_IntactBevelDisplayRadius", text="Default Bevel")
        r2 = row.row(align=True)
        r2.alignment = 'RIGHT'
        r2.prop(self, "ZBBQ_IntactBevelDisplayUnits", text="")

    @classmethod
    def poll(cls, context):
        return ZBBQ_CommonFunc.PollMeshObjectsInMode(context)

    def invoke(self, context: bpy.types.Context, event):
        wm = context.window_manager
        return wm.invoke_props_dialog(self)

    def execute(self, context: bpy.types.Context):
        for obj in ZBBQ_CommonFunc.GetMeshObjectsInMode(context):
            obj.ZBBQ_IntactBevelDisplayUnits = self.ZBBQ_IntactBevelDisplayUnits
            obj.ZenBBQ_LiveBooleanRadius = self.ZenBBQ_LiveBooleanRadius

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()

        return {'FINISHED'}


class ZBBQ_OT_SelectHardEdges(bpy.types.Operator):
    bl_idname = "mesh.zenbbq_select_hard_edges"
    bl_label = "Select Hard Edges"
    bl_description = "Select sharp/hard edges based on geometric angle thresholds for hard-surface analysis"
    bl_options = {'REGISTER', 'UNDO'}

    angle_limit: bpy.props.FloatProperty(
        name="Angle Limit",
        default=math.radians(30.0),
        min=math.radians(0.0),
        max=math.radians(180.0),
        subtype="ANGLE"
    )
    include_open_edges: bpy.props.BoolProperty(
        name="Include Open Edges",
        description="Include open boundary edges (edges with only one connected face) in the hard edges selection",
        default=False
    )

    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        return active_object is not None and active_object.type == 'MESH' and context.mode == 'EDIT_MESH'

    def execute(self, context):
        objs = ZBBQ_CommonFunc.GetMeshObjectsInMode(context)
        if not objs:
            self.report({'INFO'}, 'No mesh objects selected')

        for obj in objs:
            bm = bmesh.from_edit_mesh(obj.data)

            bm.faces.ensure_lookup_table()

            processed_faces = [f for f in bm.faces if not f.hide]

            face_region = {f: -1 for f in processed_faces}
            current_region = 0

            for face in processed_faces:
                if face_region[face] != -1:
                    continue

                stack = [face]
                face_region[face] = current_region

                while stack:
                    f = stack.pop()

                    for e in f.edges:
                        for linked in e.link_faces:
                            if linked is f:
                                continue
                            if face_region[linked] != -1:
                                continue

                            angle = f.normal.angle(linked.normal)

                            if angle <= self.angle_limit:
                                face_region[linked] = current_region
                                stack.append(linked)

                current_region += 1

            for e in bm.edges:
                if e.hide:
                    continue
                if self.include_open_edges and e.is_boundary:
                    e.select = True
                if len(e.link_faces) != 2:
                    continue

                f1, f2 = e.link_faces
                if face_region[f1] != face_region[f2]:
                    e.select = True
                else:
                    e.select = False

            bmesh.update_edit_mesh(obj.data)

        return {'FINISHED'}


class ZBBQ_AddPresetRender(AddPresetBase, Operator):
    '''Add a Render Preset'''
    bl_idname = "render.zbbq_cycles_render_preset_add"
    bl_label = "Add Render Preset"
    preset_menu = "ZBBQ_PT_render_presets"

    preset_defines = [
        "cycles = bpy.context.scene.cycles",
        "zen_bbq = bpy.context.scene.zen_bbq"
    ]

    preset_values = [
        "cycles.use_adaptive_sampling",
        "cycles.samples",
        "cycles.adaptive_threshold",
        "cycles.adaptive_min_samples",
        "cycles.time_limit",

        "zen_bbq.ao_node_samples_render",
        "zen_bbq.bevel_node_samples_render"
    ]

    preset_subdir = "zen_bbq/render"


class ZBBQ_AddPresetViewportSampling(AddPresetBase, Operator):
    bl_idname = "render.zbbq_cycles_viewport_sampling_preset_add"
    bl_label = "Add Viewport Sampling Preset"
    preset_menu = "ZBBQ_PT_viewport_sampling_presets"

    preset_defines = [
        "cycles = bpy.context.scene.cycles",
        "zen_bbq = bpy.context.scene.zen_bbq"
    ]

    preset_values = [
        "cycles.use_preview_adaptive_sampling",
        "cycles.preview_samples",
        "cycles.preview_adaptive_threshold",
        "cycles.preview_adaptive_min_samples",
        "cycles.use_preview_denoising",
        "cycles.preview_denoiser",
        "cycles.preview_denoising_input_passes",
        "cycles.preview_denoising_prefilter",
        "cycles.preview_denoising_quality",
        "cycles.preview_denoising_start_sample",

        "zen_bbq.ao_node_samples_viewport",
        "zen_bbq.bevel_node_samples_viewport"
    ]

    preset_subdir = "zen_bbq/viewport_sampling"


class ZBBQ_OT_ZenExpandComboPanel(ZenExpandComboPanel, bpy.types.Operator):
    bl_idname = "wm.zbbq_expand_combo_panel"


class ZBBQ_OT_ZenPinComboPanel(ZenPinComboPanel, bpy.types.Operator):
    bl_idname = "wm.zbbq_pin_combo_panel"


class ZBBQ_OT_ZenSetComboPanel(ZenSetComboPanel, bpy.types.Operator):
    bl_idname = "wm.zbbq_set_combo_panel"


classes = (

    ZBBQ_OT_FixSceneUnitSystem,
    ZBBQ_OT_RenderPreviewToggle,

    ZBBQ_OT_ActiveObjectGetReady,

    ZBBQ_OT_ShaderNodeNormalAdd,
    ZBBQ_OT_ShaderNodeNormalRemove,

    ZBBQ_OT_SetBevelRadiusToSelection,
    ZBBQ_OT_SetZeroBevelRadiusToSelection,
    ZBBQ_OT_SmartSelectByRadiusOfSelectedVerts,

    ZBBQ_OT_PresetsPresetGroupAdd,
    ZBBQ_OT_PresetsPresetGroupRemove,
    # ZBBQ_OT_PresetsPresetGroupOrderChange,
    ZBBQ_OT_PresetsPresetOrderChange,
    ZBBQ_OT_PresetItemAdd,
    ZBBQ_OT_PresetItemRemove,
    ZBBQ_OT_PresetsCreate,
    ZBBQ_OT_PresetReplaceRadius,
    ZBBQ_OT_PresetClearExtraValues,

    ZBBQ_OT_LoadPreset,

    ZBBQ_OT_SmartSelectByRadiusFromActivePreset,

    ZBBQ_OT_UpdateData,

    ZBBQ_OT_PreviewShaderNodeToggle,

    ZBBQ_OT_DrawHighlight,

    ZBBQ_OT_PieMenuGeometryOptionsTop,
    ZBBQ_OT_PieMenuGeometryOptionsBottom,

    ZBBQ_OT_BakeOpenFolder,

    ZBBQ_OT_ObjectAddonCleanup,
    ZBBQ_OT_GlobalAddonCleanup,
    ZBBQ_OT_Keymaps,
    ZBBQ_OT_ResetPreferences,

    # Setup Scene lights
    ZBBQ_OT_SetupNormalInspectStudio,
    ZBBQ_OT_RemoveNormalInspectStudio,
    ZBBQ_OT_SetWeightedNormalToObjs,

    ZBBQ_OT_CopyToClipboard,
    ZBBQ_OT_DescriptionHolder,

    ZBBQ_OT_ManageExplosionModifier,
    ZBBQ_OT_RepairPreviewNodes,

    ZBBQ_OT_AddNormalsMixerToMaterial,
    ZBBQ_OT_RepairNormalMixerNodes,
    ZBBQ_OT_CyclesSetup,
    ZBBQ_OT_ActivateObject,

    ZBBQ_OT_GenerateMaterialId,

    ZBBQ_AddPresetRender,
    ZBBQ_AddPresetViewportSampling,

    ZBBQ_OT_CopyBevelsToEdgeBevelWeight,
    ZBBQ_OT_SelectHardEdges,

    ZBBQ_OT_ZenExpandComboPanel,
    ZBBQ_OT_ZenPinComboPanel,
    ZBBQ_OT_ZenSetComboPanel,

    ZBBQ_OT_ManageBevelModifier,

    ZBBQ_OT_SetLiveBooleanDefaultRadius
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)
