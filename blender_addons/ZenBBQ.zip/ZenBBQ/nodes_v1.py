# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2025, Valeriy Yatsenko - lightbio@gmail.com

import bpy

from .consts import ZBBQ_Consts


# initialize from_srgb_to_linear node group
def from_srgb_to_linear_node_group():
    from_srgb_to_linear = bpy.data.node_groups.new(type='GeometryNodeTree', name="From_sRGB_to_Linear")

    # from_srgb_to_linear interface
    # Socket Float
    float_socket = from_srgb_to_linear.interface.new_socket(name="Float", in_out='OUTPUT', socket_type='NodeSocketFloat')
    float_socket.default_value = 0.0
    float_socket.min_value = -3.4028234663852886e+38
    float_socket.max_value = 3.4028234663852886e+38
    float_socket.subtype = 'NONE'
    float_socket.attribute_domain = 'POINT'
    float_socket.structure_type = 'AUTO'

    # Socket Float
    float_socket_1 = from_srgb_to_linear.interface.new_socket(name="Float", in_out='INPUT', socket_type='NodeSocketVector')
    float_socket_1.default_value = (0.0, 0.0, 0.0)
    float_socket_1.min_value = -3.4028234663852886e+38
    float_socket_1.max_value = 3.4028234663852886e+38
    float_socket_1.subtype = 'NONE'
    float_socket_1.attribute_domain = 'POINT'
    float_socket_1.structure_type = 'AUTO'

    # initialize from_srgb_to_linear nodes
    # node Group Input
    group_input = from_srgb_to_linear.nodes.new("NodeGroupInput")
    group_input.name = "Group Input"

    # node Group Output
    group_output = from_srgb_to_linear.nodes.new("NodeGroupOutput")
    group_output.name = "Group Output"
    group_output.is_active_output = True

    # node Compare
    compare = from_srgb_to_linear.nodes.new("FunctionNodeCompare")
    compare.name = "Compare"
    compare.data_type = 'FLOAT'
    compare.mode = 'ELEMENT'
    compare.operation = 'LESS_THAN'

    # node Math.001
    math_001 = from_srgb_to_linear.nodes.new("ShaderNodeMath")
    math_001.name = "Math.001"
    math_001.operation = 'ADD'
    math_001.use_clamp = False
    # Value_001
    math_001.inputs[1].default_value = 0.054999999701976776

    # node Math.002
    math_002 = from_srgb_to_linear.nodes.new("ShaderNodeMath")
    math_002.name = "Math.002"
    math_002.operation = 'DIVIDE'
    math_002.use_clamp = False
    # Value_001
    math_002.inputs[1].default_value = 1.0549999475479126

    # node Math.003
    math_003 = from_srgb_to_linear.nodes.new("ShaderNodeMath")
    math_003.name = "Math.003"
    math_003.operation = 'POWER'
    math_003.use_clamp = False
    # Value_001
    math_003.inputs[1].default_value = 2.4000000953674316

    # node Mix
    mix = from_srgb_to_linear.nodes.new("ShaderNodeMix")
    mix.name = "Mix"
    mix.blend_type = 'MIX'
    mix.clamp_factor = True
    mix.clamp_result = False
    mix.data_type = 'FLOAT'
    mix.factor_mode = 'UNIFORM'

    # node Math.004
    math_004 = from_srgb_to_linear.nodes.new("ShaderNodeMath")
    math_004.name = "Math.004"
    math_004.operation = 'DIVIDE'
    math_004.use_clamp = False
    # Value_001
    math_004.inputs[1].default_value = 12.920000076293945

    # Set locations
    group_input.location = (-1344.46826171875, -2.769836187362671)
    group_output.location = (568.9783935546875, -28.121002197265625)
    compare.location = (-36.55250549316406, 159.51365661621094)
    math_001.location = (-968.44873046875, 85.7568359375)
    math_002.location = (-768.44873046875, 85.7568359375)
    math_003.location = (-568.44873046875, 85.7568359375)
    mix.location = (341.6607971191406, -28.566307067871094)
    math_004.location = (-970.995361328125, -151.551513671875)

    # Set dimensions
    group_input.width, group_input.height = 140.0, 100.0
    group_output.width, group_output.height = 140.0, 100.0
    compare.width, compare.height = 140.0, 100.0
    math_001.width, math_001.height = 140.0, 100.0
    math_002.width, math_002.height = 140.0, 100.0
    math_003.width, math_003.height = 140.0, 100.0
    mix.width, mix.height = 140.0, 100.0
    math_004.width, math_004.height = 140.0, 100.0

    # initialize from_srgb_to_linear links
    # math_001.Value -> math_002.Value
    from_srgb_to_linear.links.new(math_001.outputs[0], math_002.inputs[0])
    # math_002.Value -> math_003.Value
    from_srgb_to_linear.links.new(math_002.outputs[0], math_003.inputs[0])
    # compare.Result -> mix.Factor
    from_srgb_to_linear.links.new(compare.outputs[0], mix.inputs[0])
    # math_003.Value -> mix.A
    from_srgb_to_linear.links.new(math_003.outputs[0], mix.inputs[2])
    # mix.Result -> group_output.Float
    from_srgb_to_linear.links.new(mix.outputs[0], group_output.inputs[0])
    # math_004.Value -> mix.B
    from_srgb_to_linear.links.new(math_004.outputs[0], mix.inputs[3])
    # math_004.Value -> compare.B
    from_srgb_to_linear.links.new(math_004.outputs[0], compare.inputs[1])
    # math_003.Value -> compare.A
    from_srgb_to_linear.links.new(math_003.outputs[0], compare.inputs[0])
    # group_input.Float -> math_001.Value
    from_srgb_to_linear.links.new(group_input.outputs[0], math_001.inputs[0])
    # group_input.Float -> math_004.Value
    from_srgb_to_linear.links.new(group_input.outputs[0], math_004.inputs[0])
    return from_srgb_to_linear


def zenbbq_bevelstovertexcolor_node_group():
    zenbbq_bevelstovertexcolor = bpy.data.node_groups.new(type='GeometryNodeTree', name="ZenBBQ_BevelsToVertexColor")

    zenbbq_bevelstovertexcolor.is_modifier = True

    # zenbbq_bevelstovertexcolor interface
    # Socket Geometry
    geometry_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="Geometry", in_out='OUTPUT', socket_type='NodeSocketGeometry')
    geometry_socket.attribute_domain = 'POINT'
    geometry_socket.structure_type = 'AUTO'

    # Socket Geometry
    geometry_socket_1 = zenbbq_bevelstovertexcolor.interface.new_socket(name="Geometry", in_out='INPUT', socket_type='NodeSocketGeometry')
    geometry_socket_1.attribute_domain = 'POINT'
    geometry_socket_1.structure_type = 'AUTO'

    # Socket R
    r_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="R", in_out='INPUT', socket_type='NodeSocketBool')
    r_socket.default_value = True
    r_socket.attribute_domain = 'POINT'
    r_socket.description = "Vertex Color Channel Red"
    r_socket.structure_type = 'AUTO'

    # Socket G
    g_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="G", in_out='INPUT', socket_type='NodeSocketBool')
    g_socket.default_value = False
    g_socket.attribute_domain = 'POINT'
    g_socket.description = "Vertex Color Channel Green"
    g_socket.structure_type = 'AUTO'

    # Socket B
    b_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="B", in_out='INPUT', socket_type='NodeSocketBool')
    b_socket.default_value = False
    b_socket.attribute_domain = 'POINT'
    b_socket.description = "Vertex Color Channel Blue"
    b_socket.structure_type = 'AUTO'

    # Socket Default Radius
    default_radius_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="Default Radius", in_out='INPUT', socket_type='NodeSocketFloat')
    default_radius_socket.default_value = 0.0
    default_radius_socket.min_value = -3.4028234663852886e+38
    default_radius_socket.max_value = 3.4028234663852886e+38
    default_radius_socket.subtype = 'NONE'
    default_radius_socket.attribute_domain = 'POINT'
    default_radius_socket.description = "Live Boolean (default) bevel radius"
    default_radius_socket.structure_type = 'AUTO'

    # Socket Units Mult
    units_mult_socket = zenbbq_bevelstovertexcolor.interface.new_socket(name="Units Mult", in_out='INPUT', socket_type='NodeSocketFloat')
    units_mult_socket.default_value = 0.0
    units_mult_socket.min_value = -3.4028234663852886e+38
    units_mult_socket.max_value = 3.4028234663852886e+38
    units_mult_socket.subtype = 'NONE'
    units_mult_socket.attribute_domain = 'POINT'
    units_mult_socket.structure_type = 'AUTO'
    units_mult_socket.hide_in_modifier = True

    # initialize zenbbq_bevelstovertexcolor nodes
    # node Group Input
    group_input_1 = zenbbq_bevelstovertexcolor.nodes.new("NodeGroupInput")
    group_input_1.name = "Group Input"

    # node Group Output
    group_output_1 = zenbbq_bevelstovertexcolor.nodes.new("NodeGroupOutput")
    group_output_1.name = "Group Output"
    group_output_1.is_active_output = True

    # node Named Attribute
    named_attribute = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeInputNamedAttribute")
    named_attribute.name = "Named Attribute"
    named_attribute.data_type = 'FLOAT'
    # Name
    named_attribute.inputs[0].default_value = "ZenBBQ"

    # node Store Named Attribute
    store_named_attribute = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeStoreNamedAttribute")
    store_named_attribute.name = "Store Named Attribute"
    store_named_attribute.data_type = 'FLOAT_COLOR'
    store_named_attribute.domain = 'CORNER'
    # Selection
    store_named_attribute.inputs[1].default_value = True
    # Name
    store_named_attribute.inputs[2].default_value = ZBBQ_Consts.VertexColorMaskNameNodes

    # node Attribute Statistic
    attribute_statistic = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeAttributeStatistic")
    attribute_statistic.name = "Attribute Statistic"
    attribute_statistic.data_type = 'FLOAT'
    attribute_statistic.domain = 'CORNER'
    # Selection
    attribute_statistic.inputs[1].default_value = True

    # node Math
    math = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math.label = "x-a1"
    math.name = "Math"
    math.operation = 'SUBTRACT'
    math.use_clamp = False

    # node Math.001
    math_001_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_001_1.label = "b2-b1"
    math_001_1.name = "Math.001"
    math_001_1.operation = 'SUBTRACT'
    math_001_1.use_clamp = False

    # node Math.002
    math_002_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_002_1.label = "a2-a1"
    math_002_1.name = "Math.002"
    math_002_1.operation = 'SUBTRACT'
    math_002_1.use_clamp = False

    # node Value
    value = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeValue")
    value.label = "b1"
    value.name = "Value"

    value.outputs[0].default_value = 0.0
    # node Value.001
    value_001 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeValue")
    value_001.label = "b2"
    value_001.name = "Value.001"

    value_001.outputs[0].default_value = 1.0
    # node Math.003
    math_003_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_003_1.label = "b1+"
    math_003_1.name = "Math.003"
    math_003_1.operation = 'ADD'
    math_003_1.use_clamp = False

    # node Math.004
    math_004_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_004_1.label = "mult"
    math_004_1.name = "Math.004"
    math_004_1.operation = 'MULTIPLY'
    math_004_1.use_clamp = False

    # node Math.005
    math_005 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_005.label = "a2-a1"
    math_005.name = "Math.005"
    math_005.operation = 'DIVIDE'
    math_005.use_clamp = False

    # node Frame
    frame = zenbbq_bevelstovertexcolor.nodes.new("NodeFrame")
    frame.name = "Frame"
    frame.label_size = 20
    frame.shrink = True

    # node From_sRGB_to_Linear
    from_srgb_to_linear_1 = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeGroup")
    from_srgb_to_linear_1.name = "From_sRGB_to_Linear"
    from_srgb_to_linear_1.node_tree = from_srgb_to_linear_node_group()

    # node Combine XYZ
    combine_xyz = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeCombineXYZ")
    combine_xyz.name = "Combine XYZ"

    # node Mix
    mix_1 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMix")
    mix_1.name = "Mix"
    mix_1.blend_type = 'MIX'
    mix_1.clamp_factor = True
    mix_1.clamp_result = False
    mix_1.data_type = 'FLOAT'
    mix_1.factor_mode = 'UNIFORM'
    # A_Float
    mix_1.inputs[2].default_value = 0.0

    # node Mix.001
    mix_001 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMix")
    mix_001.name = "Mix.001"
    mix_001.blend_type = 'MIX'
    mix_001.clamp_factor = True
    mix_001.clamp_result = False
    mix_001.data_type = 'FLOAT'
    mix_001.factor_mode = 'UNIFORM'
    # A_Float
    mix_001.inputs[2].default_value = 0.0

    # node Mix.002
    mix_002 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMix")
    mix_002.name = "Mix.002"
    mix_002.blend_type = 'MIX'
    mix_002.clamp_factor = True
    mix_002.clamp_result = False
    mix_002.data_type = 'FLOAT'
    mix_002.factor_mode = 'UNIFORM'
    # A_Float
    mix_002.inputs[2].default_value = 0.0

    # node Named Attribute.001
    named_attribute_001 = zenbbq_bevelstovertexcolor.nodes.new("GeometryNodeInputNamedAttribute")
    named_attribute_001.name = "Named Attribute.001"
    named_attribute_001.data_type = 'FLOAT'
    # Name
    named_attribute_001.inputs[0].default_value = "ZenBBQ_UserDefined"

    # node Mix.003
    mix_003 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMix")
    mix_003.name = "Mix.003"
    mix_003.blend_type = 'MIX'
    mix_003.clamp_factor = True
    mix_003.clamp_result = False
    mix_003.data_type = 'FLOAT'
    mix_003.factor_mode = 'UNIFORM'

    # node Math.006
    math_006 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeMath")
    math_006.label = "LivePremult"
    math_006.name = "Math.006"
    math_006.operation = 'MULTIPLY'
    math_006.use_clamp = False

    # node Value.002
    value_002 = zenbbq_bevelstovertexcolor.nodes.new("ShaderNodeValue")
    value_002.label = "min"
    value_002.name = "Value.002"

    value_002.outputs[0].default_value = 0.0

    # Set parents
    math.parent = frame
    math_001_1.parent = frame
    math_002_1.parent = frame
    math_003_1.parent = frame
    math_004_1.parent = frame
    math_005.parent = frame

    # Set locations
    group_input_1.location = (-385.075439453125, 116.0099105834961)
    group_output_1.location = (3106.7470703125, 81.79126739501953)
    named_attribute.location = (-382.45782470703125, -409.5552673339844)
    store_named_attribute.location = (2896.75537109375, 132.720458984375)
    attribute_statistic.location = (295.73553466796875, -156.34494018554688)
    math.location = (30.3046875, -197.958251953125)
    math_001_1.location = (413.2393798828125, -380.3027038574219)
    math_002_1.location = (414.11962890625, -29.93401336669922)
    value.location = (296.4668884277344, -600.8087768554688)
    value_001.location = (298.4585266113281, -667.9518432617188)
    math_003_1.location = (411.80615234375, -206.61434936523438)
    math_004_1.location = (670.61669921875, -194.78192138671875)
    math_005.location = (947.1546630859375, -89.47549438476562)
    frame.location = (536.0, -94.0)
    from_srgb_to_linear_1.location = (1737.782958984375, -135.86138916015625)
    combine_xyz.location = (2506.25439453125, -519.3577880859375)
    mix_1.location = (2116.6826171875, -240.30459594726562)
    mix_001.location = (2116.6826171875, -460.6708679199219)
    mix_002.location = (2121.84521484375, -682.9203491210938)
    named_attribute_001.location = (-381.52349853515625, -268.28631591796875)
    mix_003.location = (35.707237243652344, -304.61419677734375)
    math_006.location = (-181.66200256347656, -12.359786987304688)
    value_002.location = (297.5600280761719, -498.9663391113281)

    # Set dimensions
    group_input_1.width, group_input_1.height = 140.0, 100.0
    group_output_1.width, group_output_1.height = 140.0, 100.0
    named_attribute.width, named_attribute.height = 140.0, 100.0
    store_named_attribute.width, store_named_attribute.height = 140.0, 100.0
    attribute_statistic.width, attribute_statistic.height = 140.0, 100.0
    math.width, math.height = 140.0, 100.0
    math_001_1.width, math_001_1.height = 140.0, 100.0
    math_002_1.width, math_002_1.height = 140.0, 100.0
    value.width, value.height = 140.0, 100.0
    value_001.width, value_001.height = 140.0, 100.0
    math_003_1.width, math_003_1.height = 140.0, 100.0
    math_004_1.width, math_004_1.height = 140.0, 100.0
    math_005.width, math_005.height = 140.0, 100.0
    frame.width, frame.height = 1117.0, 558.0
    from_srgb_to_linear_1.width, from_srgb_to_linear_1.height = 140.0, 100.0
    combine_xyz.width, combine_xyz.height = 140.0, 100.0
    mix_1.width, mix_1.height = 140.0, 100.0
    mix_001.width, mix_001.height = 140.0, 100.0
    mix_002.width, mix_002.height = 140.0, 100.0
    named_attribute_001.width, named_attribute_001.height = 138.95523071289062, 100.0
    mix_003.width, mix_003.height = 140.0, 100.0
    math_006.width, math_006.height = 140.0, 100.0
    value_002.width, value_002.height = 140.0, 100.0

    # initialize zenbbq_bevelstovertexcolor links
    # group_input_1.Geometry -> store_named_attribute.Geometry
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[0], store_named_attribute.inputs[0])
    # store_named_attribute.Geometry -> group_output_1.Geometry
    zenbbq_bevelstovertexcolor.links.new(store_named_attribute.outputs[0], group_output_1.inputs[0])
    # group_input_1.Geometry -> attribute_statistic.Geometry
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[0], attribute_statistic.inputs[0])
    # attribute_statistic.Min -> math.Value
    # zenbbq_bevelstovertexcolor.links.new(attribute_statistic.outputs[3], math.inputs[1])
    # value.Value -> math_003_1.Value
    zenbbq_bevelstovertexcolor.links.new(value.outputs[0], math_003_1.inputs[0])
    # math.Value -> math_003_1.Value
    zenbbq_bevelstovertexcolor.links.new(math.outputs[0], math_003_1.inputs[1])
    # attribute_statistic.Max -> math_002_1.Value
    zenbbq_bevelstovertexcolor.links.new(attribute_statistic.outputs[4], math_002_1.inputs[0])
    # attribute_statistic.Min -> math_002_1.Value
    # zenbbq_bevelstovertexcolor.links.new(attribute_statistic.outputs[3], math_002_1.inputs[1])
    # math_003_1.Value -> math_004_1.Value
    zenbbq_bevelstovertexcolor.links.new(math_003_1.outputs[0], math_004_1.inputs[0])
    # math_001_1.Value -> math_004_1.Value
    zenbbq_bevelstovertexcolor.links.new(math_001_1.outputs[0], math_004_1.inputs[1])
    # math_004_1.Value -> math_005.Value
    zenbbq_bevelstovertexcolor.links.new(math_004_1.outputs[0], math_005.inputs[0])
    # math_002_1.Value -> math_005.Value
    zenbbq_bevelstovertexcolor.links.new(math_002_1.outputs[0], math_005.inputs[1])
    # value_001.Value -> math_001_1.Value
    zenbbq_bevelstovertexcolor.links.new(value_001.outputs[0], math_001_1.inputs[0])
    # value.Value -> math_001_1.Value
    zenbbq_bevelstovertexcolor.links.new(value.outputs[0], math_001_1.inputs[1])
    # math_005.Value -> from_srgb_to_linear_1.Float
    zenbbq_bevelstovertexcolor.links.new(math_005.outputs[0], from_srgb_to_linear_1.inputs[0])
    # combine_xyz.Vector -> store_named_attribute.Value
    zenbbq_bevelstovertexcolor.links.new(combine_xyz.outputs[0], store_named_attribute.inputs[3])
    # group_input_1.R -> mix_1.Factor
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[1], mix_1.inputs[0])
    # mix_1.Result -> combine_xyz.X
    zenbbq_bevelstovertexcolor.links.new(mix_1.outputs[0], combine_xyz.inputs[0])
    # from_srgb_to_linear_1.Float -> mix_1.B
    zenbbq_bevelstovertexcolor.links.new(from_srgb_to_linear_1.outputs[0], mix_1.inputs[3])
    # from_srgb_to_linear_1.Float -> mix_001.B
    zenbbq_bevelstovertexcolor.links.new(from_srgb_to_linear_1.outputs[0], mix_001.inputs[3])
    # from_srgb_to_linear_1.Float -> mix_002.B
    zenbbq_bevelstovertexcolor.links.new(from_srgb_to_linear_1.outputs[0], mix_002.inputs[3])
    # group_input_1.G -> mix_001.Factor
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[2], mix_001.inputs[0])
    # group_input_1.B -> mix_002.Factor
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[3], mix_002.inputs[0])
    # mix_001.Result -> combine_xyz.Y
    zenbbq_bevelstovertexcolor.links.new(mix_001.outputs[0], combine_xyz.inputs[1])
    # mix_002.Result -> combine_xyz.Z
    zenbbq_bevelstovertexcolor.links.new(mix_002.outputs[0], combine_xyz.inputs[2])
    # mix_003.Result -> math.Value
    zenbbq_bevelstovertexcolor.links.new(mix_003.outputs[0], math.inputs[0])
    # mix_003.Result -> attribute_statistic.Attribute
    zenbbq_bevelstovertexcolor.links.new(mix_003.outputs[0], attribute_statistic.inputs[2])
    # named_attribute.Attribute -> mix_003.B
    zenbbq_bevelstovertexcolor.links.new(named_attribute.outputs[0], mix_003.inputs[3])
    # named_attribute_001.Attribute -> mix_003.Factor
    zenbbq_bevelstovertexcolor.links.new(named_attribute_001.outputs[0], mix_003.inputs[0])
    # group_input_1.Default Radius -> math_006.Value
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[4], math_006.inputs[0])
    # group_input_1.Units Mult -> math_006.Value
    zenbbq_bevelstovertexcolor.links.new(group_input_1.outputs[5], math_006.inputs[1])
    # math_006.Value -> mix_003.A
    zenbbq_bevelstovertexcolor.links.new(math_006.outputs[0], mix_003.inputs[2])
    # value_002.Value -> math_002_1.Value
    zenbbq_bevelstovertexcolor.links.new(value_002.outputs[0], math_002_1.inputs[1])
    # value_002.Value -> math.Value
    zenbbq_bevelstovertexcolor.links.new(value_002.outputs[0], math.inputs[1])
    return zenbbq_bevelstovertexcolor


def ensure_zenbbq_bevelstovertexcolor_node_group():
    p_node = bpy.data.node_groups.get("ZenBBQ_BevelsToVertexColor")
    if not p_node:
        return zenbbq_bevelstovertexcolor_node_group()
    return p_node


if __name__ == "__main__":
    pass
