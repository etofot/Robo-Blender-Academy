# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2022, Dmitry Aleksandrovich Maslov (ABTOMAT), Alex Zhornyak (alexander.zhornyak@gmail.com)

import bpy

from .consts import ZBBQ_Consts
from .units import ZBBQ_Units

from . import globals as ZBBQ_Globals
from .vlog import Log

from .commonFunc import ZBBQ_CommonFunc, ZBBQ_PropUtils
from .preferences import ZBBQ_Pref_BevelPresetGroup
from .blender_zen_utils import ZenStrUtils


def ZBBQ_BuggedPinkShaderReset3DSpace(spaceView3D):

    if bpy.context.scene.render.engine != 'CYCLES':
        return
    if (type(spaceView3D) is not bpy.types.SpaceView3D):
        print("[Zen BBQ] ZBBQ_BuggedPinkShaderReset3DSpace func only works in SpaceView3D!")
        return

    bpy.context.view_layer.use = bpy.context.view_layer.use  # Applies the changed settings (probably a bug of Blender)

    if spaceView3D.shading.studio_light != 'Default':
        spaceView3D.shading.studio_light = spaceView3D.shading.studio_light  # Resolves bug with pink object and environment (probably a bug of Blender)
    else:
        # We will need to reset this once user changes mode to rendered, so we memorize it
        ZBBQ_Globals.buggedPinkShaderReset3DSpaceDeferred = True
        # print("ZBBQ_Globals.buggedPinkShaderReset3DSpaceDeferred will be deferred!")


class ZBBQ_SceneConfigFunc:

    @classmethod
    def CbOnBBQOverlayOn(cls):
        cls.OverlayShow(True)
        cls.OverlayConfigOverride()

    @classmethod
    def CbOnBBQOverlayOff(cls):
        cls.OverlayShow(bpy.context.scene.ZBBQ_OverlayShow)
        cls.OverlayConfigRestore()

    @staticmethod
    def OverlayConfigIsOverridden():

        if bpy.context.area is not None:

            overlayConfig = bpy.context.area.spaces.active.overlay

            return (not overlayConfig.show_edge_crease and
                    not overlayConfig.show_edge_sharp and
                    not overlayConfig.show_edge_bevel_weight and
                    not overlayConfig.show_edge_seams)

    @staticmethod
    def OverlayShow(val):  # Set Blender's Overlays On or Off

        if bpy.context.area is not None:
            bpy.context.scene.ZBBQ_OverlayShow = bpy.context.area.spaces.active.overlay.show_overlays

            if bpy.context.area.spaces.active.overlay.show_overlays != val:  # Take action only if we really need to change it

                # Need to disable subscription, otherwise we'll get settings re-set
                from . import eventHandling
                eventHandling.ZBBQ_RnaUnsubscribeSpaceView3DOverlay()
                bpy.context.area.spaces.active.overlay.show_overlays = val
                eventHandling.ZBBQ_RnaSubscribeSpaceView3DOverlay()

    @classmethod
    def OverlayConfigOverride(cls):
        if not cls.OverlayConfigIsOverridden():
            cls.OverlayConfigStore()

        # Need to disable subscription, otherwise we'll get settings re-set
        from . import eventHandling
        eventHandling.ZBBQ_RnaUnsubscribeSpaceView3DOverlayEdgeDisplay()

        if bpy.context.area is not None:

            overlayConfig = bpy.context.area.spaces.active.overlay

            overlayConfig.show_edge_crease = False
            overlayConfig.show_edge_sharp = False
            overlayConfig.show_edge_bevel_weight = False
            overlayConfig.show_edge_seams = False

        eventHandling.ZBBQ_RnaSubscribeSpaceView3DOverlayEdgeDisplay()

    @staticmethod
    def OverlayConfigStore():

        if bpy.context.area is not None:

            overlayConfig = bpy.context.area.spaces.active.overlay

            bpy.context.scene.ZBBQ_OverlayConfigCreases = overlayConfig.show_edge_crease
            bpy.context.scene.ZBBQ_OverlayConfigSharp = overlayConfig.show_edge_sharp
            bpy.context.scene.ZBBQ_OverlayConfigBevel = overlayConfig.show_edge_bevel_weight
            bpy.context.scene.ZBBQ_OverlayConfigSeams = overlayConfig.show_edge_seams

            bpy.context.scene.ZBBQ_OverlayConfigIsStored = True

    @staticmethod
    def OverlayConfigRestore():
        if not bpy.context.scene.ZBBQ_OverlayConfigIsStored:
            return

        # Need to disable subscription, otherwise we'll get settings re-set
        from . import eventHandling
        eventHandling.ZBBQ_RnaUnsubscribeSpaceView3DOverlayEdgeDisplay()

        overlayConfig = None

        if bpy.context.area is not None:  # To-Do: Make function for this!
            overlayConfig = bpy.context.area.spaces.active.overlay
        else:
            for area in bpy.context.screen.areas:
                if area.type == 'VIEW_3D':
                    overlayConfig = area.spaces.active.overlay

        if overlayConfig is not None:
            overlayConfig.show_edge_crease = bpy.context.scene.ZBBQ_OverlayConfigCreases
            overlayConfig.show_edge_sharp = bpy.context.scene.ZBBQ_OverlayConfigSharp
            overlayConfig.show_edge_bevel_weight = bpy.context.scene.ZBBQ_OverlayConfigBevel
            overlayConfig.show_edge_seams = bpy.context.scene.ZBBQ_OverlayConfigSeams

        eventHandling.ZBBQ_RnaSubscribeSpaceView3DOverlayEdgeDisplay()

    @staticmethod
    def PresetGroupSaveActive():

        # Copies bevel preset group and presets in it from prefs to scene data

        bpgActive = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
        bpgStored = bpy.context.scene.ZBBQ_PresetsIncluded

        bpgStored.title = bpgActive.title
        bpgStored.unitSystem = bpgActive.unitSystem
        bpgStored.bevelPresetsIndex = bpgActive.bevelPresetsIndex

        for i in range(len(bpgStored.bevelPresets)-1, -1, -1):
            bpgStored.bevelPresets.remove(i)

        for bpActive in bpgActive.bevelPresets:
            bpStored = bpgStored.bevelPresets.add()

            bpStored.unitSystem = bpActive.unitSystem
            bpStored.radius = bpActive.radius
            bpStored.units = bpActive.units
            bpStored.colorId = bpActive.colorId
            bpStored.color = bpActive.color

    @staticmethod
    def PresetGroupGetIdxCorresponding():

        bpgStored = bpy.context.scene.ZBBQ_PresetsIncluded
        prefs = ZBBQ_CommonFunc.GetPrefs()

        for idxBpg in range(len(prefs.bevelPresetGroups)):

            bpg = prefs.bevelPresetGroups[idxBpg]

            if not (bpgStored.title == bpg.title
                    and bpgStored.unitSystem == bpg.unitSystem
                    and len(bpgStored.bevelPresets) == len(bpg.bevelPresets)):

                continue

            for idxBp in range(len(bpg.bevelPresets)):
                bp = bpg.bevelPresets[idxBp]
                bpStored = bpgStored.bevelPresets[idxBp]

                if not (bpStored.unitSystem == bp.unitSystem
                        and bpStored.radius == bp.radius
                        and bpStored.units == bp.units
                        and bpStored.colorId == bp.colorId
                        and bpStored.color == bp.color):
                    break
            else:
                # All checks passed: this is it!
                return idxBpg
            continue

        return -1  # Not Found

    @classmethod
    def CbOnInit(cls):
        p_scene = bpy.context.scene
        if p_scene:
            bpg = ZBBQ_CommonFunc.GetActiveBevelPresetGroup()
            if len(bpg.bevelPresets) == 0:
                s_unit_system = p_scene.unit_settings.system
                s_units = 'UNITS'
                if s_unit_system == 'METRIC':
                    s_units = 'CENTIMETERS'
                elif s_unit_system == 'IMPERIAL':
                    s_units = 'INCHES'
                ZBBQ_CommonFunc.FillPreset(bpg, s_units)

        # If before saving BBQ Highlight was On, we should corerect all saved settings

        if bpy.context.scene.ZBBQ_ZenBBQOverlayShow:

            Log.debug(f"On Init: Was BBQ Highlight enabled? {bpy.context.scene.ZBBQ_ZenBBQOverlayShow}")
            cls.CbOnBBQOverlayOff()


class BakeBaseProps:
    bake_image_size_override: ZBBQ_PropUtils.bake_image_size_override
    bake_image_width: ZBBQ_PropUtils.bake_image_width
    bake_image_height: ZBBQ_PropUtils.bake_image_height
    bake_image_uniform_size: ZBBQ_PropUtils.bake_image_uniform_size
    bake_margin: ZBBQ_PropUtils.bake_margin

    bake_add_image_node_after_render: ZBBQ_PropUtils.bake_add_image_node_after_render

    def get_id_name(self: bpy.types.PropertyGroup) -> str:
        return self.MAP_ID

    @classmethod
    def draw_bake_image_override_size(cls, p_data, layout: bpy.types.UILayout, context: bpy.types.Context):
        box = layout.box()
        col = box.column(align=False)
        col.prop(p_data, "bake_image_size_override")
        col.active = p_data.bake_image_size_override
        ZBBQ_PropUtils.draw_bake_image_size(col, p_data)

    def draw(self, layout: bpy.types.UILayout, context: bpy.types.Context):
        from .preferences import ZBBQ_AddonExpandProps
        from .sceneConfig import ZBBQ_SceneProperties

        addon_prefs = ZBBQ_CommonFunc.GetPrefs()
        p_expand_props: ZBBQ_AddonExpandProps = addon_prefs.expand_props
        p_scene_props: ZBBQ_SceneProperties = context.scene.zen_bbq

        s_id_name = self.get_id_name()

        def fn_draw_render_header(p_header_layout: bpy.types.UILayout):
            r1 = p_header_layout.row(align=True)
            r1.label(text=f"{self.TITLE}")

            r2 = p_header_layout.row(align=True)
            r2.alignment = 'RIGHT'
            r2.prop(self, "bake_enabled")

        box: bpy.types.UILayout = p_expand_props.prepare_layout_panel(
            layout, f"expand_bake_{s_id_name.lower()}",
            fn_draw_header=fn_draw_render_header)
        if box:
            col = box.column(align=False)

            col.use_property_split = True
            col.use_property_decorate = False

            col.prop(self, "bake_image_suffix")

            if s_id_name == "AO":
                row = col.row(align=True)
                row.prop(p_scene_props, "ao_distance")
            elif s_id_name == "NORMAL":
                row = col.row(align=True)
                row.prop(p_scene_props, "normal_map_convention")
                col.prop(p_scene_props, "use_bbq_engine")
            elif s_id_name == "MATERIAL_ID":
                row = col.row(align=True)
                r_split = row.split(factor=1/2.5)
                r_split.separator()
                r_split.operator("mesh.zen_bbq_generate_material_id")
            elif s_id_name in {"CURVATURE", "CONCAVITY", "CONVEXITY"}:
                row = col.row(align=True)
                row.prop(p_scene_props, "cavity_distance")

            if hasattr(self, "bake_disable_explode_in_renders"):
                col.prop(self, "bake_disable_explode_in_renders")

            col.prop(self, "bake_add_image_node_after_render")

            BakeBaseProps.draw_bake_image_override_size(self, col, context)


class ZBBQ_BakeNormalProps(bpy.types.PropertyGroup, BakeBaseProps):
    TITLE = "Normal"
    MAP_ID = 'NORMAL'
    IMAGE_COLOR = (0.5, 0.5, 1.0, 0.0)

    bake_image_suffix: ZBBQ_PropUtils.get_bake_image_suffix(p_default="Normal")
    bake_enabled: ZBBQ_PropUtils.get_bake_enabled(p_default=True)

    bake_samples: ZBBQ_PropUtils.get_bake_samples(p_default=1)


class ZBBQ_BakeCurvatureProps(bpy.types.PropertyGroup, BakeBaseProps):
    TITLE = "Curvature"
    MAP_ID = 'AO'
    IMAGE_COLOR = (0.5, 0.5, 0.5, 0.0)

    bake_image_suffix: ZBBQ_PropUtils.get_bake_image_suffix(p_default="Curvature")
    bake_enabled: ZBBQ_PropUtils.get_bake_enabled(p_default=False)

    bake_samples: ZBBQ_PropUtils.get_bake_samples(p_default=4)

    bake_disable_explode_in_renders: ZBBQ_PropUtils.bake_disable_explode_in_renders


class ZBBQ_BakeAOProps(bpy.types.PropertyGroup, BakeBaseProps):
    TITLE = "Ambient Occlusion"
    MAP_ID = 'CURVATURE'
    IMAGE_COLOR = (1.0, 1.0, 1.0, 0.0)

    bake_image_suffix: ZBBQ_PropUtils.get_bake_image_suffix(p_default="AO")
    bake_enabled: ZBBQ_PropUtils.get_bake_enabled(p_default=False)

    bake_samples: ZBBQ_PropUtils.get_bake_samples(p_default=64)

    bake_disable_explode_in_renders: ZBBQ_PropUtils.bake_disable_explode_in_renders


class ZBBQ_BakeConvexityProps(bpy.types.PropertyGroup, BakeBaseProps):
    TITLE = "Convexity"
    MAP_ID = 'CONVEXITY'
    IMAGE_COLOR = (0.0, 0.0, 0.0, 0.0)

    bake_image_suffix: ZBBQ_PropUtils.get_bake_image_suffix(p_default="Convexity")
    bake_enabled: ZBBQ_PropUtils.get_bake_enabled(p_default=False)

    bake_samples: ZBBQ_PropUtils.get_bake_samples(p_default=4)

    bake_disable_explode_in_renders: ZBBQ_PropUtils.bake_disable_explode_in_renders


class ZBBQ_BakeBevelsMaskProps(bpy.types.PropertyGroup, BakeBaseProps):
    TITLE = 'Bevels Mask'
    MAP_ID = 'BEVELS_MASK'
    IMAGE_COLOR = (0.0, 0.0, 0.0, 0.0)

    bake_image_suffix: ZBBQ_PropUtils.get_bake_image_suffix(p_default="BevelsMask")
    bake_enabled: ZBBQ_PropUtils.get_bake_enabled(p_default=False)

    bake_samples: ZBBQ_PropUtils.get_bake_samples(p_default=4)


class ZBBQ_BakeConcavityProps(bpy.types.PropertyGroup, BakeBaseProps):
    TITLE = "Concavity"
    MAP_ID = 'CONCAVITY'
    IMAGE_COLOR = (1.0, 1.0, 1.0, 0.0)

    bake_image_suffix: ZBBQ_PropUtils.get_bake_image_suffix(p_default="Concavity")
    bake_enabled: ZBBQ_PropUtils.get_bake_enabled(p_default=False)

    bake_samples: ZBBQ_PropUtils.get_bake_samples(p_default=4)

    bake_disable_explode_in_renders: ZBBQ_PropUtils.bake_disable_explode_in_renders


class ZBBQ_BakePartsIDProps(bpy.types.PropertyGroup, BakeBaseProps):
    TITLE = "Parts ID"
    MAP_ID = 'PARTS_ID'
    IMAGE_COLOR = (0.0, 0.0, 0.0, 0.0)

    bake_image_suffix: ZBBQ_PropUtils.get_bake_image_suffix(p_default="PartsID")
    bake_enabled: ZBBQ_PropUtils.get_bake_enabled(p_default=False)

    bake_samples: ZBBQ_PropUtils.get_bake_samples(p_default=1)


class ZBBQ_BakeMatIDProps(bpy.types.PropertyGroup, BakeBaseProps):
    TITLE = "Material ID"
    MAP_ID = 'MATERIAL_ID'
    IMAGE_COLOR = (0.0, 0.0, 0.0, 0.0)

    bake_image_suffix: ZBBQ_PropUtils.get_bake_image_suffix(p_default="MatID")
    bake_enabled: ZBBQ_PropUtils.get_bake_enabled(p_default=False)

    bake_samples: ZBBQ_PropUtils.get_bake_samples(p_default=1)


class ZBBQ_BakeObjectSpaceNormalProps(bpy.types.PropertyGroup, BakeBaseProps):
    TITLE = "Object Space Normal"
    MAP_ID = 'OS_NORMAL'
    IMAGE_COLOR = (0.5, 0.5, 0.5, 0.0)

    bake_image_suffix: ZBBQ_PropUtils.get_bake_image_suffix(p_default="ObjectSpaceNormal")
    bake_enabled: ZBBQ_PropUtils.get_bake_enabled(p_default=False)

    bake_samples: ZBBQ_PropUtils.get_bake_samples(p_default=1)


t_PREVIEW_MAP = {
    'NORMAL': ('NORMAL', ZBBQ_BakeNormalProps.TITLE, "Visualize tangent space normal data", 'IMAGE_RGB', 0),
    'AO': ('AO', ZBBQ_BakeAOProps.TITLE, "Visualize ambient occlusion data", 'LIGHT_DATA', 1),
    'CURVATURE': ('CURVATURE', ZBBQ_BakeCurvatureProps.TITLE, "Visualize curvature and edges", 'COLOR', 2),
    'CONVEXITY': ('CONVEXITY', ZBBQ_BakeConvexityProps.TITLE, "Visualize convex surface areas", 'VERTEXSEL', 3),
    'CONCAVITY': ('CONCAVITY', ZBBQ_BakeConcavityProps.TITLE, "Visualize concave surface areas", 'EDGESEL', 4),
    'BEVELS_MASK': ('BEVELS_MASK', ZBBQ_BakeBevelsMaskProps.TITLE, "Visualize bevel mask data", 'MOD_BEVEL', 5),
    'PARTS_ID': ('PARTS_ID', ZBBQ_BakePartsIDProps.TITLE, "Visualize object parts identification segments", 'GROUP_VERTEX', 6),
    'MATERIAL_ID': ('MATERIAL_ID', ZBBQ_BakeMatIDProps.TITLE, "Visualize material identification segments", 'MATERIAL', 7),
    'OS_NORMAL': ('OS_NORMAL', ZBBQ_BakeObjectSpaceNormalProps.TITLE, "Visualize object space normal data", 'WORLD', 8),
}


class ZBBQ_SceneProperties(bpy.types.PropertyGroup):
    def get_bake_folder_expand(self):
        s_path = self.bake_template_output_directory

        p_filepaths = bpy.context.preferences.filepaths

        if '%RENDER_OUTPUT%' in s_path:
            s_path = ZenStrUtils.ireplace(s_path, '%RENDER_OUTPUT%', p_filepaths.render_output_directory)
        elif '%TEXTURES%' in s_path:
            s_path = ZenStrUtils.ireplace(s_path, '%TEXTURES%', p_filepaths.texture_directory)
        elif '%BLENDER_TEMP%' in s_path:
            s_path = ZenStrUtils.ireplace(s_path, '%BLENDER_TEMP%', bpy.app.tempdir)

        s_path = bpy.path.abspath(s_path)
        if not s_path:
            s_path = bpy.app.tempdir

        return s_path

    def set_bake_folder_expand(self, value: str):

        value = value.strip()

        if value:
            p_filepaths = bpy.context.preferences.filepaths

            t_dirs = {
                bpy.path.abspath(p_filepaths.render_output_directory): '%RENDER_OUTPUT%',
                bpy.path.abspath(p_filepaths.texture_directory): '%TEXTURES%',
                bpy.path.abspath('//'): '//',
                bpy.app.tempdir: '%BLENDER_TEMP%'
            }

            for k, v in t_dirs.items():
                if k != '' and k in value:
                    value = ZenStrUtils.ireplace(value, k, v)

        if not value:
            value = '//'

        self.bake_template_output_directory = value

    bake_output_directory: bpy.props.StringProperty(
            name="Bake Output Directory",
            description="Directory where the baked images are saved to",
            get=get_bake_folder_expand,
            set=set_bake_folder_expand,
            options={'HIDDEN', 'SKIP_SAVE'},
            subtype='DIR_PATH'
    )

    bake_template_output_directory: bpy.props.StringProperty(
        name="Dir Name",
        description=r'''Target path for the output, available constants:
* // - current scene file directory (temporary directory if not saved),
* %RENDER_OUTPUT% - render output directory path,
* %TEXTURES% - texture directory path,
* %BLENDER_TEMP% - Blender temporary directory path''',
        default="//")

    def on_bake_image_update(self, context: bpy.types.Context):
        if self.bake_image_name.strip() == '':
            self.bake_image_name = self.bl_rna.properties['bake_image_name'].default

    def on_bake_batch_image_update(self, context: bpy.types.Context):
        if self.bake_batch_image_name.strip() == '':
            self.bake_batch_image_name = self.bl_rna.properties['bake_batch_image_name'].default

    bake_image_name: bpy.props.StringProperty(
        name="Image Name",
        description=ZBBQ_PropUtils.IMAGE_NAME_DESC,
        default=r'%OBJECT%_%SUFFIX%.png',
        update=on_bake_image_update)

    bake_batch_image_name: bpy.props.StringProperty(
        name="Merged Image Name",
        description=ZBBQ_PropUtils.IMAGE_NAME_DESC,
        default=r'%BLEND%_%SUFFIX%.png',
        update=on_bake_batch_image_update)

    bake_image_width: ZBBQ_PropUtils.bake_image_width

    bake_image_height: ZBBQ_PropUtils.bake_image_height

    bake_margin: ZBBQ_PropUtils.bake_margin

    bake_image_uniform_size: ZBBQ_PropUtils.bake_image_uniform_size

    bake_render_device: bpy.props.EnumProperty(
        name="Device",
        description="Device to use for rendering/baking",
        items=(
            ('GPU', "GPU Compute", "Use Graphics Processing Unit for rendering", 'NODE_COMPOSITING', 0),
            ('CPU', "CPU", "Use Central Processing Unit for rendering", 'MEMORY', 1),
        ),
        default='GPU'
    )

    bake_material_mode: bpy.props.EnumProperty(
        name="Bake Material Mode",
        description="Choose whether to bake one specific material or all materials slots of the object",
        items=(
            ("ACTIVE", "Active Material", "Bake only the currently active material slot"),
            ("ALL", "All Materials", "Bake all material slots assigned to the object"),
        ),
        default="ALL"
    )

    bake_objects_mode: bpy.props.EnumProperty(
        name="Bake Objects Mode",
        description="Choose which objects will be included in the baking process",
        items=[
            ('SELECTED', 'Selected', "Bake only the currently selected objects"),
            ('COLLECTION', 'Collection', "Bake all visible objects within the active collection"),
        ],
        default='SELECTED'
    )

    def get_init_bake_objects(self, context: bpy.types.Context):
        p_objects = []

        p_selectable = set(context.selectable_objects)

        from .eventHandling import sm
        if sm and sm.In("BakeInit"):
            if self.bake_objects_pin:
                if self.bake_pinned_collection:
                    p_objects = self.bake_pinned_collection.objects
                else:
                    raise RuntimeError("Bake pinned collection is not filled! Update pinned objects!")
            else:
                if self.bake_objects_mode == 'SELECTED':
                    p_objects = context.selected_objects
                else:
                    if context.collection:
                        p_objects = context.collection.objects
                    else:
                        raise RuntimeError("No active collection!")
        else:
            p_objects = self.bake_pinned_collection.objects

        return [obj for obj in p_objects if obj.type == 'MESH' and obj in p_selectable]

    def save_bake_pinned_objects(self, context: bpy.types.Context):
        from .bake_model.bake_ui import ScxmlBakeItem

        p_collection = bpy.data.collections.get(ZBBQ_Consts.bake_pinned_collection_name, None)
        if p_collection is None:
            p_collection = bpy.data.collections.new(ZBBQ_Consts.bake_pinned_collection_name)

        for obj in p_collection.objects[:]:
            p_collection.objects.unlink(obj)

        if self.bake_objects_mode == 'SELECTED':
            p_objects = context.selected_objects
        else:
            p_objects = []
            if context.collection:
                p_objects = context.collection.objects

        p_selectable = set(context.selectable_objects)

        for obj in p_objects:
            if obj.type == 'MESH' and obj in p_selectable:
                p_collection.objects.link(obj)

                p_bake_data: ScxmlBakeItem = obj.zbbq_bake_data
                for attr in p_bake_data.__annotations__:
                    if p_bake_data.is_property_set(attr):
                        p_bake_data.property_unset(attr)

        self.bake_pinned_collection = p_collection

    def on_bake_objects_pin(self, context: bpy.types.Context):
        if self.bake_objects_pin:
            self.save_bake_pinned_objects(context)

    bake_objects_pin: bpy.props.BoolProperty(
        name="Pin Objects",
        description='''Pin the current selection or collection
to prevent it from changing when you select other objects''',
        default=False,
        update=on_bake_objects_pin
    )

    bake_pinned_collection: bpy.props.PointerProperty(
        name="Pinned Collection",
        description="Pinned collection to be used for the baking process",
        type=bpy.types.Collection
    )

    bake_objects_index: bpy.props.IntProperty(min=-1, default=-1)

    def get_object_index_ui(self):
        return self.bake_objects_index

    bake_objects_index_ui: bpy.props.IntProperty(
        name="Bake Objects Index",
        description="Current bake object index",
        min=-1,
        get=get_object_index_ui
    )

    preview_mode: ZBBQ_PropUtils.get_shader_preview_mode()

    def get_bake_process_state(self):
        from .eventHandling import sm
        if sm:
            if not sm.isFinished():
                if sm.In("BakeInit"):
                    return 1

                if sm.In("Baking"):
                    return 2

                if sm.In("BakeAllDone"):
                    return 3

        return 3

    bake_process_state: bpy.props.EnumProperty(
        name="Bake Process State",
        description="Current operational mode of the baking system",
        items=[
            (
                'ERROR', 'Global Error',
                "A critical render error occurred. Blender restart is required to recover", "NONE", 0),

            (
                'MONITOR', 'Object Monitor',
                "Active mode tracking selected objects or the active collection in the scene", "NONE", 1),
            (
                'BAKING', 'Baking',
                "Baking active queue sequentially. Selection is locked and scene updates are ignored", "NONE", 2),

            (
                'REVIEW', 'Bake Review',
                "Baking process completed. Displaying the summary log and final results", 3),

        ],
        get=get_bake_process_state
    )

    # Указатели на настройки каналов данных с сохранением префикса bake_
    bake_ao: bpy.props.PointerProperty(type=ZBBQ_BakeAOProps)
    bake_curvature: bpy.props.PointerProperty(type=ZBBQ_BakeCurvatureProps)
    bake_convexity: bpy.props.PointerProperty(type=ZBBQ_BakeConvexityProps)
    bake_concavity: bpy.props.PointerProperty(type=ZBBQ_BakeConcavityProps)
    bake_bevels_mask: bpy.props.PointerProperty(type=ZBBQ_BakeBevelsMaskProps)
    bake_parts_id: bpy.props.PointerProperty(type=ZBBQ_BakePartsIDProps)
    bake_material_id: bpy.props.PointerProperty(type=ZBBQ_BakeMatIDProps)
    bake_os_normal: bpy.props.PointerProperty(type=ZBBQ_BakeObjectSpaceNormalProps)
    bake_normal: bpy.props.PointerProperty(type=ZBBQ_BakeNormalProps)

    bake_image_interpolation_internal: bpy.props.EnumProperty(
        name="Texture Interpolation (internal)",
        items=(
            ("Linear", "Linear", ""),
            ("Closest", "Closest", ""),
        ),
        default="Linear",
        update=lambda self, context: context.view_layer.update()
    )

    def get_bake_image_interpolation(self):
        return self.bake_image_interpolation_internal == 'Linear'

    def set_bake_image_interpolation(self, value):
        self.bake_image_interpolation_internal = 'Linear' if value is True else 'Closest'

    bake_image_interpolation: bpy.props.BoolProperty(
        name="Texture Interpolation",
        description='''Method to scale images up or down for rendering
* enabled - Linear (Regular quality interpolation)
* disabled - Closest (No interpolation, use only closest pixel for rendering pixel art)''',
        get=get_bake_image_interpolation,
        set=set_bake_image_interpolation,
        options=set()
    )

    def on_preview_map_update(self, context: bpy.types.Context):
        if not self.is_baking_active:
            if self.preview_mode == 'IMAGE':
                ZBBQ_CommonFunc.SetImagePreviewMode(context, reset=False)

    preview_map: bpy.props.EnumProperty(
        name="Preview Map",
        description="Select which map to visualize on the mesh",
        items=tuple(t_PREVIEW_MAP.values()),
        default='NORMAL',
        update=on_preview_map_update
    )

    def get_preview_map_index(self):
        p_enum_item = t_PREVIEW_MAP.get(self.preview_map, None)
        if p_enum_item is not None:
            return p_enum_item[4]
        return 0

    preview_map_index: bpy.props.IntProperty(
        name="Prevew Map Index",
        description="Select which map to visualize on the mesh",
        get=get_preview_map_index
    )

    normal_map_convention: bpy.props.EnumProperty(
        name="Normal Map Convention",
        description="Choose the normal map convention",
        items=[
            ('OPENGL', "OpenGL", "Normal map uses OpenGL convention, with Y axis in the green channel pointing up"),
            ('DIRECTX', "DirectX", "Normal map uses DirectX convention, with Y axis in the green channel pointing down"),
        ],
        default='OPENGL'
    )

    def get_is_direct_x(self):
        return self.normal_map_convention == 'DIRECTX'

    is_direct_x: bpy.props.BoolProperty(
        name="Is DirectX",
        description="Toggle for normal map format (DirectX / OpenGL)",
        get=get_is_direct_x
    )

    def get_is_baking_active(self):
        from .eventHandling import sm
        if sm and sm.In("Baking"):
            return True
        return False

    is_baking_active: bpy.props.BoolProperty(
        name="Is Baking Active",
        description="Toggle for baking status",
        get=get_is_baking_active
    )

    ao_distance: bpy.props.FloatProperty(
        name="AO Distance",
        description="The maximum distance for ray tracing the custom Ambient Occlusion (controls the width of the shadows in crevices)",
        default=0.4,
        min=0.0,
        step=0.1,
        subtype='DISTANCE'
    )

    cavity_distance: bpy.props.FloatProperty(
        name="Cavity Distance",
        description="The maximum distance for ray tracing the custom Cavity (controls the width of the cavity)",
        default=0.05,
        min=0.0,
        step=0.1,
        subtype='DISTANCE'
    )

    bevel_node_samples: bpy.props.IntProperty(
            name="Bevel Node Samples",
            description="Samples passed to the bevel node",
            default=16,
            min=2,
    )

    # NOTE: If False, prevents baking artifacts on triangulated faces.
    use_bbq_engine: bpy.props.BoolProperty(
        name="Use BBQ Engine",
        description="If False, uses Blender's native Normal baking algorithm. If True, uses Zen BBQ's custom Emit-based baking Normal",
        default=False
    )

    ao_node_samples_viewport: ZBBQ_PropUtils.ao_node_samples

    bevel_node_samples_viewport: ZBBQ_PropUtils.bevel_node_samples

    ao_node_samples_render: ZBBQ_PropUtils.ao_node_samples

    bevel_node_samples_render: ZBBQ_PropUtils.bevel_node_samples

    def get_bevel_node_samples(self):
        return self.bevel_node_samples_render if self.is_baking_active else self.bevel_node_samples_viewport

    def get_ao_node_samples(self):
        return self.ao_node_samples_render if self.is_baking_active else self.ao_node_samples_viewport

    bevel_node_samples: bpy.props.IntProperty(
        name=ZBBQ_PropUtils.bevel_node_samples.keywords["name"],
        description=ZBBQ_PropUtils.bevel_node_samples.keywords["description"],
        get=get_bevel_node_samples
    )

    ao_node_samples: bpy.props.IntProperty(
        name=ZBBQ_PropUtils.ao_node_samples.keywords["name"],
        description=ZBBQ_PropUtils.ao_node_samples.keywords["description"],
        get=get_ao_node_samples
    )

    bake_batch: bpy.props.BoolProperty(
        name="Merged",
        description='''If enabled, all objects are baked together in a single texture.
Otherwise, each object is baked individually''',
        default=False
    )

    def get_active_bake_map(self):
        return getattr(self, f"bake_{self.preview_map.lower()}")

    def get_bake_maps(self):
        return {k.lower(): getattr(self, f"bake_{k.lower()}") for k in t_PREVIEW_MAP.keys()}

    def get_actve_bake_maps(self):
        return {k: v for k, v in self.get_bake_maps().items() if v.bake_enabled}

    def draw_bake_map_types(self, layout: bpy.types.UILayout, context: bpy.types.Context):
        bake_map: BakeBaseProps
        for bake_map in self.get_bake_maps().values():
            bake_map.draw(layout, context)


classes = (
    ZBBQ_BakeNormalProps,
    ZBBQ_BakeCurvatureProps,
    ZBBQ_BakeAOProps,
    ZBBQ_BakeConvexityProps,
    ZBBQ_BakeBevelsMaskProps,
    ZBBQ_BakeConcavityProps,
    ZBBQ_BakePartsIDProps,
    ZBBQ_BakeMatIDProps,
    ZBBQ_BakeObjectSpaceNormalProps,

    ZBBQ_SceneProperties
)


def register():

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.NodeTree.zen_bbq_version = bpy.props.StringProperty(name="Version", default="")

    bpy.types.Scene.zen_bbq = bpy.props.PointerProperty(type=ZBBQ_SceneProperties)

    # Zen BBQ Overlay On/Off

    bpy.types.Scene.ZBBQ_ZenBBQOverlayShow = bpy.props.BoolProperty(
            name="Zen BBQ Overlay Display On/Off",
            description="Stored value for Zen BBQ Overlay Display On/Off",
            default=False)

    # Overlay On/Off

    bpy.types.Scene.ZBBQ_OverlayShow = bpy.props.BoolProperty(
            name="Blender Overlay Display On/Off",
            description="Stored user's value for Blender Overlay Display On/Off",
            default=False)

    # Overlay Config

    bpy.types.Scene.ZBBQ_OverlayConfigIsStored = bpy.props.BoolProperty(
            name="Is user's Overlay Config stored?",
            description="Is user's Overlay Config stored?",
            default=False)

    bpy.types.Scene.ZBBQ_OverlayConfigCreases = bpy.props.BoolProperty(
            name="Overlay Config Creases",
            description="Stored user's value for overlay creases edges",
            default=False)

    bpy.types.Scene.ZBBQ_OverlayConfigSharp = bpy.props.BoolProperty(
            name="Overlay Config Sharp",
            description="Stored user's value for overlay sharp edges",
            default=False)

    bpy.types.Scene.ZBBQ_OverlayConfigBevel = bpy.props.BoolProperty(
            name="Overlay Config Bevel",
            description="Stored user's value for overlay bevel edges",
            default=False)

    bpy.types.Scene.ZBBQ_OverlayConfigSeams = bpy.props.BoolProperty(
            name="Overlay Config Seams",
            description="Stored user's value for overlay seam edges",
            default=False)

    # In-scene saved presets

    bpy.types.Scene.ZBBQ_PresetsIncluded = bpy.props.PointerProperty(type=ZBBQ_Pref_BevelPresetGroup)

    # Object units display

    bpy.types.Object.ZenBBQ_LiveBooleanRadius = ZBBQ_PropUtils.ZenBBQ_LiveBooleanRadius

    bpy.types.Object.ZBBQ_IntactBevelDisplayUnits = ZBBQ_PropUtils.ZBBQ_IntactBevelDisplayUnits

    bpy.types.Object.ZBBQ_IntactBevelDisplayRadius = ZBBQ_PropUtils.ZBBQ_IntactBevelDisplayRadius

    def get_units_mult(self):
        p_units = ZBBQ_Units.get(self.ZBBQ_IntactBevelDisplayUnits, None)
        if p_units is not None:
            p_val = p_units.unitAndSceneScaleMultiplier()
            if p_val:
                return p_val
        return 0

    bpy.types.Object.ZBBQ_NodeUnitsMult = bpy.props.FloatProperty(
        name='Units Multiplier',
        description='Service value. Used for Units Multiplier translation in to Geometry Nodes',
        default=0.0,
        get=get_units_mult,
    )


def unregister():

    del bpy.types.Scene.zen_bbq

    del bpy.types.Scene.ZBBQ_ZenBBQOverlayShow
    del bpy.types.Scene.ZBBQ_OverlayShow
    del bpy.types.Scene.ZBBQ_OverlayConfigIsStored
    del bpy.types.Scene.ZBBQ_OverlayConfigCreases
    del bpy.types.Scene.ZBBQ_OverlayConfigSharp
    del bpy.types.Scene.ZBBQ_OverlayConfigBevel
    del bpy.types.Scene.ZBBQ_OverlayConfigSeams
    del bpy.types.Scene.ZBBQ_PresetsIncluded

    del bpy.types.Object.ZBBQ_IntactBevelDisplayUnits
    del bpy.types.Object.ZBBQ_IntactBevelDisplayRadius
    del bpy.types.Object.ZenBBQ_LiveBooleanRadius
    del bpy.types.Object.ZBBQ_NodeUnitsMult

    del bpy.types.NodeTree.zen_bbq_version

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
