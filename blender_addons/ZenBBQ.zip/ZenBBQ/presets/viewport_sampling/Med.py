import bpy
cycles = bpy.context.scene.cycles

zen_bbq = bpy.context.scene.zen_bbq

cycles.use_preview_adaptive_sampling = True
cycles.preview_adaptive_threshold = 0.1
cycles.preview_samples = 8
cycles.preview_adaptive_min_samples = 1

cycles.use_preview_denoising = True
cycles.preview_denoiser = 'AUTO'
cycles.preview_denoising_input_passes = 'RGB_ALBEDO'
cycles.preview_denoising_prefilter = 'FAST'
cycles.preview_denoising_start_sample = 8

zen_bbq.ao_node_samples_viewport = 16
zen_bbq.bevel_node_samples_viewport = 8
