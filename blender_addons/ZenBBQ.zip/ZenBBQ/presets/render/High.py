import bpy
cycles = bpy.context.scene.cycles

zen_bbq = bpy.context.scene.zen_bbq

cycles.use_adaptive_sampling = True
cycles.samples = 128
cycles.adaptive_threshold = 0.01
cycles.adaptive_min_samples = 0
cycles.time_limit = 0.0

zen_bbq.ao_node_samples_render = 128
zen_bbq.bevel_node_samples_render = 64
