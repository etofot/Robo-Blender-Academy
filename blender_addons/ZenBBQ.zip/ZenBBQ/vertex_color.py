# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# ##### END GPL LICENSE BLOCK #####

# Copyright 2025, Valeriy Yatsenko - lightbio@gmail.com

import bpy
import bmesh
from mathutils import Vector, Color

from .consts import ZBBQ_Consts
from .labels import ZBBQ_Labels
from .units import (
    ZBBQ_Units,
    ZBBQ_UnitsForEnumPropertyUnitSystemForCurrentPresetGroup)
from .vlog import Log
from .blender_zen_utils import get_unique_mesh_objects, ZenPolls


class DriverUtils:
    @classmethod
    def get_identifier(cls, modifier, input_name):
        items = modifier.node_group.interface.items_tree
        for i in items:
            if i.name == input_name:
                return i.identifier
        return None

    @classmethod
    def set_driver_to_mod_prop_from_object(cls, obj, mod, prop_name, data_path):
        identifier = cls.get_identifier(mod, prop_name)

        if identifier is None:
            print(f"Input '{prop_name}' not found in node group.")
            return

        if ZenPolls.version_since_5_2_0:
            inputs_container = mod.properties.inputs

            socket_object = getattr(inputs_container, identifier, None)

            if socket_object is not None:
                p_driver = socket_object.driver_add("value")
            else:
                Log.debug(f"Socket {identifier} not found in mod.properties.inputs")
        else:
            p_driver = mod.driver_add(f'["{identifier}"]')

        driver = p_driver.driver
        driver.type = 'SCRIPTED'

        var = driver.variables.new()
        var.name = 'var'
        var.type = 'SINGLE_PROP'
        target = var.targets[0]
        target.id_type = 'OBJECT'
        target.id = obj
        target.data_path = data_path

        driver.expression = "var"

    @classmethod
    def set_driver_to_mod_prop_from_scene(cls, scene, mod, prop_name, data_path):
        identifier = cls.get_identifier(mod, prop_name)

        if identifier is None:
            print(f"Input '{prop_name}' not found in node group.")
            return

        if ZenPolls.version_since_5_2_0:
            inputs_container = mod.properties.inputs

            socket_object = getattr(inputs_container, identifier, None)

            if socket_object is not None:
                p_driver = socket_object.driver_add("value")
            else:
                Log.debug(f"Socket {identifier} not found in mod.properties.inputs")
        else:
            p_driver = mod.driver_add(f'["{identifier}"]')

        driver = p_driver.driver
        driver.type = 'SCRIPTED'

        var = driver.variables.new()
        var.name = 'var'
        var.type = 'SINGLE_PROP'
        target = var.targets[0]
        target.id_type = 'SCENE'
        target.id = scene
        target.data_path = data_path

        driver.expression = "var"


def get_max_bevel_scene_value(context):
    update_scene_data()
    value = context.scene.ZBBQ_PresetsIncluded.max_bevel_value
    if value == 0.0:
        return False

    return value


def update_scene_data():
    if bpy.ops.wm.zen_bbq_update_data.poll():
        bpy.ops.wm.zen_bbq_update_data('INVOKE_DEFAULT')


def get_max_bevel_value(context, obj, bevel_layer, bm, use_global_bevel_value: bool):
    if use_global_bevel_value:
        value = get_max_bevel_scene_value(context)
    else:
        if obj.mode == 'EDIT':
            bevel_values = [v[bevel_layer] for v in bm.verts]
            value = max(bevel_values)
        else:
            bevel_values = [i.value for i in bevel_layer.data]
            value = max(bevel_values)

        if value == 0.0:
            return False
    return value


class ZBBQ_OT_CreateNodeBevelToVc(bpy.types.Operator):
    bl_idname = "object.zen_bbq_add_node_bevel_to_vc"
    bl_label = "Node VC Mask"
    bl_description = "Create geometry node modifier and assign it to selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        return active_object is not None and active_object.type == 'MESH'

    def execute(self, context):
        if not ZenPolls.version_since_4_0_0:
            self.report({'ERROR'}, 'Requires Blender v4.0.0 or higher')
            return {'CANCELLED'}

        objs = []
        p_objs = set(context.objects_in_mode) | set(context.selected_objects)
        p_objs = get_unique_mesh_objects(p_objs)
        for obj in p_objs:
            color_layer = obj.data.attributes.get(ZBBQ_Consts.VertexColorMaskNameNodes)

            if not color_layer:
                color_layer = obj.data.attributes.new(name=ZBBQ_Consts.VertexColorMaskNameNodes, type='FLOAT_COLOR', domain='CORNER')

            objs.append(obj)

        if not objs:
            self.report({'WARNING'}, "There are no selected objects")
            return {'CANCELLED'}

        max_value = get_max_bevel_scene_value(context)

        if max_value is False:
            self.report({'ERROR'}, 'Global Bevel Value is Zero. Scene data needs to be updated. Operator cancelled')
            return {'CANCELLED'}

        if ZenPolls.version_since_4_5_0:
            from .geometry_nodes.nodes_4_5 import ensure_zenbbq_bevelstovertexcolor_node_group_blen_4_5
            node_group = ensure_zenbbq_bevelstovertexcolor_node_group_blen_4_5()
        else:
            if ZenPolls.version_since_4_0_0:
                from .geometry_nodes.nodes_4_0 import ensure_zenbbq_bevelstovertexcolor_node_group_blen_4_0
                node_group = ensure_zenbbq_bevelstovertexcolor_node_group_blen_4_0()

        for obj in objs:
            mod = obj.modifiers.get("ZenBBQ_BevelsToVertexColor")
            if mod:
                obj.modifiers.remove(mod)

            mod = obj.modifiers.new(name="ZenBBQ_BevelsToVertexColor", type='NODES')
            mod.node_group = node_group

            DriverUtils.set_driver_to_mod_prop_from_object(obj, mod, prop_name="Default Radius", data_path='ZBBQ_IntactBevelDisplayRadius')
            DriverUtils.set_driver_to_mod_prop_from_object(obj, mod, prop_name="Units Mult", data_path='ZBBQ_NodeUnitsMult')
            DriverUtils.set_driver_to_mod_prop_from_scene(context.scene, mod, prop_name="Max Global Value", data_path='ZBBQ_PresetsIncluded.max_bevel_value')

        return {"FINISHED"}


class ZBBQ_OT_CreateVertexColorMask(bpy.types.Operator):
    bl_idname = "object.zen_bbq_create_vc_mask"
    bl_label = "Create VC Mask"
    bl_description = "Create vertex color attributes using bevel values"
    bl_options = {'REGISTER', 'UNDO'}

    use_global_bevel_value: bpy.props.BoolProperty(
        name='Use Global Bevel Value',
        description='Use the maximum global value of the bevel',
        default=True
    )

    use_active_vc_layer: bpy.props.BoolProperty(
        name='Use Active VC Layer',
        description='Use active vertex color layer instead of creating a new one',
        default=False
    )

    color_channel: bpy.props.EnumProperty(
        name="Color Channel",
        description="Choose which color channel to use",
        items=[
            ('R', "Red", "Red channel"),
            ('G', "Green", "Green channel"),
            ('B', "Blue", "Blue channel"),
            ('A', "Alpha", "Alpha channel"),
            ('RGB', "Red, Green, Blue", "Red, Green, Blue channels"),
            ('RGBA', "Red, Green, Blue, Alpha", "Red, Green, Blue Alpha channels"),
        ],
        default='R'
    )

    add_to_existing_vc: bpy.props.BoolProperty(
        name="Add to Existing",
        description="Add generated color to the existing vertex color instead of replacing it",
        default=False
    )

    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        return active_object is not None and active_object.type == 'MESH'

    def execute(self, context):
        objs = []

        p_objs = set(context.objects_in_mode) | set(context.selected_objects)
        p_objs = get_unique_mesh_objects(p_objs)
        self.is_new_color_layer = False
        for obj in p_objs:
            bevel_layer = obj.data.attributes.get(ZBBQ_Consts.customDataLayerRadiusName)
            if not bevel_layer:
                continue
            if self.use_active_vc_layer:
                color_layer = obj.data.color_attributes.active_color
                if not color_layer:
                    color_layer = obj.data.attributes.new(name=ZBBQ_Consts.VertexColorMaskName, type='FLOAT_COLOR', domain='CORNER')
                    self.is_new_color_layer = True
                user_layer_data_type, user_layer_domain = color_layer.data_type, color_layer.domain
                if user_layer_data_type not in {'BYTE_COLOR', 'FLOAT_COLOR'} or user_layer_domain not in {'CORNER', 'POINT'}:
                    color_layer = None
            else:
                user_layer_data_type, user_layer_domain = 'FLOAT_COLOR', 'CORNER'
                color_layer = obj.data.attributes.get(ZBBQ_Consts.VertexColorMaskName)

            if not color_layer:
                color_layer = obj.data.attributes.new(name=ZBBQ_Consts.VertexColorMaskName, type='FLOAT_COLOR', domain='CORNER')
                self.is_new_color_layer = True

            obj.data.color_attributes.active_color = color_layer

            objs.append(obj)

        if not objs:
            self.report({'ERROR'}, 'There is no selected objects with bevels')
            return {'CANCELLED'}

        def remap(x, a1, a2, b1, b2):
            if a1 == a2:
                return 0
            return b1 + (x - a1) * (b2 - b1) / (a2 - a1)

        Log.debug('BevelToVC', f'Mode -> {context.mode}, Data type > {user_layer_data_type}, Domain > {user_layer_domain}')

        errors_count = 0

        for obj in objs:
            if obj.mode == 'EDIT':
                units_mult = self.get_default_units_mult(obj)
                bm = bmesh.from_edit_mesh(obj.data)
                bm.verts.ensure_lookup_table()

                bevel_layer = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerRadiusName)
                color_layer = self.search_color_layer_edit_mode(user_layer_data_type, user_layer_domain, bm)
                is_user_defined_layer = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerUserDefinedName)

                if not color_layer:
                    color_layer = bm.loops.layers.float_color.get(ZBBQ_Consts.VertexColorMaskName)

                # s_range_1 = min(bevel_values)
                s_range_1 = 0.0

                s_range_2 = get_max_bevel_value(context, obj, bevel_layer, bm, self.use_global_bevel_value)

                if self.use_global_bevel_value:
                    if s_range_2 is False:
                        self.report({'ERROR'}, 'Global Bevel Value is Zero. Scene data needs to be updated. Operator cancelled')
                        return {'FINISHED'}
                else:
                    if s_range_2 is False:
                        errors_count += 1
                        print(f'Object {obj.name} has no bevel values')

                if user_layer_domain == 'CORNER':
                    for face in bm.faces:
                        for loop in face.loops:
                            is_user_defined = loop.vert[is_user_defined_layer] == 1.0
                            bevel_value = loop.vert[bevel_layer] if is_user_defined else obj.ZBBQ_IntactBevelDisplayRadius * units_mult

                            remapped_color_value = remap(bevel_value, s_range_1, s_range_2, 0.0, 1.0)

                            current_color_value = self.fill_vc_channels(remapped_color_value, [0, 0, 0, 1])
                            v_color = Vector(loop[color_layer]) + Vector(current_color_value) if self.is_add_to_existing_allowed() else current_color_value
                            loop[color_layer] = self.srgb_to_linear(v_color) if user_layer_data_type == 'FLOAT_COLOR' else v_color

                elif user_layer_domain == 'POINT':
                    for vert in bm.verts:
                        is_user_defined = vert[is_user_defined_layer] == 1.0
                        bevel_value = vert[bevel_layer] if is_user_defined else obj.ZBBQ_IntactBevelDisplayRadius * units_mult

                        remapped_color_value = remap(bevel_value, s_range_1, s_range_2, 0.0, 1.0)

                        current_color_value = self.fill_vc_channels(remapped_color_value, [0, 0, 0, 1])
                        v_color = Vector(vert[color_layer]) + Vector(current_color_value) if self.is_add_to_existing_allowed() else current_color_value

                        vert[color_layer] = self.srgb_to_linear(v_color) if user_layer_data_type == 'FLOAT_COLOR' else v_color
                else:
                    raise RuntimeError('user_layer_domain incorrect')

                bmesh.update_edit_mesh(obj.data)

            elif obj.mode == 'OBJECT':
                units_mult = self.get_default_units_mult(obj)
                mesh = obj.data
                bevel_layer = obj.data.attributes.get(ZBBQ_Consts.customDataLayerRadiusName)
                is_user_defined_layer = obj.data.attributes.get(ZBBQ_Consts.customDataLayerUserDefinedName)

                if self.use_active_vc_layer:
                    color_layer = obj.data.color_attributes.active_color
                else:
                    color_layer = obj.data.attributes.get(ZBBQ_Consts.VertexColorMaskName)

                # s_range_1 = min(bevel_values)
                s_range_1 = 0.0
                # s_range_2 = max(bevel_values)
                s_range_2 = get_max_bevel_value(context, obj, bevel_layer, bm=None, use_global_bevel_value=self.use_global_bevel_value)

                if self.use_global_bevel_value:
                    if s_range_2 is False:
                        self.report({'ERROR'}, 'Global Bevel Value is Zero. Scene data needs to be updated. Operator cancelled')
                        return {'FINISHED'}
                else:
                    if s_range_2 is False:
                        errors_count += 1
                        print(f'Object {obj.name} has no bevel values.')

                if user_layer_domain == 'CORNER':
                    for poly in mesh.polygons:
                        for idx in poly.loop_indices:
                            loop = mesh.loops[idx]

                            vert_index = loop.vertex_index
                            is_user_defined = is_user_defined_layer.data[vert_index].value == 1.0
                            bevel_value = bevel_layer.data[vert_index].value if is_user_defined else obj.ZBBQ_IntactBevelDisplayRadius * units_mult

                            remapped_color_value = remap(bevel_value, s_range_1, s_range_2, 0.0, 1.0)
                            current_color_value = self.fill_vc_channels(remapped_color_value, [0, 0, 0, 1])
                            v_color = Vector(color_layer.data[idx].color) + Vector(current_color_value) if self.is_add_to_existing_allowed() else current_color_value

                            color_layer.data[idx].color = self.srgb_to_linear(v_color)

                elif user_layer_domain == 'POINT':
                    for vert in mesh.vertices:
                        idx = vert.index
                        is_user_defined = is_user_defined_layer.data[idx].value == 1.0
                        bevel_value = bevel_layer.data[idx].value if is_user_defined else obj.ZBBQ_IntactBevelDisplayRadius * units_mult

                        remapped_color_value = remap(bevel_value, s_range_1, s_range_2, 0.0, 1.0)
                        current_color_value = self.fill_vc_channels(remapped_color_value, [0, 0, 0, 1])
                        v_color = Vector(color_layer.data[idx].color) + Vector(current_color_value) if self.is_add_to_existing_allowed() else current_color_value
                        color_layer.data[idx].color = self.srgb_to_linear(v_color)
                else:
                    raise RuntimeError('user_layer_domain incorrect')

        if errors_count != 0:
            self.report({'WARNING'}, 'Some objects do not have bevel values. See the system log.')
            return {'FINISHED'}

        return {'FINISHED'}

    def is_add_to_existing_allowed(self):
        return self.add_to_existing_vc and not self.is_new_color_layer

    def get_default_units_mult(self, obj):
        p_units = ZBBQ_Units.get(obj.ZBBQ_IntactBevelDisplayUnits, None)
        if p_units is not None:
            p_val = p_units.unitAndSceneScaleMultiplier()
            if p_val:
                return p_val
        return 0.0

    def srgb_to_linear(self, v_color: list):
        col = Color(v_color[:3]).from_srgb_to_scene_linear()
        return col.r, col.g, col.b, v_color[3]

    def search_color_layer_edit_mode(self, user_layer_data_type, user_layer_domain, bm):
        if self.use_active_vc_layer:
            if user_layer_domain == 'CORNER':
                if user_layer_data_type == 'FLOAT_COLOR':
                    color_layer = bm.loops.layers.float_color.active
                elif user_layer_data_type == 'BYTE_COLOR':
                    color_layer = bm.loops.layers.color.active
                else:
                    color_layer = None
            elif user_layer_domain == 'POINT':
                if user_layer_data_type == 'FLOAT_COLOR':
                    color_layer = bm.verts.layers.float_color.active
                elif user_layer_data_type == 'BYTE_COLOR':
                    color_layer = bm.verts.layers.color.active
                else:
                    color_layer = None
            else:
                raise RuntimeError(f'user_layer_data_type or user_layer_domain incorrect {user_layer_data_type = }, {user_layer_domain = }')
        else:
            color_layer = bm.loops.layers.float_color.get(ZBBQ_Consts.VertexColorMaskName)

        return color_layer

    def fill_vc_channels(self, float_color_value: float, changed_color_value: list):

        channel = self.color_channel

        if channel in {'R', 'G', 'B', 'A'}:
            index = 'RGBA'.index(channel)
            changed_color_value[index] = float_color_value

        elif channel in {'RGB', 'RGBA'}:
            count = 3 if channel == 'RGB' else 4
            for i in range(count):
                changed_color_value[i] = float_color_value

        return changed_color_value


class ZBBQ_OT_ShowBevelByMaterial(bpy.types.Operator):
    bl_idname = "object.zen_bbq_show_bevel_by_material"
    bl_label = "Show Max Bevel by Material"
    bl_description = "Show the maximum bevel value for the active or all materials"
    bl_options = {'REGISTER', 'INTERNAL'}

    use_all_materials: bpy.props.BoolProperty(
        name="Use All Materials",
        description="Search for bevel values among all materials in the object",
        default=False
    )
    units: bpy.props.EnumProperty(
            name=ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Prop_Units_Name,
            description=ZBBQ_Labels.ZBBQ_OT_SetBevelRadiusToSelection_Prop_Units_Desc,
            items=lambda self, context: ZBBQ_UnitsForEnumPropertyUnitSystemForCurrentPresetGroup(),
    )

    result_text: bpy.props.StringProperty()

    @classmethod
    def poll(cls, context):
        active_object = context.active_object
        return (
            active_object is not None and
            active_object.type == 'MESH')

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "use_all_materials")
        layout.prop(self, "units")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        if obj is None or obj.type != 'MESH':
            self.report({'ERROR'}, "No active mesh object")
            return {'CANCELLED'}

        me: bpy.types.Mesh = obj.data

        p_bevel_layer = me.attributes.get(ZBBQ_Consts.customDataLayerRadiusName)

        if p_bevel_layer is None:
            self.report({'ERROR'}, f"No bevel data in object {obj.name}")
            return {'CANCELLED'}

        if me.is_editmode:
            bm = bmesh.from_edit_mesh(obj.data)

            if self.use_all_materials:
                p_faces = bm.faces[:]
                mat_name = "All Materials"
            else:
                active_mat_index = obj.active_material_index
                mat = obj.material_slots[active_mat_index].material if obj.material_slots else None
                if mat is None:
                    self.report({'ERROR'}, "No active material")
                    return {'CANCELLED'}

                mat_name = mat.name
                p_faces = [f for f in bm.faces if f.material_index == active_mat_index]

            verts = set()
            for face in p_faces:
                verts.update(face.verts)

            bevel_layer = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerRadiusName)
            bevels = [v[bevel_layer] for v in verts]
        else:
            verts = me.vertices
            bevels = []

            if self.use_all_materials:
                for i, v in enumerate(verts):
                    bevels.append(p_bevel_layer.data[i].value)
                mat_name = "All Materials"
            else:
                active_mat_index = obj.active_material_index
                mat_slot = obj.material_slots[active_mat_index] if obj.material_slots else None
                mat = mat_slot.material if mat_slot else None

                if mat is None:
                    self.report({'ERROR'}, "No active material")
                    return {'CANCELLED'}

                vert_indices = set()
                for poly in me.polygons:
                    if poly.material_index == active_mat_index:
                        vert_indices.update(poly.vertices)

                if not vert_indices:
                    self.result_text = f"{mat.name}: no faces"
                else:
                    bevels = [p_bevel_layer.data[i].value for i in vert_indices]
                mat_name = mat.name

        if not bevels:
            self.result_text = f"{mat_name}: no bevel data"
        else:
            p_mult = ZBBQ_Units[self.units].unitAndSceneScaleMultiplier()
            max_bevel = max(bevels) / p_mult
            min_bevel = min(bevels) / p_mult
            self.result_text = f"{mat_name}: min bevel = {min_bevel:.4f} max bevel = {max_bevel:.4f}"

        def draw_popup(menu_self, context):
            menu_self.layout.label(text=self.result_text)

        context.window_manager.popup_menu(draw_popup, title=f"Bevel Info. Units: {self.units}", icon='INFO')

        return {'FINISHED'}


class ZBBQ_OT_SystemGetVColor(bpy.types.Operator):
    bl_idname = "object.zen_bbq_system_get_vertex_color"
    bl_label = "Get Vertex Color"
    bl_description = "Show vertex color via Vertex Color"
    bl_options = {'REGISTER', 'UNDO'}

    color_str: bpy.props.StringProperty()

    def execute(self, context):
        self.report({'INFO'}, f"Vertex Color: {self.color_str}")
        return {'FINISHED'}

    def invoke(self, context, event):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "Need an object of Mesh type")
            return {'CANCELLED'}

        if context.mode != 'EDIT_MESH':
            self.report({'ERROR'}, "Go to Edit Mode")
            return {'CANCELLED'}

        bm = bmesh.from_edit_mesh(obj.data)
        bm.verts.ensure_lookup_table()

        bevel_layer = bm.verts.layers.float.get(ZBBQ_Consts.customDataLayerRadiusName)
        color_layer = bm.loops.layers.float_color.active
        if not color_layer:
            self.report({'ERROR'}, "No Vertex Color layer")
            return {'CANCELLED'}

        for vert in bm.verts:
            if vert.select:
                if vert.link_loops:
                    color = vert.link_loops[0][color_layer]
                    p_index = vert.index
                    p_bevel_value = vert[bevel_layer]
                    if len(color) == 4:
                        self.color_str = f"I:{p_index}, B:{p_bevel_value:.3f}, (C: {color[0]:.3f}, {color[1]:.3f}, {color[2]:.3f}, {color[3]:.3f})"
                    else:
                        self.color_str = f"I:{p_index}, B:{p_bevel_value:.3f}, (C: {color[0]:.3f}, {color[1]:.3f}, {color[2]:.3f})"

                    print(self.color_str)
                    return context.window_manager.invoke_popup(self, width=250)

        self.report({'WARNING'}, "No selected vertices with color")
        return {'CANCELLED'}

    def draw(self, context):
        layout = self.layout
        layout.label(text=self.color_str)


before_4_0_classes = (
    ZBBQ_OT_CreateVertexColorMask,
    ZBBQ_OT_ShowBevelByMaterial
)


classes = (
    ZBBQ_OT_CreateVertexColorMask,
    ZBBQ_OT_ShowBevelByMaterial,
    ZBBQ_OT_CreateNodeBevelToVc,

    # Debug
    # ZBBQ_OT_SystemGetVColor
)


def register():
    if ZenPolls.version_since_4_0_0:
        for cl in classes:
            bpy.utils.register_class(cl)
    else:
        for cl in before_4_0_classes:
            bpy.utils.register_class(cl)


def unregister():
    if ZenPolls.version_since_4_0_0:
        for cl in classes:
            bpy.utils.unregister_class(cl)
    else:
        for cl in before_4_0_classes:
            bpy.utils.unregister_class(cl)


if __name__ == "__main__":
    pass
