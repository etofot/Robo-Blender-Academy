import bpy
import bmesh
from mathutils import Vector
from bpy.types import Operator


def fill_pattern_3chain_to_5chain_trapezoid_connect(context):
    obj = context.active_object
    if not obj or obj.type != "MESH" or context.mode != "EDIT_MESH":
        raise RuntimeError("Active object must be a Mesh in Edit Mode.")

    me = obj.data

    # --------------------------------------------------
    # Quad Flow toggle (align along long-chain axis)
    # --------------------------------------------------
    do_quad_flow = bool(
        getattr(getattr(context.scene, "quad_connect_props", None), "quad_flow", False)
    )

    def bm_refresh():
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        return bm

    def clear_sel(bm):
        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        for f in bm.faces:
            f.select = False

    # --------- Robust "find vert by coordinate" ---------
    def find_vert_by_co(bm, co: Vector, tol=1e-6):
        best = None
        best_d2 = None
        for v in bm.verts:
            d2 = (v.co - co).length_squared
            if best_d2 is None or d2 < best_d2:
                best = v
                best_d2 = d2
        if best is None:
            return None
        if best_d2 <= tol * tol:
            return best
        return best  # nearest fallback

    def edge_between(v1, v2):
        for e in v1.link_edges:
            if e.other_vert(v1) == v2:
                return e
        return None

    def select_edges_by_co(bm, co_pairs):
        clear_sel(bm)
        for coa, cob in co_pairs:
            va = find_vert_by_co(bm, coa)
            vb = find_vert_by_co(bm, cob)
            if not va or not vb:
                raise RuntimeError("Missing required vert (coord match failed).")

            e = edge_between(va, vb)
            if not e:
                raise RuntimeError(f"Missing required edge (co-match): {coa} <-> {cob}")
            e.select = True

        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def select_verts_by_co(bm, co_list):
        clear_sel(bm)
        for co in co_list:
            v = find_vert_by_co(bm, co)
            if not v:
                raise RuntimeError("Missing required vert (coord match failed).")
            v.select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def selected_edges_as_pairs(bm):
        out = []
        for e in bm.edges:
            if e.select and e.is_valid:
                out.append((e.verts[0], e.verts[1]))
        return out

    def build_adj_from_edges(edge_pairs):
        adj = {}
        for a, b in edge_pairs:
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        return adj

    def components_from_verts(verts, adj):
        seen, comps = set(), []
        for v in verts:
            if v in seen:
                continue
            stack = [v]
            comp = set()
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur)
                comp.add(cur)
                for nb in adj.get(cur, ()):
                    if nb not in seen:
                        stack.append(nb)
            comps.append(comp)
        return comps

    def order_chain(chain_set, adj, expected_count):
        deg = {v: sum(1 for nb in adj.get(v, ()) if nb in chain_set) for v in chain_set}
        ends = [v for v, d in deg.items() if d == 1]
        if len(ends) != 2:
            raise RuntimeError("Each chain must be a simple path (2 ends).")

        def walk(start):
            out = [start]
            prev = None
            cur = start
            while len(out) < expected_count:
                nbs = [nb for nb in adj.get(cur, ()) if nb in chain_set and nb != prev]
                if not nbs:
                    break
                prev, cur = cur, nbs[0]
                out.append(cur)
            return out

        w = walk(ends[0])
        if len(w) != expected_count:
            w = walk(ends[1])
        if len(w) != expected_count:
            raise RuntimeError(f"Failed to order a {expected_count}-vertex chain.")
        return w

    # ---------- Detect pattern from selection ----------
    bm = bm_refresh()
    sel_edge_pairs = selected_edges_as_pairs(bm)
    if len(sel_edge_pairs) != 8:
        raise RuntimeError(
            f"Select exactly 8 edges (3-edge chain + 5-edge chain). Got {len(sel_edge_pairs)}."
        )

    # store original selection as CO pairs (for restoring later)
    orig_co_pairs = [(va.co.copy(), vb.co.copy()) for va, vb in sel_edge_pairs]

    adj = build_adj_from_edges(sel_edge_pairs)
    sel_verts = set(adj.keys())
    comps = components_from_verts(sel_verts, adj)

    comp4 = [c for c in comps if len(c) == 4]  # 3 edges
    comp6 = [c for c in comps if len(c) == 6]  # 5 edges
    if len(comp4) != 1 or len(comp6) != 1:
        raise RuntimeError("Selection must be: 1 chain (4 verts / 3 edges) + 1 chain (6 verts / 5 edges).")

    short_set = comp4[0]
    long_set = comp6[0]

    # order them
    S = order_chain(short_set, adj, expected_count=4)   # [s0,s1,s2,s3] (or reversed)
    L = order_chain(long_set, adj, expected_count=6)    # [l0,l1,l2,l3,l4,l5] (or reversed)

    # We want mapping:
    #   s0 <-> l1 (v5)
    #   s1 <-> l2 (v6)
    #   s2 <-> l3 (v7)
    #   s3 <-> l4 (v8)
    # and ends are l0 (v4) and l5 (v9)
    def score_mapping(Sseq, Lseq):
        return (
            (Sseq[0].co - Lseq[1].co).length +
            (Sseq[1].co - Lseq[2].co).length +
            (Sseq[2].co - Lseq[3].co).length +
            (Sseq[3].co - Lseq[4].co).length
        )

    candidates = []
    for Sseq in (S, list(reversed(S))):
        for Lseq in (L, list(reversed(L))):
            candidates.append((score_mapping(Sseq, Lseq), Sseq, Lseq))
    candidates.sort(key=lambda x: x[0])
    _, S, L = candidates[0]

    # Name them like your description:
    # short chain: v0-v1-v2-v3
    v0, v1, v2, v3 = S[0], S[1], S[2], S[3]
    # long chain: v4-v5-v6-v7-v8-v9
    v4, v5, v6, v7, v8, v9 = L[0], L[1], L[2], L[3], L[4], L[5]

    # Pin by coordinates (so we can refind after ops)
    co_v0 = v0.co.copy()
    co_v1 = v1.co.copy()
    co_v2 = v2.co.copy()
    co_v3 = v3.co.copy()

    co_v4 = v4.co.copy()
    co_v5 = v5.co.copy()
    co_v6 = v6.co.copy()
    co_v7 = v7.co.copy()
    co_v8 = v8.co.copy()
    co_v9 = v9.co.copy()

    # ---------- Bridge (cuts=1) to create v10,v11,v12,v13 ----------
    bm = bm_refresh()

    # edges to bridge: (v0-v1, v1-v2, v2-v3) and (v5-v6, v6-v7, v7-v8)
    select_edges_by_co(
        bm,
        [(co_v0, co_v1), (co_v1, co_v2), (co_v2, co_v3),
         (co_v5, co_v6), (co_v6, co_v7), (co_v7, co_v8)]
    )

    # expected midpoints where new verts should appear (for matching)
    bm = bm_refresh()
    V0 = find_vert_by_co(bm, co_v0)
    V1 = find_vert_by_co(bm, co_v1)
    V2 = find_vert_by_co(bm, co_v2)
    V3 = find_vert_by_co(bm, co_v3)
    V5 = find_vert_by_co(bm, co_v5)
    V6 = find_vert_by_co(bm, co_v6)
    V7 = find_vert_by_co(bm, co_v7)
    V8 = find_vert_by_co(bm, co_v8)
    if not all([V0, V1, V2, V3, V5, V6, V7, V8]):
        raise RuntimeError("Failed to refind required verts before bridge.")

    mid_05 = (V0.co + V5.co) * 0.5
    mid_16 = (V1.co + V6.co) * 0.5
    mid_27 = (V2.co + V7.co) * 0.5
    mid_38 = (V3.co + V8.co) * 0.5

    tol = 1e-6

    def qkey(co: Vector, t=tol):
        return (round(co.x / t), round(co.y / t), round(co.z / t))

    old_keys = {qkey(v.co.copy()) for v in bm.verts}

    bpy.ops.mesh.bridge_edge_loops(number_cuts=1, interpolation='LINEAR')

    bm = bm_refresh()
    new_verts = [v for v in bm.verts if qkey(v.co) not in old_keys]
    if len(new_verts) < 4:
        raise RuntimeError("Bridge didn't create the expected cut vertices (need at least 4).")

    v10 = min(new_verts, key=lambda v: (v.co - mid_05).length)  # between 0 and 5
    v11 = min(new_verts, key=lambda v: (v.co - mid_16).length)  # between 1 and 6
    v12 = min(new_verts, key=lambda v: (v.co - mid_27).length)  # between 2 and 7
    v13 = min(new_verts, key=lambda v: (v.co - mid_38).length)  # between 3 and 8

    # refind long-chain reference verts AFTER bridge
    bm = bm_refresh()
    V4 = find_vert_by_co(bm, co_v4)
    V5 = find_vert_by_co(bm, co_v5)
    V6 = find_vert_by_co(bm, co_v6)
    V7 = find_vert_by_co(bm, co_v7)
    V8 = find_vert_by_co(bm, co_v8)
    V9 = find_vert_by_co(bm, co_v9)
    if not all([V4, V5, V6, V7, V8, V9]):
        raise RuntimeError("Failed to refind long-chain reference verts after bridge.")

    def safe_norm(v: Vector, eps=1e-12):
        l2 = v.length_squared
        if l2 < eps:
            return None
        return v / (l2 ** 0.5)

    def align_along_axis(move_v, ref_v, axis_dir: Vector):
        ax = safe_norm(axis_dir)
        if ax is None:
            return
        delta = (ref_v.co - move_v.co).dot(ax)
        move_v.co += ax * delta

    if do_quad_flow:
        chain_axis = (V9.co - V4.co)  # axis along the 5-edge chain (v4->v9)
        align_along_axis(v10, V5, chain_axis)
        align_along_axis(v11, V6, chain_axis)
        align_along_axis(v12, V7, chain_axis)
        align_along_axis(v13, V8, chain_axis)

    bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    # Save new verts by coord for later steps
    co_v10 = v10.co.copy()
    co_v11 = v11.co.copy()
    co_v12 = v12.co.copy()
    co_v13 = v13.co.copy()

    # ---------- Create end faces ----------
    # Face A: v0 + v10 + v5 + v4
    bm = bm_refresh()
    select_verts_by_co(bm, [co_v0, co_v10, co_v5, co_v4])
    bpy.ops.mesh.edge_face_add()

    # Face B: v3 + v13 + v8 + v9
    bm = bm_refresh()
    select_verts_by_co(bm, [co_v3, co_v13, co_v8, co_v9])
    bpy.ops.mesh.edge_face_add()

    # ---------- Restore original edge selection ----------
    bm = bm_refresh()
    select_edges_by_co(bm, orig_co_pairs)
    bpy.ops.mesh.select_mode(type='EDGE')


class QC_OT_3_to_5_trapezoid_connect(Operator):
    bl_idname = "mesh.qc_3_to_5_trapezoid_connect"
    bl_label = "3 → 5 Trapezoid Connect"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        try:
            fill_pattern_3chain_to_5chain_trapezoid_connect(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    bpy.utils.register_class(QC_OT_3_to_5_trapezoid_connect)


def unregister():
    bpy.utils.unregister_class(QC_OT_3_to_5_trapezoid_connect)