#Left Convert to Right


import bpy
import bmesh
from mathutils import Vector
from bpy.types import Operator


def fill_pattern_2_to_3_direct_flow_right_connect(context):
    obj = context.active_object
    if not obj or obj.type != "MESH" or context.mode != "EDIT_MESH":
        raise RuntimeError("Active object must be a Mesh in Edit Mode.")

    me = obj.data

    qc = getattr(context.scene, "quad_connect_props", None)
    do_quad_flow = bool(getattr(qc, "quad_flow", False))
    if do_quad_flow and qc:
        qc.quad_flow = True  # ensure it's explicitly True if enabled

    def bm_refresh():
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        return bm

    def clear_sel(bm):
        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        for f in bm.faces:
            f.select = False

    def find_vert_by_co(bm, co: Vector):
        best = None
        best_d2 = None
        for v in bm.verts:
            d2 = (v.co - co).length_squared
            if best_d2 is None or d2 < best_d2:
                best = v
                best_d2 = d2
        return best

    def edge_between(v1, v2):
        for e in v1.link_edges:
            if e.other_vert(v1) == v2:
                return e
        return None

    def select_edges_by_co(bm, co_pairs):
        clear_sel(bm)
        for coa, cob in co_pairs:
            va = find_vert_by_co(bm, coa)
            vb = find_vert_by_co(bm, cob)
            if not va or not vb:
                raise RuntimeError("Missing required vert (coord match failed).")
            e = edge_between(va, vb)
            if not e:
                raise RuntimeError("Missing required edge.")
            e.select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def select_verts_by_co(bm, co_list):
        clear_sel(bm)
        for co in co_list:
            v = find_vert_by_co(bm, co)
            if not v:
                raise RuntimeError("Missing required vert (coord match failed).")
            v.select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def selected_edges_as_pairs(bm):
        out = []
        for e in bm.edges:
            if e.select and e.is_valid:
                out.append((e.verts[0], e.verts[1]))
        return out

    def build_adj_from_edges(edge_pairs):
        adj = {}
        for a, b in edge_pairs:
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        return adj

    def components_from_verts(verts, adj):
        seen, comps = set(), []
        for v in verts:
            if v in seen:
                continue
            stack = [v]
            comp = set()
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur)
                comp.add(cur)
                for nb in adj.get(cur, ()):
                    if nb not in seen:
                        stack.append(nb)
            comps.append(comp)
        return comps

    def order_chain(chain_set, adj, expected_count):
        deg = {v: sum(1 for nb in adj.get(v, ()) if nb in chain_set) for v in chain_set}
        ends = [v for v, d in deg.items() if d == 1]
        if len(ends) != 2:
            raise RuntimeError("Each chain must be a simple path (2 ends).")

        def walk(start):
            out = [start]
            prev = None
            cur = start
            while len(out) < expected_count:
                nbs = [nb for nb in adj.get(cur, ()) if nb in chain_set and nb != prev]
                if not nbs:
                    break
                prev, cur = cur, nbs[0]
                out.append(cur)
            return out

        w = walk(ends[0])
        if len(w) != expected_count:
            w = walk(ends[1])
        if len(w) != expected_count:
            raise RuntimeError(f"Failed to order a {expected_count}-vertex chain.")
        return w

    # --- robust "new verts" detection ---
    tol = 1e-6

    def qkey(co: Vector, t=tol):
        return (round(co.x / t), round(co.y / t), round(co.z / t))

    def snapshot(bm):
        bm.verts.ensure_lookup_table()
        return {
            "keys": {qkey(v.co.copy()) for v in bm.verts},
            "idx": {v.index for v in bm.verts},
        }

    def get_new_verts(bm, before):
        new_by_key = [v for v in bm.verts if qkey(v.co) not in before["keys"]]
        if len(new_by_key) >= 2:
            return new_by_key
        after_idx = {v.index for v in bm.verts}
        new_by_idx = sorted(list(after_idx - before["idx"]))
        if len(new_by_idx) >= 2:
            bm.verts.ensure_lookup_table()
            return [bm.verts[i] for i in new_by_idx]
        return []

    # ---------- Detect pattern from selection ----------
    bm = bm_refresh()
    sel_edge_pairs = selected_edges_as_pairs(bm)
    if len(sel_edge_pairs) != 5:
        raise RuntimeError(
            f"Select exactly 5 edges (2-edge chain + 3-edge chain). Got {len(sel_edge_pairs)}."
        )

    orig_co_pairs = [(va.co.copy(), vb.co.copy()) for va, vb in sel_edge_pairs]

    adj = build_adj_from_edges(sel_edge_pairs)
    sel_verts = set(adj.keys())
    comps = components_from_verts(sel_verts, adj)

    comp3 = [c for c in comps if len(c) == 3]  # 2 edges => 3 verts
    comp4 = [c for c in comps if len(c) == 4]  # 3 edges => 4 verts
    if len(comp3) != 1 or len(comp4) != 1:
        raise RuntimeError("Selection must be: 1 chain (3 verts) + 1 chain (4 verts).")

    S = order_chain(comp3[0], adj, expected_count=3)
    L = order_chain(comp4[0], adj, expected_count=4)

    # ✅ right connect: force non-inverted order by matching right-to-right:
    # v0~v3, v1~v4, v2~v5 (not centered matching)
    def right_score(Sseq, Lseq):
        return (
            (Sseq[0].co - Lseq[0].co).length +
            (Sseq[1].co - Lseq[1].co).length +
            (Sseq[2].co - Lseq[2].co).length
        )

    candidates = []
    for Sseq in (S, list(reversed(S))):
        for Lseq in (L, list(reversed(L))):
            candidates.append((right_score(Sseq, Lseq), Sseq, Lseq))
    candidates.sort(key=lambda x: x[0])
    _, S, L = candidates[0]

    # label verts as you described
    v0, v1, v2 = S
    v3, v4, v5, v6 = L

    co_v0, co_v1, co_v2 = v0.co.copy(), v1.co.copy(), v2.co.copy()
    co_v3, co_v4, co_v5, co_v6 = v3.co.copy(), v4.co.copy(), v5.co.copy(), v6.co.copy()

    # ---------------- Bridge (v0-v1) with (v3-v4) ----------------
    bm = bm_refresh()
    before1 = snapshot(bm)

    V0 = find_vert_by_co(bm, co_v0)
    V1 = find_vert_by_co(bm, co_v1)
    V3 = find_vert_by_co(bm, co_v3)
    V4 = find_vert_by_co(bm, co_v4)

    mid_03 = (V0.co + V3.co) * 0.5
    mid_14 = (V1.co + V4.co) * 0.5

    select_edges_by_co(bm, [(co_v0, co_v1), (co_v3, co_v4)])
    bpy.ops.mesh.bridge_edge_loops(number_cuts=1, interpolation='LINEAR')

    bm = bm_refresh()
    new_1 = get_new_verts(bm, before1)
    if len(new_1) < 2:
        raise RuntimeError("Bridge: could not detect 2 new verts.")

    v7 = min(new_1, key=lambda v: (v.co - mid_03).length)
    v8 = min(new_1, key=lambda v: (v.co - mid_14).length)

    # ---- quad flow alignment ----
    bm = bm_refresh()
    V3 = find_vert_by_co(bm, co_v3)
    V6 = find_vert_by_co(bm, co_v6)
    V4 = find_vert_by_co(bm, co_v4)

    def safe_norm(v: Vector, eps=1e-12):
        l2 = v.length_squared
        if l2 < eps:
            return None
        return v / (l2 ** 0.5)

    def align_along_axis(move_v, ref_v, axis_dir: Vector):
        ax = safe_norm(axis_dir)
        if ax is None:
            return
        delta = (ref_v.co - move_v.co).dot(ax)
        move_v.co += ax * delta

    if do_quad_flow:
        chain_axis = (V6.co - V3.co)  # long chain direction
        align_along_axis(v8, V4, chain_axis)

    bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    # ---- faces requested ----
    bm = bm_refresh()
    select_verts_by_co(bm, [co_v1, v8.co.copy(), co_v4, co_v5])
    bpy.ops.mesh.edge_face_add()

    bm = bm_refresh()
    select_verts_by_co(bm, [co_v1, co_v2, co_v5, co_v6])
    bpy.ops.mesh.edge_face_add()

    # ---- restore original selection ----
    bm = bm_refresh()
    select_edges_by_co(bm, orig_co_pairs)
    bpy.ops.mesh.select_mode(type='EDGE')


class QC_OT_2_to_3_direct_flow_right_connect(Operator):
    bl_idname = "mesh.op_2_to_3_direct_flow_right_connect"
    bl_label = "2 → 3 Direct Flow right Connect"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        try:
            fill_pattern_2_to_3_direct_flow_right_connect(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    bpy.utils.register_class(QC_OT_2_to_3_direct_flow_right_connect)


def unregister():
    bpy.utils.unregister_class(QC_OT_2_to_3_direct_flow_right_connect)