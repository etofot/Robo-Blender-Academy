import bpy
import bmesh
from bpy.types import Operator


def connect_1_to_2_make_middle_edge_then_face_add(context):
    ctx = context
    obj = ctx.edit_object
    if not obj or obj.type != "MESH" or ctx.mode != "EDIT_MESH":
        raise RuntimeError("Must be in Edit Mode on a mesh")

    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()

    sel_edges_all = [e for e in bm.edges if e.select]
    if len(sel_edges_all) < 3:
        raise RuntimeError("Select at least 3 edges (must include 1 solo edge + a 2-edge chain)")

    # ----------------------------
    # Auto-extract: (solo edge) + (2-edge chain)
    # ----------------------------
    sel_edge_count = {}
    for e in sel_edges_all:
        for v in e.verts:
            sel_edge_count[v] = sel_edge_count.get(v, 0) + 1

    shared = None
    chain_edges = None
    for v, c in sel_edge_count.items():
        if c == 2:
            incident = [e for e in sel_edges_all if v in e.verts]
            if len(incident) == 2:
                shared = v
                chain_edges = incident
                break

    if not shared or not chain_edges:
        raise RuntimeError("Could not find a 2-edge chain (two selected edges sharing a middle vertex)")

    chain_verts = set(chain_edges[0].verts) | set(chain_edges[1].verts)

    solo_edge = None
    for e in sel_edges_all:
        if e in chain_edges:
            continue
        a, b = e.verts
        if (a in chain_verts) or (b in chain_verts):
            continue
        if sel_edge_count.get(a, 0) == 1 and sel_edge_count.get(b, 0) == 1:
            solo_edge = e
            break

    if not solo_edge:
        raise RuntimeError("Could not find a solo edge (isolated) not connected to the 2-edge chain")

    v0, v1 = solo_edge.verts
    outer_a = chain_edges[0].other_vert(shared)
    outer_b = chain_edges[1].other_vert(shared)

    # ---- store ORIGINAL vertex indices (safe)
    v0_i, v1_i = v0.index, v1.index
    sh_i = shared.index
    oa_i, ob_i = outer_a.index, outer_b.index

    # ---- store ORIGINAL edges as index pairs (so we can reselect them at the end)
    solo_pair = tuple(sorted((v0_i, v1_i)))
    chain_pair_a = tuple(sorted((sh_i, oa_i)))
    chain_pair_b = tuple(sorted((sh_i, ob_i)))

    # ----------------------------
    # Create edges (v0-shared) and (v1-shared)
    # ----------------------------
    eA = bm.edges.get((bm.verts[v0_i], bm.verts[sh_i])) or bm.edges.new((bm.verts[v0_i], bm.verts[sh_i]))
    eB = bm.edges.get((bm.verts[v1_i], bm.verts[sh_i])) or bm.edges.new((bm.verts[v1_i], bm.verts[sh_i]))

    bm.edges.ensure_lookup_table()

    # ----------------------------
    # Subdivide ONLY these two edges, capture new verts
    # ----------------------------
    res = bmesh.ops.subdivide_edges(
        bm,
        edges=[eA, eB],
        cuts=1,
        use_grid_fill=False
    )

    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()

    new_verts = [g for g in res.get("geom_split", []) if isinstance(g, bmesh.types.BMVert)]
    if len(new_verts) < 2:
        raise RuntimeError("Subdivide did not create the expected midpoint verts")

    # Identify midpoint on (v0-shared) and (v1-shared)
    mid0 = None
    mid1 = None
    for nv in new_verts:
        neigh = {e.other_vert(nv).index for e in nv.link_edges}
        if v0_i in neigh and sh_i in neigh:
            mid0 = nv
        if v1_i in neigh and sh_i in neigh:
            mid1 = nv

    if not mid0 or not mid1:
        raise RuntimeError("Failed to identify the two midpoint verts on the new edges")

    # Create edge between midpoints
    bm.edges.get((mid0, mid1)) or bm.edges.new((mid0, mid1))

    # ----------------------------
    # Select 7 verts and edge_face_add
    # ----------------------------
    bm.verts.ensure_lookup_table()
    v0r = bm.verts[v0_i]
    v1r = bm.verts[v1_i]
    shr = bm.verts[sh_i]
    oar = bm.verts[oa_i]
    obr = bm.verts[ob_i]

    for v in bm.verts:
        v.select = False
    for e in bm.edges:
        e.select = False

    for v in (v0r, v1r, shr, oar, obr, mid0, mid1):
        v.select = True

    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)
    bpy.ops.mesh.select_mode(type='VERT')
    bpy.ops.mesh.edge_face_add()

    # ----------------------------
    # FINAL: HARD deselect → reselect ORIGINAL edges only
    # ----------------------------
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.mesh.select_mode(type='EDGE')

    bm = bmesh.from_edit_mesh(obj.data)
    bm.verts.ensure_lookup_table()
    bm.edges.ensure_lookup_table()

    wanted_pairs = {solo_pair, chain_pair_a, chain_pair_b}

    for e in bm.edges:
        a, b = e.verts[0].index, e.verts[1].index
        if tuple(sorted((a, b))) in wanted_pairs:
            e.select = True

    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)


class QC_OT_1_to_2_middle_connect(Operator):
    bl_idname = "mesh.qc_1_to_2_middle_connect"
    bl_label = "1 → 2 Middle Connect"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        try:
            connect_1_to_2_make_middle_edge_then_face_add(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    bpy.utils.register_class(QC_OT_1_to_2_middle_connect)

def unregister():
    bpy.utils.unregister_class(QC_OT_1_to_2_middle_connect)