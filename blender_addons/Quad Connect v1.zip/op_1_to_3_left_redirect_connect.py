import bpy
import bmesh
from mathutils import Vector
from bpy.types import Operator


def fill_pattern_1_to_3_left_redirect_connect(context):
    obj = context.active_object
    if not obj or obj.type != "MESH" or context.mode != "EDIT_MESH":
        raise RuntimeError("Active object must be a Mesh in Edit Mode.")

    me = obj.data

    def bm_refresh():
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        return bm

    def clear_sel(bm):
        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        for f in bm.faces:
            f.select = False

    def find_vert_by_co(bm, co: Vector):
        best = None
        best_d2 = None
        for v in bm.verts:
            d2 = (v.co - co).length_squared
            if best_d2 is None or d2 < best_d2:
                best = v
                best_d2 = d2
        return best

    def edge_between(v1, v2):
        for e in v1.link_edges:
            if e.other_vert(v1) == v2:
                return e
        return None

    def select_verts_by_co(bm, co_list):
        clear_sel(bm)
        for co in co_list:
            v = find_vert_by_co(bm, co)
            if not v:
                raise RuntimeError("Missing required vert (coord match failed).")
            v.select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def select_edges_by_co(bm, co_pairs):
        clear_sel(bm)
        for coa, cob in co_pairs:
            va = find_vert_by_co(bm, coa)
            vb = find_vert_by_co(bm, cob)
            if not va or not vb:
                raise RuntimeError("Missing required vert (coord match failed).")
            e = edge_between(va, vb)
            if not e:
                raise RuntimeError("Missing required edge.")
            e.select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def selected_edges_as_pairs(bm):
        out = []
        for e in bm.edges:
            if e.select and e.is_valid:
                out.append((e.verts[0], e.verts[1]))
        return out

    def build_adj_from_edges(edge_pairs):
        adj = {}
        for a, b in edge_pairs:
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        return adj

    def components_from_verts(verts, adj):
        seen, comps = set(), []
        for v in verts:
            if v in seen:
                continue
            stack = [v]
            comp = set()
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur)
                comp.add(cur)
                for nb in adj.get(cur, ()):
                    if nb not in seen:
                        stack.append(nb)
            comps.append(comp)
        return comps

    def order_chain(chain_set, adj, expected_count):
        deg = {v: sum(1 for nb in adj.get(v, ()) if nb in chain_set) for v in chain_set}
        ends = [v for v, d in deg.items() if d == 1]
        if len(ends) != 2:
            raise RuntimeError("Chain must be a simple path (2 ends).")

        def walk(start):
            out = [start]
            prev = None
            cur = start
            while len(out) < expected_count:
                nbs = [nb for nb in adj.get(cur, ()) if nb in chain_set and nb != prev]
                if not nbs:
                    break
                prev, cur = cur, nbs[0]
                out.append(cur)
            return out

        w = walk(ends[0])
        if len(w) != expected_count:
            w = walk(ends[1])
        if len(w) != expected_count:
            raise RuntimeError(f"Failed to order a {expected_count}-vertex chain.")
        return w

    # -------- Detect pattern from selection --------
    bm = bm_refresh()
    sel_edge_pairs = selected_edges_as_pairs(bm)
    if len(sel_edge_pairs) != 4:
        raise RuntimeError(
            f"Select exactly 4 edges (1 single edge + 3-edge chain). Got {len(sel_edge_pairs)}."
        )

    orig_co_pairs = [(va.co.copy(), vb.co.copy()) for va, vb in sel_edge_pairs]

    adj = build_adj_from_edges(sel_edge_pairs)
    sel_verts = set(adj.keys())
    comps = components_from_verts(sel_verts, adj)

    comp2 = [c for c in comps if len(c) == 2]  # single edge
    comp4 = [c for c in comps if len(c) == 4]  # 3 edges => 4 verts
    if len(comp2) != 1 or len(comp4) != 1:
        raise RuntimeError("Selection must be: 1 single edge (2 verts) + 1 chain (4 verts).")

    # Single edge verts
    e2_verts = list(comp2[0])
    if len(e2_verts) != 2:
        raise RuntimeError("Internal error: single edge component not 2 verts.")
    sA, sB = e2_verts[0], e2_verts[1]

    # Long chain ordered
    L = order_chain(comp4[0], adj, expected_count=4)

    # ---- Fix orientation to avoid inversion ----
    # Pick long-chain direction that best matches sA->L0 and sB->L3 (or swapped).
    def orient_score(sa, sb, Lseq):
        return (sa.co - Lseq[0].co).length + (sb.co - Lseq[3].co).length

    L_fwd = L
    L_rev = list(reversed(L))

    # choose best pairing for (sA,sB) and also allow swapping sA/sB
    candidates = []
    candidates.append((orient_score(sA, sB, L_fwd), sA, sB, L_fwd))
    candidates.append((orient_score(sA, sB, L_rev), sA, sB, L_rev))
    candidates.append((orient_score(sB, sA, L_fwd), sB, sA, L_fwd))
    candidates.append((orient_score(sB, sA, L_rev), sB, sA, L_rev))
    candidates.sort(key=lambda x: x[0])

    _, v0, v1, L = candidates[0]
    v2, v3, v4, v5 = L  # now stable direction

    co_v0, co_v1 = v0.co.copy(), v1.co.copy()
    co_v2, co_v3, co_v4, co_v5 = v2.co.copy(), v3.co.copy(), v4.co.copy(), v5.co.copy()

    # -------- Create faces (exactly as requested) --------
    bm = bm_refresh()
    select_verts_by_co(bm, [co_v0, co_v2, co_v3, co_v4])
    bpy.ops.mesh.edge_face_add()

    bm = bm_refresh()
    select_verts_by_co(bm, [co_v0, co_v1, co_v4, co_v5])
    bpy.ops.mesh.edge_face_add()

    # ---- restore original selection ----
    bm = bm_refresh()
    select_edges_by_co(bm, orig_co_pairs)
    bpy.ops.mesh.select_mode(type='EDGE')


class QC_OT_1_to_3_left_redirect_connect(Operator):
    bl_idname = "mesh.op_1_to_3_left_redirect_connect"
    bl_label = "1 → 3 Left Redirect Connect"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        try:
            fill_pattern_1_to_3_left_redirect_connect(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    bpy.utils.register_class(QC_OT_1_to_3_left_redirect_connect)


def unregister():
    bpy.utils.unregister_class(QC_OT_1_to_3_left_redirect_connect)