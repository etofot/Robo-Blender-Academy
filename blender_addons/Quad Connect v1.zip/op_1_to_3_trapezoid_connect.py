import bpy
import bmesh
from mathutils import Vector
from bpy.types import Operator


def qc_1_to_3_linear(context):
    obj = context.active_object
    if not obj or obj.type != "MESH" or context.mode != "EDIT_MESH":
        raise RuntimeError("Active object must be a Mesh in Edit Mode.")

    me = obj.data

    # --------------------------------------------------
    # Quad Flow toggle (align cuts ALONG the 3-edge chain axis)
    # --------------------------------------------------
    do_quad_flow = bool(
        getattr(getattr(context.scene, "quad_connect_props", None), "quad_flow", False)
    )

    def bm_refresh():
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        return bm

    def clear_sel(bm):
        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        for f in bm.faces:
            f.select = False

    def find_vert_by_co(bm, co: Vector, tol=1e-6):
        best = None
        best_d2 = None
        for v in bm.verts:
            d2 = (v.co - co).length_squared
            if best_d2 is None or d2 < best_d2:
                best = v
                best_d2 = d2
        if best is None:
            return None
        # keep nearest as fallback (like your 1->4)
        return best

    def edge_between(v1, v2):
        for e in v1.link_edges:
            if e.other_vert(v1) == v2:
                return e
        return None

    def select_pairs_by_co(bm, co_pairs):
        clear_sel(bm)
        for coa, cob in co_pairs:
            va = find_vert_by_co(bm, coa)
            vb = find_vert_by_co(bm, cob)
            if not va or not vb:
                raise RuntimeError("Missing required vert (coord match failed).")
            e = edge_between(va, vb)
            if not e:
                raise RuntimeError(f"Missing required edge (co-match): {coa} <-> {cob}")
            e.select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def selected_edges_as_pairs(bm):
        out = []
        for e in bm.edges:
            if e.select and e.is_valid:
                out.append((e.verts[0], e.verts[1]))
        return out

    def build_adj_from_edges(edge_pairs):
        adj = {}
        for a, b in edge_pairs:
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        return adj

    def components_from_verts(verts, adj):
        seen, comps = set(), []
        for v in verts:
            if v in seen:
                continue
            stack = [v]
            comp = set()
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur)
                comp.add(cur)
                for nb in adj.get(cur, ()):
                    if nb not in seen:
                        stack.append(nb)
            comps.append(comp)
        return comps

    def order_chain_4(chain_set, adj):
        deg = {v: sum(1 for nb in adj.get(v, ()) if nb in chain_set) for v in chain_set}
        ends = [v for v, d in deg.items() if d == 1]
        if len(ends) != 2:
            raise RuntimeError("3-edge chain must be a simple 3-edge path (2 ends).")

        def walk(start):
            out = [start]
            prev = None
            cur = start
            while len(out) < 4:
                nbs = [nb for nb in adj.get(cur, ()) if nb in chain_set and nb != prev]
                if not nbs:
                    break
                prev, cur = cur, nbs[0]
                out.append(cur)
            return out

        w = walk(ends[0])
        if len(w) != 4:
            w = walk(ends[1])
        if len(w) != 4:
            raise RuntimeError("Failed to order the 4 chain vertices.")
        return w  # end0, mid0, mid1, end1

    def neigh_ids(v):
        return {e.other_vert(v).index for e in v.link_edges}

    def safe_norm(v: Vector, eps=1e-12):
        l2 = v.length_squared
        if l2 < eps:
            return None
        return v / (l2 ** 0.5)

    def align_along_axis(move_v, ref_v, axis_dir: Vector):
        ax = safe_norm(axis_dir)
        if ax is None:
            return
        delta = (ref_v.co - move_v.co).dot(ax)
        move_v.co += ax * delta

    def face_add_verts(bm, a, b, c, d):
        clear_sel(bm)
        a.select = b.select = c.select = d.select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)
        if "FINISHED" not in bpy.ops.mesh.edge_face_add():
            raise RuntimeError("edge_face_add failed")

    # ---------- Detect pattern from selection ----------
    bm = bm_refresh()
    sel_edge_pairs = selected_edges_as_pairs(bm)
    if len(sel_edge_pairs) != 4:
        raise RuntimeError(f"Select exactly 4 edges (solo + 3-chain). Got {len(sel_edge_pairs)}.")

    # store original selection as CO pairs (for restoring later)
    orig_co_pairs = [(va.co.copy(), vb.co.copy()) for va, vb in sel_edge_pairs]

    adj = build_adj_from_edges(sel_edge_pairs)
    sel_verts = set(adj.keys())
    comps = components_from_verts(sel_verts, adj)

    comp2 = [c for c in comps if len(c) == 2]
    comp4 = [c for c in comps if len(c) == 4]
    if len(comp2) != 1 or len(comp4) != 1:
        raise RuntimeError("Selection must be: 1 solo edge (2 verts) + 1 chain (4 verts).")

    solo_verts = list(comp2[0])      # 2 BMVerts
    chain_set = comp4[0]             # 4 BMVerts

    end0, mid0, mid1, end1 = order_chain_4(chain_set, adj)

    # The middle edge is (mid0-mid1). We'll bridge SOLO edge with this middle edge.
    # Choose v0 closer to mid0 for stable orientation (doesn't affect topology, just references)
    sA, sB = solo_verts
    if (sB.co - mid0.co).length < (sA.co - mid0.co).length:
        v0, v1 = sB, sA
    else:
        v0, v1 = sA, sB

    # Pin coords so we can refind after ops
    co_v0 = v0.co.copy()
    co_v1 = v1.co.copy()
    co_end0 = end0.co.copy()
    co_mid0 = mid0.co.copy()
    co_mid1 = mid1.co.copy()
    co_end1 = end1.co.copy()

    # ---------- Step 1: Bridge SOLO edge with MID edge (LINEAR) ----------
    bm = bm_refresh()
    select_pairs_by_co(bm, [(co_v0, co_v1), (co_mid0, co_mid1)])

    res = bpy.ops.mesh.bridge_edge_loops(number_cuts=1, interpolation='LINEAR', smoothness=0)
    if "FINISHED" not in res:
        raise RuntimeError("bridge_edge_loops failed")

    bm = bm_refresh()

    # ---------- Step 2: Refind refs + detect the two cut verts ----------
    V0 = find_vert_by_co(bm, co_v0)
    V1 = find_vert_by_co(bm, co_v1)
    END0 = find_vert_by_co(bm, co_end0)
    MID0 = find_vert_by_co(bm, co_mid0)
    MID1 = find_vert_by_co(bm, co_mid1)
    END1 = find_vert_by_co(bm, co_end1)
    if not all([V0, V1, END0, MID0, MID1, END1]):
        raise RuntimeError("Failed to refind required verts after bridge.")

    originals = {V0, V1, END0, MID0, MID1, END1}
    solo_set = {V0.index, V1.index}
    mid_set = {MID0.index, MID1.index}

    cuts = []
    for v in bm.verts:
        if v in originals:
            continue
        n = neigh_ids(v)
        if (n & solo_set) and (n & mid_set):
            cuts.append(v)

    if len(cuts) < 2:
        raise RuntimeError("Could not find cut verts (bridge output not as expected).")

    def closest_to(target, verts):
        best = None
        best_d2 = 1e30
        for v in verts:
            d2 = (v.co - target.co).length_squared
            if d2 < best_d2:
                best_d2 = d2
                best = v
        return best

    cut0 = closest_to(MID0, cuts)
    cut1 = closest_to(MID1, [v for v in cuts if v is not cut0]) or (cuts[1] if cuts[0] is cut0 else cuts[0])

    def touches(v, other):
        return other.index in neigh_ids(v)

    # ---------- Step 3: Optional Quad Flow alignment ALONG chain axis ----------
    if do_quad_flow:
        chain_axis = (END1.co - END0.co)

        # align each cut to the mid it actually touches, sliding along chain axis
        if touches(cut0, MID0):
            align_along_axis(cut0, MID0, chain_axis)
        elif touches(cut0, MID1):
            align_along_axis(cut0, MID1, chain_axis)

        if touches(cut1, MID1):
            align_along_axis(cut1, MID1, chain_axis)
        elif touches(cut1, MID0):
            align_along_axis(cut1, MID0, chain_axis)

        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    # ---------- Step 4: Create the two faces (same approach as your older 1->3) ----------
    bm = bm_refresh()

    def cut_solo(cv):
        n = neigh_ids(cv)
        return V0 if V0.index in n else V1

    # Face A (end0 side): solo - cut0 - (mid0 or mid1) - end0
    face_add_verts(
        bm,
        cut_solo(cut0),
        cut0,
        MID0 if touches(cut0, MID0) else MID1,
        END0
    )

    # refresh + refind (ops can rebuild)
    bm = bm_refresh()
    V0 = find_vert_by_co(bm, co_v0)
    V1 = find_vert_by_co(bm, co_v1)
    END1 = find_vert_by_co(bm, co_end1)
    MID0 = find_vert_by_co(bm, co_mid0)
    MID1 = find_vert_by_co(bm, co_mid1)
    if not all([V0, V1, END1, MID0, MID1]):
        raise RuntimeError("Failed to refind verts after face A.")

    # re-find cut1 by nearest position (cheap + safe)
    cut1 = find_vert_by_co(bm, cut1.co.copy())
    if not cut1:
        raise RuntimeError("Failed to refind cut1 after face A.")

    def cut_solo_2(cv):
        n = neigh_ids(cv)
        return V0 if V0.index in n else V1

    # Face B (end1 side): solo - cut1 - (mid1 or mid0) - end1
    face_add_verts(
        bm,
        cut_solo_2(cut1),
        cut1,
        MID1 if touches(cut1, MID1) else MID0,
        END1
    )

    # ---------- Step 5: restore original edge selection only ----------
    bm = bm_refresh()
    select_pairs_by_co(bm, orig_co_pairs)
    bpy.ops.mesh.select_mode(type='EDGE')


class QC_OT_1_to_3_trapezoid_connect(Operator):
    bl_idname = "mesh.qc_1_to_3_trapezoid_connect"
    bl_label = "1 → 3 Trapezoid Connect (Linear)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        try:
            qc_1_to_3_linear(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    bpy.utils.register_class(QC_OT_1_to_3_trapezoid_connect)

def unregister():
    bpy.utils.unregister_class(QC_OT_1_to_3_trapezoid_connect)
