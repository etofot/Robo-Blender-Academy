import bpy
import bmesh
from bpy.types import Panel, PropertyGroup, Menu
from bpy.props import BoolProperty, PointerProperty

# operator imports...
from .import op_1_to_2_middle_connect
from .import op_1_to_2_right_redirect_connect
from .import op_1_to_2_left_redirect_connect

from .import op_1_to_3_trapezoid_connect
from .import op_1_to_3_right_redirect_connect
from .import op_1_to_3_left_redirect_connect

from .import op_1_to_4_trapezoid_connect

from .import op_2_to_3_left_redirect_connect
from .import op_2_to_3_right_redirect_connect
from .import op_2_to_3_direct_flow_left_connect
from .import op_2_to_3_direct_flow_right_connect

from .import op_2_to_4_trapezoid_connect
from .import op_2_to_4_direct_flow_connect

from .import op_3_to_5_trapezoid_connect
from .import op_3_to_5_direct_flow_connect


bl_info = {
    "name": "3DPRS Quad Connect",
    "author": "Khaled Reez",
    "version": (1, 0, 0),
    "blender": (5, 0, 0),
    "location": "View3D > Sidebar > Edit > Quad Connect",
    "description": "UI-only panel for Quad Connect tools (single Quad Flow toggle) + Pie Menu.",
    "category": "Mesh",
}


# ----------------------------
# Properties
# ----------------------------

class QUADCONNECT_Props(PropertyGroup):
    quad_flow: BoolProperty(
        name="Quad Flow",
        description="Toggle quad-friendly bridge behavior",
        default=True
    )


# ----------------------------
# Helpers
# ----------------------------

def _selected_edge_component_sizes(bm):
    """Return a list of connected-component sizes among selected edges (connectivity by shared verts)."""
    sel = [e for e in bm.edges if e.select]
    if not sel:
        return []

    sel_set = set(sel)
    visited = set()
    sizes = []

    for e0 in sel:
        if e0 in visited:
            continue

        stack = [e0]
        visited.add(e0)
        count = 0

        while stack:
            e = stack.pop()
            count += 1

            # neighbors = other selected edges sharing either vertex with this edge
            for v in e.verts:
                for ne in v.link_edges:
                    if ne in sel_set and ne not in visited:
                        visited.add(ne)
                        stack.append(ne)

        sizes.append(count)

    return sizes

# ----------------------------
# Pie Menu
# ----------------------------

class VIEW3D_MT_quad_connect_pie(Menu):
    bl_label = "Quad Connect"
    bl_idname = "VIEW3D_MT_quad_connect_pie"

    def draw(self, context):
        pie = self.layout.menu_pie()
        props = context.scene.quad_connect_props

        can_run = (
            context.mode == 'EDIT_MESH'
            and context.active_object
            and context.active_object.type == "MESH"
        )

        # Always drive logic from component sizes (NOT total selected edges)
        comp_size = []
        if can_run:
            bm = bmesh.from_edit_mesh(context.active_object.data)
            comp_size = sorted(_selected_edge_component_sizes(bm))  # e.g. [1,2], [2,3], [3,5], etc.

        ops = []

        # 1 → 2 (total 3 edges, split into [1,2])
        if comp_size == [1, 2]:
            ops = [
                (op_1_to_2_left_redirect_connect.QC_OT_1_to_2_left_redirect_connect.bl_idname, "1 → 2 Left Redirect"),
                (op_1_to_2_right_redirect_connect.QC_OT_1_to_2_right_redirect_connect.bl_idname, "1 → 2 Right Redirect"),
                (op_1_to_2_middle_connect.QC_OT_1_to_2_middle_connect.bl_idname, "1 → 2 Middle"), 
            ]

        # 1 → 3 (total 4 edges, split into [1,3])
        elif comp_size == [1, 3]:
            ops = [
                (op_1_to_3_left_redirect_connect.QC_OT_1_to_3_left_redirect_connect.bl_idname, "1 → 3 Left Redirect"),
                (op_1_to_3_right_redirect_connect.QC_OT_1_to_3_right_redirect_connect.bl_idname, "1 → 3 Right Redirect"),
                (op_1_to_3_trapezoid_connect.QC_OT_1_to_3_trapezoid_connect.bl_idname, "1 → 3 Trapezoid"),
            ]

        # 1 → 4 (total 5 edges, split into [1,4])
        elif comp_size == [1, 4]:
            ops = [
                (op_1_to_4_trapezoid_connect.QC_OT_1_to_4_trapezoid_connect.bl_idname, "1 → 4 Trapezoid"),
            ]

        elif comp_size == [2, 3]:
            ops = [
                (op_2_to_3_left_redirect_connect.QC_OT_2_to_3_left_redirect_connect.bl_idname, "2 → 3 Left Redirect"),      # LEFT
                (op_2_to_3_right_redirect_connect.QC_OT_2_to_3_right_redirect_connect.bl_idname, "2 → 3 Right Redirect"),    # RIGHT
                None,                                                                                                         # BOTTOM (empty)
                (op_2_to_3_direct_flow_left_connect.QC_OT_2_to_3_direct_flow_left_connect.bl_idname, "2 → 3 Direct Flow Left Connect"),   # TOP-LEFT
                (op_2_to_3_direct_flow_right_connect.QC_OT_2_to_3_direct_flow_right_connect.bl_idname, "2 → 3 Direct Flow Right Connect"), # TOP-RIGHT
            ]

        # 2 → 4 (total 6 edges, split into [2,4])
        elif comp_size == [2, 4]:
            ops = [
                (op_2_to_4_trapezoid_connect.QC_OT_2_to_4_trapezoid_connect.bl_idname, "2 → 4 Trapezoid"),
                (op_2_to_4_direct_flow_connect.QC_OT_2_to_4_direct_flow_connect.bl_idname, "2 → 4 Direct Flow"),
            ]

        # 3 → 5 (total 8 edges, split into [3,5])
        elif comp_size == [3, 5]:
            ops = [
                (op_3_to_5_trapezoid_connect.QC_OT_3_to_5_trapezoid_connect.bl_idname, "3 → 5 Trapezoid"),
                (op_3_to_5_direct_flow_connect.QC_OT_3_to_5_direct_flow_connect.bl_idname, "3 → 5 Direct Flow"),
            ]

        # Helper: draw an operator if possible, otherwise a label (keeps pie stable)
        def pie_op_or_label(op_tuple):
            if not op_tuple:
                pie.separator()
                return
            bl_idname, text = op_tuple
            if can_run:
                pie.operator(bl_idname, text=text)
            else:
                pie.label(text=text)

        # QUAD FLOW ALWAYS ON TOP (4th slot)
        # Order: LEFT, RIGHT, BOTTOM, TOP, TOP-LEFT, TOP-RIGHT, BOTTOM-LEFT, BOTTOM-RIGHT

        # LEFT
        pie_op_or_label(ops[0] if len(ops) > 0 else None)

        # RIGHT
        pie_op_or_label(ops[1] if len(ops) > 1 else None)

        # BOTTOM
        pie_op_or_label(ops[2] if len(ops) > 2 else None)

        # TOP (Always)
        pie.prop(props, "quad_flow", text="Quad Flow", toggle=True)

        # TOP-LEFT
        pie_op_or_label(ops[3] if len(ops) > 3 else None)

        # TOP-RIGHT
        pie_op_or_label(ops[4] if len(ops) > 4 else None)

        # BOTTOM-LEFT
        pie_op_or_label(ops[5] if len(ops) > 5 else None)

        # BOTTOM-RIGHT
        pie.separator()


"""

# ----------------------------
# Panel
# ----------------------------

class VIEW3D_PT_quad_connect(Panel):
    bl_label = "Quad Connect"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "3DPRS Modeling"


    def draw(self, context):
        layout = self.layout
        props = context.scene.quad_connect_props

        layout.prop(props, "quad_flow",text="Quad Flow Toggle",toggle=True)
        layout.separator()

        can_run = (context.mode == 'EDIT_MESH')
        col = layout.column()
        col.enabled = can_run

        col.operator(
            op_1_to_2_middle_connect.QC_OT_1_to_2_middle_connect.bl_idname,
            text="1 → 2 Middle Connect")

        col.operator(
            op_1_to_2_right_redirect_connect.QC_OT_1_to_2_right_redirect_connect.bl_idname,
            text="1 → 2 Right Redirect Connect")

        col.operator(
            op_1_to_2_left_redirect_connect.QC_OT_1_to_2_left_redirect_connect.bl_idname,
            text="1 → 2 Left Redirect Connect")

        col.operator(
            op_1_to_3_trapezoid_connect.QC_OT_1_to_3_trapezoid_connect.bl_idname,
            text="1 → 3 Trapezoid Connect")

        col.operator(
            op_1_to_4_trapezoid_connect.QC_OT_1_to_4_trapezoid_connect.bl_idname,
            text="1 → 4 Trapezoid Connect")

        col.operator(
            op_2_to_4_trapezoid_connect.QC_OT_2_to_4_trapezoid_connect.bl_idname,
            text="2 → 4 Trapezoid Connect")

        col.operator(
            op_2_to_4_direct_flow_connect.QC_OT_2_to_4_direct_flow_connect.bl_idname,
            text="2 → 4 Direct Flow Connect")

        col.operator(
            op_3_to_5_trapezoid_connect.QC_OT_3_to_5_trapezoid_connect.bl_idname,
            text="3 → 5 Trapezoid Connect")

        col.operator(
            op_3_to_5_direct_flow_connect.QC_OT_3_to_5_direct_flow_connect.bl_idname,
            text="3 → 5 Direct Flow Connect")

"""


# ----------------------------
# Keymap storage + helper (REFERENCE STYLE)
# ----------------------------

addon_keymaps = {}

def find_user_keyconfig(key):
    if key in addon_keymaps:
        km, kmi = addon_keymaps[key]
        user_kc = bpy.context.window_manager.keyconfigs.user
        if not user_kc:
            return None

        user_km = user_kc.keymaps.get(km.name)
        if not user_km:
            return None

        user_keymap_items = user_km.keymap_items

        kmi_properties = set(dir(kmi.properties)) - {'_RNA_UI'}
        for item in user_keymap_items:
            if kmi.idname == item.idname:
                item_properties = set(dir(item.properties)) - {'_RNA_UI'}
                if kmi_properties == item_properties:
                    return item
    return None


# ----------------------------
# Addon Preferences (draw keymap in prefs)
# ----------------------------

class QUADCONNECT_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__ if __package__ else __name__

    def draw(self, context):
        layout = self.layout

        box = layout.box()
        box.label(text="Links", icon="NONE")
        row = box.row()
        row.operator("wm.url_open", text="Behance", icon="URL").url = "https://www.behance.net/3dprs"
        row = box.row()
        row.operator("wm.url_open", text="Blender Market", icon="URL").url = "https://blendermarket.com/creators/3dprs"

        box = layout.box()
        box.label(text="Keymaps", icon="KEYINGSET")

        kmi = find_user_keyconfig("quad_connect_pie_menu")
        if kmi:
            # editable shortcut like your reference
            box.prop(kmi, "type", text="Quad Connect Pie Menu", full_event=True)
        else:
            box.label(text="Pie menu keymap not found (register the addon to create it).", icon="INFO")



# ----------------------------
# Register / Unregister
# ----------------------------

classes = (
    QUADCONNECT_Props,
    QUADCONNECT_AddonPreferences,
    VIEW3D_MT_quad_connect_pie,
    # VIEW3D_PT_quad_connect,
)

def register():
    # register ops modules
    op_1_to_2_middle_connect.register()
    op_1_to_2_right_redirect_connect.register()
    op_1_to_2_left_redirect_connect.register()

    op_1_to_3_trapezoid_connect.register()
    op_1_to_3_left_redirect_connect.register()
    op_1_to_3_right_redirect_connect.register()

    op_1_to_4_trapezoid_connect.register()

    op_2_to_3_left_redirect_connect.register()
    op_2_to_3_right_redirect_connect.register()
    op_2_to_3_direct_flow_left_connect.register()
    op_2_to_3_direct_flow_right_connect.register()

    op_2_to_4_trapezoid_connect.register()
    op_2_to_4_direct_flow_connect.register()

    op_3_to_5_trapezoid_connect.register()
    op_3_to_5_direct_flow_connect.register()

    for c in classes:
        bpy.utils.register_class(c)

    bpy.types.Scene.quad_connect_props = PointerProperty(type=QUADCONNECT_Props)

    # --- Keymap: Shift+Q to call the pie menu ---
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        km = kc.keymaps.new(name="Mesh", space_type="EMPTY")  # Edit Mesh keymap
        kmi = km.keymap_items.new("wm.call_menu_pie", type='Q', value='PRESS', shift=True)
        kmi.properties.name = VIEW3D_MT_quad_connect_pie.bl_idname
        addon_keymaps["quad_connect_pie_menu"] = (km, kmi)

def unregister():
    # remove keymap items
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if kc:
        for km, kmi in addon_keymaps.values():
            try:
                km.keymap_items.remove(kmi)
            except Exception:
                pass
    addon_keymaps.clear()

    if hasattr(bpy.types.Scene, "quad_connect_props"):
        del bpy.types.Scene.quad_connect_props

    for c in reversed(classes):
        bpy.utils.unregister_class(c)

    # unregister ops modules
    op_1_to_2_right_redirect_connect.unregister()
    op_1_to_2_left_redirect_connect.unregister()
    op_1_to_2_middle_connect.unregister()

    op_1_to_3_trapezoid_connect.unregister()
    op_1_to_3_left_redirect_connect.unregister()
    op_1_to_3_right_redirect_connect.unregister()

    op_1_to_4_trapezoid_connect.unregister()

    op_2_to_3_left_redirect_connect.unregister()
    op_2_to_3_right_redirect_connect.unregister()
    op_2_to_3_direct_flow_left_connect.unregister()
    op_2_to_3_direct_flow_right_connect.unregister()

    op_2_to_4_trapezoid_connect.unregister()
    op_2_to_4_direct_flow_connect.unregister()

    op_3_to_5_trapezoid_connect.unregister()
    op_3_to_5_direct_flow_connect.unregister()