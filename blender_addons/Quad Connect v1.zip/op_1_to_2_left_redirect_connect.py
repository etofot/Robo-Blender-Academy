import bpy
import bmesh
from bpy.types import Operator
from bpy.props import BoolProperty


# ------------------------------------------------------------
# Core
# ------------------------------------------------------------

def qc_1edge_to_2edgechain_bridge_then_face(context):
    """
    Selection: exactly 3 boundary edges forming:
      - 1 solo edge: (v0-v1)  (unordered in selection)
      - 2-edge chain: (v2-v3), (v3-v4)  ordered as v2 - v3 - v4

    Steps (your request):
      1) Bridge (solo edge) <-> (v2-v3) with number_cuts=1, interpolation='LINEAR'
         -> creates:
            v5 = cut vert on v2 side (between solo and v2)  [not used in face]
            v6 = cut vert on v3 side (between solo and v3)
         We also FORCE:
            v1 = the solo vertex that connects to v6 (the v3-side cut)
      2) If quad_flow: align v6 to v3 along axis (v4 - v2) using projection method
      3) Face add: select verts (v1, v6, v3, v4) -> edge_face_add()
      4) Restore original edge selection.
    """

    obj = context.edit_object
    if not obj or obj.type != "MESH" or context.mode != "EDIT_MESH":
        raise RuntimeError("Edit Mode mesh required.")

    me = obj.data

    do_quad_flow = bool(
        getattr(getattr(context.scene, "quad_connect_props", None), "quad_flow", False)
    )

    # ----------------------------
    # BMesh helpers
    # ----------------------------
    def bm_refresh():
        bm_ = bmesh.from_edit_mesh(me)
        bm_.verts.ensure_lookup_table()
        bm_.edges.ensure_lookup_table()
        bm_.faces.ensure_lookup_table()
        return bm_

    def bm_update():
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def clear_sel(bm_):
        for v in bm_.verts:
            v.select = False
        for e in bm_.edges:
            e.select = False
        for f in bm_.faces:
            f.select = False

    def edge_between(v1, v2):
        for e in v1.link_edges:
            if e.other_vert(v1) is v2:
                return e
        return None

    def edge_by_vids(bm_, a_i, b_i):
        if a_i == b_i:
            return None
        return edge_between(bm_.verts[a_i], bm_.verts[b_i])

    def select_edges_by_vid_pairs(bm_, vid_pairs):
        clear_sel(bm_)
        bpy.ops.mesh.select_mode(type="EDGE")
        for a_i, b_i in vid_pairs:
            e = edge_by_vids(bm_, a_i, b_i)
            if not e:
                raise RuntimeError(f"Missing required edge ({a_i}-{b_i}). Are these boundary edges?")
            e.select = True
        bm_update()

    def select_verts_by_vids(bm_, vid_list):
        clear_sel(bm_)
        bpy.ops.mesh.select_mode(type="VERT")
        for i in vid_list:
            if i < 0 or i >= len(bm_.verts):
                raise RuntimeError("Vertex index out of range while selecting verts for face add.")
            bm_.verts[i].select = True
        bm_update()

    def selected_edges_vid_pairs(bm_):
        out = []
        for e in bm_.edges:
            if e.is_valid and e.select:
                out.append((e.verts[0].index, e.verts[1].index))
        return out

    def build_adj_from_vid_edges(vid_pairs):
        adj = {}
        for a, b in vid_pairs:
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        return adj

    def components_from_vids(vids, adj):
        seen, comps = set(), []
        for v in vids:
            if v in seen:
                continue
            stack = [v]
            comp = set()
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur)
                comp.add(cur)
                for nb in adj.get(cur, ()):
                    if nb not in seen:
                        stack.append(nb)
            comps.append(comp)
        return comps

    def order_chain_vids(chain_set, adj, n_expected):
        deg = {v: sum(1 for nb in adj.get(v, ()) if nb in chain_set) for v in chain_set}
        ends = [v for v, d in deg.items() if d == 1]
        if len(ends) != 2:
            raise RuntimeError("Chain must be a simple open path (2 ends).")

        def walk(start):
            out = [start]
            prev = None
            cur = start
            while len(out) < n_expected:
                nbs = [nb for nb in adj.get(cur, ()) if nb in chain_set and nb != prev]
                if not nbs:
                    break
                prev, cur = cur, nbs[0]
                out.append(cur)
            return out

        w = walk(ends[0])
        if len(w) != n_expected:
            w = walk(ends[1])
        if len(w) != n_expected:
            raise RuntimeError("Failed to order chain vertices.")
        return w

    def safe_norm(v, eps=1e-12):
        l2 = v.length_squared
        if l2 < eps:
            return None
        return v / (l2 ** 0.5)

    def align_along_axis(move_v, ref_v, axis_dir):
        ax = safe_norm(axis_dir)
        if ax is None:
            return
        delta = (ref_v.co - move_v.co).dot(ax)
        move_v.co += ax * delta

    def common_neighbors(a, b):
        a_n = {e.other_vert(a) for e in a.link_edges if e.is_valid}
        b_n = {e.other_vert(b) for e in b.link_edges if e.is_valid}
        return a_n & b_n

    # ------------------------------------------------------------
    # Detect selection (3 edges -> 1 solo + 2-chain)
    # ------------------------------------------------------------
    bm = bm_refresh()
    sel_pairs = selected_edges_vid_pairs(bm)
    if len(sel_pairs) != 3:
        raise RuntimeError(f"Select exactly 3 edges (1 solo + 2-chain). Got {len(sel_pairs)}.")

    orig_edge_keys = [tuple(sorted(p)) for p in sel_pairs]

    adj = build_adj_from_vid_edges(sel_pairs)
    comps = components_from_vids(set(adj.keys()), adj)

    comp2 = [c for c in comps if len(c) == 2]  # solo edge
    comp3 = [c for c in comps if len(c) == 3]  # 2-edge chain
    if len(comp2) != 1 or len(comp3) != 1:
        raise RuntimeError("Selection must be: 1 solo edge (2 verts) + 2-edge chain (3 verts).")

    solo_a_i, solo_b_i = list(comp2[0])
    v2_i, v3_i, v4_i = order_chain_vids(comp3[0], adj, 3)

    # ------------------------------------------------------------
    # Bridge (solo edge) <-> (v2-v3)
    # ------------------------------------------------------------
    bm = bm_refresh()
    SA = bm.verts[solo_a_i]
    SB = bm.verts[solo_b_i]
    V2 = bm.verts[v2_i]
    V3 = bm.verts[v3_i]

    # store pre-common neighbors for all possible pairings
    pre_a2 = common_neighbors(SA, V2)
    pre_b2 = common_neighbors(SB, V2)
    pre_a3 = common_neighbors(SA, V3)
    pre_b3 = common_neighbors(SB, V3)

    select_edges_by_vid_pairs(bm, [(solo_a_i, solo_b_i), (v2_i, v3_i)])
    bpy.ops.mesh.bridge_edge_loops(number_cuts=1, interpolation="LINEAR")

    bm = bm_refresh()
    SA = bm.verts[solo_a_i]
    SB = bm.verts[solo_b_i]
    V2 = bm.verts[v2_i]
    V3 = bm.verts[v3_i]

    # v5 exists on v2 side (not used for the face, but we keep detection stable)
    new_a2 = list((common_neighbors(SA, V2) - pre_a2))
    new_b2 = list((common_neighbors(SB, V2) - pre_b2))
    v5_cands = list({*new_a2, *new_b2})
    if not v5_cands:
        raise RuntimeError("Bridge did not create the v2-side cut vert (boundary edge issue).")
    v5 = min(v5_cands, key=lambda v: (v.co - V2.co).length_squared)
    v5_i = v5.index  # unused in face, but kept for consistency

    # v6 on v3 side, and determines which solo vert is v1
    new_a3 = list((common_neighbors(SA, V3) - pre_a3))
    new_b3 = list((common_neighbors(SB, V3) - pre_b3))
    if not new_a3 and not new_b3:
        raise RuntimeError("Bridge did not create the v3-side cut vert v6 (boundary edge issue).")

    if new_a3:
        v6 = min(new_a3, key=lambda v: (v.co - V3.co).length_squared)
        v1_i = solo_a_i
        v0_i = solo_b_i
    else:
        v6 = min(new_b3, key=lambda v: (v.co - V3.co).length_squared)
        v1_i = solo_b_i
        v0_i = solo_a_i

    v6_i = v6.index

    # ------------------------------------------------------------
    # Quad Flow alignment: align v6 -> v3 along axis (v4 - v2)
    # ------------------------------------------------------------
    if do_quad_flow:
        bm = bm_refresh()
        axis = bm.verts[v4_i].co - bm.verts[v2_i].co
        align_along_axis(bm.verts[v6_i], bm.verts[v3_i], axis)
        bm_update()

    # ------------------------------------------------------------
    # Face (your exact request): (v1, v6, v3, v4)
    # ------------------------------------------------------------
    bm = bm_refresh()
    select_verts_by_vids(bm, [v1_i, v6_i, v3_i, v4_i])
    bpy.ops.mesh.edge_face_add()

    # ------------------------------------------------------------
    # Restore original edge selection
    # ------------------------------------------------------------
    bm = bm_refresh()
    clear_sel(bm)
    bm_update()

    bm = bm_refresh()
    clear_sel(bm)
    bpy.ops.mesh.select_mode(type="EDGE")
    for a_i, b_i in orig_edge_keys:
        e = edge_by_vids(bm, a_i, b_i)
        if e:
            e.select = True
    bm_update()


# ------------------------------------------------------------
# Operator
# ------------------------------------------------------------

class QC_OT_1_to_2_left_redirect_connect(Operator):
    bl_idname = "mesh.qc_1_to_2_left_redirect_connect"
    bl_label = "1 → 2 Left Redirect Connect"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        obj = context.edit_object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        try:
            qc_1edge_to_2edgechain_bridge_then_face(context)
        except Exception as e:
            self.report({"ERROR"}, str(e))
            return {"CANCELLED"}
        return {"FINISHED"}


def register():
    bpy.utils.register_class(QC_OT_1_to_2_left_redirect_connect)


def unregister():
    bpy.utils.unregister_class(QC_OT_1_to_2_left_redirect_connect)
