import bpy
import bmesh
from mathutils import Vector
from bpy.types import Operator


def fill_pattern_2chain_to_4chain_trapezoid_connect(context):
    obj = context.active_object
    if not obj or obj.type != "MESH" or context.mode != "EDIT_MESH":
        raise RuntimeError("Active object must be a Mesh in Edit Mode.")

    me = obj.data

    # --------------------------------------------------
    # Quad Flow toggle (align along long-chain axis)
    # --------------------------------------------------
    do_quad_flow = bool(
        getattr(getattr(context.scene, "quad_connect_props", None), "quad_flow", False)
    )

    def bm_refresh():
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        return bm

    def clear_sel(bm):
        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        for f in bm.faces:
            f.select = False

    # --------- Robust "find vert by coordinate" ---------
    def find_vert_by_co(bm, co: Vector, tol=1e-6):
        best = None
        best_d2 = None
        for v in bm.verts:
            d2 = (v.co - co).length_squared
            if best_d2 is None or d2 < best_d2:
                best = v
                best_d2 = d2
        if best is None:
            return None
        if best_d2 <= tol * tol:
            return best
        return best  # nearest fallback

    def edge_between(v1, v2):
        for e in v1.link_edges:
            if e.other_vert(v1) == v2:
                return e
        return None

    def select_edges_by_co(bm, co_pairs):
        clear_sel(bm)
        for coa, cob in co_pairs:
            va = find_vert_by_co(bm, coa)
            vb = find_vert_by_co(bm, cob)
            if not va or not vb:
                raise RuntimeError("Missing required vert (coord match failed).")

            e = edge_between(va, vb)
            if not e:
                raise RuntimeError(f"Missing required edge (co-match): {coa} <-> {cob}")
            e.select = True

        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def select_verts_by_co(bm, co_list):
        clear_sel(bm)
        for co in co_list:
            v = find_vert_by_co(bm, co)
            if not v:
                raise RuntimeError("Missing required vert (coord match failed).")
            v.select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def selected_edges_as_pairs(bm):
        out = []
        for e in bm.edges:
            if e.select and e.is_valid:
                out.append((e.verts[0], e.verts[1]))
        return out

    def build_adj_from_edges(edge_pairs):
        adj = {}
        for a, b in edge_pairs:
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        return adj

    def components_from_verts(verts, adj):
        seen, comps = set(), []
        for v in verts:
            if v in seen:
                continue
            stack = [v]
            comp = set()
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur)
                comp.add(cur)
                for nb in adj.get(cur, ()):
                    if nb not in seen:
                        stack.append(nb)
            comps.append(comp)
        return comps

    def order_chain(chain_set, adj, expected_count):
        # expected_count verts in a simple path (expected_count-1 edges)
        deg = {v: sum(1 for nb in adj.get(v, ()) if nb in chain_set) for v in chain_set}
        ends = [v for v, d in deg.items() if d == 1]
        if len(ends) != 2:
            raise RuntimeError("Each chain must be a simple path (2 ends).")

        def walk(start):
            out = [start]
            prev = None
            cur = start
            while len(out) < expected_count:
                nbs = [nb for nb in adj.get(cur, ()) if nb in chain_set and nb != prev]
                if not nbs:
                    break
                prev, cur = cur, nbs[0]
                out.append(cur)
            return out

        w = walk(ends[0])
        if len(w) != expected_count:
            w = walk(ends[1])
        if len(w) != expected_count:
            raise RuntimeError(f"Failed to order a {expected_count}-vertex chain.")
        return w

    # ---------- Detect pattern from selection ----------
    bm = bm_refresh()
    sel_edge_pairs = selected_edges_as_pairs(bm)
    if len(sel_edge_pairs) != 6:
        raise RuntimeError(
            f"Select exactly 6 edges (2-edge chain + 4-edge chain). Got {len(sel_edge_pairs)}."
        )

    # store original selection as CO pairs (for restoring later)
    orig_co_pairs = [(va.co.copy(), vb.co.copy()) for va, vb in sel_edge_pairs]

    adj = build_adj_from_edges(sel_edge_pairs)
    sel_verts = set(adj.keys())
    comps = components_from_verts(sel_verts, adj)

    comp3 = [c for c in comps if len(c) == 3]  # 2 edges
    comp5 = [c for c in comps if len(c) == 5]  # 4 edges
    if len(comp3) != 1 or len(comp5) != 1:
        raise RuntimeError("Selection must be: 1 chain (3 verts / 2 edges) + 1 chain (5 verts / 4 edges).")

    short_set = comp3[0]
    long_set = comp5[0]

    # order them
    S = order_chain(short_set, adj, expected_count=3)   # [s0,s1,s2] (or reversed)
    L = order_chain(long_set, adj, expected_count=5)    # [l0,l1,l2,l3,l4] (or reversed)

    # We want mapping:
    #   s0 <-> l1 (v4)
    #   s1 <-> l2 (v5)
    #   s2 <-> l3 (v6)
    # and ends are l0 (v3) and l4 (v7)
    #
    # Choose best orientation for both chains based on proximity
    def score_mapping(Sseq, Lseq):
        return (
            (Sseq[0].co - Lseq[1].co).length +
            (Sseq[1].co - Lseq[2].co).length +
            (Sseq[2].co - Lseq[3].co).length
        )

    candidates = []
    for Sseq in (S, list(reversed(S))):
        for Lseq in (L, list(reversed(L))):
            candidates.append((score_mapping(Sseq, Lseq), Sseq, Lseq))
    candidates.sort(key=lambda x: x[0])
    _, S, L = candidates[0]

    # Name them like your description:
    # short chain: v0-v1-v2
    v0, v1, v2 = S[0], S[1], S[2]
    # long chain: v3-v4-v5-v6-v7
    v3, v4, v5, v6, v7 = L[0], L[1], L[2], L[3], L[4]

    # Pin by coordinates (so we can refind after ops)
    co_v0 = v0.co.copy()
    co_v1 = v1.co.copy()
    co_v2 = v2.co.copy()

    co_v3 = v3.co.copy()
    co_v4 = v4.co.copy()
    co_v5 = v5.co.copy()
    co_v6 = v6.co.copy()
    co_v7 = v7.co.copy()

    # ---------- Bridge (cuts=1) to create v8,v9,v10 ----------
    bm = bm_refresh()

    # edges to bridge: (v0-v1, v1-v2) and (v4-v5, v5-v6)
    select_edges_by_co(
        bm,
        [(co_v0, co_v1), (co_v1, co_v2), (co_v4, co_v5), (co_v5, co_v6)]
    )

    # expected midpoints where new verts should appear (for matching)
    bm = bm_refresh()
    V0 = find_vert_by_co(bm, co_v0)
    V1 = find_vert_by_co(bm, co_v1)
    V2 = find_vert_by_co(bm, co_v2)
    V4 = find_vert_by_co(bm, co_v4)
    V5 = find_vert_by_co(bm, co_v5)
    V6 = find_vert_by_co(bm, co_v6)
    if not all([V0, V1, V2, V4, V5, V6]):
        raise RuntimeError("Failed to refind required verts before bridge.")

    mid_04 = (V0.co + V4.co) * 0.5
    mid_15 = (V1.co + V5.co) * 0.5
    mid_26 = (V2.co + V6.co) * 0.5

    # SAFE "new verts" detection via quantized key snapshot
    tol = 1e-6

    def qkey(co: Vector, t=tol):
        return (round(co.x / t), round(co.y / t), round(co.z / t))

    old_keys = {qkey(v.co.copy()) for v in bm.verts}

    bpy.ops.mesh.bridge_edge_loops(number_cuts=1, interpolation='LINEAR')

    bm = bm_refresh()
    new_verts = [v for v in bm.verts if qkey(v.co) not in old_keys]
    if len(new_verts) < 3:
        raise RuntimeError("Bridge didn't create the expected cut vertices (need at least 3).")

    v8  = min(new_verts, key=lambda v: (v.co - mid_04).length)  # between 0 and 4
    v9  = min(new_verts, key=lambda v: (v.co - mid_15).length)  # between 1 and 5
    v10 = min(new_verts, key=lambda v: (v.co - mid_26).length)  # between 2 and 6

    # refind long-chain reference verts AFTER bridge
    V3 = find_vert_by_co(bm, co_v3)
    V4 = find_vert_by_co(bm, co_v4)
    V6 = find_vert_by_co(bm, co_v6)
    V7 = find_vert_by_co(bm, co_v7)
    if not all([V3, V4, V6, V7]):
        raise RuntimeError("Failed to refind long-chain reference verts after bridge.")

    def safe_norm(v: Vector, eps=1e-12):
        l2 = v.length_squared
        if l2 < eps:
            return None
        return v / (l2 ** 0.5)

    def align_along_axis(move_v, ref_v, axis_dir: Vector):
        ax = safe_norm(axis_dir)
        if ax is None:
            return
        delta = (ref_v.co - move_v.co).dot(ax)
        move_v.co += ax * delta

    if do_quad_flow:
        chain_axis = (V7.co - V3.co)  # axis along the 4-edge chain (v3->v7)
        align_along_axis(v8, V4, chain_axis)   # align v8 to v4 along chain axis
        align_along_axis(v10, V6, chain_axis)  # align v10 to v6 along chain axis

    bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    # Save new verts by coord for later steps
    co_v8 = v8.co.copy()
    co_v9 = v9.co.copy()
    co_v10 = v10.co.copy()

    # ---------- Create end faces ----------
    # Face A: v0 + v8 + v4 + v3
    bm = bm_refresh()
    select_verts_by_co(bm, [co_v0, co_v8, co_v4, co_v3])
    bpy.ops.mesh.edge_face_add()

    # Face B: v2 + v10 + v6 + v7
    bm = bm_refresh()
    select_verts_by_co(bm, [co_v2, co_v10, co_v6, co_v7])
    bpy.ops.mesh.edge_face_add()

    # ---------- Restore original edge selection ----------
    bm = bm_refresh()
    select_edges_by_co(bm, orig_co_pairs)
    bpy.ops.mesh.select_mode(type='EDGE')


class QC_OT_2_to_4_trapezoid_connect(Operator):
    bl_idname = "mesh.qc_2_to_4_trapezoid_connect"
    bl_label = "2 → 4 Trapezoid Connect"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        try:
            fill_pattern_2chain_to_4chain_trapezoid_connect(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    bpy.utils.register_class(QC_OT_2_to_4_trapezoid_connect)


def unregister():
    bpy.utils.unregister_class(QC_OT_2_to_4_trapezoid_connect)