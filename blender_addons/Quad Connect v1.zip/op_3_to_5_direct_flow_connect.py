import bpy
import bmesh
from mathutils import Vector
from bpy.types import Operator


def fill_pattern_3_to_5_direct_flow_connect(context):
    obj = context.active_object
    if not obj or obj.type != "MESH" or context.mode != "EDIT_MESH":
        raise RuntimeError("Active object must be a Mesh in Edit Mode.")

    me = obj.data

    do_quad_flow = bool(
        getattr(getattr(context.scene, "quad_connect_props", None), "quad_flow", False)
    )

    def bm_refresh():
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        return bm

    def clear_sel(bm):
        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        for f in bm.faces:
            f.select = False

    def find_vert_by_co(bm, co: Vector, tol=1e-6):
        best = None
        best_d2 = None
        for v in bm.verts:
            d2 = (v.co - co).length_squared
            if best_d2 is None or d2 < best_d2:
                best = v
                best_d2 = d2
        return best

    def edge_between(v1, v2):
        for e in v1.link_edges:
            if e.other_vert(v1) == v2:
                return e
        return None

    def select_edges_by_co(bm, co_pairs):
        clear_sel(bm)
        for coa, cob in co_pairs:
            va = find_vert_by_co(bm, coa)
            vb = find_vert_by_co(bm, cob)
            if not va or not vb:
                raise RuntimeError("Missing required vert (coord match failed).")

            e = edge_between(va, vb)
            if not e:
                raise RuntimeError("Missing required edge.")
            e.select = True

        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def select_verts_by_co(bm, co_list):
        clear_sel(bm)
        for co in co_list:
            v = find_vert_by_co(bm, co)
            if not v:
                raise RuntimeError("Missing required vert (coord match failed).")
            v.select = True
        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def selected_edges_as_pairs(bm):
        out = []
        for e in bm.edges:
            if e.select and e.is_valid:
                out.append((e.verts[0], e.verts[1]))
        return out

    def build_adj_from_edges(edge_pairs):
        adj = {}
        for a, b in edge_pairs:
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        return adj

    def components_from_verts(verts, adj):
        seen, comps = set(), []
        for v in verts:
            if v in seen:
                continue
            stack = [v]
            comp = set()
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur)
                comp.add(cur)
                for nb in adj.get(cur, ()):
                    if nb not in seen:
                        stack.append(nb)
            comps.append(comp)
        return comps

    def order_chain(chain_set, adj, expected_count):
        deg = {v: sum(1 for nb in adj.get(v, ()) if nb in chain_set) for v in chain_set}
        ends = [v for v, d in deg.items() if d == 1]
        if len(ends) != 2:
            raise RuntimeError("Each chain must be a simple path (2 ends).")

        def walk(start):
            out = [start]
            prev = None
            cur = start
            while len(out) < expected_count:
                nbs = [nb for nb in adj.get(cur, ()) if nb in chain_set and nb != prev]
                if not nbs:
                    break
                prev, cur = cur, nbs[0]
                out.append(cur)
            return out

        w = walk(ends[0])
        if len(w) != expected_count:
            w = walk(ends[1])
        if len(w) != expected_count:
            raise RuntimeError(f"Failed to order a {expected_count}-vertex chain.")
        return w

    # ---------- Detect pattern from selection ----------
    bm = bm_refresh()
    sel_edge_pairs = selected_edges_as_pairs(bm)
    if len(sel_edge_pairs) != 8:
        raise RuntimeError(
            f"Select exactly 8 edges (3-edge chain + 5-edge chain). Got {len(sel_edge_pairs)}."
        )

    orig_co_pairs = [(va.co.copy(), vb.co.copy()) for va, vb in sel_edge_pairs]

    adj = build_adj_from_edges(sel_edge_pairs)
    sel_verts = set(adj.keys())
    comps = components_from_verts(sel_verts, adj)

    comp4 = [c for c in comps if len(c) == 4]
    comp6 = [c for c in comps if len(c) == 6]
    if len(comp4) != 1 or len(comp6) != 1:
        raise RuntimeError("Selection must be: 1 chain (4 verts) + 1 chain (6 verts).")

    S = order_chain(comp4[0], adj, expected_count=4)
    L = order_chain(comp6[0], adj, expected_count=6)

    def score_mapping(Sseq, Lseq):
        return (
            (Sseq[0].co - Lseq[1].co).length +
            (Sseq[1].co - Lseq[2].co).length +
            (Sseq[2].co - Lseq[3].co).length +
            (Sseq[3].co - Lseq[4].co).length
        )

    candidates = []
    for Sseq in (S, list(reversed(S))):
        for Lseq in (L, list(reversed(L))):
            candidates.append((score_mapping(Sseq, Lseq), Sseq, Lseq))
    candidates.sort(key=lambda x: x[0])
    _, S, L = candidates[0]

    v0, v1, v2, v3 = S
    v4, v5, v6, v7, v8, v9 = L

    co_v0, co_v1, co_v2, co_v3 = v0.co.copy(), v1.co.copy(), v2.co.copy(), v3.co.copy()
    co_v4, co_v5, co_v6, co_v7, co_v8, co_v9 = (
        v4.co.copy(), v5.co.copy(), v6.co.copy(),
        v7.co.copy(), v8.co.copy(), v9.co.copy()
    )

    # ---------------- Bridge #1 ----------------
    bm = bm_refresh()
    V0 = find_vert_by_co(bm, co_v0)
    V1 = find_vert_by_co(bm, co_v1)
    V4 = find_vert_by_co(bm, co_v4)
    V5 = find_vert_by_co(bm, co_v5)

    mid_04 = (V0.co + V4.co) * 0.5
    mid_15 = (V1.co + V5.co) * 0.5

    select_edges_by_co(bm, [(co_v0, co_v1), (co_v4, co_v5)])
    bpy.ops.mesh.bridge_edge_loops(number_cuts=1, interpolation='LINEAR')

    bm = bm_refresh()
    candidates_1 = bm.verts[-2:]
    v10 = min(candidates_1, key=lambda v: (v.co - mid_04).length)
    v11 = min(candidates_1, key=lambda v: (v.co - mid_15).length)

    # ---------------- Bridge #2 ----------------
    bm = bm_refresh()
    V2 = find_vert_by_co(bm, co_v2)
    V3 = find_vert_by_co(bm, co_v3)
    V8 = find_vert_by_co(bm, co_v8)
    V9 = find_vert_by_co(bm, co_v9)

    mid_28 = (V2.co + V8.co) * 0.5
    mid_39 = (V3.co + V9.co) * 0.5

    select_edges_by_co(bm, [(co_v2, co_v3), (co_v8, co_v9)])
    bpy.ops.mesh.bridge_edge_loops(number_cuts=1, interpolation='LINEAR')

    bm = bm_refresh()
    candidates_2 = bm.verts[-2:]
    v12 = min(candidates_2, key=lambda v: (v.co - mid_28).length)
    v13 = min(candidates_2, key=lambda v: (v.co - mid_39).length)

    # ---- quad flow alignment ----
    def safe_norm(v: Vector, eps=1e-12):
        l2 = v.length_squared
        if l2 < eps:
            return None
        return v / (l2 ** 0.5)

    def align_along_axis(move_v, ref_v, axis_dir: Vector):
        ax = safe_norm(axis_dir)
        if ax is None:
            return
        delta = (ref_v.co - move_v.co).dot(ax)
        move_v.co += ax * delta

    if do_quad_flow:
        chain_axis = (V9.co - V4.co)
        align_along_axis(v11, V5, chain_axis)
        align_along_axis(v12, V8, chain_axis)

    bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    co_v11 = v11.co.copy()
    co_v12 = v12.co.copy()

    # ---- faces ----
    bm = bm_refresh()
    select_edges_by_co(bm, [(co_v1, co_v2), (co_v6, co_v7)])
    bpy.ops.mesh.edge_face_add()

    bm = bm_refresh()
    select_verts_by_co(bm, [co_v1, co_v11, co_v5, co_v6])
    bpy.ops.mesh.edge_face_add()

    bm = bm_refresh()
    select_verts_by_co(bm, [co_v2, co_v12, co_v8, co_v7])
    bpy.ops.mesh.edge_face_add()

    # ---- restore original selection ----
    bm = bm_refresh()
    select_edges_by_co(bm, orig_co_pairs)
    bpy.ops.mesh.select_mode(type='EDGE')


class QC_OT_3_to_5_direct_flow_connect(Operator):
    bl_idname = "mesh.qc_3_to_5_direct_flow_connect"
    bl_label = "3 → 5 Direct Flow Connect"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        try:
            fill_pattern_3_to_5_direct_flow_connect(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    bpy.utils.register_class(QC_OT_3_to_5_direct_flow_connect)


def unregister():
    bpy.utils.unregister_class(QC_OT_3_to_5_direct_flow_connect)