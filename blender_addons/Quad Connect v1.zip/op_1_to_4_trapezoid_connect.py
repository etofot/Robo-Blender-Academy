import bpy
import bmesh
from mathutils import Vector
from bpy.types import Operator


def fill_pattern_solo_to_4chain_x_align(context):
    obj = context.active_object
    if not obj or obj.type != "MESH" or context.mode != "EDIT_MESH":
        raise RuntimeError("Active object must be a Mesh in Edit Mode.")

    me = obj.data

    # --------------------------------------------------
    # Quad Flow toggle (now affects alignment along chain axis)
    # --------------------------------------------------
    do_quad_flow = bool(
        getattr(getattr(context.scene, "quad_connect_props", None), "quad_flow", False)
    )

    def bm_refresh():
        bm = bmesh.from_edit_mesh(me)
        bm.verts.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.faces.ensure_lookup_table()
        return bm

    def clear_sel(bm):
        for v in bm.verts:
            v.select = False
        for e in bm.edges:
            e.select = False
        for f in bm.faces:
            f.select = False

    # --------- Robust "find vert by coordinate" ---------
    def find_vert_by_co(bm, co: Vector, tol=1e-6):
        best = None
        best_d2 = None
        for v in bm.verts:
            d2 = (v.co - co).length_squared
            if best_d2 is None or d2 < best_d2:
                best = v
                best_d2 = d2
        if best is None:
            return None
        if best_d2 <= tol * tol:
            return best
        return best  # nearest fallback

    def edge_between(v1, v2):
        for e in v1.link_edges:
            if e.other_vert(v1) == v2:
                return e
        return None

    def edge_exists_by_co(bm, co_a, co_b):
        va = find_vert_by_co(bm, co_a)
        vb = find_vert_by_co(bm, co_b)
        if not va or not vb:
            return False
        return edge_between(va, vb) is not None

    def select_pairs_by_co(bm, co_pairs):
        clear_sel(bm)
        for coa, cob in co_pairs:
            va = find_vert_by_co(bm, coa)
            vb = find_vert_by_co(bm, cob)
            if not va or not vb:
                raise RuntimeError("Missing required vert (coord match failed).")

            e = edge_between(va, vb)
            if not e:
                raise RuntimeError(f"Missing required edge (co-match): {coa} <-> {cob}")
            e.select = True

        bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    def selected_edges_as_pairs(bm):
        out = []
        for e in bm.edges:
            if e.select and e.is_valid:
                out.append((e.verts[0], e.verts[1]))
        return out

    def build_adj_from_edges(edge_pairs):
        adj = {}
        for a, b in edge_pairs:
            adj.setdefault(a, set()).add(b)
            adj.setdefault(b, set()).add(a)
        return adj

    def components_from_verts(verts, adj):
        seen, comps = set(), []
        for v in verts:
            if v in seen:
                continue
            stack = [v]
            comp = set()
            while stack:
                cur = stack.pop()
                if cur in seen:
                    continue
                seen.add(cur)
                comp.add(cur)
                for nb in adj.get(cur, ()):
                    if nb not in seen:
                        stack.append(nb)
            comps.append(comp)
        return comps

    def order_chain_5(chain_set, adj):
        deg = {v: sum(1 for nb in adj.get(v, ()) if nb in chain_set) for v in chain_set}
        ends = [v for v, d in deg.items() if d == 1]
        if len(ends) != 2:
            raise RuntimeError("Chain must be a simple 4-edge path (2 ends).")

        def walk(start):
            out = [start]
            prev = None
            cur = start
            while len(out) < 5:
                nbs = [nb for nb in adj.get(cur, ()) if nb in chain_set and nb != prev]
                if not nbs:
                    break
                prev, cur = cur, nbs[0]
                out.append(cur)
            return out

        w = walk(ends[0])
        if len(w) != 5:
            w = walk(ends[1])
        if len(w) != 5:
            raise RuntimeError("Failed to order the 5 chain vertices.")
        return w

    # ---------- Detect pattern from selection ----------
    bm = bm_refresh()
    sel_edge_pairs = selected_edges_as_pairs(bm)
    if len(sel_edge_pairs) != 5:
        raise RuntimeError(f"Select exactly 5 edges (solo + 4-chain). Got {len(sel_edge_pairs)}.")

    # store original selection as CO pairs (for restoring later)
    orig_co_pairs = [(va.co.copy(), vb.co.copy()) for va, vb in sel_edge_pairs]

    adj = build_adj_from_edges(sel_edge_pairs)
    sel_verts = set(adj.keys())
    comps = components_from_verts(sel_verts, adj)

    comp2 = [c for c in comps if len(c) == 2]
    comp5 = [c for c in comps if len(c) == 5]
    if len(comp2) != 1 or len(comp5) != 1:
        raise RuntimeError("Selection must be: 1 solo edge (2 verts) + 1 chain (5 verts).")

    solo_verts = list(comp2[0])      # 2 BMVerts
    chain_set = comp5[0]             # 5 BMVerts

    # order chain into v2,v3,v4,v5,v6
    v2, v3, v4, v5, v6 = order_chain_5(chain_set, adj)

    # choose v0 closer to v3 for stable orientation
    sA, sB = solo_verts
    if (sB.co - v3.co).length < (sA.co - v3.co).length:
        v0, v1 = sB, sA
    else:
        v0, v1 = sA, sB

    # Pin key verts by coordinate (so we can refind them after ops)
    co_v0 = v0.co.copy()
    co_v1 = v1.co.copy()
    co_v2 = v2.co.copy()
    co_v3 = v3.co.copy()
    co_v4 = v4.co.copy()
    co_v5 = v5.co.copy()
    co_v6 = v6.co.copy()

    # ---------- Step 1 ----------
    bm = bm_refresh()
    select_pairs_by_co(bm, [(co_v0, co_v1), (co_v3, co_v4), (co_v4, co_v5)])
    bpy.ops.mesh.edge_face_add()
    bm = bm_refresh()

    if not edge_exists_by_co(bm, co_v0, co_v3) or not edge_exists_by_co(bm, co_v1, co_v5):
        raise RuntimeError("edge_face_add didn't create (v0-v3) and (v1-v5). Topology may be incompatible.")

    # ---------- Step 2 (subdivide + optional align ALONG CHAIN) ----------
    bm = bm_refresh()
    V0 = find_vert_by_co(bm, co_v0)
    V1 = find_vert_by_co(bm, co_v1)
    V2 = find_vert_by_co(bm, co_v2)
    V3 = find_vert_by_co(bm, co_v3)
    V5 = find_vert_by_co(bm, co_v5)
    V6 = find_vert_by_co(bm, co_v6)
    if not all([V0, V1, V2, V3, V5, V6]):
        raise RuntimeError("Failed to refind required verts after Step 1.")

    mid03 = (V0.co + V3.co) * 0.5
    mid15 = (V1.co + V5.co) * 0.5

    # --- SAFE "new verts" detection (no BMVert refs stored) ---
    tol = 1e-6

    def qkey(co: Vector, t=tol):
        return (round(co.x / t), round(co.y / t), round(co.z / t))

    old_keys = {qkey(v.co.copy()) for v in bm.verts}

    select_pairs_by_co(bm, [(co_v0, co_v3), (co_v1, co_v5)])
    bpy.ops.mesh.subdivide(number_cuts=1)

    # refresh AFTER op
    bm = bm_refresh()

    new_verts = [v for v in bm.verts if qkey(v.co) not in old_keys]
    if len(new_verts) < 2:
        raise RuntimeError("Subdivide didn't create the expected 2 vertices.")

    v7 = min(new_verts, key=lambda v: (v.co - mid03).length)
    v8 = min(new_verts, key=lambda v: (v.co - mid15).length)

    # IMPORTANT: refind reference verts AFTER subdivide (old BMVerts are invalid now)
    V2 = find_vert_by_co(bm, co_v2)
    V3 = find_vert_by_co(bm, co_v3)
    V5 = find_vert_by_co(bm, co_v5)
    V6 = find_vert_by_co(bm, co_v6)
    if not all([V2, V3, V5, V6]):
        raise RuntimeError("Failed to refind chain reference verts after subdivide.")

    def safe_norm(v: Vector, eps=1e-12):
        l2 = v.length_squared
        if l2 < eps:
            return None
        return v / (l2 ** 0.5)

    def align_along_axis(move_v, ref_v, axis_dir: Vector):
        ax = safe_norm(axis_dir)
        if ax is None:
            return
        delta = (ref_v.co - move_v.co).dot(ax)
        move_v.co += ax * delta

    if do_quad_flow:
        chain_axis = (V6.co - V2.co)  # axis parallel to the 4-chain (v2->v6)
        align_along_axis(v7, V3, chain_axis)  # v7 aligns to v3 along chain axis
        align_along_axis(v8, V5, chain_axis)  # v8 aligns to v5 along chain axis

    bmesh.update_edit_mesh(me, loop_triangles=False, destructive=False)

    co_v7 = v7.co.copy()
    co_v8 = v8.co.copy()


    # ---------- Step 3 ----------
    bm = bm_refresh()
    select_pairs_by_co(bm, [(co_v0, co_v7), (co_v7, co_v3), (co_v2, co_v3)])
    bpy.ops.mesh.edge_face_add()

    # ---------- Step 4 ----------
    bm = bm_refresh()
    select_pairs_by_co(bm, [(co_v1, co_v8), (co_v8, co_v5), (co_v5, co_v6)])
    bpy.ops.mesh.edge_face_add()

    # ---------- Step 5: restore original edge selection only ----------
    bm = bm_refresh()
    select_pairs_by_co(bm, orig_co_pairs)
    bpy.ops.mesh.select_mode(type='EDGE')


class QC_OT_1_to_4_trapezoid_connect(Operator):
    bl_idname = "mesh.qc_1_to_4_trapezoid_connect"
    bl_label = "1 → 4 Trapezoid Connect"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == "MESH" and context.mode == "EDIT_MESH"

    def execute(self, context):
        try:
            fill_pattern_solo_to_4chain_x_align(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}


def register():
    bpy.utils.register_class(QC_OT_1_to_4_trapezoid_connect)

def unregister():
    bpy.utils.unregister_class(QC_OT_1_to_4_trapezoid_connect)